# Mushroom Pet Pet Passive Abilities
# - Fungal Growth: Max health (20.5 → 24.0)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.mushroom

# Fungal Growth: Max health (20.5 → 24.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s max_health base set 20.606
execute if score #value companion.calc matches 8..12 run return run attribute @s max_health base set 20.818
execute if score #value companion.calc matches 13..17 run return run attribute @s max_health base set 20.995
execute if score #value companion.calc matches 18..22 run return run attribute @s max_health base set 21.172
execute if score #value companion.calc matches 23..27 run return run attribute @s max_health base set 21.348
execute if score #value companion.calc matches 28..32 run return run attribute @s max_health base set 21.525
execute if score #value companion.calc matches 33..37 run return run attribute @s max_health base set 21.702
execute if score #value companion.calc matches 38..42 run return run attribute @s max_health base set 21.879
execute if score #value companion.calc matches 43..47 run return run attribute @s max_health base set 22.056
execute if score #value companion.calc matches 48..52 run return run attribute @s max_health base set 22.232
execute if score #value companion.calc matches 53..57 run return run attribute @s max_health base set 22.409
execute if score #value companion.calc matches 58..62 run return run attribute @s max_health base set 22.586
execute if score #value companion.calc matches 63..67 run return run attribute @s max_health base set 22.763
execute if score #value companion.calc matches 68..72 run return run attribute @s max_health base set 22.939
execute if score #value companion.calc matches 73..77 run return run attribute @s max_health base set 23.116
execute if score #value companion.calc matches 78..82 run return run attribute @s max_health base set 23.293
execute if score #value companion.calc matches 83..87 run return run attribute @s max_health base set 23.47
execute if score #value companion.calc matches 88..92 run return run attribute @s max_health base set 23.646
execute if score #value companion.calc matches 93..97 run return run attribute @s max_health base set 23.823
execute if score #value companion.calc matches 98..100 run return run attribute @s max_health base set 23.965
