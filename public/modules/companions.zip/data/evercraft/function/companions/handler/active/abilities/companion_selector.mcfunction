function evercraft:companions/handler/active/abilities/reset_perks

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[2].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int
scoreboard players operation #current_level companion.exp = #value companion.calc

# Load relationship multiplier (defaults to 100 = 1.0x if not set)
execute as @a[predicate=evercraft:companions/check_id, limit=1] run function evercraft:companions/handler/relationship/load_rp
execute unless score @a[predicate=evercraft:companions/check_id, limit=1] companion.relmult matches 1.. run scoreboard players set #rel_mult companion.calc 100
execute if score @a[predicate=evercraft:companions/check_id, limit=1] companion.relmult matches 1.. run scoreboard players operation #rel_mult companion.calc = @a[predicate=evercraft:companions/check_id, limit=1] companion.relmult

$function evercraft:companions/handler/active/abilities/passive/$(signature)

# Apply relationship multiplier to attack damage attribute
function evercraft:companions/handler/relationship/apply_multiplier