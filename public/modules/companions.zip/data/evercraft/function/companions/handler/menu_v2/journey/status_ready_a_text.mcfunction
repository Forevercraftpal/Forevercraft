# SP5 — Journey: macro — write the Sub-A ready status text. Args: {subname:"..."}.
$data modify entity @n[type=text_display,tag=companion.jr_a_status,distance=..5] text set value [{text:"$(subname)",color:"green"},{text:" — ready to journey",color:"gray"}]
