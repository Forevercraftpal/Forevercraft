# Abyssal Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.abyssal

# Deep Pressure: Submerge mine (0.24 → 1.0)
$execute if score #value companion.calc matches 1..7 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.263 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.309 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.347 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.386 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.424 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.463 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.501 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.539 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.578 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.616 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.655 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.693 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.731 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.77 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.808 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.846 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.885 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.923 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.962 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s submerged_mining_speed modifier add evercraft:home/slot$(ability_slot)/submerged_mining_speed 0.992 add_value
