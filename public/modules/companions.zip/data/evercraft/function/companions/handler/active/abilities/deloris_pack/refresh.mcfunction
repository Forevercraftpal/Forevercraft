# Deloris Pack — Refresh slot displays
# @s = player with pack menu open

execute store result storage evercraft:companions dlpack_temp.pid int 1 run scoreboard players get @s companion.id
function evercraft:companions/handler/active/abilities/deloris_pack/refresh_slots with storage evercraft:companions dlpack_temp
