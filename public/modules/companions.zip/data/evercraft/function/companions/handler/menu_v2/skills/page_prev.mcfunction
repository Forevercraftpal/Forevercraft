# SP5 — Skills: flip to page 1 (companion.skillpage 0) + re-render. Run as player. One-writer = skills/*.
scoreboard players set @s companion.skillpage 0
function evercraft:companions/handler/menu_v2/skills/refresh
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.4 1.6
