scoreboard players operation #Search companion.id = @s companion.id

# --------------------------------------------------------------------------------- #

# OPT: Duplicate companion check — moved from per-tick ai.mcfunction (rare event, 5s is plenty)
execute store result score @s companion.temp if entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id]
execute if score @s companion.temp matches 2.. as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id] run function evercraft:companions/handler/active/remove_duplicates

# Emberheart "Magma Blood": health-gated fire burst (self-gates on <30% HP inside the trigger).
execute as @s[tag=companion.emberheart] at @s run function evercraft:companions/handler/active/abilities/trigger/phoenix_fire

execute as @s[tag=companion.sentinel] as @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id] run return run function evercraft:companions/handler/active/abilities/trigger/red_parrot