# Companion Catalogue - Close
# Kills all menu elements and cleans up tags

# Only proceed if in menu
execute unless entity @s[tag=companion.inmenuv2] run return fail

# Menu Core: Y-displacement close anchor
tag @s remove ec.menu_active
scoreboard players reset @s ec.menu_open_y

# Get player ID for cleanup
scoreboard players operation #Search companion.id = @s companion.id

# Kill all menu elements belonging to this player
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=item_display,tag=companion.menuelement,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=text_display,tag=companion.menuelement,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=companion.menuelement,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp run kill @s
kill @e[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id]

# Kill buddy/summon/training tab content (uses different tag namespace)
execute as @e[tag=bd.tab_content,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp run kill @s

# Remove player tags
tag @s remove companion.inmenuv2
tag @s remove companion.activemenu
tag @s remove companion.infoscreen
tag @s remove hc.placing
tag @s remove gc.placing
tag @s remove companion.assign_sub
# SP3: drop any live win-back offer on menu close (the departed flag persists — re-openable next time).
tag @s remove companion.wb_pending
scoreboard players set @s companion.wb_timer 0

# Reset page
scoreboard players reset @s companion.menupage

# Cleanup orphaned menu elements (from previous broken opens where companion.id was never assigned)
# Kill ALL companion menu entities near the player that match session OR have no session set
execute as @e[type=item_display,tag=companion.menuelement,distance=..10] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=text_display,tag=companion.menuelement,distance=..10] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=companion.menuelement,distance=..10] if score @s adv.gui_session = #gui_check ec.temp run kill @s
# Also kill orphans with NO session set (entities that never got stamped)
execute unless entity @a[tag=companion.inmenuv2,distance=..10] as @e[type=item_display,tag=companion.menuelement,distance=..10] unless score @s adv.gui_session matches 1.. run kill @s
execute unless entity @a[tag=companion.inmenuv2,distance=..10] as @e[type=text_display,tag=companion.menuelement,distance=..10] unless score @s adv.gui_session matches 1.. run kill @s
execute unless entity @a[tag=companion.inmenuv2,distance=..10] as @e[type=interaction,tag=companion.menuelement,distance=..10] unless score @s adv.gui_session matches 1.. run kill @s
# Kill tab content entities that aren't tagged as menuelement (buddy/summon/training tabs)
execute as @e[tag=companion.tab_content,distance=..10] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[tag=bd.tab_content,distance=..10] if score @s adv.gui_session = #gui_check ec.temp run kill @s
# Kill orphaned anchors
execute unless entity @a[tag=companion.inmenuv2,distance=..10] run kill @e[type=marker,tag=companion.menuanchor,distance=..10]

# Play close sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chest.close master @s ~ ~ ~ 0.5 1.2
