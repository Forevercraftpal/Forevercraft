# ============================================================
# Home Companion — Retrieve a companion from home
# Run as: player
# Requires: #hc_retrieve_slot hc.slot = the hc.slot of the companion to retrieve
# ============================================================

scoreboard players operation #Search companion.id = @s companion.id

# Find the HC.Head entity with matching slot and sync RP before removing
execute as @e[type=item_display, tag=HC.Head, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_retrieve_slot hc.slot run function evercraft:companions/handler/home/sync_rp

# Kill all entities for this slot (chicken + head + interaction)
execute as @e[type=chicken, tag=HomeCompanion, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_retrieve_slot hc.slot run kill @s
execute as @e[type=item_display, tag=HC.Head, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_retrieve_slot hc.slot run kill @s
execute as @e[type=interaction, tag=HC.Interact, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_retrieve_slot hc.slot run kill @s

# Remove home:1b flag from the matching Pets[] entry
# We need to find the right Pets[] entry — iterate to find one with home:1b and matching name
# For now, we store the home companion's name to match against
data modify storage evercraft:companions home.retrieve_name set from storage evercraft:companions home.retrieve_item.components."minecraft:profile".properties[{name:"name"}].value

# Remove the HomePets[] entry by filtering — copy all non-matching entries
# Store the slot we're removing
execute store result storage evercraft:companions home.remove_slot int 1 run scoreboard players get #hc_retrieve_slot hc.slot

# Remove from HomePets[] — find entry with matching slot and remove it
function evercraft:companions/handler/home/remove_homepet_entry

# Decrement count
scoreboard players remove @s hc.count 1
execute if score @s hc.count matches ..-1 run scoreboard players set @s hc.count 0

# If player is in home zone, recompute abilities (one fewer companion)
execute if score @s hs.in_zone matches 1 run function evercraft:companions/handler/home/abilities/apply_all

data modify storage evercraft:notify stage.c set value [{text:"Your companion has been retrieved from home.",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 0.5 1.2
