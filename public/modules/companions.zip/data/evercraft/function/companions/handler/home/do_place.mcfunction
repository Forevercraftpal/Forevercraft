# ============================================================
# Home Companion — Execute placement from menu
# Run as: player, Macro: {slot} — MenuDisplay index clicked
# Called from spawn_selected_companion when hc.placing is active
# ============================================================

# Clear placing mode
tag @s remove hc.placing

# Calculate actual Pets[] index accounting for page: (page - 1) * 48 + slot
$scoreboard players set #hc_pets_idx hc.slot $(slot)
scoreboard players operation #hc_page_off hc.slot = @s companion.menupage
scoreboard players remove #hc_page_off hc.slot 1
scoreboard players operation #hc_page_off hc.slot *= #48 companion.calc
scoreboard players operation #hc_pets_idx hc.slot += #hc_page_off hc.slot

# Check this companion isn't already the active pet
execute if entity @s[tag=companion.activepet] store result score #hc_active_check hc.slot run scoreboard players get @s companion.activeslot
data modify storage evercraft:notify stage.c set value [{text:"You can't place your active companion at home. Despawn it first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=companion.activepet] if score #hc_active_check hc.slot = #hc_pets_idx hc.slot run return run function evercraft:util/notify/emit

# Store the computed Pets[] index to storage for the place function
execute store result storage evercraft:companions home.pets_slot int 1 run scoreboard players get #hc_pets_idx hc.slot

# Call the main place function with the Pets[] index
function evercraft:companions/handler/home/place with storage evercraft:companions home

# Close menu after placement
function evercraft:companions/handler/menu_v2/close
