# SP5 — Rename: macro — write the new name into the STORED Pets[$(idx)] record. Run as player.
# Args: {idx:N, name:"..."}. Writes BOTH name fields (D-GUI-7) so display + the profile-immune removal
# path agree: custom_name (what spawn_selected_companion:110 copies to the head) AND custom_data.pet_name
# (the reliable name read at do_remove:14). Because the name lands on the stored Pets[] item, a renamed
# companion KEEPS its name when later removed from the collection.
$execute in overworld run data modify entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[$(idx)].components."minecraft:custom_name" set value {text:"$(name)",color:"gold"}
$execute in overworld run data modify entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[$(idx)].components."minecraft:custom_data".pet_name set value "$(name)"
