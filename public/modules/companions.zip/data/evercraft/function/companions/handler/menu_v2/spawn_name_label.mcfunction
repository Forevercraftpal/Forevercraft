# Spawn a name label above a single pet slot
# Run as the pet item_display entity, at its position

# Copy the pet's custom_name to storage for the summon command
data modify storage evercraft:companions name_label.name set from entity @s item.components."minecraft:custom_name"

# Spawn text_display 0.13 above this entity's position
# Use ^ for relative positioning — entity is already at the slot position
summon text_display ~ ~0.13 ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.petname","companion.menuelement","companion.tab_content"],billboard:"center",background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.159f,0.159f,0.159f]}}

# Set the name text from storage (the custom_name is already a text component)
data modify entity @e[type=text_display,tag=companion.petname,distance=..0.2,limit=1,sort=nearest] text set from storage evercraft:companions name_label.name

# Copy session IDs
scoreboard players operation @e[type=text_display,tag=companion.petname,distance=..0.2,limit=1,sort=nearest] companion.id = @s companion.id
