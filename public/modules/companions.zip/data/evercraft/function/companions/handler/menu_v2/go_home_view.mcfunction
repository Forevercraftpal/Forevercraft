# SP5 — Re-render the home view (3 floating heads + nav). Run as player.
# Called by go_back when returning from the catalogue hub (8) or an SP5 tab (5/6/7), and could be
# called directly to refresh. Sets ec.bd_tab 0, respawns spawn_home, and session-stamps the new elements.

scoreboard players set @s ec.bd_tab 0
scoreboard players operation #Search companion.id = @s companion.id

# Tear down any prior screen before rendering the home view (2026-06-17 bugfix). go_back kills tab content
# BEFORE calling here, but do_assign_sub calls go_home_view DIRECTLY — so without this the open roster grid
# was left on screen and the home view spawned ON TOP of it (Joseph: "the companion list gui stays open and
# the home page spawns on top"). Mirrors go_back:22-30; excludes the permanent frame (menubg/menutitle/
# menuanchor/menuinfo). Redundant-but-harmless when reached via go_back (nothing left to kill).
execute as @e[type=text_display,tag=companion.menuelement,predicate=evercraft:companions/check_id,tag=!companion.menutitle,tag=!companion.menuinfotext] run kill @s
execute as @e[type=interaction,tag=companion.menuelement,predicate=evercraft:companions/check_id,tag=!companion.menuinfoclick] run kill @s
execute as @e[type=item_display,tag=companion.menuelement,predicate=evercraft:companions/check_id,tag=!companion.menubg] run kill @s
execute as @e[tag=bd.buddy_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[tag=bd.summon_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[tag=bd.training_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[tag=bd.tab_content,predicate=evercraft:companions/check_id] run kill @s

# Respawn the home view (anchor-facing to prevent yaw drift).
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet run function evercraft:companions/handler/menu_v2/spawn_home

# Session-stamp the freshly spawned home elements (mirror go_back's old stamp block).
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=item_display,tag=companion.menuelement,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=text_display,tag=companion.menuelement,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=companion.menuelement,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.4
