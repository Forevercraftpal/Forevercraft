# === COMPANION CATALOGUE — PROCESS USE ===
# Run as: player, at player

# Guard: skip if player no longer has catalogue in either hand
execute unless items entity @s weapon.mainhand book[custom_data~{CompanionMenuKey:true}] unless items entity @s weapon.offhand book[custom_data~{CompanionMenuKey:true}] run return 0

# Guard: already in menu
execute if entity @s[tag=companion.inmenuv2] run return 0

# Open the companion catalogue
function evercraft:companions/handler/menu_v2/open
