# ============================================================
# Home Companion — Per-entity passive RP check
# Run as: HomeCompanion item_display entity
# Requires: #now hc.rp_timer = current gametime
# Grants +1 RP if 10 minutes (12000 ticks) have elapsed
# ============================================================

# Initialize timer if not set (e.g., after /reload or migration)
execute unless score @s hc.rp_timer matches 0.. run scoreboard players operation @s hc.rp_timer = #now hc.rp_timer

# Calculate elapsed time
scoreboard players operation #elapsed hc.rp_timer = #now hc.rp_timer
scoreboard players operation #elapsed hc.rp_timer -= @s hc.rp_timer

# Check if 10 minutes (12000 ticks) have passed
execute unless score #elapsed hc.rp_timer matches 12000.. run return fail

# Update timer to now
scoreboard players operation @s hc.rp_timer = #now hc.rp_timer

# Read current RP from entity NBT
data modify storage evercraft:companions math.string set string entity @s item.components."minecraft:profile".properties[{name:"relationship"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

# Add 1 RP, cap at 5000
scoreboard players add #value companion.calc 1
execute if score #value companion.calc > #5000 companion.calc run return fail

# Save back to entity
function evercraft:companions/handler/math/int_to_string
data modify entity @s item.components."minecraft:profile".properties[{name:"relationship"}].value set from storage evercraft:companions math.string

# Sync to marker storage (HomePets[] and Pets[])
function evercraft:companions/handler/home/sync_rp
