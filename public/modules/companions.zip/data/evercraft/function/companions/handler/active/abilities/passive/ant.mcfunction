# Pixie Pet Passive Abilities
# - Pixie Dust: Scale (0.975 → 0.5)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.pixie

# Pixie Dust: Scale (0.975 → 0.5)
execute if score #value companion.calc matches 1..7 run return run attribute @s scale base set 0.961
execute if score #value companion.calc matches 8..12 run return run attribute @s scale base set 0.932
execute if score #value companion.calc matches 13..17 run return run attribute @s scale base set 0.908
execute if score #value companion.calc matches 18..22 run return run attribute @s scale base set 0.884
execute if score #value companion.calc matches 23..27 run return run attribute @s scale base set 0.86
execute if score #value companion.calc matches 28..32 run return run attribute @s scale base set 0.836
execute if score #value companion.calc matches 33..37 run return run attribute @s scale base set 0.812
execute if score #value companion.calc matches 38..42 run return run attribute @s scale base set 0.788
execute if score #value companion.calc matches 43..47 run return run attribute @s scale base set 0.764
execute if score #value companion.calc matches 48..52 run return run attribute @s scale base set 0.74
execute if score #value companion.calc matches 53..57 run return run attribute @s scale base set 0.716
execute if score #value companion.calc matches 58..62 run return run attribute @s scale base set 0.692
execute if score #value companion.calc matches 63..67 run return run attribute @s scale base set 0.668
execute if score #value companion.calc matches 68..72 run return run attribute @s scale base set 0.644
execute if score #value companion.calc matches 73..77 run return run attribute @s scale base set 0.62
execute if score #value companion.calc matches 78..82 run return run attribute @s scale base set 0.596
execute if score #value companion.calc matches 83..87 run return run attribute @s scale base set 0.572
execute if score #value companion.calc matches 88..92 run return run attribute @s scale base set 0.548
execute if score #value companion.calc matches 93..97 run return run attribute @s scale base set 0.524
execute if score #value companion.calc matches 98..100 run return run attribute @s scale base set 0.505
