# SP5 — Care: focus the PREVIOUS owned companion. Run as player (on target from click_care).
# Cycles companion.careidx down across [0, count-1] with wrap. One-writer = care/*.

scoreboard players remove @s companion.careidx 1
# Wrap below 0 → last roster index (count-1). #cc_last = count-1, floored at 0.
scoreboard players operation #cc_last companion.menu = @s companion.count
scoreboard players remove #cc_last companion.menu 1
execute if score #cc_last companion.menu matches ..-1 run scoreboard players set #cc_last companion.menu 0
execute if score @s companion.careidx matches ..-1 run scoreboard players operation @s companion.careidx = #cc_last companion.menu
function evercraft:companions/handler/menu_v2/care/refresh
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.4 1.6
