# SP5 — Edge note: the very first companion (Pets[0]) is the empty-slot sentinel in the sub encoding,
# so it can't be sent on a journey. Run as player from do_assign_sub when the picked index resolves to 0.
data modify storage evercraft:notify stage.c set value [{text:"Your first companion can't be sent on a journey — pick another.",color:"red"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
