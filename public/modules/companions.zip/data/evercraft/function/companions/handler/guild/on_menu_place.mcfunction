# ============================================================
# Guild Companion — Handle "Place at Guild" button click
# Run as: companion.menuguildclick interaction entity
# ============================================================

data remove entity @s interaction

# Find the owner
scoreboard players operation #Search companion.id = @s companion.id
execute as @a[tag=companion.inmenuv2, predicate=evercraft:companions/check_id, limit=1] run function evercraft:companions/handler/guild/toggle_place_mode
