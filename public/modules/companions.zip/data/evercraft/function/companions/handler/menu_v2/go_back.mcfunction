# Return one level up from any sub-page.
# Run as player (@s = player, guaranteed by tick's flag pattern).
#
# Tab tree (2026-06-06 — hub is the landing again; home view demoted to a sub-page):
#   8  = catalogue hub (4 buttons)   ← LANDING (root; no Back button)
#   0  = home view (3 heads)         ← reached from the hub's top-left "Companions"
#   1  = roster grid (all pets)      ← reached from the home view's "Companions" nav
#   2-4 = Buddy / Summon / Training   ← reached from the hub
#   5/6/7 = Care / Journey / Skills   ← reached from the home view
#   9  = Wayfarer Track (SP8)         ← reached from the home view banner
# Back routing:
#   from the home view (0) or a hub sub-tab (Buddy/Summon/Training 2-4) → catalogue hub (8)
#   from the roster grid (1) or an SP5/SP8 tab (Care/Journey/Skills/Wayfarer 5/6/7/9) → home view (0)

scoreboard players operation #Search companion.id = @s companion.id

# Capture the tab we are leaving BEFORE any kills (the tab score is on the player, untouched by kills).
scoreboard players operation #cc_fromtab ec.temp = @s ec.bd_tab

# Kill ALL tab content — everything tagged companion.menuelement EXCEPT the permanent frame.
# Permanent frame: menubg, menutitle, menuanchor, menuinfotext/click.
execute as @e[type=text_display,tag=companion.menuelement,predicate=evercraft:companions/check_id,tag=!companion.menutitle,tag=!companion.menuinfotext] run kill @s
execute as @e[type=interaction,tag=companion.menuelement,predicate=evercraft:companions/check_id,tag=!companion.menuinfoclick] run kill @s
execute as @e[type=item_display,tag=companion.menuelement,predicate=evercraft:companions/check_id,tag=!companion.menubg] run kill @s

# Also kill buddy-specific content (bd.* tags without companion.menuelement).
execute as @e[tag=bd.buddy_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[tag=bd.summon_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[tag=bd.training_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[tag=bd.tab_content,predicate=evercraft:companions/check_id] run kill @s

# === Route 1: from the home view (0) or a hub sub-tab Buddy/Summon/Training (2-4) → catalogue hub (8) ===
execute if score #cc_fromtab ec.temp matches 0 run return run function evercraft:companions/handler/menu_v2/open_catalogue_hub
execute if score #cc_fromtab ec.temp matches 2..4 run return run function evercraft:companions/handler/menu_v2/open_catalogue_hub

# === Route 2: from the roster grid (1) or an SP5/SP8 tab (Care/Journey/Skills/Wayfarer 5/6/7/9) → home (0) ===
function evercraft:companions/handler/menu_v2/go_home_view
