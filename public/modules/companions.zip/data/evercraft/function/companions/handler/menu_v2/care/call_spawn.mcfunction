# SP5 — Macro: summon the focused companion as MAIN via the canonical spawn path. Run as player.
# Args: {relslot:N} = page-relative slot (companion.menupage already set, MenuDisplay loaded by call).
$function evercraft:companions/handler/menu_v2/spawn_selected_companion {slot:$(relslot)}
