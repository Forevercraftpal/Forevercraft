# Write synced memories back to companion.marker at the correct slot index
# Run as: companion.marker entity at 0 -60 0
# Args: $(slot_index) = int index from storage evercraft:companions sync.slot_index
#       $(memories) not used directly — reads from storage
# Called via: function ... with storage evercraft:companions sync

$data modify entity @s data.Pets[$(slot_index)].components."minecraft:profile".properties[{name:"memories"}].value set from storage evercraft:companions sync.memories
