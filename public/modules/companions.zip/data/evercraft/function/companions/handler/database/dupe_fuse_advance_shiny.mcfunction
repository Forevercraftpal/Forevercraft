# Macro {pet_name, fuse, cap}: write fuse_count on the owned record (SHINY filter) + notify.
# SHINY incoming: shiny-filtered selector form so it fuses the shiny record specifically (mirrors the
# shiny ownership probe in check_duplicates). A held normal + its shiny are distinct keepers.
# Display name comes from the incoming item's custom_name (interpret:true) — correct for every species.
$execute in overworld run data modify entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(pet_name)",shiny:1b}}}].components."minecraft:custom_data".fuse_count set value $(fuse)

# Live-refresh (2026-06-10): if the fused SHINY is the player's currently-ACTIVE pet (shiny-filtered
# match, mirroring the DB write above), update the live head's copy + the owner's companion.fuse cache —
# fixes the stale-until-resummon gap for whistle/horn/flavor reads.
scoreboard players operation #Search companion.id = @s companion.id
$execute if entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1,nbt={item:{components:{"minecraft:custom_data":{pet_name:"$(pet_name)",shiny:1b}}}}] run data modify entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:custom_data".fuse_count set value $(fuse)
$execute if entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1,nbt={item:{components:{"minecraft:custom_data":{pet_name:"$(pet_name)",shiny:1b}}}}] run scoreboard players set @s companion.fuse $(fuse)

$data modify storage evercraft:notify stage.c set value [{text:"⚒ ",color:"yellow"},{nbt:"generatedItem.components.\"minecraft:custom_name\"",storage:"evercraft:companions",interpret:true,color:"aqua"},{text:" fused — ",color:"gray"},{text:"+$(fuse)% power",color:"yellow"},{text:" (",color:"gray"},{text:"$(fuse)/$(cap)",color:"yellow"},{text:")",color:"gray"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
# One-time "fully fused" gray note when this dupe hit the cap exactly.
$execute if score #df_fuse ec.temp matches $(cap) run data modify storage evercraft:notify stage.c set value [{nbt:"generatedItem.components.\"minecraft:custom_name\"",storage:"evercraft:companions",interpret:true,color:"dark_gray"},{text:" is fully fused ($(cap)/$(cap))",color:"dark_gray"}]
execute if score #df_fuse ec.temp >= #df_cap ec.var run scoreboard players set #ndur ec.temp 55
execute if score #df_fuse ec.temp >= #df_cap ec.var run function evercraft:util/notify/emit
execute at @s run function evercraft:fx/companion/dupe_fuse
