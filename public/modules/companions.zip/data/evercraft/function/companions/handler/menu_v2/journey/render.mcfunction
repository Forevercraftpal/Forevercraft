# SP5 — Journey: render the journey screen. Run as player, facing-anchor context from open_tab_journey.
# Two sub-slot rows (A/B): assigned companion name + status (idle / "back in ~N min"). A 5-theme picker
# (Forge/Forage/Delve/Tide/Wandering) sets ec.journey_type. Per-slot Send sets companion.jrnyslot then
# ec.journey_send (consumed by the existing journey/dispatch_send → journey/send). Replaces the legacy
# [Send on Expedition] button as the journey entry surface.

scoreboard players operation #Search companion.id = @s companion.id
execute store result score #cc_now ec.temp run time query gametime

# Title.
execute rotated ~ 0 positioned ^ ^1.98 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.jr_title"],billboard:"center",text:[{text:"🧭 Companion Journeys",color:"aqua",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.40f,0.40f,0.40f]}}
scoreboard players operation @e[type=text_display,tag=companion.jr_title,distance=..5] companion.id = @s companion.id

# === Slot A row (Y ~1.70) ===
function evercraft:companions/handler/menu_v2/journey/render_slot_a
# === Slot B row (Y ~1.48) ===
function evercraft:companions/handler/menu_v2/journey/render_slot_b

# === Theme picker (5 buttons) — sets ec.journey_type ===
function evercraft:companions/handler/menu_v2/journey/render_themes

# === Selected-slot indicator (which sub Send will dispatch) ===
execute rotated ~ 0 positioned ^ ^0.78 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.jr_sel"],billboard:"center",background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
function evercraft:companions/handler/menu_v2/journey/render_selected
scoreboard players operation @e[type=text_display,tag=companion.jr_sel,distance=..5] companion.id = @s companion.id

# Back.
function evercraft:companions/handler/menu_v2/spawn_back_btn
