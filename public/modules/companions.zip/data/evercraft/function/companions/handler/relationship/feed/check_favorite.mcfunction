# Check if current food is pet's favorite (2x bonus)
# Doubles #feedRP if favorite

scoreboard players operation #Search companion.id = @s companion.id

# Prowler/Wolf favorites: Meat items
execute if entity @e[type=item_display, tag=companion.prowler, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/any_meat run scoreboard players operation #feedRP companion.calc *= #2 companion.calc
execute if entity @e[type=item_display, tag=companion.wolf, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/any_meat run scoreboard players operation #feedRP companion.calc *= #2 companion.calc

# Glider favorites: Fish
execute if entity @e[type=item_display, tag=companion.glider, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/any_fish run scoreboard players operation #feedRP companion.calc *= #2 companion.calc

# Tidecaller favorites: Tropical fish
execute if entity @e[type=item_display, tag=companion.tidecaller, predicate=evercraft:companions/check_id] if items entity @s weapon.mainhand tropical_fish run scoreboard players operation #feedRP companion.calc *= #2 companion.calc

# Sentinel favorites: Seeds
execute if entity @e[type=item_display, tag=companion.sentinel, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/any_seeds run scoreboard players operation #feedRP companion.calc *= #2 companion.calc

# Bee favorites: Flowers, Honey
execute if entity @e[type=item_display, tag=companion.bee, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/bee_favorites run scoreboard players operation #feedRP companion.calc *= #2 companion.calc

# Undead evercraft:companions/ Rotten flesh, Bones
execute if entity @e[type=item_display, tag=companion.wither, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/undead_favorites run scoreboard players operation #feedRP companion.calc *= #2 companion.calc
execute if entity @e[type=item_display, tag=companion.wraith, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/undead_favorites run scoreboard players operation #feedRP companion.calc *= #2 companion.calc
# Butterfly favorites: Flowers, Honey
execute if entity @e[type=item_display, tag=companion.butterfly, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/bee_favorites run scoreboard players operation #feedRP companion.calc *= #2 companion.calc

# Dragon evercraft:companions/ Blaze powder, Magma cream
execute if entity @e[type=item_display, tag=companion.ashborn, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/dragon_favorites run scoreboard players operation #feedRP companion.calc *= #2 companion.calc
execute if entity @e[type=item_display, tag=companion.endwalker, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/dragon_favorites run scoreboard players operation #feedRP companion.calc *= #2 companion.calc
execute if entity @e[type=item_display, tag=companion.goldendragon, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/dragon_favorites run scoreboard players operation #feedRP companion.calc *= #2 companion.calc

# Aquatic evercraft:companions/ Fish
execute if entity @e[type=item_display, tag=companion.naiad, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/any_fish run scoreboard players operation #feedRP companion.calc *= #2 companion.calc
execute if entity @e[type=item_display, tag=companion.bulwark, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/any_fish run scoreboard players operation #feedRP companion.calc *= #2 companion.calc
execute if entity @e[type=item_display, tag=companion.bramble, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/any_fish run scoreboard players operation #feedRP companion.calc *= #2 companion.calc
execute if entity @e[type=item_display, tag=companion.abyssal, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/any_fish run scoreboard players operation #feedRP companion.calc *= #2 companion.calc
execute if entity @e[type=item_display, tag=companion.leviathan, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/any_fish run scoreboard players operation #feedRP companion.calc *= #2 companion.calc

# Emberheart: Blaze powder
execute if entity @e[type=item_display, tag=companion.emberheart, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/dragon_favorites run scoreboard players operation #feedRP companion.calc *= #2 companion.calc

# Grasshopper: Carrots
execute if entity @e[type=item_display, tag=companion.grasshopper, predicate=evercraft:companions/check_id] if items entity @s weapon.mainhand #minecraft:villager_plantable_seeds run scoreboard players operation #feedRP companion.calc *= #2 companion.calc

# Panther favorites: Meat
execute if entity @e[type=item_display, tag=companion.panther, predicate=evercraft:companions/check_id] if predicate evercraft:companions/food/any_meat run scoreboard players operation #feedRP companion.calc *= #2 companion.calc

# Red Panda favorites: Sweet berries, bamboo
execute if entity @e[type=item_display, tag=companion.red_panda, predicate=evercraft:companions/check_id] if items entity @s weapon.mainhand sweet_berries run scoreboard players operation #feedRP companion.calc *= #2 companion.calc
execute if entity @e[type=item_display, tag=companion.red_panda, predicate=evercraft:companions/check_id] if items entity @s weapon.mainhand bamboo run scoreboard players operation #feedRP companion.calc *= #2 companion.calc

# Cow of Eden favorites: Golden apple, golden carrot
execute if entity @e[type=item_display, tag=companion.cow_of_eden, predicate=evercraft:companions/check_id] if items entity @s weapon.mainhand golden_apple run scoreboard players operation #feedRP companion.calc *= #2 companion.calc
execute if entity @e[type=item_display, tag=companion.cow_of_eden, predicate=evercraft:companions/check_id] if items entity @s weapon.mainhand golden_carrot run scoreboard players operation #feedRP companion.calc *= #2 companion.calc
