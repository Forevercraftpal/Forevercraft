# SP5 — Care: Pet the focused companion. Run as player (on target from click_care).
# focused == active MAIN → the existing do_treat (+5 RP, live entity, cooldown via companion.feedcd).
# focused == a stored companion → pet_stored (writes +5 to the stored Pets[] record).
# Then re-render Care so the RP bar + bond reflect the change.

execute if score #cc_is_main ec.temp matches 1 run function evercraft:companions/handler/menu_v2/do_treat
execute if score #cc_is_main ec.temp matches 0 run function evercraft:companions/handler/menu_v2/care/pet_stored

# Re-render the Care screen (do_treat closes the menu only on a SUMMON path — Pet does not; but to be
# safe, only refresh if the menu is still open at the Care tab).
execute if entity @s[tag=companion.inmenuv2] if score @s ec.bd_tab matches 5 run function evercraft:companions/handler/menu_v2/care/refresh
