# Deloris Pack — Menu Tick (click detection, 2t schedule)
execute unless entity @a[tag=ec.dlpack_in_menu] run return fail
schedule function evercraft:companions/handler/active/abilities/deloris_pack/tick 2t replace

execute as @a[tag=ec.dlpack_in_menu] run function evercraft:companions/handler/active/abilities/deloris_pack/check_clicks
