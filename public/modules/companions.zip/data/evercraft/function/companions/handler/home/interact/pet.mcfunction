# ============================================================
# Home Companion — Pet interaction
# Run as: player, at player position
# +5 RP, 5 minute cooldown (per-pet via hc.petcd on HC.Interact entity)
# ============================================================

# Skip if this specific companion is on cooldown
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=interaction, tag=HC.Interact, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_interact_slot hc.slot run execute if score @s hc.petcd matches 1.. run return fail

# Set cooldown on this companion's interact entity (5 minutes = 6000 ticks)
execute as @e[type=interaction, tag=HC.Interact, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_interact_slot hc.slot run scoreboard players set @s hc.petcd 6000

# Load current RP from home companion
function evercraft:companions/handler/home/interact/load_rp

# Store old level
scoreboard players operation #oldLevel companion.calc = @s companion.rellevel

# Add 5 RP for petting
scoreboard players add @s companion.rp 5

# Cap at 5000
execute if score @s companion.rp > #5000 companion.calc run scoreboard players set @s companion.rp 5000

# Save RP (also syncs to marker)
function evercraft:companions/handler/home/interact/save_rp

# Recalculate level
function evercraft:companions/handler/home/interact/load_rp

# Effects — particles at the home companion's position
execute as @e[type=chicken, tag=HomeCompanion, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_interact_slot hc.slot at @s run particle heart ~ ~0.5 ~ 0.2 0.2 0.2 0 2
execute at @s run function evercraft:util/sfx/pet_chime

# Message
data modify storage evercraft:notify stage.c set value [{text:"You pet your companion! ",color:"white"},{text:"(+5 RP)",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Check for level up
execute unless score @s companion.rellevel = #oldLevel companion.calc run function evercraft:companions/handler/relationship/level_up
