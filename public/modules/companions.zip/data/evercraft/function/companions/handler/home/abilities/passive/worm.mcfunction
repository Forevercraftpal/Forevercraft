# Moldwarp Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.moldwarp

# Earthen Guidance: Mining speed (0.5 → 10.0)
$execute if score #value companion.calc matches 1..7 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 0.788 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 1.364 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 1.843 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 2.323 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 2.803 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 3.283 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 3.763 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 4.242 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 4.722 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 5.202 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 5.682 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 6.162 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 6.641 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 7.121 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 7.601 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 8.081 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 8.561 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 9.04 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 9.52 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s mining_efficiency modifier add evercraft:home/slot$(ability_slot)/mining_efficiency 9.904 add_value

# Treasure Nose: flat Dream Rate / Luck (0.2 → 2.0, Uncommon curve)
$execute if score #value companion.calc matches 1..7 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.2 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.295 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.389 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.484 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.579 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.674 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.768 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.863 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.958 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.053 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.147 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.242 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.337 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.432 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.526 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.621 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.716 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.811 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.905 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2 add_value
