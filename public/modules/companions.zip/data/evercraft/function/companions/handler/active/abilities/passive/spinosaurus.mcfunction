# Titan Pet Passive Abilities
# - Giant's Stature: Scale (1.025 → 1.5)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.titan

# Giant's Stature: Scale (1.025 → 1.5)
execute if score #value companion.calc matches 1..7 run return run attribute @s scale base set 1.039
execute if score #value companion.calc matches 8..12 run return run attribute @s scale base set 1.068
execute if score #value companion.calc matches 13..17 run return run attribute @s scale base set 1.092
execute if score #value companion.calc matches 18..22 run return run attribute @s scale base set 1.116
execute if score #value companion.calc matches 23..27 run return run attribute @s scale base set 1.14
execute if score #value companion.calc matches 28..32 run return run attribute @s scale base set 1.164
execute if score #value companion.calc matches 33..37 run return run attribute @s scale base set 1.188
execute if score #value companion.calc matches 38..42 run return run attribute @s scale base set 1.212
execute if score #value companion.calc matches 43..47 run return run attribute @s scale base set 1.236
execute if score #value companion.calc matches 48..52 run return run attribute @s scale base set 1.26
execute if score #value companion.calc matches 53..57 run return run attribute @s scale base set 1.284
execute if score #value companion.calc matches 58..62 run return run attribute @s scale base set 1.308
execute if score #value companion.calc matches 63..67 run return run attribute @s scale base set 1.332
execute if score #value companion.calc matches 68..72 run return run attribute @s scale base set 1.356
execute if score #value companion.calc matches 73..77 run return run attribute @s scale base set 1.38
execute if score #value companion.calc matches 78..82 run return run attribute @s scale base set 1.404
execute if score #value companion.calc matches 83..87 run return run attribute @s scale base set 1.428
execute if score #value companion.calc matches 88..92 run return run attribute @s scale base set 1.452
execute if score #value companion.calc matches 93..97 run return run attribute @s scale base set 1.476
execute if score #value companion.calc matches 98..100 run return run attribute @s scale base set 1.495
