# Squid Pet Passive Abilities
# - Deep Lungs: O2 bonus (0.5 → 10.0)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.squid

# Deep Lungs: O2 bonus (0.5 → 10.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s oxygen_bonus base set 0.788
execute if score #value companion.calc matches 8..12 run return run attribute @s oxygen_bonus base set 1.364
execute if score #value companion.calc matches 13..17 run return run attribute @s oxygen_bonus base set 1.843
execute if score #value companion.calc matches 18..22 run return run attribute @s oxygen_bonus base set 2.323
execute if score #value companion.calc matches 23..27 run return run attribute @s oxygen_bonus base set 2.803
execute if score #value companion.calc matches 28..32 run return run attribute @s oxygen_bonus base set 3.283
execute if score #value companion.calc matches 33..37 run return run attribute @s oxygen_bonus base set 3.763
execute if score #value companion.calc matches 38..42 run return run attribute @s oxygen_bonus base set 4.242
execute if score #value companion.calc matches 43..47 run return run attribute @s oxygen_bonus base set 4.722
execute if score #value companion.calc matches 48..52 run return run attribute @s oxygen_bonus base set 5.202
execute if score #value companion.calc matches 53..57 run return run attribute @s oxygen_bonus base set 5.682
execute if score #value companion.calc matches 58..62 run return run attribute @s oxygen_bonus base set 6.162
execute if score #value companion.calc matches 63..67 run return run attribute @s oxygen_bonus base set 6.641
execute if score #value companion.calc matches 68..72 run return run attribute @s oxygen_bonus base set 7.121
execute if score #value companion.calc matches 73..77 run return run attribute @s oxygen_bonus base set 7.601
execute if score #value companion.calc matches 78..82 run return run attribute @s oxygen_bonus base set 8.081
execute if score #value companion.calc matches 83..87 run return run attribute @s oxygen_bonus base set 8.561
execute if score #value companion.calc matches 88..92 run return run attribute @s oxygen_bonus base set 9.04
execute if score #value companion.calc matches 93..97 run return run attribute @s oxygen_bonus base set 9.52
execute if score #value companion.calc matches 98..100 run return run attribute @s oxygen_bonus base set 9.904
