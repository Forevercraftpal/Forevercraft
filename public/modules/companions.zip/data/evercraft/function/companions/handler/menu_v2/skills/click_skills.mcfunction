# SP5 — Skills tab click dispatch (ec.bd_tab 7). Run as player in menu. Mirrors check_clicks.
# Slot click → set that slot active (only if unlocked). Page prev/next → flip the pager + re-render.

scoreboard players operation #Search companion.id = @s companion.id

# Is the focused companion the live MAIN? (set_active targets the live item; a stored focus persists
# to the Pets[] record instead.)
scoreboard players set #cc_is_main ec.temp 0
execute if entity @s[tag=companion.activepet] if score @s companion.careidx = @s companion.activeslot run scoreboard players set #cc_is_main ec.temp 1

# === Slot clicks → set active ===
# Read the clicked slot's skillidx, then route. Only one slot can be clicked per tick.
scoreboard players set #cc_clicked ec.temp -1
execute as @e[type=interaction,tag=companion.skill_btn,predicate=evercraft:companions/check_id] if data entity @s interaction run scoreboard players operation #cc_clicked ec.temp = @s companion.skillidx
execute as @e[type=interaction,tag=companion.skill_btn,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction
execute if score #cc_clicked ec.temp matches 0.. run function evercraft:companions/handler/menu_v2/skills/pick_slot

# === Page prev (◀) ===
execute as @e[type=interaction,tag=companion.skill_pageprev_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/skills/page_prev
execute as @e[type=interaction,tag=companion.skill_pageprev_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === Page next (▶) ===
execute as @e[type=interaction,tag=companion.skill_pagenext_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/skills/page_next
execute as @e[type=interaction,tag=companion.skill_pagenext_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === SP8: Eject Chip (live MAIN only) → eject newest chip (-5 lvl, chip returned), then re-render ===
scoreboard players set #cc_eject ec.temp 0
execute as @e[type=interaction,tag=companion.skill_eject_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run scoreboard players set #cc_eject ec.temp 1
execute as @e[type=interaction,tag=companion.skill_eject_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute if score #cc_eject ec.temp matches 1 if score #cc_is_main ec.temp matches 1 run function evercraft:companions/handler/menu_v2/skills/do_eject

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=companion.skill_btn,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Bond Skill",b:"Chooses this bond skill for your companion."}
execute as @e[type=interaction,tag=companion.skill_btn,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.skill_eject_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Eject Skill",b:"Removes the equipped skill from its slot."}
execute as @e[type=interaction,tag=companion.skill_eject_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.skill_pageprev_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous Page",b:"Flips to the previous page of skills."}
execute as @e[type=interaction,tag=companion.skill_pageprev_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.skill_pagenext_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next Page",b:"Flips to the next page of skills."}
execute as @e[type=interaction,tag=companion.skill_pagenext_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
