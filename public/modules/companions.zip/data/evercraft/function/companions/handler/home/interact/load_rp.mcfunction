# ============================================================
# Home Companion — Load RP from home companion entity
# Run as: player
# Requires: #hc_interact_slot hc.slot = target companion's slot
# Sets: companion.rp, companion.rellevel on the player
# ============================================================

scoreboard players operation #Search companion.id = @s companion.id

# Find the HomeCompanion with matching slot and load its RP
# Tag the matching entity temporarily for targeted data read
execute as @e[type=item_display, tag=HC.Head, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_interact_slot hc.slot run tag @s add hc.target

# Check if pet has relationship data, if not initialize it
execute unless data entity @e[type=item_display, tag=hc.target, limit=1] item.components."minecraft:profile".properties[{name:"relationship"}] as @e[type=item_display, tag=hc.target, limit=1] run function evercraft:companions/handler/relationship/init

# Get RP from pet NBT
data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=hc.target, limit=1] item.components."minecraft:profile".properties[{name:"relationship"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int
scoreboard players operation @s companion.rp = #value companion.calc

# Calculate relationship level (0-5)
scoreboard players set @s companion.rellevel 0
execute if score @s companion.rp >= #RelLvl1 companion.calc run scoreboard players set @s companion.rellevel 1
execute if score @s companion.rp >= #RelLvl2 companion.calc run scoreboard players set @s companion.rellevel 2
execute if score @s companion.rp >= #RelLvl3 companion.calc run scoreboard players set @s companion.rellevel 3
execute if score @s companion.rp >= #RelLvl4 companion.calc run scoreboard players set @s companion.rellevel 4
execute if score @s companion.rp >= #RelLvl5 companion.calc run scoreboard players set @s companion.rellevel 5

tag @e[tag=hc.target] remove hc.target
