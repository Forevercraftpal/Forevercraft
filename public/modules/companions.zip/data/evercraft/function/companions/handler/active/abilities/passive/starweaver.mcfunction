# Starweaver Pet Passive Abilities (Mythical — Gacha Exclusive)
# - Constellation Web: 10% chance slow + weaken targets on player hit (handled by on_hit)
# - Stellar Ward: Absorption I permanent
# - Cosmic Thread: Luck 1.0 → 9.0

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.starweaver

# Stellar Ward - Absorption I permanent
effect give @s absorption 13 0 true

# Cosmic Thread - Luck scaling (1.0 → 9.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s luck base set 1.0
execute if score #value companion.calc matches 8..12 run return run attribute @s luck base set 1.421
execute if score #value companion.calc matches 13..17 run return run attribute @s luck base set 1.789
execute if score #value companion.calc matches 18..22 run return run attribute @s luck base set 2.158
execute if score #value companion.calc matches 23..27 run return run attribute @s luck base set 2.526
execute if score #value companion.calc matches 28..32 run return run attribute @s luck base set 2.895
execute if score #value companion.calc matches 33..37 run return run attribute @s luck base set 3.263
execute if score #value companion.calc matches 38..42 run return run attribute @s luck base set 3.632
execute if score #value companion.calc matches 43..47 run return run attribute @s luck base set 4.0
execute if score #value companion.calc matches 48..52 run return run attribute @s luck base set 4.368
execute if score #value companion.calc matches 53..57 run return run attribute @s luck base set 4.737
execute if score #value companion.calc matches 58..62 run return run attribute @s luck base set 5.105
execute if score #value companion.calc matches 63..67 run return run attribute @s luck base set 5.474
execute if score #value companion.calc matches 68..72 run return run attribute @s luck base set 5.842
execute if score #value companion.calc matches 73..77 run return run attribute @s luck base set 6.211
execute if score #value companion.calc matches 78..82 run return run attribute @s luck base set 6.579
execute if score #value companion.calc matches 83..87 run return run attribute @s luck base set 6.947
execute if score #value companion.calc matches 88..92 run return run attribute @s luck base set 7.316
execute if score #value companion.calc matches 93..97 run return run attribute @s luck base set 7.684
execute if score #value companion.calc matches 98..100 run return run attribute @s luck base set 9.0
