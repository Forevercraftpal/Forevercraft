# ============================================================
# Home Companion — Toggle "Place at Home" mode
# Run as: player in menu
# ============================================================

# Validate: player has a home
data modify storage evercraft:notify stage.c set value [{text:"You need a Hearthstone to place companions at home.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s hs.tier matches 1.. run return run function evercraft:util/notify/emit

# Validate: under the 5-companion cap
data modify storage evercraft:notify stage.c set value [{text:"You can only place up to 5 companions at home.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s hc.count matches 5.. run return run function evercraft:util/notify/emit

# Toggle the placing mode
execute if entity @s[tag=hc.placing] run return run function evercraft:companions/handler/home/cancel_place_mode
tag @s add hc.placing

# Cancel guild placing mode if active
execute if entity @s[tag=gc.placing] run function evercraft:companions/handler/guild/cancel_place_mode

# Update button text to show active state
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=text_display, tag=companion.menuhometext, predicate=evercraft:companions/check_id] run data modify entity @s text set value [{text:"\u2302 ",color:"aqua"},{text:"Select Pet",color:"white",bold:true}]

data modify storage evercraft:notify stage.c set value [{text:"Click a companion to place at home.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.6
