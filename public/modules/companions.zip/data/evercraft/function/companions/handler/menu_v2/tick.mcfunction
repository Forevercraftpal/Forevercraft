# Companion Catalogue - Tick
# Called every tick for players with menu open
# Handles: click detection, distance checks
# Menu is STATIONARY — spawned once and stays in place

# Only run for players in menu
execute unless entity @s[tag=companion.inmenuv2] run return fail

scoreboard players operation #Search companion.id = @s companion.id

# SP5: decrement the Care stored-pet anti-spam cooldown while the menu is open (sole decrement site;
# set by care/pet_stored + care/feed_stored). Menu-open existence-gated, so it never runs off-menu.
execute if score @s ec.cc_petcd matches 1.. run scoreboard players remove @s ec.cc_petcd 1

# Close menu if player switches away from Companion Catalogue item
# Also accept eternal/phoenix codex — opens companion menu via codex selector tab 3
# (Item-triggered menu: no distance/timer auto-close needed — item switch handles it)
execute unless items entity @s weapon.mainhand book[custom_data~{CompanionMenuKey:true}] unless items entity @s weapon.mainhand stick[custom_data~{CompanionMenuKey:1b}] unless items entity @s weapon.mainhand warped_fungus_on_a_stick[custom_data~{CompanionMenuKey:1b}] unless items entity @s weapon.mainhand book[custom_data~{eternal_codex:true}] unless items entity @s weapon.mainhand book[custom_data~{phoenix_codex:true}] run return run function evercraft:companions/handler/menu_v2/close

# Safety: if menu anchor is gone (killed by cleanup, chunk issue, etc.), close properly
execute unless entity @e[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] run return run function evercraft:companions/handler/menu_v2/close

# SP3: tick down a live win-back offer (tag-gated — only runs while an offer is latched). At 0 the latch
# drops; the departed flag persists, so clicking the slot again re-opens the offer. Nothing is lost.
execute if entity @s[tag=companion.wb_pending] run scoreboard players remove @s companion.wb_timer 1
execute if entity @s[tag=companion.wb_pending] if score @s companion.wb_timer matches ..0 run tag @s remove companion.wb_pending

# Unified UI-click FX (Joseph 2026-06-05): every companion + buddy menu interaction carries the umbrella
# tag companion.menuelement (ownership via check_id predicate). If ANY registered a click this tick, play
# the gated cue ONCE before the per-tab dispatchers below consume it. One-tick data lifetime guards re-fire.
execute if entity @e[type=interaction,tag=companion.menuelement,predicate=evercraft:companions/check_id,nbt={interaction:{}},limit=1] run function evercraft:fx/ui/click

# === HOME VIEW (SP5): Check head + nav clicks (tab 0 = the new landing) ===
execute if score @s ec.bd_tab matches 0 run function evercraft:companions/handler/menu_v2/click_home

# === CATALOGUE HUB (SP5 tab 8): the old 4-button landing, nested under the home view ===
execute if score @s ec.bd_tab matches 8 run function evercraft:companions/handler/menu_v2/click_hub

# === INFO BUTTON [?]: Check on all pages ===
scoreboard players set #cc_info ec.temp 0
execute as @e[type=interaction,tag=companion.menuinfoclick,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run scoreboard players set #cc_info ec.temp 1
execute as @e[type=interaction,tag=companion.menuinfoclick,predicate=evercraft:companions/check_id,limit=1] run data remove entity @s interaction
execute if score #cc_info ec.temp matches 1 run function evercraft:companions/handler/menu_v2/on_info_click

# === BACK BUTTON: Detect click, clear data, then call go_back AS PLAYER ===
# (go_back needs @s=player for tab switching, hub spawning, etc.)
# Back button present on the home view (0, → hub), the roster grid + Buddy/Summon/Training (1-4),
# and the SP5/SP8 tabs Care/Journey/Skills/Wayfarer (5/6/7/9). NOT on the catalogue hub (8 = root).
scoreboard players set #cc_back ec.temp 0
execute if score @s ec.bd_tab matches 0..9 as @e[type=interaction,tag=companion.back_btn_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run scoreboard players set #cc_back ec.temp 1
execute if score @s ec.bd_tab matches 0..9 as @e[type=interaction,tag=companion.back_btn_click,predicate=evercraft:companions/check_id,limit=1] run data remove entity @s interaction
execute if score #cc_back ec.temp matches 1 run function evercraft:companions/handler/menu_v2/go_back

# === VIEW MEMORIES BUTTON: Detect click on info overlay's memories button ===
scoreboard players set #cc_mem ec.temp 0
execute as @e[type=interaction,tag=companion.mem_btn_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run scoreboard players set #cc_mem ec.temp 1
execute as @e[type=interaction,tag=companion.mem_btn_click,predicate=evercraft:companions/check_id,limit=1] run data remove entity @s interaction
execute if score #cc_mem ec.temp matches 1 run function evercraft:companions/handler/menu_v2/show_memories_chat

# === TAB CONTENT: Check for interactions (clicks) — only on Companions tab ===
execute if score @s ec.bd_tab matches 1 run function evercraft:companions/handler/menu_v2/check_clicks

# === BUDDY/SUMMON/TRAINING TABS: Centralized click detection (tabs 2-4) ===
execute if score @s ec.bd_tab matches 2..4 run function evercraft:buddy/gui/check_tab_clicks

# === SP5 TABS: Care (5) / Journey (6) / Skills (7) click detection ===
execute if score @s ec.bd_tab matches 5 run function evercraft:companions/handler/menu_v2/care/click_care
execute if score @s ec.bd_tab matches 6 run function evercraft:companions/handler/menu_v2/journey/click_journey
execute if score @s ec.bd_tab matches 7 run function evercraft:companions/handler/menu_v2/skills/click_skills

# === SP8 TAB: Wayfarer Track (9) click detection ===
execute if score @s ec.bd_tab matches 9 run function evercraft:companions/handler/menu_v2/wayfarer/click_wayfarer
