# Silverfish Pet Passive Abilities
# - Burrower: Mining speed (0.5 → 8.0)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.silverfish

# Burrower: Mining speed (0.5 → 8.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s mining_efficiency base set 0.727
execute if score #value companion.calc matches 8..12 run return run attribute @s mining_efficiency base set 1.182
execute if score #value companion.calc matches 13..17 run return run attribute @s mining_efficiency base set 1.561
execute if score #value companion.calc matches 18..22 run return run attribute @s mining_efficiency base set 1.939
execute if score #value companion.calc matches 23..27 run return run attribute @s mining_efficiency base set 2.318
execute if score #value companion.calc matches 28..32 run return run attribute @s mining_efficiency base set 2.697
execute if score #value companion.calc matches 33..37 run return run attribute @s mining_efficiency base set 3.076
execute if score #value companion.calc matches 38..42 run return run attribute @s mining_efficiency base set 3.455
execute if score #value companion.calc matches 43..47 run return run attribute @s mining_efficiency base set 3.833
execute if score #value companion.calc matches 48..52 run return run attribute @s mining_efficiency base set 4.212
execute if score #value companion.calc matches 53..57 run return run attribute @s mining_efficiency base set 4.591
execute if score #value companion.calc matches 58..62 run return run attribute @s mining_efficiency base set 4.97
execute if score #value companion.calc matches 63..67 run return run attribute @s mining_efficiency base set 5.348
execute if score #value companion.calc matches 68..72 run return run attribute @s mining_efficiency base set 5.727
execute if score #value companion.calc matches 73..77 run return run attribute @s mining_efficiency base set 6.106
execute if score #value companion.calc matches 78..82 run return run attribute @s mining_efficiency base set 6.485
execute if score #value companion.calc matches 83..87 run return run attribute @s mining_efficiency base set 6.864
execute if score #value companion.calc matches 88..92 run return run attribute @s mining_efficiency base set 7.242
execute if score #value companion.calc matches 93..97 run return run attribute @s mining_efficiency base set 7.621
execute if score #value companion.calc matches 98..100 run return run attribute @s mining_efficiency base set 7.924
