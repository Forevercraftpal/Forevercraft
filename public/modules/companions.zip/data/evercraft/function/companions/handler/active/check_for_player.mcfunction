execute if entity @s[tag=companion.hidden] run return fail
scoreboard players operation #Search companion.id = @s companion.id

execute unless entity @a[tag=companion.activepet, predicate=evercraft:companions/check_id] run data modify entity @s view_range set value 0f