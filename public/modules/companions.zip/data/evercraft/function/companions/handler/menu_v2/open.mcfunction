# Companion Catalogue - Open (Hub-Style Layout)
# Spawns a hub page with 4 section buttons: Companions | Buddy | Summon | Training
# Uses rotated ~ 0 for yaw-only positioning (menu stays at eye level)

# === BUDDY SYSTEM: Sneak + catalogue redirects ===
# If sneaking near a tamed mob, redirect to buddy designation instead of opening menu
execute if predicate evercraft:companions/is_sneaking if entity @e[type=#evercraft:tameable_companions,tag=ec.tame_protected,distance=..5,limit=1,sort=nearest] run return run function evercraft:buddy/designate/detect

# Revoke advancement (on_use already revokes, but safety for direct calls)
advancement revoke @s only evercraft:companions/menu_v2/spawn

# Book-based item with consume_seconds:100 — NOT consumed, no restore needed

# Safety: clear stuck tag if menu anchor is gone (crash/disconnect recovery)
execute if entity @s[tag=companion.inmenuv2] run scoreboard players operation #Search companion.id = @s companion.id
execute if entity @s[tag=companion.inmenuv2] unless entity @e[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] run function evercraft:companions/handler/menu_v2/close

# Prevent double-opening
execute if entity @s[tag=companion.inmenuv2] run return fail
execute if data storage evercraft:companions uninstalled run return fail

# Menu Core: Y-displacement close anchor
# One-menu-at-a-time (2026-06-15): close any other open menu before this one claims
# ec.menu_active. Two overlapping menus share the @s adv.gui_session slot; the newer
# open orphans the older menu's session, so it can never consume its click -> stuck
# interaction NBT -> click-sound spam. force_close is idempotent (no-op when nothing open).
execute if entity @s[tag=ec.menu_active] run function evercraft:menu_core/force_close
tag @s add ec.menu_active
execute store result score @s ec.menu_open_y run data get entity @s Pos[1] 100

# Tag player as in menu
tag @s add companion.inmenuv2
tag @s add companion.activemenu

# Store player ID for menu ownership
scoreboard players operation #Search companion.id = @s companion.id

# Count pets for pagination (precomputed for when Companions tab opens)
scoreboard players operation #CompanionCount companion.menu = @s companion.count

# Compute max pages: ceil(count / 48) = (count + 47) / 48, minimum 1
scoreboard players operation #MaxPage companion.menu = #CompanionCount companion.menu
scoreboard players add #MaxPage companion.menu 47
scoreboard players operation #MaxPage companion.menu /= #48 companion.calc
execute if score #MaxPage companion.menu matches ..0 run scoreboard players set #MaxPage companion.menu 1

# Reset page to 1
scoreboard players set @s companion.menupage 1

# Set tab to 8 (catalogue hub — the 4-button landing: Companions/Buddy/Summon/Training).
# Joseph 2026-06-06: reverted the landing back to the hub; the SP5 home view (3 heads) is now the
# destination of the hub's top-left "Companions" button (see click_hub + open_home_from_hub).
scoreboard players set @s ec.bd_tab 8

# Spawn menu anchor at new position (matches Codex hub size)
execute rotated ~ 0 positioned ^ ^1.3 ^1.8 run summon marker ~ ~ ~ {Tags:["companion.menuanchor","companion.new"],Invisible:1b}
scoreboard players operation @e[type=marker,tag=companion.new,distance=..5] companion.id = @s companion.id
tag @e[type=marker,tag=companion.new] remove companion.new

# Spawn the menu background (4.0 x 2.5 — matches Codex hub frame)
execute rotated ~ 0 positioned ^ ^1.3 ^1.8 as @n[type=marker,tag=companion.menuanchor,distance=..5] at @s run function evercraft:companions/handler/menu_v2/spawn_frame
scoreboard players operation @e[type=item_display,tag=companion.menubg,distance=..5] companion.id = @s companion.id

# Spawn title text (top center, Codex-style)
# Ownership-header label (MP-P3.6): foreign viewers see whose menu this is
# 26.1: {selector:} renders blank in text_display — bake @s's name to a $(owner) literal.
function evercraft:util/gui/owner_name
execute rotated ~ 0 positioned ^ ^2.43 ^1.78 run function evercraft:companions/handler/menu_v2/open_nm with storage evercraft:scorebake args
execute rotated ~ 0 positioned ^ ^2.25 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menutitle","companion.menuelement"],billboard:"center",text:{text:"The Companion Catalogue",color:"gold",bold:true},background:0,shadow:1b,see_through:0b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.715f,0.715f,0.715f]}}
scoreboard players operation @e[type=text_display,tag=companion.menutitle,distance=..5] companion.id = @s companion.id

# Spawn Info [?] button (top center, below title)
execute rotated ~ 0 positioned ^ ^2.1 ^1.76 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuinfotext","companion.menuelement"],billboard:"center",text:[{text:"[",color:"dark_gray"},{text:"?",color:"yellow",bold:true},{text:"]",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.298f,0.298f,0.298f]}}
execute rotated ~ 0 positioned ^ ^2.05 ^1.78 run summon interaction ~ ~ ~ {Tags:["companion.menuinfoclick","companion.menuelement"],width:0.15f,height:0.06f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.menuinfotext,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.menuinfoclick,distance=..5] companion.id = @s companion.id

# Spawn the 4-button catalogue hub (Companions/Buddy/Summon/Training) as the landing page. No Back
# button here — the hub is the root; the menu closes on item-switch (handled in tick). The top-left
# "Companions" button opens the SP5 home view (3 heads) via click_hub → open_home_from_hub.
function evercraft:companions/handler/menu_v2/spawn_hub

# Session isolation
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=companion.menuelement,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=companion.menuelement,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=companion.menuelement,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.chest.open master @s ~ ~ ~ 0.5 1.2
