# Hoglin Pet Passive Abilities
# - Brute Force: Attack damage (1.5 → 4.0)
# - Thick Hide: Armor (0.5 → 2.0)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.hoglin

# Brute Force: Attack damage (1.5 → 4.0)
execute if score #value companion.calc matches 1..7 run attribute @s attack_damage base set 1.576
execute if score #value companion.calc matches 8..12 run attribute @s attack_damage base set 1.727
execute if score #value companion.calc matches 13..17 run attribute @s attack_damage base set 1.854
execute if score #value companion.calc matches 18..22 run attribute @s attack_damage base set 1.98
execute if score #value companion.calc matches 23..27 run attribute @s attack_damage base set 2.106
execute if score #value companion.calc matches 28..32 run attribute @s attack_damage base set 2.232
execute if score #value companion.calc matches 33..37 run attribute @s attack_damage base set 2.359
execute if score #value companion.calc matches 38..42 run attribute @s attack_damage base set 2.485
execute if score #value companion.calc matches 43..47 run attribute @s attack_damage base set 2.611
execute if score #value companion.calc matches 48..52 run attribute @s attack_damage base set 2.737
execute if score #value companion.calc matches 53..57 run attribute @s attack_damage base set 2.864
execute if score #value companion.calc matches 58..62 run attribute @s attack_damage base set 2.99
execute if score #value companion.calc matches 63..67 run attribute @s attack_damage base set 3.116
execute if score #value companion.calc matches 68..72 run attribute @s attack_damage base set 3.242
execute if score #value companion.calc matches 73..77 run attribute @s attack_damage base set 3.369
execute if score #value companion.calc matches 78..82 run attribute @s attack_damage base set 3.495
execute if score #value companion.calc matches 83..87 run attribute @s attack_damage base set 3.621
execute if score #value companion.calc matches 88..92 run attribute @s attack_damage base set 3.747
execute if score #value companion.calc matches 93..97 run attribute @s attack_damage base set 3.874
execute if score #value companion.calc matches 98..100 run attribute @s attack_damage base set 3.975

# Thick Hide: Armor (0.5 → 2.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s armor base set 0.545
execute if score #value companion.calc matches 8..12 run return run attribute @s armor base set 0.636
execute if score #value companion.calc matches 13..17 run return run attribute @s armor base set 0.712
execute if score #value companion.calc matches 18..22 run return run attribute @s armor base set 0.788
execute if score #value companion.calc matches 23..27 run return run attribute @s armor base set 0.864
execute if score #value companion.calc matches 28..32 run return run attribute @s armor base set 0.939
execute if score #value companion.calc matches 33..37 run return run attribute @s armor base set 1.015
execute if score #value companion.calc matches 38..42 run return run attribute @s armor base set 1.091
execute if score #value companion.calc matches 43..47 run return run attribute @s armor base set 1.167
execute if score #value companion.calc matches 48..52 run return run attribute @s armor base set 1.242
execute if score #value companion.calc matches 53..57 run return run attribute @s armor base set 1.318
execute if score #value companion.calc matches 58..62 run return run attribute @s armor base set 1.394
execute if score #value companion.calc matches 63..67 run return run attribute @s armor base set 1.47
execute if score #value companion.calc matches 68..72 run return run attribute @s armor base set 1.545
execute if score #value companion.calc matches 73..77 run return run attribute @s armor base set 1.621
execute if score #value companion.calc matches 78..82 run return run attribute @s armor base set 1.697
execute if score #value companion.calc matches 83..87 run return run attribute @s armor base set 1.773
execute if score #value companion.calc matches 88..92 run return run attribute @s armor base set 1.848
execute if score #value companion.calc matches 93..97 run return run attribute @s armor base set 1.924
execute if score #value companion.calc matches 98..100 run return run attribute @s armor base set 1.985
