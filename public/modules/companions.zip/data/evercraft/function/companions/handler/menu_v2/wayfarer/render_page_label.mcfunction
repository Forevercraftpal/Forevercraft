# SP8 — Wayfarer Track: render the "Page N / 3" label between the page arrows (just above Back). Run as player.
execute rotated ~ 0 positioned ^ ^0.62 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.wf_pagelabel"],billboard:"center",background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}
# Dynamic "Page N / M" — M = ceil(node_max / 10) (= 25 at node_max 250). N = wf_page + 1.
scoreboard players operation #wf_pg_disp ec.temp = @s companion.wf_page
scoreboard players add #wf_pg_disp ec.temp 1
scoreboard players operation #wf_tot_disp ec.temp = #wf_node_max ec.const
scoreboard players add #wf_tot_disp ec.temp 9
scoreboard players operation #wf_tot_disp ec.temp /= #10 ec.const
# === 26.1 fix: {score} blank in text_display -> bake via storage macro (cat B) ===
scoreboard players add #wf_pg_disp ec.temp 0
execute store result storage evercraft:scorebake bargs.v1 int 1 run scoreboard players get #wf_pg_disp ec.temp
scoreboard players add #wf_tot_disp ec.temp 0
execute store result storage evercraft:scorebake bargs.v2 int 1 run scoreboard players get #wf_tot_disp ec.temp
function evercraft:companions/handler/menu_v2/wayfarer/render_page_label_dynb with storage evercraft:scorebake bargs
scoreboard players operation @e[type=text_display,tag=companion.wf_pagelabel,distance=..5] companion.id = @s companion.id
