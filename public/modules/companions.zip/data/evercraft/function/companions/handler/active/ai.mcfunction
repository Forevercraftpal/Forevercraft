tag @s add companion.owner
scoreboard players operation #Search companion.id = @s companion.id

# --------------------------------------------------------------------------------- #

# OPT: 3 entity scans (idle + movement + XP) → 1 dispatch + cheap tag lookup
scoreboard players set #pet_idle ec.temp 0
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id] run function evercraft:companions/handler/active/pet_tick

# If idle pet was found and reactivated, skip the rest
execute if score #pet_idle ec.temp matches 1 run tag @s remove companion.owner
execute if score #pet_idle ec.temp matches 1 run return 0

# Companion specific AI
execute as @s[tag=companion.frostweaver] at @s align xyz if block ~.5 ~ ~.5 air if block ~.5 ~-1 ~.5 water run fill ~1 ~-1 ~1 ~-1 ~-1 ~-1 frosted_ice[age=2] replace water

# Experience gain detection (uses ec.pet_found tag set by pet_tick — no predicate re-scan)
execute if score @s companion.playerexp > @s companion.previousplayerexp as @e[tag=ec.pet_found,limit=1] run function evercraft:companions/handler/active/leveling/exp_gain
tag @e[tag=ec.pet_found] remove ec.pet_found

# Relationship system - check for feeding/petting interactions
execute as @e[type=interaction, tag=companion.petinteract, predicate=evercraft:companions/check_id] if data entity @s interaction run function evercraft:companions/handler/relationship/on_interact

# Tick down cooldowns
execute if score @s companion.feedcd matches 1.. run scoreboard players remove @s companion.feedcd 1
execute if score @s companion.interactcd matches 1.. run scoreboard players remove @s companion.interactcd 1

# --------------------------------------------------------------------------------- #

tag @s remove companion.owner
