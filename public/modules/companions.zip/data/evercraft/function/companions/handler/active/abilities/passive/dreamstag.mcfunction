# Dreamstag Pet Passive Abilities (Mythical — Gacha Exclusive)
# - Dreamwalker's Grace: Resistance I + Regeneration I on grass/dirt
# - Ethereal Leap: Jump strength scaling (0.5 → 1.5)
# - Dream Weave: Luck 1.0 → 9.0

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.dreamstag

# Dreamwalker's Grace - Resistance I + Regeneration I on grass/dirt
execute if block ~ ~-1 ~ #minecraft:dirt run effect give @s resistance 5 0 true
execute if block ~ ~-1 ~ #minecraft:dirt unless score @s ec.h_regen matches 2.. run effect give @s regeneration 5 0 true

# Ethereal Leap - Jump strength scaling (0.5 → 1.5)
execute if score #value companion.calc matches 1..7 run attribute @s jump_strength base set 1.02
execute if score #value companion.calc matches 8..12 run attribute @s jump_strength base set 1.083
execute if score #value companion.calc matches 13..17 run attribute @s jump_strength base set 1.135
execute if score #value companion.calc matches 18..22 run attribute @s jump_strength base set 1.187
execute if score #value companion.calc matches 23..27 run attribute @s jump_strength base set 1.239
execute if score #value companion.calc matches 28..32 run attribute @s jump_strength base set 1.291
execute if score #value companion.calc matches 33..37 run attribute @s jump_strength base set 1.343
execute if score #value companion.calc matches 38..42 run attribute @s jump_strength base set 1.395
execute if score #value companion.calc matches 43..47 run attribute @s jump_strength base set 1.447
execute if score #value companion.calc matches 48..52 run attribute @s jump_strength base set 1.5
execute if score #value companion.calc matches 53..57 run attribute @s jump_strength base set 1.552
execute if score #value companion.calc matches 58..62 run attribute @s jump_strength base set 1.604
execute if score #value companion.calc matches 63..67 run attribute @s jump_strength base set 1.656
execute if score #value companion.calc matches 68..72 run attribute @s jump_strength base set 1.708
execute if score #value companion.calc matches 73..77 run attribute @s jump_strength base set 1.76
execute if score #value companion.calc matches 78..82 run attribute @s jump_strength base set 1.812
execute if score #value companion.calc matches 83..87 run attribute @s jump_strength base set 1.864
execute if score #value companion.calc matches 88..92 run attribute @s jump_strength base set 1.916
execute if score #value companion.calc matches 93..97 run attribute @s jump_strength base set 1.968
execute if score #value companion.calc matches 98..100 run attribute @s jump_strength base set 2.02

# Dream Weave - Luck scaling (1.0 → 9.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s luck base set 1.0
execute if score #value companion.calc matches 8..12 run return run attribute @s luck base set 1.421
execute if score #value companion.calc matches 13..17 run return run attribute @s luck base set 1.789
execute if score #value companion.calc matches 18..22 run return run attribute @s luck base set 2.158
execute if score #value companion.calc matches 23..27 run return run attribute @s luck base set 2.526
execute if score #value companion.calc matches 28..32 run return run attribute @s luck base set 2.895
execute if score #value companion.calc matches 33..37 run return run attribute @s luck base set 3.263
execute if score #value companion.calc matches 38..42 run return run attribute @s luck base set 3.632
execute if score #value companion.calc matches 43..47 run return run attribute @s luck base set 4.0
execute if score #value companion.calc matches 48..52 run return run attribute @s luck base set 4.368
execute if score #value companion.calc matches 53..57 run return run attribute @s luck base set 4.737
execute if score #value companion.calc matches 58..62 run return run attribute @s luck base set 5.105
execute if score #value companion.calc matches 63..67 run return run attribute @s luck base set 5.474
execute if score #value companion.calc matches 68..72 run return run attribute @s luck base set 5.842
execute if score #value companion.calc matches 73..77 run return run attribute @s luck base set 6.211
execute if score #value companion.calc matches 78..82 run return run attribute @s luck base set 6.579
execute if score #value companion.calc matches 83..87 run return run attribute @s luck base set 6.947
execute if score #value companion.calc matches 88..92 run return run attribute @s luck base set 7.316
execute if score #value companion.calc matches 93..97 run return run attribute @s luck base set 7.684
execute if score #value companion.calc matches 98..100 run return run attribute @s luck base set 9.0
