# SP8 — Wayfarer Track: header line "Wayfarer XP: X  ·  next node Y XP  ·  Dream Rank R". Run as player.
# NON-BOLD. Reads ec.wf_xp + ec.wf_node (track/accrue) + ec.dream_rank (the codex-header DR read).
# The "next" threshold is the threshold of node (wf_node+1); at node 30 it shows "MAX".

# Next-node XP target = #wf_thr_(wf_node+1). Resolve into #wf_next ec.temp via macro; -1 sentinel = maxed.
scoreboard players operation #wf_nn ec.temp = @s ec.wf_node
scoreboard players add #wf_nn ec.temp 1
scoreboard players set #wf_next ec.temp -1
execute store result storage evercraft:companions wfm.nn int 1 run scoreboard players get #wf_nn ec.temp
execute if score #wf_nn ec.temp <= #wf_node_max ec.const run function evercraft:companions/handler/menu_v2/wayfarer/header_next with storage evercraft:companions wfm

# Copy the player's live values into FIXED fake-players so the text_display can render them (a {score}
# component with @s would resolve against the display entity, not the player — so we mirror to fakes).
scoreboard players operation #wf_disp_xp ec.temp = @s ec.wf_xp
scoreboard players operation #wf_disp_dr ec.temp = @s ec.dream_rank

# Spawn the header text_display, then fill it with the mirrored scores.
execute rotated ~ 0 positioned ^ ^1.70 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.wf_header"],billboard:"center",background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
# === 26.1 fix: {score} blank in text_display -> bake via storage macro (cat B) ===
scoreboard players add #wf_disp_xp ec.temp 0
execute store result storage evercraft:scorebake bargs.v1 int 1 run scoreboard players get #wf_disp_xp ec.temp
scoreboard players add #wf_next ec.temp 0
execute store result storage evercraft:scorebake bargs.v2 int 1 run scoreboard players get #wf_next ec.temp
scoreboard players add #wf_disp_dr ec.temp 0
execute store result storage evercraft:scorebake bargs.v3 int 1 run scoreboard players get #wf_disp_dr ec.temp
function evercraft:companions/handler/menu_v2/wayfarer/render_header_dynb with storage evercraft:scorebake bargs
scoreboard players operation @e[type=text_display,tag=companion.wf_header,distance=..5] companion.id = @s companion.id
