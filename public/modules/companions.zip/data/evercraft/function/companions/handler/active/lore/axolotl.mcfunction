scoreboard players operation #oxygen_bonus companion.calc = #current_level companion.exp
scoreboard players operation #oxygen_bonus companion.calc *= #oxygen_bonus companion.calc
scoreboard players operation #oxygen_bonus companion.calc *= #5 companion.calc

scoreboard players operation #percentage_increase companion.calc = #oxygen_bonus companion.calc

scoreboard players operation #oxygen_bonus companion.calc = #current_level companion.exp
scoreboard players operation #oxygen_bonus companion.calc *= #400 companion.calc

scoreboard players operation #percentage_increase companion.calc += #oxygen_bonus companion.calc
execute store result storage evercraft:companions math.percentage_increase float 0.01 run scoreboard players get #percentage_increase companion.calc

data modify entity @s item.components."minecraft:lore"[4].extra[0].text set string storage evercraft:companions math.percentage_increase 0 -1
data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:profile":{properties:[{},{value:"Tidecaller"}]}}}].components."minecraft:lore"[5].extra[0].text set string storage evercraft:companions math.percentage_increase 0 -1

execute as @a[tag=companion.owner, limit=1] at @s run function evercraft:companions/handler/active/abilities/passive/axolotl