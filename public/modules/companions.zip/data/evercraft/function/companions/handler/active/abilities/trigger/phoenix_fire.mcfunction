advancement revoke @s only evercraft:companions/abilities/phoenix
scoreboard players operation #Search companion.id = @s companion.id

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value

scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

execute if score #value companion.calc matches 1..7 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 10
execute if score #value companion.calc matches 8..12 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 20
execute if score #value companion.calc matches 13..17 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 30
execute if score #value companion.calc matches 18..22 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 40
execute if score #value companion.calc matches 23..27 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 50
execute if score #value companion.calc matches 28..32 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 60
execute if score #value companion.calc matches 33..37 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 70
execute if score #value companion.calc matches 38..42 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 80
execute if score #value companion.calc matches 43..47 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 90
execute if score #value companion.calc matches 48..52 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 100
execute if score #value companion.calc matches 53..57 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 110
execute if score #value companion.calc matches 58..62 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 120
execute if score #value companion.calc matches 63..67 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 130
execute if score #value companion.calc matches 68..72 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 140
execute if score #value companion.calc matches 73..77 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 150
execute if score #value companion.calc matches 78..82 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 160
execute if score #value companion.calc matches 83..87 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 170
execute if score #value companion.calc matches 88..92 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 180
execute if score #value companion.calc matches 93..97 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 190
execute if score #value companion.calc matches 98..100 as @e[distance=..10, type=#undead, predicate=evercraft:companions/is_hurt] run return run data modify entity @s Fire set value 200
# Achievement tracking
scoreboard players add @s ach.comp_abilities 1
