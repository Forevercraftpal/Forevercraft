scoreboard players operation #Search companion.id = @s companion.id

execute as @s[tag=companion.zephyr] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[5].extra[{text:"28"}] at @s run return run function evercraft:companions/handler/active/abilities/trigger/chicken

execute as @s[tag=companion.bramble] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[5].extra[{text:"28"}] at @s run return run function evercraft:companions/handler/active/abilities/trigger/pufferfish