# SP5 — Journey: render the 5-theme picker row. Run as player, facing-anchor context.
# Forge(1) Forage(2) Delve(3) Tide(4) Wandering(5). Clicking a theme sets ec.journey_type (SP4 contract).
# The currently-picked theme reads ec.journey_type; render_selected shows it below.

# Forge.
execute rotated ~ 0 positioned ^ ^1.18 ^1.74 positioned ^1.20 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.jr_theme1_text"],billboard:"center",text:[{text:"Forge",color:"red"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}
execute rotated ~ 0 positioned ^ ^1.15 ^1.76 positioned ^1.20 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.jr_theme_btn","companion.jr_theme1_click"],width:0.30f,height:0.11f,response:1b}
# Forage.
execute rotated ~ 0 positioned ^ ^1.18 ^1.74 positioned ^0.60 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.jr_theme2_text"],billboard:"center",text:[{text:"Forage",color:"green"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}
execute rotated ~ 0 positioned ^ ^1.15 ^1.76 positioned ^0.60 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.jr_theme_btn","companion.jr_theme2_click"],width:0.30f,height:0.11f,response:1b}
# Delve.
execute rotated ~ 0 positioned ^ ^1.18 ^1.74 positioned ^0 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.jr_theme3_text"],billboard:"center",text:[{text:"Delve",color:"dark_purple"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}
execute rotated ~ 0 positioned ^ ^1.15 ^1.76 positioned ^0 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.jr_theme_btn","companion.jr_theme3_click"],width:0.30f,height:0.11f,response:1b}
# Tide.
execute rotated ~ 0 positioned ^ ^1.18 ^1.74 positioned ^-0.60 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.jr_theme4_text"],billboard:"center",text:[{text:"Tide",color:"aqua"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}
execute rotated ~ 0 positioned ^ ^1.15 ^1.76 positioned ^-0.60 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.jr_theme_btn","companion.jr_theme4_click"],width:0.30f,height:0.11f,response:1b}
# Wandering.
execute rotated ~ 0 positioned ^ ^1.18 ^1.74 positioned ^-1.20 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.jr_theme5_text"],billboard:"center",text:[{text:"Wander",color:"yellow"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}
execute rotated ~ 0 positioned ^ ^1.15 ^1.76 positioned ^-1.20 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.jr_theme_btn","companion.jr_theme5_click"],width:0.30f,height:0.11f,response:1b}

scoreboard players operation @e[type=text_display,tag=companion.jr_theme_btn,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.jr_theme_btn,distance=..5] companion.id = @s companion.id
# Stamp ids on the theme label text_displays too (they use jr_themeN_text, not jr_theme_btn).
scoreboard players operation @e[type=text_display,tag=companion.jr_theme1_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=text_display,tag=companion.jr_theme2_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=text_display,tag=companion.jr_theme3_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=text_display,tag=companion.jr_theme4_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=text_display,tag=companion.jr_theme5_text,distance=..5] companion.id = @s companion.id
