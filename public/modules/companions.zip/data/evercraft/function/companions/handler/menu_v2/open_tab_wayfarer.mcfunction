# SP8 — Open the WAYFARER TRACK tab (ec.bd_tab 9). Run as player (on target from the home banner).
# A paged node ladder (10 nodes/page → 3 pages for 30 nodes) with a header XP bar + Dream Rank line.
# Mirrors open_tab_skills: tears down the home view, sets the tab, defaults the pager, renders. Claimable
# nodes glow + are clickable → track/claim. SP8 owns the render; reuses the menu frame (no new framework).

scoreboard players operation #Search companion.id = @s companion.id

# Tear down the home view / prior tab content (same set open_tab_skills kills).
execute as @e[type=item_display,tag=companion.homehead,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.homehead,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.headslot,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.home_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.home_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=item_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s

# Set the Wayfarer tab + default the pager to page 0. Valid range is 0..24 (25 pages × 10 = the 250-node
# ladder — node_max 250). Was 0..2 (a 30-node leftover) which silently snapped pages 3..24 back to 0 on
# every reopen, so the back half of the track was unreachable after closing the menu.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players set @s ec.bd_tab 9
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] unless score @s companion.wf_page matches 0..24 run scoreboard players set @s companion.wf_page 0

# Render the ladder + header.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] at @s facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet run function evercraft:companions/handler/menu_v2/wayfarer/render

# Session-stamp the new elements.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

playsound minecraft:block.note_block.hat master @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.6
