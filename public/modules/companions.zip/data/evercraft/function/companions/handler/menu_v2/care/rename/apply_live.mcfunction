# SP5 — Rename: macro — update the live MAIN companion head's CustomName immediately. Run as player.
# Args: {name:"..."}. So the rename shows without a re-summon. The persistent record is already updated
# by rename/apply; this just refreshes the floating head + its stored item name field.
$data modify entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] CustomName set value {text:"$(name)",color:"gold"}
$data modify entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:custom_name" set value {text:"$(name)",color:"gold"}
$data modify entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:custom_data".pet_name set value "$(name)"
