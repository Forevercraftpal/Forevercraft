# Twilight Hare Pet Passive Abilities (Exquisite — Gacha Exclusive)
# - Dusk Runner: Movement speed 0.11 → 0.20
# - Twilight Dodge: Evasion (luck-based DR system)
# - Fading Light: Luck 1.0 → 5.0

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.twilight_hare

# Dusk Runner - Movement speed scaling (0.11 → 0.20)
execute if score #value companion.calc matches 1..7 run attribute @s movement_speed base set 0.211
execute if score #value companion.calc matches 8..12 run attribute @s movement_speed base set 0.215
execute if score #value companion.calc matches 13..17 run attribute @s movement_speed base set 0.219
execute if score #value companion.calc matches 18..22 run attribute @s movement_speed base set 0.223
execute if score #value companion.calc matches 23..27 run attribute @s movement_speed base set 0.227
execute if score #value companion.calc matches 28..32 run attribute @s movement_speed base set 0.231
execute if score #value companion.calc matches 33..37 run attribute @s movement_speed base set 0.235
execute if score #value companion.calc matches 38..42 run attribute @s movement_speed base set 0.239
execute if score #value companion.calc matches 43..47 run attribute @s movement_speed base set 0.243
execute if score #value companion.calc matches 48..52 run attribute @s movement_speed base set 0.247
execute if score #value companion.calc matches 53..57 run attribute @s movement_speed base set 0.251
execute if score #value companion.calc matches 58..62 run attribute @s movement_speed base set 0.255
execute if score #value companion.calc matches 63..67 run attribute @s movement_speed base set 0.259
execute if score #value companion.calc matches 68..72 run attribute @s movement_speed base set 0.263
execute if score #value companion.calc matches 73..77 run attribute @s movement_speed base set 0.267
execute if score #value companion.calc matches 78..82 run attribute @s movement_speed base set 0.271
execute if score #value companion.calc matches 83..87 run attribute @s movement_speed base set 0.275
execute if score #value companion.calc matches 88..92 run attribute @s movement_speed base set 0.279
execute if score #value companion.calc matches 93..97 run attribute @s movement_speed base set 0.283
execute if score #value companion.calc matches 98..100 run attribute @s movement_speed base set 0.3

# Fading Light - Luck scaling (1.0 → 5.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s luck base set 1.0
execute if score #value companion.calc matches 8..12 run return run attribute @s luck base set 1.211
execute if score #value companion.calc matches 13..17 run return run attribute @s luck base set 1.395
execute if score #value companion.calc matches 18..22 run return run attribute @s luck base set 1.579
execute if score #value companion.calc matches 23..27 run return run attribute @s luck base set 1.763
execute if score #value companion.calc matches 28..32 run return run attribute @s luck base set 1.947
execute if score #value companion.calc matches 33..37 run return run attribute @s luck base set 2.132
execute if score #value companion.calc matches 38..42 run return run attribute @s luck base set 2.316
execute if score #value companion.calc matches 43..47 run return run attribute @s luck base set 2.5
execute if score #value companion.calc matches 48..52 run return run attribute @s luck base set 2.684
execute if score #value companion.calc matches 53..57 run return run attribute @s luck base set 2.868
execute if score #value companion.calc matches 58..62 run return run attribute @s luck base set 3.053
execute if score #value companion.calc matches 63..67 run return run attribute @s luck base set 3.237
execute if score #value companion.calc matches 68..72 run return run attribute @s luck base set 3.421
execute if score #value companion.calc matches 73..77 run return run attribute @s luck base set 3.605
execute if score #value companion.calc matches 78..82 run return run attribute @s luck base set 3.789
execute if score #value companion.calc matches 83..87 run return run attribute @s luck base set 3.974
execute if score #value companion.calc matches 88..92 run return run attribute @s luck base set 4.158
execute if score #value companion.calc matches 93..97 run return run attribute @s luck base set 4.342
execute if score #value companion.calc matches 98..100 run return run attribute @s luck base set 5.0
