# Unsummon active pet from catalogue — stays in list, just inactive
# Syncs memories back to companion.marker, despawns entities, closes menu
# Run as: player with companion.activepet tag

execute unless entity @s[tag=companion.activepet] run return fail

scoreboard players operation #Search companion.id = @s companion.id

# Save companion HP before despawning
function evercraft:companions/health/save

# Sync memories AND relationship from live entity back to companion.marker before despawning
function evercraft:companions/handler/active/sync_memories_to_marker
function evercraft:companions/handler/active/sync_relationship_to_marker

# Kill the live pet entities (floating head + interaction + hp_label passenger)
# Passengers survive when their parent is killed — must kill the hp_label explicitly.
kill @e[type=text_display,tag=companion.hp_label,predicate=evercraft:companions/check_id]
kill @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id]
kill @e[type=interaction,tag=companion.petinteract,predicate=evercraft:companions/check_id]

# Remove active pet tags and clear slot index
tag @s remove companion.activepet
scoreboard players reset @s companion.activeslot
# Drop the Thick Hide refresh tag so the owner Resistance aura lapses promptly (the 5s refresh in
# tick_5s_player is activepet-gated, so it already stops — this just clears the now-inert marker).
tag @s remove companion.bond_thickhide

# Clear evolution tags (all 37 pets — handled by removing generic + clearing attribute mods)
function evercraft:companion_evolution/on_unsummon

# Cancel active pet duel if in one
execute if entity @s[tag=pd.duelist] run function evercraft:pet_duel/resolve_draw

# Reset kill counter (kills are per-summon session)
scoreboard players set @s companion.kills 0

# Close the menu
function evercraft:companions/handler/menu_v2/close

# Notify
data modify storage evercraft:notify stage.c set value [{text:"Pet unsummoned.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Sanctioned unsummon flavor vocal — KEEP + GATE.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.allay.ambient_with_item master @s ~ ~ ~ 0.5 1.2
