# ============================================================
# Home Companion — Remove a HomePets[] entry by slot index
# Run as: player (with #Search companion.id set)
# Requires: storage evercraft:companions home.remove_slot = slot to remove
# Also clears home:1b flag from matching Pets[] entry
# ============================================================

# Copy HomePets to temp, clear HomePets, re-add non-matching entries
data modify storage evercraft:companions home.temp_pets set from entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets
data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets set value []

# Process each entry — re-add if slot doesn't match
execute store result score #hc_remove_target hc.slot run data get storage evercraft:companions home.remove_slot

# Check each possible index (max 5 entries: 0-4)
execute if data storage evercraft:companions home.temp_pets[0] run function evercraft:companions/handler/home/filter_homepet {idx:0}
execute if data storage evercraft:companions home.temp_pets[1] run function evercraft:companions/handler/home/filter_homepet {idx:1}
execute if data storage evercraft:companions home.temp_pets[2] run function evercraft:companions/handler/home/filter_homepet {idx:2}
execute if data storage evercraft:companions home.temp_pets[3] run function evercraft:companions/handler/home/filter_homepet {idx:3}
execute if data storage evercraft:companions home.temp_pets[4] run function evercraft:companions/handler/home/filter_homepet {idx:4}

# Clear home:1b from Pets[] — iterate to find matching entry
# Store the companion name we're looking for from the removed HomePet
function evercraft:companions/handler/home/clear_home_flag
