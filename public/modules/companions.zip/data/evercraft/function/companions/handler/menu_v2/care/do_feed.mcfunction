# SP5 — Care: Feed the focused companion. Run as player (on target from click_care).
# Two paths (Joseph's spec): holding food → run the food→RP ladder on the focused companion; empty hand
# (or non-food) → a quick +5 snack (the Pet treat path). Works for both the live MAIN and stored pets.
#
#   focused == active MAIN, holding food → the existing feed/detect ladder (consumes 1, maps food→RP).
#   focused == active MAIN, no food      → do_treat (+5 quick snack).
#   focused == stored, holding food      → care/feed_stored (food ladder against the Pets[] record).
#   focused == stored, no food           → care/pet_stored (+5 quick snack).

# Holding food (non-air mainhand) → food ladder; else → quick snack.
scoreboard players set #cc_holdingfood ec.temp 0
execute unless items entity @s weapon.mainhand air run scoreboard players set #cc_holdingfood ec.temp 1

# --- Active MAIN ---
execute if score #cc_is_main ec.temp matches 1 if score #cc_holdingfood ec.temp matches 1 run function evercraft:companions/handler/relationship/feed/detect
execute if score #cc_is_main ec.temp matches 1 if score #cc_holdingfood ec.temp matches 0 run function evercraft:companions/handler/menu_v2/do_treat

# --- Stored companion ---
execute if score #cc_is_main ec.temp matches 0 if score #cc_holdingfood ec.temp matches 1 run function evercraft:companions/handler/menu_v2/care/feed_stored
execute if score #cc_is_main ec.temp matches 0 if score #cc_holdingfood ec.temp matches 0 run function evercraft:companions/handler/menu_v2/care/pet_stored

# Re-render Care so the RP bar + bond update (if still on the Care tab — feeding never closes the menu).
execute if entity @s[tag=companion.inmenuv2] if score @s ec.bd_tab matches 5 run function evercraft:companions/handler/menu_v2/care/refresh
