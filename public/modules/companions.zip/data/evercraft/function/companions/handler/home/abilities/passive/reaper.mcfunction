# Wraith Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.wraith

# Spectral Flurry: Attack speed (4.5 → 8.0)
$execute if score #value companion.calc matches 1..7 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 4.606 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 4.818 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 4.995 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.172 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.348 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.525 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.702 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.879 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 6.056 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 6.232 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 6.409 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 6.586 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 6.763 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 6.939 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 7.116 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 7.293 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 7.47 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 7.646 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 7.823 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 7.965 add_value
