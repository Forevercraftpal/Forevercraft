# Dupe-Fusion (Joseph 2026-06-10).
# A duplicate of an owned companion FUSES into that specific pet: +1% power per fuse, capped by rarity.
# The +1% rides the pet's whistle-attack damage (combat/calc_damage) and horn-ability damage (horn/scale)
# via a fuse_count field on the DB record's custom_data — so it travels when the companion is traded, and
# the live entity inherits it wholesale on summon (spawn_selected_companion copies the record item).
# This is the FIRST job an owned duplicate does; dupe_evolve runs after, and shards are the fallback only
# when BOTH are capped/done (orchestrated by dupe_absorb). Run as: the player obtaining the dupe.
#   In:  storage evercraft:companions name        — the record's pet_name key (profile name value)
#        #inc_shiny ec.temp                        — 1 if the incoming keeper is a shiny (set by check_duplicates)
#   Out: #df_applied ec.temp                       — 1 if this dupe was absorbed as a fuse, else 0

scoreboard players set #df_applied ec.temp 0

# Macro args mirror the dupe_evolve family (df.* on the companions storage).
data modify storage evercraft:companions df.pet_name set from storage evercraft:companions name

# Resolve the rarity tier (1 Common .. 6 Mythical) of the OWNED species → fuse cap.
#   Common 20 / Uncommon 15 / Rare 12 / Ornate 10 / Exquisite 8 / Mythical 5.
data modify storage evercraft:companion_combat companion_name set from storage evercraft:companions name
function evercraft:companions/combat/get_tier_stats
scoreboard players set #df_cap ec.var 20
execute if score #pc_tier ec.var matches 2 run scoreboard players set #df_cap ec.var 15
execute if score #pc_tier ec.var matches 3 run scoreboard players set #df_cap ec.var 12
execute if score #pc_tier ec.var matches 4 run scoreboard players set #df_cap ec.var 10
execute if score #pc_tier ec.var matches 5 run scoreboard players set #df_cap ec.var 8
execute if score #pc_tier ec.var matches 6 run scoreboard players set #df_cap ec.var 5

# Load current fuse_count off the owned record (absent → 0). Set 0 first, then store-result the read,
# so an absent NBT path leaves the score untouched at 0 (the optional-read idiom; mirrors dupe_evolve_load).
scoreboard players set #df_fuse ec.temp 0
function evercraft:companions/handler/database/dupe_fuse_load with storage evercraft:companions df

# At/over cap → no fuse (caller falls through to evolution, then shards). #df_applied stays 0.
execute if score #df_fuse ec.temp >= #df_cap ec.var run return 0

# Under cap: this dupe counts. Increment, write back to the record, notify, FX.
scoreboard players add #df_fuse ec.temp 1
scoreboard players set #df_applied ec.temp 1

# Stash the macro args (fuse/cap). The notify's name comes from the incoming item's custom_name
# inside the advance macro (interpret:true) — correct for every species, no get_display_name needed.
execute store result storage evercraft:companions df.fuse int 1 run scoreboard players get #df_fuse ec.temp
execute store result storage evercraft:companions df.cap int 1 run scoreboard players get #df_cap ec.var

# Write the new fuse_count + notify. The macro selects the record filter by shiny-ness of the incoming
# keeper so a shiny dupe fuses the shiny record (mirrors check_duplicates' shiny probe). A NORMAL incoming
# uses the plain pet_name filter, which can subset-match a shiny record of the same species — a pre-existing
# limitation shared with evo_prog (see BIG_BRAIN/10-pending.md "Companion fusion follow-ups").
execute if score #inc_shiny ec.temp matches 1 run function evercraft:companions/handler/database/dupe_fuse_advance_shiny with storage evercraft:companions df
execute if score #inc_shiny ec.temp matches 0 run function evercraft:companions/handler/database/dupe_fuse_advance with storage evercraft:companions df
return 1
