# Load relationship points from active pet into scoreboard
# Run as player with active pet
# Sets: companion.rp, companion.rellevel, companion.relmult

scoreboard players operation #Search companion.id = @s companion.id

# Check if pet has relationship data, if not initialize it
execute unless data entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"relationship"}] as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] run function evercraft:companions/handler/relationship/init

# Get RP from pet NBT
data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"relationship"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int
scoreboard players operation @s companion.rp = #value companion.calc

# Calculate relationship level (0-5)
scoreboard players set @s companion.rellevel 0
execute if score @s companion.rp >= #RelLvl1 companion.calc run scoreboard players set @s companion.rellevel 1
execute if score @s companion.rp >= #RelLvl2 companion.calc run scoreboard players set @s companion.rellevel 2
execute if score @s companion.rp >= #RelLvl3 companion.calc run scoreboard players set @s companion.rellevel 3
execute if score @s companion.rp >= #RelLvl4 companion.calc run scoreboard players set @s companion.rellevel 4
execute if score @s companion.rp >= #RelLvl5 companion.calc run scoreboard players set @s companion.rellevel 5

# Calculate multiplier (100 = 1.0x .. 200 = 2.0x).  SP2 / KEYSTONE §4-E re-curve: bond is a REAL
# second power axis (was 100..150 / 1.5x soft-cap in Wave 1). New curve = 120/140/160/180/200 so
# Eternal Bond doubles ability power. The horn engine (horn/scale:28-31, horn/fire:64-74) was already
# authored against a 100..200 ceiling — re-mapping here lifts every horn ability to full power AND
# the attack-damage modifier (apply_multiplier_to_player) to +100% at max bond.
# Level 0 = 100(1.0x), 1 = 120(1.2x), 2 = 140(1.4x), 3 = 160(1.6x), 4 = 180(1.8x), 5 = 200(2.0x).
# ONE-WRITER of companion.relmult (this fn) — re-curve is a literals-only edit.
scoreboard players set @s companion.relmult 100
execute if score @s companion.rellevel matches 1 run scoreboard players set @s companion.relmult 120
execute if score @s companion.rellevel matches 2 run scoreboard players set @s companion.relmult 140
execute if score @s companion.rellevel matches 3 run scoreboard players set @s companion.relmult 160
execute if score @s companion.rellevel matches 4 run scoreboard players set @s companion.relmult 180
execute if score @s companion.rellevel matches 5 run scoreboard players set @s companion.relmult 200
