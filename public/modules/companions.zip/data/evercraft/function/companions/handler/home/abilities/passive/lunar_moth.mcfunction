# Lunar Moth Pet Passive Abilities (Exquisite — Gacha Exclusive)
# - Moonlit Wings: Slow Falling + Night Vision at night
# - Lunar Grace: Movement speed scaling + Evasion
# - Moonbeam: Luck 1.0 -> 5.0

tag @s add companion.lunar_moth

# Moonlit Wings - Slow Falling + Night Vision at night (DayTime 13000-23000 = night)
execute if score #visual_time ec.var matches 13000..23000 run effect give @s slow_falling 5 0 true
execute if score #visual_time ec.var matches 13000..23000 run effect give @s night_vision 13 0 true

# Lunar Grace - Movement speed scaling (0.105 -> 0.18)
$execute if score #value companion.calc matches 1..10 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.105 add_value
$execute if score #value companion.calc matches 11..20 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.1125 add_value
$execute if score #value companion.calc matches 21..30 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.12 add_value
$execute if score #value companion.calc matches 31..40 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.1275 add_value
$execute if score #value companion.calc matches 41..50 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.135 add_value
$execute if score #value companion.calc matches 51..60 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.1425 add_value
$execute if score #value companion.calc matches 61..70 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.15 add_value
$execute if score #value companion.calc matches 71..80 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.1575 add_value
$execute if score #value companion.calc matches 81..90 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.165 add_value
$execute if score #value companion.calc matches 91..100 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.18 add_value

# Moonbeam - Luck scaling (1.0 -> 5.0)
$execute if score #value companion.calc matches 1..10 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1 add_value
$execute if score #value companion.calc matches 11..20 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.444 add_value
$execute if score #value companion.calc matches 21..30 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.889 add_value
$execute if score #value companion.calc matches 31..40 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.333 add_value
$execute if score #value companion.calc matches 41..50 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.778 add_value
$execute if score #value companion.calc matches 51..60 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.222 add_value
$execute if score #value companion.calc matches 61..70 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.667 add_value
$execute if score #value companion.calc matches 71..80 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.111 add_value
$execute if score #value companion.calc matches 81..90 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.556 add_value
$execute if score #value companion.calc matches 91..100 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 5 add_value
