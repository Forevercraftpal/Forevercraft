# Pet Level 50 Milestone Celebration
# @s = pet item_display, owner = @p[tag=companion.owner]

# Realm-wide announcement
tellraw @a [{text:"[Pets] ",color:"aqua"},{selector:"@p[tag=companion.owner,limit=1]",color:"yellow"},{text:"'s ",color:"green"},{nbt:"leveling.display_name",storage:"evercraft:companions",color:"aqua"},{text:" reached level 50!",color:"green"}]

# Firework at owner's location
execute at @p[tag=companion.owner,limit=1] run summon firework_rocket ~ ~ ~ {LifeTime:0,FireworkItem:{id:"firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"small_ball",colors:[I;65535],has_twinkle:1b}],flight_duration:1b}}}}

# Celebration sound for owner
execute as @p[tag=companion.owner,limit=1] at @s run playsound ui.toast.challenge_complete master @s ~ ~ ~ 1 1.0
