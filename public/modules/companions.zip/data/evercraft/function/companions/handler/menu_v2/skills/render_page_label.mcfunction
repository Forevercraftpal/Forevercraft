# SP5 — Skills: render the "Page N / 2" label between the page arrows. Run as player.
execute rotated ~ 0 positioned ^ ^0.95 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.skill_pagelabel"],billboard:"center",background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}
execute if score @s companion.skillpage matches 0 run data modify entity @n[type=text_display,tag=companion.skill_pagelabel,distance=..5] text set value [{text:"Page 1 / 2",color:"gray"}]
execute if score @s companion.skillpage matches 1.. run data modify entity @n[type=text_display,tag=companion.skill_pagelabel,distance=..5] text set value [{text:"Page 2 / 2",color:"gray"}]
scoreboard players operation @e[type=text_display,tag=companion.skill_pagelabel,distance=..5] companion.id = @s companion.id
