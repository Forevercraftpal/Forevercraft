# Nebula Kit Pet Passive Abilities (Exquisite — Gacha Exclusive)
# - Cosmic Awareness: Glowing on hostile mobs within 16 blocks
# - Stellar Agility: Speed I + Jump Boost I + Haste I
# - Star Sight: Luck 1.0 -> 5.0

tag @s add companion.nebula_kit

# Cosmic Awareness - Glowing on hostile mobs within 16 blocks
effect give @e[type=#minecraft:hostile,distance=..16] glowing 3 0 true

# Stellar Agility - Speed I + Jump Boost I + Haste I
execute unless score @s ec.h_speed matches 2.. run effect give @s speed 5 0 true
effect give @s jump_boost 5 0 true
execute unless score @s ec.h_haste matches 2.. run effect give @s haste 5 0 true

# Star Sight - Luck scaling (1.0 -> 5.0)
$execute if score #value companion.calc matches 1..10 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1 add_value
$execute if score #value companion.calc matches 11..20 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.444 add_value
$execute if score #value companion.calc matches 21..30 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.889 add_value
$execute if score #value companion.calc matches 31..40 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.333 add_value
$execute if score #value companion.calc matches 41..50 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.778 add_value
$execute if score #value companion.calc matches 51..60 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.222 add_value
$execute if score #value companion.calc matches 61..70 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.667 add_value
$execute if score #value companion.calc matches 71..80 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.111 add_value
$execute if score #value companion.calc matches 81..90 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.556 add_value
$execute if score #value companion.calc matches 91..100 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 5 add_value
