# Mushroom Pet Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.mushroom

# Fungal Growth: Max health (20.5 → 24.0)
$execute if score #value companion.calc matches 1..7 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 20.606 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 20.818 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 20.995 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 21.172 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 21.348 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 21.525 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 21.702 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 21.879 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 22.056 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 22.232 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 22.409 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 22.586 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 22.763 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 22.939 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 23.116 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 23.293 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 23.47 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 23.646 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 23.823 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s max_health modifier add evercraft:home/slot$(ability_slot)/max_health 23.965 add_value
