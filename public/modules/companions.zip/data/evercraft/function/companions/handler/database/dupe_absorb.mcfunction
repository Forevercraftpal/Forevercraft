# Dupe-Absorb orchestrator (Joseph 2026-06-10).
# An owned duplicate does DOUBLE DUTY: it FUSES into the specific pet (+1% power, rarity-capped) AND
# advances evolution where applicable. Shards are the fallback ONLY when fusion is capped AND evolution
# is done/non-evolvable. Run as: the player obtaining the dupe (called from check_duplicates for both the
# normal-dupe and shiny-dupe cases). Inputs the dupe-flow already set:
#   storage evercraft:companions name        — record pet_name key
#   storage evercraft:companions generatedItem — the incoming keeper item (for the shard/confirm path)
#   #inc_shiny ec.temp                        — 1 if the incoming keeper is a shiny

# 1) Fusion attempt (sets #df_applied; emits its own notify + FX when it fuses).
function evercraft:companions/handler/database/dupe_fuse

# 2) Evolution attempt (sets #de_applied; emits its own notify + FX when it advances/completes).
#    Both emits are independent — when a dupe both fuses AND evolves, the player sees both lines.
function evercraft:companions/handler/database/dupe_evolve

# 3) Shard fallback ONLY if NEITHER applied (fully fused AND non-evolvable/already-evolved). This is the
#    existing path unchanged: tiers 1-4 auto-convert, tiers 5-6 prompt to confirm, and a sharded dupe still
#    grants the SP7 ability-slot roll (all inside duplicate_to_shard). An absorbed dupe gets no shards and
#    no slot roll — consistent with how evo-absorbed dupes behaved before this rework.
execute if score #df_applied ec.temp matches 0 if score #de_applied ec.temp matches 0 run return run function evercraft:companions/duplicate_to_shard
return 0
