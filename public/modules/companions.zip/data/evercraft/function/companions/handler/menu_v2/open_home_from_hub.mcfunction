# 2026-06-06 — Open the SP5 home view (3 floating heads) FROM the catalogue hub's top-left "Companions"
# button. Run as player (on target from click_hub). Mirrors open_catalogue_hub in reverse: tears down the
# 4 hub buttons, sets ec.bd_tab 0, respawns the home view (which now includes a Back button → hub), and
# session-stamps. go_back from the home view (tab 0) routes back to the hub.

scoreboard players operation #Search companion.id = @s companion.id

# Kill the hub buttons (companion.hub_btn).
execute as @e[type=text_display,tag=companion.hub_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.hub_btn,predicate=evercraft:companions/check_id] run kill @s

# Set the home tab (find the real player — @s may be the dead hub interaction entity).
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players set @s ec.bd_tab 0

# Respawn the home view (anchor-facing to prevent yaw drift). spawn_home renders the 3 heads + nav +
# Wayfarer banner + a Back button (→ hub) and stamps companion.id on its own elements internally.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] at @s facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet run function evercraft:companions/handler/menu_v2/spawn_home

# Session-stamp the freshly spawned home elements (mirror open_catalogue_hub:22-24 / go_home_view:11-14).
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=item_display,tag=companion.menuelement,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=text_display,tag=companion.menuelement,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=companion.menuelement,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

playsound minecraft:block.note_block.hat master @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.6
