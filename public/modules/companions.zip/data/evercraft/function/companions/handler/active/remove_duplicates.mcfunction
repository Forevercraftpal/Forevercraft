scoreboard players operation #Search companion.id = @a[tag=companion.owner] companion.id

# Despawn warning names the pet entity (@s) → direct render in the entity's context (§5b).
data modify storage evercraft:notify stage.c set value [{text:"Multiple pets detected — despawning ",color:"dark_green"},{nbt:"item.components.\"minecraft:custom_name\"",entity:"@s",interpret:true},{text:".",color:"dark_green"}]
scoreboard players set #ndur ec.temp 50
execute as @a[tag=companion.owner] run scoreboard players set #nttl ec.temp 600
execute as @a[tag=companion.owner] run function evercraft:util/notify/emit_keep

execute as @a[tag=companion.owner] run function evercraft:companions/handler/active/abilities/reset_perks
tag @a[tag=companion.owner] remove companion.activepet
execute as @a[tag=companion.owner] run function evercraft:companions/handler/menu_v2/close

kill @s