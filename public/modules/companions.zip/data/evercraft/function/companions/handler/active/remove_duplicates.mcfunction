scoreboard players operation #Search companion.id = @a[tag=companion.owner] companion.id

tellraw @a[tag=companion.owner] [{text:"Multiple pets have been detected and will all be despawned!\nNow despawning", color:"dark_green"},{nbt:"item.components.\"minecraft:custom_name\"", entity:"@s", interpret:true},{text:".", color:"dark_green"}]

execute as @a[tag=companion.owner] run function evercraft:companions/handler/active/abilities/reset_perks
tag @a[tag=companion.owner] remove companion.activepet
execute as @a[tag=companion.owner] run function evercraft:companions/handler/menu_v2/close

kill @s