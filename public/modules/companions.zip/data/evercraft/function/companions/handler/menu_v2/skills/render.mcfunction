# SP5 — Skills: render the 6-slot ability grid for the current page (companion.skillpage 0/1).
# Run as player, facing-anchor context from open_tab_skills. 3x2 grid. Each slot interaction is tagged
# companion.skill_btn (NOT companion.skillslot — DATA-MODEL §4-A tag/objective clash avoidance) and
# stamped companion.skillidx (the global 0-11 slot index). A filled slot (idx < companion.slots) shows a
# star icon + (active border if idx == companion.skillslot); a locked slot shows a dim padlock.
# SP1 owns the ability icon/name data — SP5 renders a generic icon as a thin renderer placeholder.

scoreboard players operation #Search companion.id = @s companion.id

# Title.
execute rotated ~ 0 positioned ^ ^1.95 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.skill_title"],billboard:"center",text:[{text:"✦ Ability Slots",color:"light_purple",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.40f,0.40f,0.40f]}}
scoreboard players operation @e[type=text_display,tag=companion.skill_title,distance=..5] companion.id = @s companion.id

# Base slot index for this page (page 0 → 0..5, page 1 → 6..11).
scoreboard players operation #cc_base companion.menu = @s companion.skillpage
scoreboard players operation #cc_base companion.menu *= #6 companion.calc

# Render the 6 slots (2 rows x 3 cols). Each render_slot reads #cc_slotidx + grid offsets.
scoreboard players operation #cc_slotidx companion.menu = #cc_base companion.menu
function evercraft:companions/handler/menu_v2/skills/render_slot {col:0,row:0}
scoreboard players add #cc_slotidx companion.menu 1
function evercraft:companions/handler/menu_v2/skills/render_slot {col:1,row:0}
scoreboard players add #cc_slotidx companion.menu 1
function evercraft:companions/handler/menu_v2/skills/render_slot {col:2,row:0}
scoreboard players add #cc_slotidx companion.menu 1
function evercraft:companions/handler/menu_v2/skills/render_slot {col:0,row:1}
scoreboard players add #cc_slotidx companion.menu 1
function evercraft:companions/handler/menu_v2/skills/render_slot {col:1,row:1}
scoreboard players add #cc_slotidx companion.menu 1
function evercraft:companions/handler/menu_v2/skills/render_slot {col:2,row:1}

# Page toggle (◀ / Page N / ▶).
execute rotated ~ 0 positioned ^ ^0.95 ^1.74 positioned ^0.55 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.skill_pageprev_text"],billboard:"center",text:[{text:"◀",color:"aqua"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
execute rotated ~ 0 positioned ^ ^0.92 ^1.76 positioned ^0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.skill_pageprev_click"],width:0.22f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^ ^0.95 ^1.74 positioned ^-0.55 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.skill_pagenext_text"],billboard:"center",text:[{text:"▶",color:"aqua"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
execute rotated ~ 0 positioned ^ ^0.92 ^1.76 positioned ^-0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.skill_pagenext_click"],width:0.22f,height:0.12f,response:1b}
function evercraft:companions/handler/menu_v2/skills/render_page_label
scoreboard players operation @e[type=text_display,tag=companion.skill_pageprev_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.skill_pageprev_click,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=text_display,tag=companion.skill_pagenext_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.skill_pagenext_click,distance=..5] companion.id = @s companion.id

# SP8 — Chip Eject affordance. Shown only for the LIVE MAIN companion (the one whose per-instance chip
# ledger we can mutate) when it carries at least one chip-sourced slot. Ejecting returns the newest chip
# + costs -5 companion levels (eject_chip_slot, LIFO). Placed bottom-right, distinct from Back.
execute if entity @s[tag=companion.activepet] if score @s companion.careidx = @s companion.activeslot run function evercraft:companions/handler/menu_v2/skills/render_eject

# Back.
function evercraft:companions/handler/menu_v2/spawn_back_btn
