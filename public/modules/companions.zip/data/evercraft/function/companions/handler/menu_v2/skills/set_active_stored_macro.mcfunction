# SP5 — Skills: macro — write horn_active onto the stored Pets[$(careidx)] record. Run as player.
# Args: {careidx:N, active:N}.
$execute in overworld run data modify entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[$(careidx)].components."minecraft:custom_data".horn_active set value $(active)
