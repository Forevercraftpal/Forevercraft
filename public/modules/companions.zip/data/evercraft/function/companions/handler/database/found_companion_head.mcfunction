# ============================================================
# Found Companion Head — Process the placed block
# Run at the block position during raycast
# ============================================================
scoreboard players set #comp_found companion.calc 1

# Read profile from block entity before removing
data modify storage evercraft:companions temp_profile set from block ~ ~ ~ profile
data modify storage evercraft:companions temp_sig set from block ~ ~ ~ profile.properties[{name:"name"}].signature

# Remove the placed block
setblock ~ ~ ~ air

# Generate base item from loot table into barrel (overworld)
execute in overworld run data modify block 0 -63 0 Items set value []
function evercraft:companions/handler/database/generate_companion_item with storage evercraft:companions

# Override profile with the placed block's profile (preserves level/exp/textures)
execute in overworld run data modify block 0 -63 0 Items[0].components."minecraft:profile" set from storage evercraft:companions temp_profile

# Copy the complete item from barrel to storage (dimension-safe for later use)
execute in overworld run data modify storage evercraft:companions generatedItem set from block 0 -63 0 Items[0]
# Strip barrel Slot tag — item_display.item codec rejects items with extra fields
data remove storage evercraft:companions generatedItem.Slot
