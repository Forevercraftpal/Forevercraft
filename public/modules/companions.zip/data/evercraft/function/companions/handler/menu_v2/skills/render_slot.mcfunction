# SP5 — Skills: render one ability slot. Run as player. Macro: {col:0-2, row:0-1}.
# Reads #cc_slotidx companion.menu (the global 0-11 index for this cell). FILLED if
# #cc_slotidx < companion.slots; ACTIVE if #cc_slotidx == companion.skillslot. Spawns an icon
# text_display + a companion.skill_btn interaction stamped companion.skillidx for click routing.
# col 0/1/2 → X +0.55/0/-0.55 ; row 0/1 → Y 1.62/1.32. (3x2 grid, 6 slots/page.)

# Classify this slot, pick icon text + color.
scoreboard players set #cc_filled ec.temp 0
execute if score #cc_slotidx companion.menu < @s companion.slots run scoreboard players set #cc_filled ec.temp 1
scoreboard players set #cc_active ec.temp 0
execute if score #cc_slotidx companion.menu = @s companion.skillslot run scoreboard players set #cc_active ec.temp 1

data modify storage evercraft:companions skills.icon set value "🔒"
data modify storage evercraft:companions skills.color set value "dark_gray"
execute if score #cc_filled ec.temp matches 1 run data modify storage evercraft:companions skills.icon set value "✦"
execute if score #cc_filled ec.temp matches 1 run data modify storage evercraft:companions skills.color set value "light_purple"
execute if score #cc_filled ec.temp matches 1 if score #cc_active ec.temp matches 1 run data modify storage evercraft:companions skills.icon set value "★"
execute if score #cc_filled ec.temp matches 1 if score #cc_active ec.temp matches 1 run data modify storage evercraft:companions skills.color set value "gold"
execute store result storage evercraft:companions skills.idx int 1 run scoreboard players get #cc_slotidx companion.menu

# Forward col/row macro args into the render scratch for place_slot's positioning branch.
$data modify storage evercraft:companions skills.col set value $(col)
$data modify storage evercraft:companions skills.row set value $(row)

# Resolve the cell's X/Y offset from col/row, then spawn icon + hitbox.
function evercraft:companions/handler/menu_v2/skills/place_slot
