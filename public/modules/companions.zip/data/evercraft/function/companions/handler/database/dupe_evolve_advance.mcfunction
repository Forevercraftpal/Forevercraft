# Macro {pet_name, prog, thr, display}: store progress on the owned record + notify the player.
$execute in overworld run data modify entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(pet_name)"}}}].components."minecraft:custom_data".evo_prog set value $(prog)
$data modify storage evercraft:notify stage.c set value [{text:"⟳ ",color:"light_purple"},{text:"$(display)",color:"aqua"},{text:" — evolution ",color:"gray"},{text:"$(prog)/$(thr)",color:"yellow"},{text:" (duplicate absorbed)",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/companion/dupe_evolve_step
