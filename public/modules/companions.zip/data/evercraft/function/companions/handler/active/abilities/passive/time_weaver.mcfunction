# Time Weaver Pet Passive Abilities
# - Temporal Acceleration: Speed (0.11 → 0.15)
# - Effect: haste

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.time_weaver

effect give @s haste infinite 1 true

# Temporal Acceleration: Speed (0.11 → 0.15)
execute if score #value companion.calc matches 1..7 run return run attribute @s movement_speed base set 0.111
execute if score #value companion.calc matches 8..12 run return run attribute @s movement_speed base set 0.114
execute if score #value companion.calc matches 13..17 run return run attribute @s movement_speed base set 0.116
execute if score #value companion.calc matches 18..22 run return run attribute @s movement_speed base set 0.118
execute if score #value companion.calc matches 23..27 run return run attribute @s movement_speed base set 0.12
execute if score #value companion.calc matches 28..32 run return run attribute @s movement_speed base set 0.122
execute if score #value companion.calc matches 33..37 run return run attribute @s movement_speed base set 0.124
execute if score #value companion.calc matches 38..42 run return run attribute @s movement_speed base set 0.126
execute if score #value companion.calc matches 43..47 run return run attribute @s movement_speed base set 0.128
execute if score #value companion.calc matches 48..52 run return run attribute @s movement_speed base set 0.13
execute if score #value companion.calc matches 53..57 run return run attribute @s movement_speed base set 0.132
execute if score #value companion.calc matches 58..62 run return run attribute @s movement_speed base set 0.134
execute if score #value companion.calc matches 63..67 run return run attribute @s movement_speed base set 0.136
execute if score #value companion.calc matches 68..72 run return run attribute @s movement_speed base set 0.138
execute if score #value companion.calc matches 73..77 run return run attribute @s movement_speed base set 0.14
execute if score #value companion.calc matches 78..82 run return run attribute @s movement_speed base set 0.142
execute if score #value companion.calc matches 83..87 run return run attribute @s movement_speed base set 0.144
execute if score #value companion.calc matches 88..92 run return run attribute @s movement_speed base set 0.146
execute if score #value companion.calc matches 93..97 run return run attribute @s movement_speed base set 0.148
execute if score #value companion.calc matches 98..100 run return run attribute @s movement_speed base set 0.15
