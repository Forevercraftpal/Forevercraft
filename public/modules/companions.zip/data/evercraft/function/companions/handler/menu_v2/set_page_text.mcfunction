# Update the page info text display to show "Page X/Y"
# Called with storage {page:N, maxpage:N} macro
$execute as @e[type=text_display,tag=companion.menupageinfo,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s text set value {text:"Page $(page)/$(maxpage)",color:"gray"}
