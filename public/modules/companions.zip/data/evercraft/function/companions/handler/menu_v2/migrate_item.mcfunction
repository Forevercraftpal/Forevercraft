# Migrate old stick-based Companion Catalogue to new book-based version
# Run as player on join/reload
# Detects old stick/wfoas/wooden_sword catalogue and replaces with book version

# Check for old stick catalogue (clear 0 = count matching items without removing)
execute store result score #cc_migrate ec.temp run clear @s stick[custom_data~{CompanionMenuKey:true}] 0
execute if score #cc_migrate ec.temp matches 1.. run clear @s stick[custom_data~{CompanionMenuKey:true}] 1
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #cc_migrate ec.temp matches 1.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:companions/menu
execute if score #cc_migrate ec.temp matches 1.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:companions/menu
data modify storage evercraft:notify stage.c set value [{text:"Your Companion Catalogue has been upgraded!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #cc_migrate ec.temp matches 1.. run function evercraft:util/notify/emit

# Check for old warped_fungus_on_a_stick catalogue
execute store result score #cc_migrate ec.temp run clear @s warped_fungus_on_a_stick[custom_data~{CompanionMenuKey:true}] 0
execute if score #cc_migrate ec.temp matches 1.. run clear @s warped_fungus_on_a_stick[custom_data~{CompanionMenuKey:true}] 1
execute if score #cc_migrate ec.temp matches 1.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:companions/menu
execute if score #cc_migrate ec.temp matches 1.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:companions/menu
data modify storage evercraft:notify stage.c set value [{text:"Your Companion Catalogue has been upgraded!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #cc_migrate ec.temp matches 1.. run function evercraft:util/notify/emit

# Check for old wooden_sword catalogue
execute store result score #cc_migrate ec.temp run clear @s wooden_sword[custom_data~{CompanionMenuKey:true}] 0
execute if score #cc_migrate ec.temp matches 1.. run clear @s wooden_sword[custom_data~{CompanionMenuKey:true}] 1
execute if score #cc_migrate ec.temp matches 1.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:companions/menu
execute if score #cc_migrate ec.temp matches 1.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:companions/menu
data modify storage evercraft:notify stage.c set value [{text:"Your Companion Catalogue has been upgraded!",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #cc_migrate ec.temp matches 1.. run function evercraft:util/notify/emit
