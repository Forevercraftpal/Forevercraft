# Giraffe Pet Passive Abilities
# - Long Neck: Range (3.1 → 4.5)
# - Long Neck: Block range (4.6 → 6.0)
# - Effect: slow_falling

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.giraffe

effect give @s slow_falling infinite 0 true

# Long Neck: Range (3.1 → 4.5)
execute if score #value companion.calc matches 1..7 run attribute @s entity_interaction_range base set 3.142
execute if score #value companion.calc matches 8..12 run attribute @s entity_interaction_range base set 3.227
execute if score #value companion.calc matches 13..17 run attribute @s entity_interaction_range base set 3.298
execute if score #value companion.calc matches 18..22 run attribute @s entity_interaction_range base set 3.369
execute if score #value companion.calc matches 23..27 run attribute @s entity_interaction_range base set 3.439
execute if score #value companion.calc matches 28..32 run attribute @s entity_interaction_range base set 3.51
execute if score #value companion.calc matches 33..37 run attribute @s entity_interaction_range base set 3.581
execute if score #value companion.calc matches 38..42 run attribute @s entity_interaction_range base set 3.652
execute if score #value companion.calc matches 43..47 run attribute @s entity_interaction_range base set 3.722
execute if score #value companion.calc matches 48..52 run attribute @s entity_interaction_range base set 3.793
execute if score #value companion.calc matches 53..57 run attribute @s entity_interaction_range base set 3.864
execute if score #value companion.calc matches 58..62 run attribute @s entity_interaction_range base set 3.934
execute if score #value companion.calc matches 63..67 run attribute @s entity_interaction_range base set 4.005
execute if score #value companion.calc matches 68..72 run attribute @s entity_interaction_range base set 4.076
execute if score #value companion.calc matches 73..77 run attribute @s entity_interaction_range base set 4.146
execute if score #value companion.calc matches 78..82 run attribute @s entity_interaction_range base set 4.217
execute if score #value companion.calc matches 83..87 run attribute @s entity_interaction_range base set 4.288
execute if score #value companion.calc matches 88..92 run attribute @s entity_interaction_range base set 4.359
execute if score #value companion.calc matches 93..97 run attribute @s entity_interaction_range base set 4.429
execute if score #value companion.calc matches 98..100 run attribute @s entity_interaction_range base set 4.486

# Long Neck: Block range (4.6 → 6.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s block_interaction_range base set 4.642
execute if score #value companion.calc matches 8..12 run return run attribute @s block_interaction_range base set 4.727
execute if score #value companion.calc matches 13..17 run return run attribute @s block_interaction_range base set 4.798
execute if score #value companion.calc matches 18..22 run return run attribute @s block_interaction_range base set 4.869
execute if score #value companion.calc matches 23..27 run return run attribute @s block_interaction_range base set 4.939
execute if score #value companion.calc matches 28..32 run return run attribute @s block_interaction_range base set 5.01
execute if score #value companion.calc matches 33..37 run return run attribute @s block_interaction_range base set 5.081
execute if score #value companion.calc matches 38..42 run return run attribute @s block_interaction_range base set 5.152
execute if score #value companion.calc matches 43..47 run return run attribute @s block_interaction_range base set 5.222
execute if score #value companion.calc matches 48..52 run return run attribute @s block_interaction_range base set 5.293
execute if score #value companion.calc matches 53..57 run return run attribute @s block_interaction_range base set 5.364
execute if score #value companion.calc matches 58..62 run return run attribute @s block_interaction_range base set 5.434
execute if score #value companion.calc matches 63..67 run return run attribute @s block_interaction_range base set 5.505
execute if score #value companion.calc matches 68..72 run return run attribute @s block_interaction_range base set 5.576
execute if score #value companion.calc matches 73..77 run return run attribute @s block_interaction_range base set 5.646
execute if score #value companion.calc matches 78..82 run return run attribute @s block_interaction_range base set 5.717
execute if score #value companion.calc matches 83..87 run return run attribute @s block_interaction_range base set 5.788
execute if score #value companion.calc matches 88..92 run return run attribute @s block_interaction_range base set 5.859
execute if score #value companion.calc matches 93..97 run return run attribute @s block_interaction_range base set 5.929
execute if score #value companion.calc matches 98..100 run return run attribute @s block_interaction_range base set 5.986
