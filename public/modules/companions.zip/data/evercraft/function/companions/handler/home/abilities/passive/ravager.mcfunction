# Ravager Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.ravager

# Destructive Force: Attack damage (2.5 → 6.0)
$execute if score #value companion.calc matches 1..7 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.606 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.818 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.995 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.172 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.348 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.525 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.702 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.879 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.056 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.232 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.409 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.586 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.763 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.939 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 5.116 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 5.293 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 5.47 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 5.646 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 5.823 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 5.965 add_value

# Trampling Charge: KB (0.1 → 0.5)
$execute if score #value companion.calc matches 1..7 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.112 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.136 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.157 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.177 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.197 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.217 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.237 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.258 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.278 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.298 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.318 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.338 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.359 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.379 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.399 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.419 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.439 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.46 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.48 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s attack_knockback modifier add evercraft:home/slot$(ability_slot)/attack_knockback 0.496 add_value
