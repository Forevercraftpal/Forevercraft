# SP8 — Wayfarer Track: read reward label for table index #(ridx) into wf.label. Run anywhere.
# Macro arg: {ridx:N}. Copies track.rewards[ridx].label → wf.label for the cell render.
$data modify storage evercraft:companions wf.label set from storage evercraft:companions track.rewards[$(ridx)].label
