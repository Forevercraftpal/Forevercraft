# Deloris Pack — On Slot Click
# @s = player. dlpack_temp.slot = "s0"-"s4"

execute store result storage evercraft:companions dlpack_temp.pid int 1 run scoreboard players get @s companion.id
function evercraft:companions/handler/active/abilities/deloris_pack/handle_click with storage evercraft:companions dlpack_temp
