execute store result storage evercraft:companions math.sound_mimmicing int 0.1 run scoreboard players get #current_level companion.exp
execute store result score #sound_mimmicing companion.calc run data get storage evercraft:companions math.sound_mimmicing 2
scoreboard players add #sound_mimmicing companion.calc 10
execute store result storage evercraft:companions math.sound_mimmicing int 1 run scoreboard players get #sound_mimmicing companion.calc

data modify entity @s item.components."minecraft:lore"[7].extra[0].text set string storage evercraft:companions math.sound_mimmicing
data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:profile":{properties:[{},{value:"Sentinel"}]}}}].components."minecraft:lore"[7].extra[0].text set string storage evercraft:companions math.sound_mimmicing

execute as @a[tag=companion.owner, limit=1] at @s run function evercraft:companions/handler/active/abilities/passive/red_parrot