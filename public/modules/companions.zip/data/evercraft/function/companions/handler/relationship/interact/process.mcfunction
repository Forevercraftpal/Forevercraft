# Process petting interaction
# Run as player
# Gives +5 RP, 5 minute cooldown

# Skip if on cooldown
execute if score @s companion.interactcd matches 1.. run return fail

# Set cooldown (5 minutes = 6000 ticks)
# ONE-WRITER (R9): interactcd is SET here on a successful active-pet pet; decremented in
# handler/active/ai (active) + home/tick (home-only, disjoint by the !activepet gate).
scoreboard players set @s companion.interactcd 6000

# Load current RP
function evercraft:companions/handler/relationship/load_rp

# Store old level
scoreboard players operation #oldLevel companion.calc = @s companion.rellevel

# Add 5 RP for petting
scoreboard players add @s companion.rp 5

# Cap at 5000
execute if score @s companion.rp > #5000 companion.calc run scoreboard players set @s companion.rp 5000

# Save RP
function evercraft:companions/handler/relationship/save_rp

# Recalculate level
function evercraft:companions/handler/relationship/load_rp

# Effects
scoreboard players operation #Search companion.id = @s companion.id
execute at @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] run particle heart ~ ~0.5 ~ 0.2 0.2 0.2 0 2
execute at @s run function evercraft:util/sfx/pet_chime

# Message
data modify storage evercraft:notify stage.c set value [{text:"You pet "},{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:"! ",color:"white"},{text:"(+5 RP)",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Check for level up
execute unless score @s companion.rellevel = #oldLevel companion.calc run function evercraft:companions/handler/relationship/level_up

# SP2 Bond & Care: petting tops up happiness +50 (the anti-chore upkeep — one Pet + one Feed = full).
# Routed through the single happiness writer (bond/happiness/add), never a scattered scoreboard add.
function evercraft:companions/bond/happiness/add {amount:50}

# Return success for interaction tracking
return 1
