execute store result storage evercraft:companions math.detection_distance float 0.4 run scoreboard players get #current_level companion.exp
execute store result score #detection_distance companion.calc run data get storage evercraft:companions math.detection_distance 10
scoreboard players add #detection_distance companion.calc 100
execute store result storage evercraft:companions math.detection_distance float 0.1 run scoreboard players get #detection_distance companion.calc

data modify entity @s item.components."minecraft:lore"[5].extra[0].text set string storage evercraft:companions math.detection_distance 0 -3
data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:profile":{properties:[{},{value:"Monolith"}]}}}].components."minecraft:lore"[5].extra[0].text set string storage evercraft:companions math.detection_distance 0 -3

execute as @a[tag=companion.owner, limit=1] at @s run function evercraft:companions/handler/active/abilities/passive/warden