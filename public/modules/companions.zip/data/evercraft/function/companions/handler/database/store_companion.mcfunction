playsound entity.player.levelup master @s ~ ~ ~ 1 2
tellraw @s [{text: "Added ",color:"dark_green"},{nbt:"generatedItem.components.\"minecraft:custom_name\"",storage:"evercraft:companions",interpret:true},{text:" to The Companion Catalogue.",color:"dark_green"}]

scoreboard players add @s companion.count 1
function evercraft:milestones/increment/companion_found

# Give Companion Catalogue on first companion discovery
execute if score @s companion.count matches 1 run loot give @s loot evercraft:companions/menu
execute if score @s companion.count matches 1 run tellraw @s [{text:"You received ",color:"green"},{text:"The Companion Catalogue",color:"gold"},{text:"! Use it to summon and manage your companions.",color:"green"}]

# Build database entry from the generated item in storage
data modify storage evercraft:companions modifyCompanion set from storage evercraft:companions generatedItem
data modify storage evercraft:companions modifyCompanion.components."minecraft:custom_data" set value {companionMenu:true, companion:true}
# Store pet signature in custom_data for reliable matching (profile properties may be lost to resolution)
data modify storage evercraft:companions modifyCompanion.components."minecraft:custom_data".pet_name set from storage evercraft:companions name
data modify storage evercraft:companions modifyCompanion.components."minecraft:lore"[-1] set value {text:"Click to summon", color:"yellow", italic: false}

execute in overworld run data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets append from storage evercraft:companions modifyCompanion
