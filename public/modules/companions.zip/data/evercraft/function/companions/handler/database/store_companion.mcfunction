# Catalogue-add cue is fired by the new-species reveal in check_duplicates (fx/collect/companion_dex);
# this store path also runs for evolution-sync (as a display entity) and dupe-keep, so it carries no
# un-gated sound of its own — the notify line below is the shared "added to catalogue" feedback.
data modify storage evercraft:notify stage.c set value [{text:"Added ",color:"dark_green"},{nbt:"generatedItem.components.\"minecraft:custom_name\"",storage:"evercraft:companions",interpret:true},{text:" to The Companion Catalogue.",color:"dark_green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

scoreboard players add @s companion.count 1
# Realm milestone moved to the new-discovery callers only 2026-05-25
# (check_duplicates.mcfunction + wild_companions/capture/add_to_roster.mcfunction)
# so duplicate-keep and evolution-sync don't inflate the realm pet counter

# Give Companion Catalogue on first companion discovery (with inv-full hygiene)
execute if score @s companion.count matches 1 store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s companion.count matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:companions/menu
execute if score @s companion.count matches 1 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:companions/menu
data modify storage evercraft:notify stage.c set value [{text:"You received ",color:"green"},{text:"The Companion Catalogue",color:"gold"},{text:"! Use it to summon and manage your companions.",color:"green"}]
scoreboard players set #ndur ec.temp 50
execute if score @s companion.count matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"(Inventory full — Catalogue dropped at your feet)",color:"yellow",italic:true}]
scoreboard players set #ndur ec.temp 40
execute if score @s companion.count matches 1 if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit

# Build database entry from the generated item in storage
data modify storage evercraft:companions modifyCompanion set from storage evercraft:companions generatedItem
data modify storage evercraft:companions modifyCompanion.components."minecraft:custom_data" set value {companionMenu:true, companion:true}
# Store pet signature in custom_data for reliable matching (profile properties may be lost to resolution)
data modify storage evercraft:companions modifyCompanion.components."minecraft:custom_data".pet_name set from storage evercraft:companions name
# Preserve the shiny flag (Joseph 2026-06-06): the custom_data reset above drops it, but the shiny dex
# (ec.comp_dex_shiny) and shiny-aware dedup rely on it. Re-stamp if the source item was a shiny variant.
execute if data storage evercraft:companions generatedItem.components."minecraft:custom_data"{shiny:1b} run data modify storage evercraft:companions modifyCompanion.components."minecraft:custom_data".shiny set value true
data modify storage evercraft:companions modifyCompanion.components."minecraft:lore"[-1] set value {text:"Click to summon", color:"yellow", italic: false}

execute in overworld run data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets append from storage evercraft:companions modifyCompanion
