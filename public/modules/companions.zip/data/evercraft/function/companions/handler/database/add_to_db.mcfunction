advancement revoke @s only evercraft:companions/add_to_player
execute if data storage evercraft:companions uninstalled run return fail

# Clear stale data before raycast
data remove storage evercraft:companions generatedItem
data remove storage evercraft:companions name

# Try raycast to find the placed companion head
scoreboard players set #comp_found companion.calc 0
scoreboard players set #comp_ray companion.calc 0
execute at @s anchored eyes run function evercraft:companions/handler/database/raycast_companion

# Fallback: grid scan if raycast missed (oblique angles)
execute unless score #comp_found companion.calc matches 1 at @s align xyz run function evercraft:companions/handler/database/scan_for_head

# Safety check — if neither method found the block, bail
execute unless score #comp_found companion.calc matches 1 run return fail

# Check pet count (in overworld where marker lives)
scoreboard players operation #Search companion.id = @s companion.id
execute in overworld store result score @s companion.count if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[]

data modify storage evercraft:notify stage.c set value [{text:"You have reached the maximum amount of companions!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s companion.count matches 150.. run return run function evercraft:util/notify/emit

# Get companion name from the generated item in storage
data modify storage evercraft:companions name set from storage evercraft:companions generatedItem.components."minecraft:profile".properties[{name:"name"}].value
execute if score @s companion.count matches 0..149 run return run function evercraft:companions/handler/database/check_duplicates with storage evercraft:companions
