# Frozen Zombie - Frost Touch: On hit, chance to apply Slowness I
# Chance scales 20% → 50%, duration 3s → 6s

advancement revoke @s only evercraft:companions/abilities/frozen_zombie
scoreboard players operation #Search companion.id = @s companion.id

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value

scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

execute if score #value companion.calc matches 1..7 if predicate {condition:"random_chance",chance:0.2} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 3 0 true
execute if score #value companion.calc matches 8..12 if predicate {condition:"random_chance",chance:0.216} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 3 0 true
execute if score #value companion.calc matches 13..17 if predicate {condition:"random_chance",chance:0.232} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 3 0 true
execute if score #value companion.calc matches 18..22 if predicate {condition:"random_chance",chance:0.247} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 3 0 true
execute if score #value companion.calc matches 23..27 if predicate {condition:"random_chance",chance:0.263} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 4 0 true
execute if score #value companion.calc matches 28..32 if predicate {condition:"random_chance",chance:0.279} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 4 0 true
execute if score #value companion.calc matches 33..37 if predicate {condition:"random_chance",chance:0.295} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 4 0 true
execute if score #value companion.calc matches 38..42 if predicate {condition:"random_chance",chance:0.311} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 4 0 true
execute if score #value companion.calc matches 43..47 if predicate {condition:"random_chance",chance:0.326} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 4 0 true
execute if score #value companion.calc matches 48..52 if predicate {condition:"random_chance",chance:0.342} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 5 0 true
execute if score #value companion.calc matches 53..57 if predicate {condition:"random_chance",chance:0.358} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 5 0 true
execute if score #value companion.calc matches 58..62 if predicate {condition:"random_chance",chance:0.374} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 5 0 true
execute if score #value companion.calc matches 63..67 if predicate {condition:"random_chance",chance:0.389} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 5 0 true
execute if score #value companion.calc matches 68..72 if predicate {condition:"random_chance",chance:0.405} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 5 0 true
execute if score #value companion.calc matches 73..77 if predicate {condition:"random_chance",chance:0.421} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 6 0 true
execute if score #value companion.calc matches 78..82 if predicate {condition:"random_chance",chance:0.437} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 6 0 true
execute if score #value companion.calc matches 83..87 if predicate {condition:"random_chance",chance:0.453} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 6 0 true
execute if score #value companion.calc matches 88..92 if predicate {condition:"random_chance",chance:0.468} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 6 0 true
execute if score #value companion.calc matches 93..97 if predicate {condition:"random_chance",chance:0.484} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 6 0 true
execute if score #value companion.calc matches 98..100 if predicate {condition:"random_chance",chance:0.5} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 6 0 true
