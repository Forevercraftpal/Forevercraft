# Wolf Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.wolf

# Pack Leader: Attack damage (1.5 → 4.0)
$execute if score #value companion.calc matches 1..7 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.576 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.727 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.854 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.98 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.106 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.232 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.359 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.485 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.611 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.737 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.864 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.99 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.116 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.242 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.369 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.495 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.621 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.747 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.874 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.975 add_value
