# OPT: Consolidated pet slot left-click handler
# Runs as: clicked interaction entity (companion.petclick with attack data)
# Reads slot score, writes to storage, dispatches via macro

# Store slot index to storage for macro call
execute store result storage evercraft:companions click.slot int 1 run scoreboard players get @s companion.slot

# Dispatch to companion_info_chat with slot as macro arg (it clears attack data internally)
function evercraft:companions/handler/menu_v2/companion_info_chat with storage evercraft:companions click
