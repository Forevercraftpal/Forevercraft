# Mooshroom Pet Passive Abilities
# - Effect: regeneration

tag @s add companion.mooshroom

effect give @s regeneration infinite 0 true

