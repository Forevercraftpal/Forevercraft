# Toggle active pet visibility
# Called as the player

# Must have an active pet
data modify storage evercraft:notify stage.c set value [{text:"Summon a pet first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @s[tag=companion.activepet] run return run function evercraft:util/notify/emit

# Toggle: if currently hidden, make visible; if visible, make hidden
# Store current state before toggling to prevent double-execution
execute store success score #didToggle companion.calc if entity @s[tag=companion.hidden]
execute if score #didToggle companion.calc matches 1 run function evercraft:companions/handler/player/visible_status
execute if score #didToggle companion.calc matches 0 run function evercraft:companions/handler/player/hidden_status

# Update the button text in menu to reflect new state
scoreboard players operation #Search companion.id = @s companion.id
execute if entity @s[tag=companion.hidden] as @e[type=text_display,tag=companion.menuvistext,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s text set value {text:"Hidden",color:"red",bold:true}
execute unless entity @s[tag=companion.hidden] as @e[type=text_display,tag=companion.menuvistext,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s text set value {text:"Visible",color:"green",bold:true}
