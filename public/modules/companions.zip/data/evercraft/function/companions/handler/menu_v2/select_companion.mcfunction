# Handle pet slot click
# Called as the interaction entity with {slot:N} macro
# $slot = 0-47 (index in MenuDisplay storage)

# Clear the interaction data so it doesn't trigger again
data remove entity @s interaction

# Play click sound
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id] at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.6

# Calculate actual pet index based on page
# Page 1: slots 0-47 = pets 0-47
# Page 2: slots 0-47 = pets 48-95
$execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id] run function evercraft:companions/handler/menu_v2/spawn_selected_companion {slot:$(slot)}
