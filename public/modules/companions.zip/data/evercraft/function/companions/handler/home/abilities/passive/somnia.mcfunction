# Somnia Pet Passive Abilities (Mythical — Gacha Exclusive)
# - Dreamshift: 5% chance teleport behind attacker when hit (handled by on_hurt)
# - Lullaby: 3% chance hostile mobs within 8b get Slowness V (1s)
# - Eternal Dream: Luck 1.0 -> 9.0

tag @s add companion.somnia

# Lullaby - 3% chance Slowness V on nearby hostiles
execute store result score #lullaby_roll ec.temp run random value 1..100
execute if score #lullaby_roll ec.temp matches 1..3 run effect give @e[type=#minecraft:hostile,distance=..8] slowness 1 4 true

# Eternal Dream - Luck scaling (1.0 -> 9.0)
$execute if score #value companion.calc matches 1..10 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1 add_value
$execute if score #value companion.calc matches 11..20 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.889 add_value
$execute if score #value companion.calc matches 21..30 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.778 add_value
$execute if score #value companion.calc matches 31..40 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.667 add_value
$execute if score #value companion.calc matches 41..50 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.556 add_value
$execute if score #value companion.calc matches 51..60 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 5.444 add_value
$execute if score #value companion.calc matches 61..70 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 6.333 add_value
$execute if score #value companion.calc matches 71..80 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 7.222 add_value
$execute if score #value companion.calc matches 81..90 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 8.111 add_value
$execute if score #value companion.calc matches 91..100 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 9 add_value
