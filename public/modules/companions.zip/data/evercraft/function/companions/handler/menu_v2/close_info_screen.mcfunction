# Close Pet Info Overlay — Restore pet grid
# Run as: player in menu with companion.infoscreen tag
# Requires: #Search companion.id already set

tag @s remove companion.infoscreen

# Kill all overlay text entities
kill @e[type=text_display,tag=companion.infooverlay,predicate=evercraft:companions/check_id]

# Restore pet grid visibility
execute as @e[type=item_display,tag=companion.petslot,predicate=evercraft:companions/check_id] run data modify entity @s transformation.scale set value [0.3f,0.3f,0.3f]
execute as @e[type=interaction,tag=companion.petclick,predicate=evercraft:companions/check_id] run data modify entity @s width set value 0.55f
execute as @e[type=interaction,tag=companion.petclick,predicate=evercraft:companions/check_id] run data modify entity @s height set value 0.55f

# Restore ? button text
execute as @e[type=text_display,tag=companion.menuinfotext,predicate=evercraft:companions/check_id] run data modify entity @s text set value [{text:"[",color:"dark_gray"},{text:"?",color:"yellow",bold:true},{text:"]",color:"dark_gray"}]

# Restore title
execute as @e[type=text_display,tag=companion.menutitle,predicate=evercraft:companions/check_id] run data modify entity @s text set value {text:"The Companion Catalogue",color:"gold",bold:true}

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.2
