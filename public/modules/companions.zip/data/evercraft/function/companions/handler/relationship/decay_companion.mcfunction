# Apply RP decay to player's active pet
# deprecated — no longer scheduled (SP2 Bond & Care retired RP decay; bond RP is now monotonic).
# Kept as the documented retired path; neglect now decays companion.happiness, not RP.
# Run as player

scoreboard players operation #Search companion.id = @s companion.id

# Load current RP
function evercraft:companions/handler/relationship/load_rp

# Bonded pets (max relationship level 5) are immune to decay
execute if score @s companion.rellevel matches 5.. run return 0

# Store old level
scoreboard players operation #oldLevel companion.calc = @s companion.rellevel

# Decay by 25 RP per hour
scoreboard players remove @s companion.rp 25

# Minimum 0
execute if score @s companion.rp < #0 companion.calc run scoreboard players set @s companion.rp 0

# Save
function evercraft:companions/handler/relationship/save_rp

# Recalculate level
function evercraft:companions/handler/relationship/load_rp

# Check if level dropped
execute unless score @s companion.rellevel = #oldLevel companion.calc if score @s companion.rellevel < #oldLevel companion.calc run function evercraft:companions/handler/relationship/level_down
