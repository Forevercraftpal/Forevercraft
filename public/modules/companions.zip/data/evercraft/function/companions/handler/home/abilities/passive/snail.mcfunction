# Shade Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.shade

# Shadow Step: Sneak speed (0.335 → 1.0)
$execute if score #value companion.calc matches 1..7 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.355 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.395 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.429 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.463 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.496 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.53 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.563 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.597 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.631 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.664 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.698 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.731 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.765 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.798 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.832 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.866 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.899 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.933 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.966 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s sneaking_speed modifier add evercraft:home/slot$(ability_slot)/sneaking_speed 0.993 add_value
