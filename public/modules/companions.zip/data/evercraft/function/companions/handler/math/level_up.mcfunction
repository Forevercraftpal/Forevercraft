scoreboard players operation #current_exp companion.exp -= #exp_to_next_level companion.exp

scoreboard players set #exp_to_next_level companion.calc 2
scoreboard players operation #next_level companion.calc = #current_level companion.exp
scoreboard players add #next_level companion.calc 1

scoreboard players operation #exp_to_next_level companion.calc *= #next_level companion.calc
scoreboard players operation #exp_to_next_level companion.calc *= #next_level companion.calc

scoreboard players set #term2 companion.calc 4
scoreboard players operation #term2 companion.calc *= #next_level companion.calc

scoreboard players operation #exp_to_next_level companion.calc += #term2 companion.calc

scoreboard players operation #exp_to_next_level companion.calc += #10 companion.calc

scoreboard players operation #exp_to_next_level companion.exp = #exp_to_next_level companion.calc
scoreboard players add #current_level companion.exp 1

# Forever Coin milestones at 25/50/75/100
function evercraft:coins/pet_milestone

execute if score #current_exp companion.exp >= #exp_to_next_level companion.exp run function evercraft:companions/handler/math/level_up