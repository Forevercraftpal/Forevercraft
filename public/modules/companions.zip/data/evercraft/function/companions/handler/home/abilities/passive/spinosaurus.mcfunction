# Titan Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.titan

# Giant's Stature: Scale (1.025 → 1.5)
$execute if score #value companion.calc matches 1..7 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.039 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.068 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.092 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.116 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.14 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.164 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.188 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.212 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.236 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.26 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.284 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.308 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.332 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.356 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.38 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.404 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.428 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.452 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.476 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 1.495 add_value
