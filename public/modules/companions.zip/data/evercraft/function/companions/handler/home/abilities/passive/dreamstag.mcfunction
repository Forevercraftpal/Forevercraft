# Dreamstag Pet Passive Abilities (Mythical — Gacha Exclusive)
# - Dreamwalker's Grace: Resistance I + Regeneration I on grass/dirt
# - Ethereal Leap: Jump strength scaling (0.5 -> 1.5)
# - Dream Weave: Luck 1.0 -> 9.0

tag @s add companion.dreamstag

# Dreamwalker's Grace - Resistance I + Regeneration I on grass/dirt
execute if block ~ ~-1 ~ #evercraft:natural_ground run effect give @s resistance 5 0 true
execute if block ~ ~-1 ~ #evercraft:natural_ground unless score @s ec.h_regen matches 2.. run effect give @s regeneration 5 0 true

# Ethereal Leap - Jump strength scaling (0.5 -> 1.5)
$execute if score #value companion.calc matches 1..10 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump 0.5 add_value
$execute if score #value companion.calc matches 11..20 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump 0.611 add_value
$execute if score #value companion.calc matches 21..30 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump 0.722 add_value
$execute if score #value companion.calc matches 31..40 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump 0.833 add_value
$execute if score #value companion.calc matches 41..50 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump 0.944 add_value
$execute if score #value companion.calc matches 51..60 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump 1.056 add_value
$execute if score #value companion.calc matches 61..70 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump 1.167 add_value
$execute if score #value companion.calc matches 71..80 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump 1.278 add_value
$execute if score #value companion.calc matches 81..90 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump 1.389 add_value
$execute if score #value companion.calc matches 91..100 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump 1.5 add_value

# Dream Weave - Luck scaling (1.0 -> 9.0)
$execute if score #value companion.calc matches 1..10 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1 add_value
$execute if score #value companion.calc matches 11..20 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.889 add_value
$execute if score #value companion.calc matches 21..30 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.778 add_value
$execute if score #value companion.calc matches 31..40 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.667 add_value
$execute if score #value companion.calc matches 41..50 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.556 add_value
$execute if score #value companion.calc matches 51..60 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 5.444 add_value
$execute if score #value companion.calc matches 61..70 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 6.333 add_value
$execute if score #value companion.calc matches 71..80 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 7.222 add_value
$execute if score #value companion.calc matches 81..90 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 8.111 add_value
$execute if score #value companion.calc matches 91..100 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 9 add_value
