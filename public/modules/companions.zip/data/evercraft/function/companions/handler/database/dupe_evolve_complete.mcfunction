# Macro {pet_name, display}: evolve the owned record — mark evolved, clear progress, apply Ascended name.
# The evolved flag + name live in the record's custom_data/custom_name, so on_summon lights up its abilities
# and the evolution travels with the companion if traded.
$execute in overworld run data modify entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(pet_name)"}}}].components."minecraft:custom_data".evolved set value true
$execute in overworld run data modify entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(pet_name)"}}}].components."minecraft:custom_data".evo_prog set value 0
$execute in overworld run data modify entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(pet_name)"}}}].components."minecraft:custom_name" set value [{"text":"✦ ","color":"light_purple","italic":false},{"text":"Ascended $(display)","color":"gold","bold":true,"italic":false}]
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
$title @s title [{"text":"✦ ","color":"light_purple"},{"text":"$(display) Ascended!","color":"gold"}]
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"$(display)",color:"aqua"},{text:" reached its evolved form through devotion!",color:"gray"}]
scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/companion/dupe_evolve_done
