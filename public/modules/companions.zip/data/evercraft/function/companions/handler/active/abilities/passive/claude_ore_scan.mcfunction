# Claude Ore Sight - Scan for ores within range
# Called with macro: {range} = scan radius in blocks
# Scatters probes on XZ plane, scans columns around player Y level
# Spawns glowing armor stands at detected ore positions (10s lifetime)

# Store player Y for probe repositioning
execute store result score #playerY companion.calc run data get entity @s Pos[1]

# Summon 12 probe markers to scatter and check for ores
summon marker ~ ~ ~ {Tags:["companion.oreprobe"]}
summon marker ~ ~ ~ {Tags:["companion.oreprobe"]}
summon marker ~ ~ ~ {Tags:["companion.oreprobe"]}
summon marker ~ ~ ~ {Tags:["companion.oreprobe"]}
summon marker ~ ~ ~ {Tags:["companion.oreprobe"]}
summon marker ~ ~ ~ {Tags:["companion.oreprobe"]}
summon marker ~ ~ ~ {Tags:["companion.oreprobe"]}
summon marker ~ ~ ~ {Tags:["companion.oreprobe"]}
summon marker ~ ~ ~ {Tags:["companion.oreprobe"]}
summon marker ~ ~ ~ {Tags:["companion.oreprobe"]}
summon marker ~ ~ ~ {Tags:["companion.oreprobe"]}
summon marker ~ ~ ~ {Tags:["companion.oreprobe"]}

# Spread probes randomly within range on XZ (lands on surface)
$spreadplayers ~ ~ 0 $(range) false @e[type=marker, tag=companion.oreprobe]

# Move probes to player's Y level so column scan works underground
execute as @e[type=marker, tag=companion.oreprobe] store result entity @s Pos[1] double 1 run scoreboard players get #playerY companion.calc

# For each probe, scan the Y column below and above for ores
execute as @e[type=marker, tag=companion.oreprobe] at @s run function evercraft:companions/handler/active/abilities/passive/claude_ore_column

# Add ore markers to glow team (aqua outline)
team join companion.oreglow @e[type=armor_stand, tag=companion.oremarker]

# Clean up probes
kill @e[type=marker, tag=companion.oreprobe]

# Schedule marker cleanup (ore markers despawn after 10 seconds)
schedule function evercraft:companions/handler/active/abilities/passive/claude_ore_cleanup 10s replace
