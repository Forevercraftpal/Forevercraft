execute store result storage evercraft:companions math.sneak_increase float 2.33 run scoreboard players get #current_level companion.exp

data modify entity @s item.components."minecraft:lore"[5].extra[0].text set string storage evercraft:companions math.sneak_increase 0 -1
data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:profile":{properties:[{},{value:"Shade"}]}}}].components."minecraft:lore"[5].extra[0].text set string storage evercraft:companions math.sneak_increase 0 -1

execute as @a[tag=companion.owner, limit=1] at @s run function evercraft:companions/handler/active/abilities/passive/snail