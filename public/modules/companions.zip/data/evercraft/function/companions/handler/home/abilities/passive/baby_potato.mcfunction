# Baby Potato Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.baby_potato

# Tiny Spud: Scale (0.98 → 0.85)
$execute if score #value companion.calc matches 1..7 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.976 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.968 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.962 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.955 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.948 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.942 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.935 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.929 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.922 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.916 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.909 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.903 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.896 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.889 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.883 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.876 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.87 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.863 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.857 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.851 add_value
