# SP8 — Skills: render the "Eject Chip" button (live MAIN only). Run as player, facing-anchor context.
# Only shown when the live MAIN companion has at least one chip-sourced slot (a non-empty chip_slots
# ledger on the head). Clicking it ejects the NEWEST chip (LIFO) via skills/eject_chip_slot: returns the
# chip + costs -5 companion levels (floor 1). Tagged companion.skill_eject_click for click routing.

scoreboard players operation #Search companion.id = @s companion.id
# Gate: the live head must carry a chip-sourced slot.
execute unless data entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:custom_data".chip_slots[0] run return 0

execute rotated ~ 0 positioned ^ ^0.45 ^1.74 positioned ^-0.62 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.skill_eject_text"],billboard:"center",text:[{text:"⤓ Eject Chip",color:"red",italic:false},{text:"\n(-5 lvl, chip returned)",color:"gray",italic:false}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.20f,0.20f,0.20f]}}
execute rotated ~ 0 positioned ^ ^0.45 ^1.76 positioned ^-0.62 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.skill_eject_click"],width:0.34f,height:0.14f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.skill_eject_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.skill_eject_click,distance=..5] companion.id = @s companion.id
