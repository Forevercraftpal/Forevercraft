# ============================================================
# Home Companion — Hearth Comfort: recompute the owner's cached comfort score (SP9)
# Run as: player (the home owner), called from abilities/apply_all on every roster change
# (zone-enter / place / retrieve). ONE-writer of companion.hcomfort.
# ============================================================
# Caches the BEST placed home companion's (tier + bondLvl) into companion.hcomfort 0..11. The per-2s
# housing/zone/apply_buffs reads this cache and refreshes a modest short-duration effect, so the buff
# lapses cleanly when the player leaves the zone or the companion is retrieved (apply_all re-runs and the
# score drops). Cached here (not per-tick) to avoid per-tick NBT reads — recompute only on roster change.

# Reset to 0; an owner with no placed companions gets no Hearth Comfort.
scoreboard players set @s companion.hcomfort 0

# Accumulate the max contribution across this owner's placed home companions.
# #Search companion.id is already this owner's id (set by apply_all before calling us).
execute as @e[type=item_display, tag=HC.Head, predicate=evercraft:companions/check_id] run function evercraft:companions/handler/home/abilities/comfort_score_one
