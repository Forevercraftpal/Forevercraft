# Deloris Pack — Open Inventory
# @s = player with Deloris as active companion
# Deloris can carry 5 items (llama = pack animal)
# Uses storage-based system like buddy pack mule

# Verify Deloris is active
execute unless entity @s[tag=companion.deloris] run tellraw @s [{text:"[",color:"dark_gray"},{text:"Pets",color:"gold"},{text:"] ",color:"dark_gray"},{text:"Deloris must be your active companion!",color:"red"}]
execute unless entity @s[tag=companion.deloris] run return fail

# Safety: kill orphaned elements
execute at @s run kill @e[type=text_display,tag=ec.dlpack_el,distance=..5]
execute at @s run kill @e[type=interaction,tag=ec.dlpack_el,distance=..5]
execute at @s run kill @e[type=item_display,tag=ec.dlpack_el,distance=..5]

# Tag player as in deloris pack menu
tag @s add ec.dlpack_in_menu

# Initialize storage if not present (keyed by companion.id)
execute store result storage evercraft:companions dlpack_temp.pid int 1 run scoreboard players get @s companion.id
function evercraft:companions/handler/active/abilities/deloris_pack/init_storage with storage evercraft:companions dlpack_temp

# Spawn GUI
execute at @s run function evercraft:companions/handler/active/abilities/deloris_pack/spawn_gui

# Refresh slots
function evercraft:companions/handler/active/abilities/deloris_pack/refresh

# Start tick
schedule function evercraft:companions/handler/active/abilities/deloris_pack/tick 2t replace

playsound minecraft:entity.llama.chest master @s ~ ~ ~ 0.8 1.0
