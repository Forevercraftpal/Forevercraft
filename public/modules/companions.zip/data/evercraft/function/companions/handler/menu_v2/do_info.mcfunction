# Toggle pet info/memories GUI overlay
# Called as the player from on_info
# Toggles between pet grid and info screen overlay

# Must have an active pet
data modify storage evercraft:notify stage.c set value [{text:"Summon a pet first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @s[tag=companion.activepet] run return run function evercraft:util/notify/emit

scoreboard players operation #Search companion.id = @s companion.id

# Check if info screen is already open → close it and return
scoreboard players set #was_info companion.calc 0
execute if entity @s[tag=companion.infoscreen] run scoreboard players set #was_info companion.calc 1
execute if entity @s[tag=companion.infoscreen] run function evercraft:companions/handler/menu_v2/close_info_screen
execute if score #was_info companion.calc matches 1 run return 0

# Otherwise open the info screen
function evercraft:companions/handler/menu_v2/show_info_screen
