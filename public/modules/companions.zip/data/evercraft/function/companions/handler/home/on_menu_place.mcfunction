# ============================================================
# Home Companion — Handle "Place at Home" button click
# Run as: HC.MenuHome interaction entity
# Toggles the hc.placing mode — next pet slot click places at home
# ============================================================

data remove entity @s interaction

# Find the owner
scoreboard players operation #Search companion.id = @s companion.id
execute as @a[tag=companion.inmenuv2, predicate=evercraft:companions/check_id, limit=1] run function evercraft:companions/handler/home/toggle_place_mode
