# Wayfarer GUI — set #wf_state=2 (CLAIMED) if node $(tnode) is claimed (per-player advancement). Run as @s.
$execute if entity @s[advancements={evercraft:companions/track/claimed/n$(tnode)=true}] run scoreboard players set #wf_state ec.temp 2
