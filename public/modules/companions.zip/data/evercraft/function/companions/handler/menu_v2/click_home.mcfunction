# SP5 — Home view click dispatch. Run as player in menu with ec.bd_tab == 0 (replaces click_hub at tick:25).
# Routes: head click (companion.headslot) → open Care focused on that head; nav buttons → tabs.

scoreboard players operation #Search companion.id = @s companion.id

# === Head clicks → select that head as Care focus and open Care ===
# Each clicked head carries companion.headidx (0 main / 1 subA / 2 subB). on target runs as the player.
execute as @e[type=interaction,tag=companion.headslot,predicate=evercraft:companions/check_id] if data entity @s interaction run scoreboard players operation #cc_headidx ec.temp = @s companion.headidx
execute as @e[type=interaction,tag=companion.headslot,predicate=evercraft:companions/check_id] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/care/open_from_head
execute as @e[type=interaction,tag=companion.headslot,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction

# === Nav: Companions → the full roster grid (tab 1). The home view is now reached from the hub's
# top-left "Companions" button, so this nav surfaces the all-pets grid one level deeper (2026-06-06). ===
execute as @e[type=interaction,tag=companion.home_companions_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/open_tab_companions
execute as @e[type=interaction,tag=companion.home_companions_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === Nav: Journey ===
execute as @e[type=interaction,tag=companion.home_journey_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/open_tab_journey
execute as @e[type=interaction,tag=companion.home_journey_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === Nav: Care (defaults focus to MAIN) ===
execute as @e[type=interaction,tag=companion.home_care_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/care/open_default
execute as @e[type=interaction,tag=companion.home_care_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === Banner: Wayfarer's Track (SP8) → open the track view (tab 9) ===
# Select the cube that actually carries interaction data (nbt={interaction:{}}) rather than an arbitrary
# limit=1 of the 5 banner cubes — otherwise a clicked-but-not-first cube would never route (belt-and-
# suspenders alongside the spawn_home_nav hitbox recenter).
execute as @e[type=interaction,tag=companion.home_wayfarer_click,predicate=evercraft:companions/check_id,nbt={interaction:{}},limit=1] on target run function evercraft:companions/handler/menu_v2/open_tab_wayfarer
execute as @e[type=interaction,tag=companion.home_wayfarer_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction

# Clear any lingering interaction data on home elements (prevent re-trigger).
execute as @e[type=interaction,tag=companion.home_btn,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction
