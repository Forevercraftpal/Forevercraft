# SP5 — Journey: Sub-A in-flight status ("<name> — back in ~N min"). Run as player.
# journey.mins (set by render_slot_a) carries the minutes-left. Pulls the sub's name from its sent slot.
data modify storage evercraft:companions journey.subname set value "Your companion"
execute store result storage evercraft:companions journey.journey_slot int 1 run scoreboard players get @s companion.jA_slot
execute in overworld run function evercraft:companions/journey/get_subname with storage evercraft:companions journey
function evercraft:companions/handler/menu_v2/journey/status_inflight_a_text with storage evercraft:companions journey
