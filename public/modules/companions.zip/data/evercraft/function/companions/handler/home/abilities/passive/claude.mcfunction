# Claude Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.claude

effect give @s night_vision infinite 1 true

# [Home skip: active helper] # Ore Sight - Kill existing markers and rescan
# [Home skip: active helper] kill @e[type=armor_stand, tag=companion.oremarker, distance=..50]
# [Home skip: active helper] execute if score #value companion.calc matches 1..7 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:8}
# [Home skip: active helper] execute if score #value companion.calc matches 8..12 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:9}
# [Home skip: active helper] execute if score #value companion.calc matches 13..17 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:10}
# [Home skip: active helper] execute if score #value companion.calc matches 18..22 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:11}
# [Home skip: active helper] execute if score #value companion.calc matches 23..27 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:11}
# [Home skip: active helper] execute if score #value companion.calc matches 28..32 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:12}
# [Home skip: active helper] execute if score #value companion.calc matches 33..37 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:13}
# [Home skip: active helper] execute if score #value companion.calc matches 38..42 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:14}
# [Home skip: active helper] execute if score #value companion.calc matches 43..47 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:15}
# [Home skip: active helper] execute if score #value companion.calc matches 48..52 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:15}
# [Home skip: active helper] execute if score #value companion.calc matches 53..57 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:16}
# [Home skip: active helper] execute if score #value companion.calc matches 58..62 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:17}
# [Home skip: active helper] execute if score #value companion.calc matches 63..67 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:18}
# [Home skip: active helper] execute if score #value companion.calc matches 68..72 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:19}
# [Home skip: active helper] execute if score #value companion.calc matches 73..77 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:19}
# [Home skip: active helper] execute if score #value companion.calc matches 78..82 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:20}
# [Home skip: active helper] execute if score #value companion.calc matches 83..87 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:21}
# [Home skip: active helper] execute if score #value companion.calc matches 88..92 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:22}
# [Home skip: active helper] execute if score #value companion.calc matches 93..97 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:23}
# [Home skip: active helper] execute if score #value companion.calc matches 98..100 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:23}

# Persistent Helper: Attack damage (1.5 → 3.5)
$execute if score #value companion.calc matches 1..7 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.561 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.682 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.783 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.884 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.985 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.086 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.187 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.288 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.389 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.49 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.591 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.692 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.793 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.894 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.995 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.096 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.197 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.298 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.399 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.48 add_value
