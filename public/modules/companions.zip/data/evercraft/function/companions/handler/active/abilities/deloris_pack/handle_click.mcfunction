# Deloris Pack — Handle Click (macro)
# $(pid) = player ID, $(slot) = s0-s4

# Snapshot whether slot has an item BEFORE either branch mutates it
$execute store success score #satch_op ec.temp if data storage evercraft:companions dlpack.$(pid).$(slot).name
$execute if score #satch_op ec.temp matches 1 run function evercraft:companions/handler/active/abilities/deloris_pack/retrieve with storage evercraft:companions dlpack_temp
$execute if score #satch_op ec.temp matches 0 run function evercraft:companions/handler/active/abilities/deloris_pack/store with storage evercraft:companions dlpack_temp

# Refresh
function evercraft:companions/handler/active/abilities/deloris_pack/refresh
