# SP5 — Journey: macro — Sub-B ready status text. Args: {subname:"..."}.
$data modify entity @n[type=text_display,tag=companion.jr_b_status,distance=..5] text set value [{text:"$(subname)",color:"green"},{text:" — ready to journey",color:"gray"}]
