# Wraith Pet Passive Abilities
# - Spectral Flurry: Attack speed (4.5 → 8.0)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.wraith

# Spectral Flurry: Attack speed (4.5 → 8.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s attack_speed base set 4.606
execute if score #value companion.calc matches 8..12 run return run attribute @s attack_speed base set 4.818
execute if score #value companion.calc matches 13..17 run return run attribute @s attack_speed base set 4.995
execute if score #value companion.calc matches 18..22 run return run attribute @s attack_speed base set 5.172
execute if score #value companion.calc matches 23..27 run return run attribute @s attack_speed base set 5.348
execute if score #value companion.calc matches 28..32 run return run attribute @s attack_speed base set 5.525
execute if score #value companion.calc matches 33..37 run return run attribute @s attack_speed base set 5.702
execute if score #value companion.calc matches 38..42 run return run attribute @s attack_speed base set 5.879
execute if score #value companion.calc matches 43..47 run return run attribute @s attack_speed base set 6.056
execute if score #value companion.calc matches 48..52 run return run attribute @s attack_speed base set 6.232
execute if score #value companion.calc matches 53..57 run return run attribute @s attack_speed base set 6.409
execute if score #value companion.calc matches 58..62 run return run attribute @s attack_speed base set 6.586
execute if score #value companion.calc matches 63..67 run return run attribute @s attack_speed base set 6.763
execute if score #value companion.calc matches 68..72 run return run attribute @s attack_speed base set 6.939
execute if score #value companion.calc matches 73..77 run return run attribute @s attack_speed base set 7.116
execute if score #value companion.calc matches 78..82 run return run attribute @s attack_speed base set 7.293
execute if score #value companion.calc matches 83..87 run return run attribute @s attack_speed base set 7.47
execute if score #value companion.calc matches 88..92 run return run attribute @s attack_speed base set 7.646
execute if score #value companion.calc matches 93..97 run return run attribute @s attack_speed base set 7.823
execute if score #value companion.calc matches 98..100 run return run attribute @s attack_speed base set 7.965
