data modify storage evercraft:companions math.string set string entity @s item.components."minecraft:profile".properties[2].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int
scoreboard players operation #current_level companion.exp = #value companion.calc

execute if score #current_level companion.exp matches 100.. run return fail

data modify storage evercraft:companions math.string set string entity @s item.components."minecraft:profile".properties[3].signature
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int
scoreboard players operation #exp_to_next_level companion.exp = #value companion.calc

data modify storage evercraft:companions math.string set string entity @s item.components."minecraft:profile".properties[3].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int
scoreboard players operation #current_exp companion.exp = #value companion.calc

data modify storage evercraft:companions leveling.name set from entity @s item.components."minecraft:profile".properties[1].value

scoreboard players operation #current_exp companion.exp += #exp_to_gain companion.exp
execute if score #current_exp companion.exp >= #exp_to_next_level companion.exp run function evercraft:companions/handler/active/leveling/level_up

execute store result storage evercraft:companions leveling.current_exp int 1 run scoreboard players get #current_exp companion.exp
execute store result storage evercraft:companions leveling.exp_to_next_level int 1 run scoreboard players get #exp_to_next_level companion.exp

data modify entity @s item.components."minecraft:profile".properties[3].value set string storage evercraft:companions leveling.current_exp
data modify entity @s item.components."minecraft:profile".properties[3].signature set string storage evercraft:companions leveling.exp_to_next_level

function evercraft:companions/handler/active/leveling/update_database with storage evercraft:companions leveling