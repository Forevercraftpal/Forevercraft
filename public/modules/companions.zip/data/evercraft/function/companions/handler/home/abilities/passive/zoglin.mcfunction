# Zoglin Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.zoglin

# Rampaging Charge: Attack speed (4.2 → 6.0)
$execute if score #value companion.calc matches 1..7 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 4.255 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 4.364 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 4.455 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 4.545 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 4.636 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 4.727 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 4.818 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 4.909 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.0 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.091 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.182 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.273 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.364 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.455 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.545 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.636 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.727 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.818 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.909 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s attack_speed modifier add evercraft:home/slot$(ability_slot)/attack_speed 5.982 add_value
