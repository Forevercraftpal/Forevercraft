tellraw @s [{text:"You have converted your ",color:"dark_green"},{nbt:"item.components.\"minecraft:custom_name\"",entity:"@e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1]",interpret:true},{text:" back to an item.",color:"dark_green"}]

scoreboard players operation #Search companion.id = @s companion.id

# Copy pet item data to storage first (avoids multi-selector race condition)
data modify storage evercraft:companions converted_item set from entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item

# Summon item entity and set data from storage (reliable single source)
summon item ~ ~ ~ {PickupDelay:0s, Tags:[companion.convertedpet], Item:{id:"player_head", count:1b}}
data modify entity @e[distance=..10, type=item, tag=companion.convertedpet, limit=1] Item set from storage evercraft:companions converted_item

# Strip old custom_data, update lore, set companion flag
data remove entity @e[type=item, tag=companion.convertedpet, limit=1] Item.components."minecraft:custom_data"
data modify entity @e[type=item, tag=companion.convertedpet, limit=1] Item.components."minecraft:lore"[-1] set value {text:"Click to add to your pet list.", color:"yellow", italic:false}
data modify entity @e[type=item, tag=companion.convertedpet, limit=1] Item.components."minecraft:custom_data" set value {companion:1b}

# Clean up tag so future conversions don't collide
tag @e[type=item, tag=companion.convertedpet] remove companion.convertedpet

kill @e[type=wolf, tag=CompanionWolf, predicate=evercraft:companions/check_id]
kill @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id]
kill @e[type=interaction, tag=companion.petinteract, predicate=evercraft:companions/check_id]

function evercraft:companions/handler/active/abilities/reset_perks

tag @s remove companion.activepet
