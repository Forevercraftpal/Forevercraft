# Dupe-Evolution router (Joseph 2026-06-07; flag-refactor 2026-06-10).
# A duplicate of an owned, EVOLVABLE, not-yet-evolved companion advances its evolution. Rarer = fewer
# dupes. Once evolved (or non-evolvable), this path does nothing and the orchestrator (dupe_absorb) falls
# back to shards. Progress + evolved flag live on the DB record (custom_data) so they travel when traded.
# Run as: the player obtaining the dupe. pet_name string in storage evercraft:companions name.
#   Out: #de_applied ec.temp — 1 if this dupe advanced/completed evolution, else 0 (orchestrator reads it).
# NOTE (2026-06-10): every owned dupe now also FUSES (dupe_fuse) BEFORE this runs — both do double duty.
# This file no longer returns to duplicate_to_shard; dupe_absorb decides the shard fallback once both miss.
scoreboard players set #de_applied ec.temp 0

# Set up pet_name for the evolution helpers + our macro args
data modify storage evercraft:ce temp.pet_name set from storage evercraft:companions name
data modify storage evercraft:companions de.pet_name set from storage evercraft:companions name

# Is this species evolvable? check_mythical sets #ce_bit (a power of 2) only when pet_name maps to an evolved form.
scoreboard players set #ce_bit ec.ce_temp 0
function evercraft:companion_evolution/check_mythical
# Not evolvable -> no evo this dupe (orchestrator handles shard fallback).
execute if score #ce_bit ec.ce_temp matches 0 run return 0

# Load current state from the owned record: #de_done (1 if already evolved), #de_prog (current progress).
scoreboard players set #de_done ec.temp 0
scoreboard players set #de_prog ec.temp 0
function evercraft:companions/handler/database/dupe_evolve_load with storage evercraft:companions de
# Already evolved -> no evo this dupe (orchestrator handles shard fallback).
execute if score #de_done ec.temp matches 1 run return 0

# This dupe counts: advance progress by 1.
scoreboard players add #de_prog ec.temp 1

# Threshold by rarity tier (rarer = fewer). #pc_tier ec.var: 1 Common .. 6 Mythical.
data modify storage evercraft:companion_combat companion_name set from storage evercraft:companions name
function evercraft:companions/combat/get_tier_stats
scoreboard players set #de_thr ec.var 5
execute if score #pc_tier ec.var matches 3 run scoreboard players set #de_thr ec.var 4
execute if score #pc_tier ec.var matches 4 run scoreboard players set #de_thr ec.var 3
execute if score #pc_tier ec.var matches 5 run scoreboard players set #de_thr ec.var 3
execute if score #pc_tier ec.var matches 6 run scoreboard players set #de_thr ec.var 2

# Resolve display name + stash everything the macro writers need.
function evercraft:companion_evolution/get_display_name
data modify storage evercraft:companions de.display set from storage evercraft:ce temp.display_name
execute store result storage evercraft:companions de.prog int 1 run scoreboard players get #de_prog ec.temp
execute store result storage evercraft:companions de.thr int 1 run scoreboard players get #de_thr ec.var

# This dupe advances evolution either way -> flag it so the orchestrator skips the shard fallback.
scoreboard players set #de_applied ec.temp 1

# Not enough yet -> write progress + show "X/Y". Threshold reached -> evolve.
execute if score #de_prog ec.temp < #de_thr ec.var run return run function evercraft:companions/handler/database/dupe_evolve_advance with storage evercraft:companions de
execute if score #de_prog ec.temp >= #de_thr ec.var run return run function evercraft:companions/handler/database/dupe_evolve_complete with storage evercraft:companions de
