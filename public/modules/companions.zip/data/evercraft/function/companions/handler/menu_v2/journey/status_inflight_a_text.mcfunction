# SP5 — Journey: macro — write the Sub-A in-flight status text. Args: {subname:"...", mins:N}.
$data modify entity @n[type=text_display,tag=companion.jr_a_status,distance=..5] text set value [{text:"$(subname)",color:"aqua"},{text:" — back in ~$(mins) min",color:"gray"}]
