# Macro {pet_name}: read the owned DB record's evolution state.
# Sets #de_done ec.temp = 1 if the record is already evolved; #de_prog ec.temp = current evo_prog (unchanged if absent).
$execute in overworld if data entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(pet_name)",evolved:true}}}] run scoreboard players set #de_done ec.temp 1
$execute in overworld store result score #de_prog ec.temp run data get entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(pet_name)"}}}].components."minecraft:custom_data".evo_prog
