# SP5 — Home view: SUB-RIGHT empty placeholder (no companion assigned to journey slot B).
# 2026-06-06: NO head — blank slots are invisible (no Steve player_head), just a "+ Empty" label.
# Clicking it (headidx 2) arms assign-to-Sub-B mode + opens the roster to pick. Run as player. Tagged companion.homehead.

# "+ Empty" label — centered, paired side-by-side just RIGHT of center, mirroring slot A (2026-06-06;
# was out at ^-0.62).
execute rotated ~ 0 positioned ^ ^1.70 ^1.82 positioned ^-0.30 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.homehead","companion.menuelement","companion.tab_content","companion.homesubrname"],billboard:"center",text:[{text:"+ ",color:"dark_gray"},{text:"Empty",color:"gray",italic:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.22f,0.22f,0.22f]}}

execute rotated ~ 0 positioned ^ ^1.68 ^1.78 positioned ^-0.30 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.headslot","companion.menuelement","companion.tab_content","companion.homesubrclick"],width:0.28f,height:0.14f,response:1b}
scoreboard players set @n[type=interaction,tag=companion.homesubrclick,distance=..5] companion.headidx 2

tag @e[type=text_display,tag=companion.homesubrname,distance=..5] remove companion.homesubrname
tag @e[type=interaction,tag=companion.homesubrclick,distance=..5] remove companion.homesubrclick
