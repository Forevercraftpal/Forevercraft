# Regal Tiger Pet Lore Update
# Updates dynamic lore values on level-up

execute as @a[tag=companion.owner, limit=1] if score @s companion.id = #Search companion.id at @s run function evercraft:companions/handler/active/abilities/passive/regal_tiger
