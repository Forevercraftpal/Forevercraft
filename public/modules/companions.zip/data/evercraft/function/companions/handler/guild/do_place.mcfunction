# ============================================================
# Guild Companion — Execute placement from menu
# Run as: player, Macro: {slot} — MenuDisplay index clicked
# Called from spawn_selected_companion when gc.placing is active
# ============================================================

# Clear placing mode
tag @s remove gc.placing

# Calculate actual Pets[] index accounting for page: (page - 1) * 48 + slot
$scoreboard players set #gc_pets_idx gc.slot $(slot)
scoreboard players operation #gc_page_off gc.slot = @s companion.menupage
scoreboard players remove #gc_page_off gc.slot 1
scoreboard players operation #gc_page_off gc.slot *= #48 companion.calc
scoreboard players operation #gc_pets_idx gc.slot += #gc_page_off gc.slot

# Check this companion isn't already the active pet
execute if entity @s[tag=companion.activepet] store result score #gc_active_check gc.slot run scoreboard players get @s companion.activeslot
execute if entity @s[tag=companion.activepet] if score #gc_active_check gc.slot = #gc_pets_idx gc.slot run return run tellraw @s [{text:"[Guild] ",color:"dark_purple"},{text:"You can't place your active companion at the guild. Despawn it first.",color:"red"}]

# Store the computed Pets[] index to storage for the place function
execute store result storage evercraft:companions guild.pets_slot int 1 run scoreboard players get #gc_pets_idx gc.slot

# Call the main place function with the Pets[] index
function evercraft:guild/pets/place with storage evercraft:companions guild

# Close menu after placement
function evercraft:companions/handler/menu_v2/close
