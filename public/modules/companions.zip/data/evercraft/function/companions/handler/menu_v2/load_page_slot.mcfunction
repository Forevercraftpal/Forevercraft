# Append a single pet from marker entity data.Pets[idx] to MenuDisplay storage
# Called as: companion.marker with {idx:N} macro
$data modify storage evercraft:companions MenuDisplay append from entity @s data.Pets[$(idx)]
