# SP5 — Journey: Send Sub B on the picked themed run. Run as player. Sets companion.jrnyslot=2, the
# ec.journey_send trigger=2 (SP4 contract: 1=A 2=B), drives journey/dispatch_send synchronously, refresh.
scoreboard players set @s companion.jrnyslot 2
scoreboard players set @s ec.journey_send 2
function evercraft:companions/journey/dispatch_send
function evercraft:companions/handler/menu_v2/journey/refresh
