# SP5 — Assign the clicked roster companion to the armed journey sub-slot. Run as player, Macro {slot}
# = page-relative MenuDisplay index. Called from spawn_selected_companion when companion.assign_sub is
# armed (mirrors home/do_place). Computes the absolute Pets[] index, then defers to journey/assign
# (which owns the guard ladder + the slot write + the confirm message).
tag @s remove companion.assign_sub

# Absolute Pets[] index = (page-1)*48 + slot  (same math as spawn_selected_companion / home/do_place).
$scoreboard players set #j_assign_idx ec.temp $(slot)
scoreboard players operation #ds_page ec.temp = @s companion.menupage
scoreboard players remove #ds_page ec.temp 1
scoreboard players operation #ds_page ec.temp *= #48 companion.calc
scoreboard players operation #j_assign_idx ec.temp += #ds_page ec.temp

# Pets[0] is the empty sentinel in the slot encoding, so it can't be a sub. Bail clearly instead of
# letting journey/assign silently treat idx 0 as "clear the slot".
execute if score #j_assign_idx ec.temp matches 0 run function evercraft:companions/handler/menu_v2/assign_sub_idx0_note
execute if score #j_assign_idx ec.temp matches 0 run return run function evercraft:companions/handler/menu_v2/go_home_view

# Which sub slot was armed (1 = A, 2 = B).
scoreboard players operation #j_assign_slot ec.temp = @s companion.assign_slot

# Assign (guards + write + sync + confirm notify all live in journey/assign).
function evercraft:companions/journey/assign

# Back to the home view so the freshly filled slot renders.
function evercraft:companions/handler/menu_v2/go_home_view
