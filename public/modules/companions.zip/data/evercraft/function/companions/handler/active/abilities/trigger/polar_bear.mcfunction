# Polar Bear - Maul: On hit, chance to apply Weakness I
# Chance scales 15% → 40%, duration 3s → 6s

advancement revoke @s only evercraft:companions/abilities/polar_bear
scoreboard players operation #Search companion.id = @s companion.id

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value

scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

execute if score #value companion.calc matches 1..7 if predicate {condition:"random_chance",chance:0.15} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 3 0 true
execute if score #value companion.calc matches 8..12 if predicate {condition:"random_chance",chance:0.163} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 3 0 true
execute if score #value companion.calc matches 13..17 if predicate {condition:"random_chance",chance:0.176} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 3 0 true
execute if score #value companion.calc matches 18..22 if predicate {condition:"random_chance",chance:0.189} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 3 0 true
execute if score #value companion.calc matches 23..27 if predicate {condition:"random_chance",chance:0.203} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 4 0 true
execute if score #value companion.calc matches 28..32 if predicate {condition:"random_chance",chance:0.216} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 4 0 true
execute if score #value companion.calc matches 33..37 if predicate {condition:"random_chance",chance:0.229} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 4 0 true
execute if score #value companion.calc matches 38..42 if predicate {condition:"random_chance",chance:0.242} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 4 0 true
execute if score #value companion.calc matches 43..47 if predicate {condition:"random_chance",chance:0.255} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 5 0 true
execute if score #value companion.calc matches 48..52 if predicate {condition:"random_chance",chance:0.268} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 5 0 true
execute if score #value companion.calc matches 53..57 if predicate {condition:"random_chance",chance:0.282} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 5 0 true
execute if score #value companion.calc matches 58..62 if predicate {condition:"random_chance",chance:0.295} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 5 0 true
execute if score #value companion.calc matches 63..67 if predicate {condition:"random_chance",chance:0.308} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 5 0 true
execute if score #value companion.calc matches 68..72 if predicate {condition:"random_chance",chance:0.321} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 6 0 true
execute if score #value companion.calc matches 73..77 if predicate {condition:"random_chance",chance:0.334} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 6 0 true
execute if score #value companion.calc matches 78..82 if predicate {condition:"random_chance",chance:0.347} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 6 0 true
execute if score #value companion.calc matches 83..87 if predicate {condition:"random_chance",chance:0.361} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 6 0 true
execute if score #value companion.calc matches 88..92 if predicate {condition:"random_chance",chance:0.374} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 6 0 true
execute if score #value companion.calc matches 93..97 if predicate {condition:"random_chance",chance:0.387} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 6 0 true
execute if score #value companion.calc matches 98..100 if predicate {condition:"random_chance",chance:0.4} as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s weakness 6 0 true
