# Squid Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.squid

# Deep Lungs: O2 bonus (0.5 → 10.0)
$execute if score #value companion.calc matches 1..7 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 0.788 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 1.364 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 1.843 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 2.323 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 2.803 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 3.283 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 3.763 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 4.242 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 4.722 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 5.202 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 5.682 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 6.162 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 6.641 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 7.121 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 7.601 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 8.081 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 8.561 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 9.04 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 9.52 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s oxygen_bonus modifier add evercraft:home/slot$(ability_slot)/oxygen_bonus 9.904 add_value
