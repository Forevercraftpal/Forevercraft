# ============================================================
# Home Companion — Sync interaction entity position to chicken
# Run as: chicken (HomeCompanion), at: chicken position
# Teleports the paired HC.Interact entity to this chicken
# ============================================================

scoreboard players operation #Search companion.id = @s companion.id
scoreboard players operation #hc_sync_slot hc.slot = @s hc.slot
# Offset Y+0.5 so interaction hitbox sits above the chicken's hitbox (prevents chicken intercepting clicks)
execute as @e[type=interaction, tag=HC.Interact, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_sync_slot hc.slot run tp @s ~ ~0.5 ~
