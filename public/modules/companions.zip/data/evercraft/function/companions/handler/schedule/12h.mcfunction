scoreboard players operation #Search companion.id = @s companion.id

execute as @s[tag=companion.emberheart] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[9].extra[{text:"18"}] run return run function evercraft:companions/handler/active/abilities/trigger/phoenix_totem