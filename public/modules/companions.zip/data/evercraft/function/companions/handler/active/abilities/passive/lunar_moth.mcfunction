# Lunar Moth Pet Passive Abilities (Exquisite — Gacha Exclusive)
# - Moonlit Wings: Slow Falling + Night Vision at night
# - Lunar Grace: Movement speed scaling (0.105 → 0.18)
# - Moonbeam: Luck 1.0 → 5.0

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.lunar_moth

# Moonlit Wings - Slow Falling + Night Vision at night (DayTime 13000-23000 = night)
execute if score #visual_time ec.var matches 13000..23000 run effect give @s slow_falling 5 0 true
execute if score #visual_time ec.var matches 13000..23000 run effect give @s night_vision 13 0 true

# Lunar Grace - Movement speed scaling (0.105 → 0.18)
execute if score #value companion.calc matches 1..7 run attribute @s movement_speed base set 0.205
execute if score #value companion.calc matches 8..12 run attribute @s movement_speed base set 0.209
execute if score #value companion.calc matches 13..17 run attribute @s movement_speed base set 0.213
execute if score #value companion.calc matches 18..22 run attribute @s movement_speed base set 0.216
execute if score #value companion.calc matches 23..27 run attribute @s movement_speed base set 0.22
execute if score #value companion.calc matches 28..32 run attribute @s movement_speed base set 0.224
execute if score #value companion.calc matches 33..37 run attribute @s movement_speed base set 0.228
execute if score #value companion.calc matches 38..42 run attribute @s movement_speed base set 0.231
execute if score #value companion.calc matches 43..47 run attribute @s movement_speed base set 0.235
execute if score #value companion.calc matches 48..52 run attribute @s movement_speed base set 0.239
execute if score #value companion.calc matches 53..57 run attribute @s movement_speed base set 0.243
execute if score #value companion.calc matches 58..62 run attribute @s movement_speed base set 0.246
execute if score #value companion.calc matches 63..67 run attribute @s movement_speed base set 0.25
execute if score #value companion.calc matches 68..72 run attribute @s movement_speed base set 0.254
execute if score #value companion.calc matches 73..77 run attribute @s movement_speed base set 0.258
execute if score #value companion.calc matches 78..82 run attribute @s movement_speed base set 0.261
execute if score #value companion.calc matches 83..87 run attribute @s movement_speed base set 0.265
execute if score #value companion.calc matches 88..92 run attribute @s movement_speed base set 0.269
execute if score #value companion.calc matches 93..97 run attribute @s movement_speed base set 0.273
execute if score #value companion.calc matches 98..100 run attribute @s movement_speed base set 0.28

# Moonbeam - Luck scaling (1.0 → 5.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s luck base set 1.0
execute if score #value companion.calc matches 8..12 run return run attribute @s luck base set 1.211
execute if score #value companion.calc matches 13..17 run return run attribute @s luck base set 1.395
execute if score #value companion.calc matches 18..22 run return run attribute @s luck base set 1.579
execute if score #value companion.calc matches 23..27 run return run attribute @s luck base set 1.763
execute if score #value companion.calc matches 28..32 run return run attribute @s luck base set 1.947
execute if score #value companion.calc matches 33..37 run return run attribute @s luck base set 2.132
execute if score #value companion.calc matches 38..42 run return run attribute @s luck base set 2.316
execute if score #value companion.calc matches 43..47 run return run attribute @s luck base set 2.5
execute if score #value companion.calc matches 48..52 run return run attribute @s luck base set 2.684
execute if score #value companion.calc matches 53..57 run return run attribute @s luck base set 2.868
execute if score #value companion.calc matches 58..62 run return run attribute @s luck base set 3.053
execute if score #value companion.calc matches 63..67 run return run attribute @s luck base set 3.237
execute if score #value companion.calc matches 68..72 run return run attribute @s luck base set 3.421
execute if score #value companion.calc matches 73..77 run return run attribute @s luck base set 3.605
execute if score #value companion.calc matches 78..82 run return run attribute @s luck base set 3.789
execute if score #value companion.calc matches 83..87 run return run attribute @s luck base set 3.974
execute if score #value companion.calc matches 88..92 run return run attribute @s luck base set 4.158
execute if score #value companion.calc matches 93..97 run return run attribute @s luck base set 4.342
execute if score #value companion.calc matches 98..100 run return run attribute @s luck base set 5.0
