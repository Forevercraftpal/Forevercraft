# Deloris Pack — Initialize Storage
# $(pid) = player's companion.id
$execute unless data storage evercraft:companions dlpack.$(pid) run data modify storage evercraft:companions dlpack.$(pid) set value {s0:{},s1:{},s2:{},s3:{},s4:{}}
