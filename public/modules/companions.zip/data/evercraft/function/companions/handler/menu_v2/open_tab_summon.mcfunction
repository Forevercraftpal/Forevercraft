# Open Summon tab — tamed animal summon list
# NOTE: @s may be dead hub interaction entity (killed on line 5-6). Use #Search for ID.

# Kill hub buttons
execute as @e[type=text_display,tag=companion.hub_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.hub_btn,predicate=evercraft:companions/check_id] run kill @s

# Set tab (find actual player)
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players set @s ec.bd_tab 3

# Spawn back button (anchor-facing to prevent yaw drift)
# MP-P3.12: hit recentered on text_y - h/2 per R.1 (was ^1.12 with h=0.10; AABB sat below glyph)
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.45 ^1.76 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.back_btn_text","companion.menuelement","companion.tab_content"],billboard:"center",text:{text:"\u25C0 Back",color:"yellow"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.4 ^1.78 run summon interaction ~ ~ ~ {Tags:["companion.back_btn_click","companion.menuelement","companion.tab_content"],width:0.35f,height:0.10f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.back_btn_text,distance=..5] companion.id = #Search companion.id
scoreboard players operation @e[type=interaction,tag=companion.back_btn_click,distance=..5] companion.id = #Search companion.id

# Session stamp
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=companion.tab_content,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=companion.tab_content,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

# Open existing summon tab content (pass anchor-facing rotation context)
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet run function evercraft:buddy/gui/tab_summon/open

playsound minecraft:block.note_block.hat master @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.6
