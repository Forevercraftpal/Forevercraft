# Sync active pet memories from live entity back to companion.marker storage
# Uses companion.activeslot scoreboard (set at spawn time) to know which index to write
# Run as: player with active pet

scoreboard players operation #Search companion.id = @s companion.id

# Check memories property exists on live entity
execute unless data entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:profile".properties[{name:"memories"}] run return 0

# Copy memories value to sync storage
data modify storage evercraft:companions sync.memories set from entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:profile".properties[{name:"memories"}].value

# Store slot index into storage as a string for macro use
execute store result storage evercraft:companions sync.slot_index int 1 run scoreboard players get @s companion.activeslot

# Write back to companion.marker at the correct slot index
execute in overworld positioned 0 -60 0 as @n[distance=..10,type=marker,tag=companion.marker,predicate=evercraft:companions/check_id] run function evercraft:companions/handler/active/sync_memories_write with storage evercraft:companions sync
