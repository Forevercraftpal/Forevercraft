# Goat Pet Passive Abilities
# - Mountain Stance: KB res (0.05 → 0.5)
# - Ram: Attack KB (0.1 → 0.5)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.goat

# Mountain Stance: KB res (0.05 → 0.5)
execute if score #value companion.calc matches 1..7 run attribute @s knockback_resistance base set 0.064
execute if score #value companion.calc matches 8..12 run attribute @s knockback_resistance base set 0.091
execute if score #value companion.calc matches 13..17 run attribute @s knockback_resistance base set 0.114
execute if score #value companion.calc matches 18..22 run attribute @s knockback_resistance base set 0.136
execute if score #value companion.calc matches 23..27 run attribute @s knockback_resistance base set 0.159
execute if score #value companion.calc matches 28..32 run attribute @s knockback_resistance base set 0.182
execute if score #value companion.calc matches 33..37 run attribute @s knockback_resistance base set 0.205
execute if score #value companion.calc matches 38..42 run attribute @s knockback_resistance base set 0.227
execute if score #value companion.calc matches 43..47 run attribute @s knockback_resistance base set 0.25
execute if score #value companion.calc matches 48..52 run attribute @s knockback_resistance base set 0.273
execute if score #value companion.calc matches 53..57 run attribute @s knockback_resistance base set 0.295
execute if score #value companion.calc matches 58..62 run attribute @s knockback_resistance base set 0.318
execute if score #value companion.calc matches 63..67 run attribute @s knockback_resistance base set 0.341
execute if score #value companion.calc matches 68..72 run attribute @s knockback_resistance base set 0.364
execute if score #value companion.calc matches 73..77 run attribute @s knockback_resistance base set 0.386
execute if score #value companion.calc matches 78..82 run attribute @s knockback_resistance base set 0.409
execute if score #value companion.calc matches 83..87 run attribute @s knockback_resistance base set 0.432
execute if score #value companion.calc matches 88..92 run attribute @s knockback_resistance base set 0.455
execute if score #value companion.calc matches 93..97 run attribute @s knockback_resistance base set 0.477
execute if score #value companion.calc matches 98..100 run attribute @s knockback_resistance base set 0.495

# Ram: Attack KB (0.1 → 0.5)
execute if score #value companion.calc matches 1..7 run return run attribute @s attack_knockback base set 0.112
execute if score #value companion.calc matches 8..12 run return run attribute @s attack_knockback base set 0.136
execute if score #value companion.calc matches 13..17 run return run attribute @s attack_knockback base set 0.157
execute if score #value companion.calc matches 18..22 run return run attribute @s attack_knockback base set 0.177
execute if score #value companion.calc matches 23..27 run return run attribute @s attack_knockback base set 0.197
execute if score #value companion.calc matches 28..32 run return run attribute @s attack_knockback base set 0.217
execute if score #value companion.calc matches 33..37 run return run attribute @s attack_knockback base set 0.237
execute if score #value companion.calc matches 38..42 run return run attribute @s attack_knockback base set 0.258
execute if score #value companion.calc matches 43..47 run return run attribute @s attack_knockback base set 0.278
execute if score #value companion.calc matches 48..52 run return run attribute @s attack_knockback base set 0.298
execute if score #value companion.calc matches 53..57 run return run attribute @s attack_knockback base set 0.318
execute if score #value companion.calc matches 58..62 run return run attribute @s attack_knockback base set 0.338
execute if score #value companion.calc matches 63..67 run return run attribute @s attack_knockback base set 0.359
execute if score #value companion.calc matches 68..72 run return run attribute @s attack_knockback base set 0.379
execute if score #value companion.calc matches 73..77 run return run attribute @s attack_knockback base set 0.399
execute if score #value companion.calc matches 78..82 run return run attribute @s attack_knockback base set 0.419
execute if score #value companion.calc matches 83..87 run return run attribute @s attack_knockback base set 0.439
execute if score #value companion.calc matches 88..92 run return run attribute @s attack_knockback base set 0.46
execute if score #value companion.calc matches 93..97 run return run attribute @s attack_knockback base set 0.48
execute if score #value companion.calc matches 98..100 run return run attribute @s attack_knockback base set 0.496
