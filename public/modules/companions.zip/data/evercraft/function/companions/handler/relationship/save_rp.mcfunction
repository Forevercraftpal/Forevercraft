# Save relationship points back to pet NBT
# Run as player with active pet
# Reads from @s companion.rp

scoreboard players operation #Search companion.id = @s companion.id

# Clamp RP to 0-5000
execute if score @s companion.rp < #0 companion.calc run scoreboard players set @s companion.rp 0
execute if score @s companion.rp > #5000 companion.calc run scoreboard players set @s companion.rp 5000

# Convert score to NBT string
scoreboard players operation #value companion.calc = @s companion.rp
function evercraft:companions/handler/math/int_to_string

# Update pet NBT
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] run data modify entity @s item.components."minecraft:profile".properties[{name:"relationship"}].value set from storage evercraft:companions math.string

# Mirror the new value into Pets[] storage so the catalogue grid + future summons see it.
# Without this sync, RP changes lived on the entity NBT only and died with the pet on unsummon —
# the player would gain RP in-session (chat correct), but the menu always showed stale values and
# any unsummon/resummon reverted RP to the last stored value.
function evercraft:companions/handler/active/sync_relationship_to_marker
