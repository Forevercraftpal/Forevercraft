# SP5 — Skills: load the focused companion's slot descriptor for the GUI. Run as player.
# SP1 owns the authoritative slot model; SP5 is a thin renderer. For the live MAIN we reuse SP1's
# read-cache (companion.slots / companion.skillslot already mirrored by skills/load_slots on summon).
# For a stored (non-summoned) focus we surface what the item carries: custom_data.horn_slots (earned)
# + the signature slot 0, and custom_data.horn_active (persisted active slot). When SP1's full slot
# model ships, this descriptor read lights up automatically (same NBT keys).

scoreboard players operation #Search companion.id = @s companion.id

# Is the focused companion the live MAIN? Then companion.slots/skillslot are already correct (SP1 cache).
execute if entity @s[tag=companion.activepet] if score @s companion.careidx = @s companion.activeslot run return 0

# --- Stored focus: snapshot + read the item's slot fields ---
data remove storage evercraft:companions care.head
execute store result storage evercraft:companions care.probeidx int 1 run scoreboard players get @s companion.careidx
function evercraft:companions/handler/menu_v2/care/snapshot_idx with storage evercraft:companions care

# Unlocked slots = 1 (signature) + earned horn_slots, clamped to the 12 cap.
scoreboard players set @s companion.slots 1
execute store result score #cc_earned ec.temp run data get storage evercraft:companions care.head.components."minecraft:custom_data".horn_slots
execute if score #cc_earned ec.temp matches 1.. run scoreboard players operation @s companion.slots += #cc_earned ec.temp
execute if score @s companion.slots matches 13.. run scoreboard players set @s companion.slots 12

# Active slot from the item (default 0 = signature). Clamp to the unlocked range.
scoreboard players set @s companion.skillslot 0
execute store result score #cc_active ec.temp run data get storage evercraft:companions care.head.components."minecraft:custom_data".horn_active
execute if score #cc_active ec.temp matches 1.. run scoreboard players operation @s companion.skillslot = #cc_active ec.temp
execute if score @s companion.skillslot >= @s companion.slots run scoreboard players set @s companion.skillslot 0
