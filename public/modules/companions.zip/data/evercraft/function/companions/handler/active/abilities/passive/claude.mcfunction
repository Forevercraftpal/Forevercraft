# Claude Pet Passive Abilities
# - Persistent Helper: Attack damage (1.5 → 3.5)
# - Effect: night_vision

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.claude

effect give @s night_vision infinite 1 true

# Ore Sight - Kill existing markers and rescan
kill @e[type=armor_stand, tag=companion.oremarker, distance=..50]
execute if score #value companion.calc matches 1..7 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:8}
execute if score #value companion.calc matches 8..12 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:9}
execute if score #value companion.calc matches 13..17 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:10}
execute if score #value companion.calc matches 18..22 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:11}
execute if score #value companion.calc matches 23..27 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:11}
execute if score #value companion.calc matches 28..32 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:12}
execute if score #value companion.calc matches 33..37 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:13}
execute if score #value companion.calc matches 38..42 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:14}
execute if score #value companion.calc matches 43..47 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:15}
execute if score #value companion.calc matches 48..52 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:15}
execute if score #value companion.calc matches 53..57 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:16}
execute if score #value companion.calc matches 58..62 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:17}
execute if score #value companion.calc matches 63..67 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:18}
execute if score #value companion.calc matches 68..72 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:19}
execute if score #value companion.calc matches 73..77 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:19}
execute if score #value companion.calc matches 78..82 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:20}
execute if score #value companion.calc matches 83..87 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:21}
execute if score #value companion.calc matches 88..92 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:22}
execute if score #value companion.calc matches 93..97 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:23}
execute if score #value companion.calc matches 98..100 run function evercraft:companions/handler/active/abilities/passive/claude_ore_scan {range:23}

# Persistent Helper: Attack damage (1.5 → 3.5)
execute if score #value companion.calc matches 1..7 run attribute @s attack_damage base set 1.561
execute if score #value companion.calc matches 8..12 run attribute @s attack_damage base set 1.682
execute if score #value companion.calc matches 13..17 run attribute @s attack_damage base set 1.783
execute if score #value companion.calc matches 18..22 run attribute @s attack_damage base set 1.884
execute if score #value companion.calc matches 23..27 run attribute @s attack_damage base set 1.985
execute if score #value companion.calc matches 28..32 run attribute @s attack_damage base set 2.086
execute if score #value companion.calc matches 33..37 run attribute @s attack_damage base set 2.187
execute if score #value companion.calc matches 38..42 run attribute @s attack_damage base set 2.288
execute if score #value companion.calc matches 43..47 run attribute @s attack_damage base set 2.389
execute if score #value companion.calc matches 48..52 run attribute @s attack_damage base set 2.49
execute if score #value companion.calc matches 53..57 run attribute @s attack_damage base set 2.591
execute if score #value companion.calc matches 58..62 run attribute @s attack_damage base set 2.692
execute if score #value companion.calc matches 63..67 run attribute @s attack_damage base set 2.793
execute if score #value companion.calc matches 68..72 run attribute @s attack_damage base set 2.894
execute if score #value companion.calc matches 73..77 run attribute @s attack_damage base set 2.995
execute if score #value companion.calc matches 78..82 run attribute @s attack_damage base set 3.096
execute if score #value companion.calc matches 83..87 run attribute @s attack_damage base set 3.197
execute if score #value companion.calc matches 88..92 run attribute @s attack_damage base set 3.298
execute if score #value companion.calc matches 93..97 run attribute @s attack_damage base set 3.399
execute if score #value companion.calc matches 98..100 run attribute @s attack_damage base set 3.48
