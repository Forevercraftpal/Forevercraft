# Starweaver Pet Passive Abilities (Mythical — Gacha Exclusive)
# - Constellation Web: 10% chance slow + weaken targets on player hit (handled by on_hit)
# - Stellar Ward: Absorption I permanent
# - Cosmic Thread: Luck 1.0 -> 9.0

tag @s add companion.starweaver

# Stellar Ward - Absorption I permanent
effect give @s absorption 13 0 true

# Cosmic Thread - Luck scaling (1.0 -> 9.0)
$execute if score #value companion.calc matches 1..10 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1 add_value
$execute if score #value companion.calc matches 11..20 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.889 add_value
$execute if score #value companion.calc matches 21..30 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.778 add_value
$execute if score #value companion.calc matches 31..40 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.667 add_value
$execute if score #value companion.calc matches 41..50 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.556 add_value
$execute if score #value companion.calc matches 51..60 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 5.444 add_value
$execute if score #value companion.calc matches 61..70 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 6.333 add_value
$execute if score #value companion.calc matches 71..80 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 7.222 add_value
$execute if score #value companion.calc matches 81..90 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 8.111 add_value
$execute if score #value companion.calc matches 91..100 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 9 add_value
