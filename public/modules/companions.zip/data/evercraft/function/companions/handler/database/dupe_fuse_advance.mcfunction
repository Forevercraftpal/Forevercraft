# Macro {pet_name, fuse, cap}: write fuse_count on the owned record (NORMAL filter) + notify.
# NORMAL incoming: plain pet_name filter (subset-matches a shiny record of the same species too — a
# pre-existing limitation shared with evo_prog; see BIG_BRAIN/10-pending.md "Companion fusion follow-ups").
# The display name comes from the incoming item's custom_name (interpret:true) so it's correct for EVERY
# species (get_display_name only maps evolvables); generatedItem is still the incoming keeper here.
$execute in overworld run data modify entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(pet_name)"}}}].components."minecraft:custom_data".fuse_count set value $(fuse)

# Live-refresh (2026-06-10): if the fused species is the player's currently-ACTIVE pet, update the live
# head's copy (whistle/horn/flavor reads — fixes the stale-until-resummon gap) + the owner's
# companion.fuse session cache. Same pet_name filter semantics as the DB write above.
scoreboard players operation #Search companion.id = @s companion.id
$execute if entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1,nbt={item:{components:{"minecraft:custom_data":{pet_name:"$(pet_name)"}}}}] run data modify entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:custom_data".fuse_count set value $(fuse)
$execute if entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1,nbt={item:{components:{"minecraft:custom_data":{pet_name:"$(pet_name)"}}}}] run scoreboard players set @s companion.fuse $(fuse)

$data modify storage evercraft:notify stage.c set value [{text:"⚒ ",color:"yellow"},{nbt:"generatedItem.components.\"minecraft:custom_name\"",storage:"evercraft:companions",interpret:true,color:"aqua"},{text:" fused — ",color:"gray"},{text:"+$(fuse)% power",color:"yellow"},{text:" (",color:"gray"},{text:"$(fuse)/$(cap)",color:"yellow"},{text:")",color:"gray"}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
# One-time "fully fused" gray note when this dupe hit the cap exactly.
$execute if score #df_fuse ec.temp matches $(cap) run data modify storage evercraft:notify stage.c set value [{nbt:"generatedItem.components.\"minecraft:custom_name\"",storage:"evercraft:companions",interpret:true,color:"dark_gray"},{text:" is fully fused ($(cap)/$(cap))",color:"dark_gray"}]
execute if score #df_fuse ec.temp >= #df_cap ec.var run scoreboard players set #ndur ec.temp 55
execute if score #df_fuse ec.temp >= #df_cap ec.var run function evercraft:util/notify/emit
execute at @s run function evercraft:fx/companion/dupe_fuse
