# Macro {pet_name}: read the owned DB record's fuse_count into #df_fuse ec.temp.
# Set 0 first (caller did), then store-result the read — an absent fuse_count path leaves it at 0.
$execute in overworld store result score #df_fuse ec.temp run data get entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(pet_name)"}}}].components."minecraft:custom_data".fuse_count
