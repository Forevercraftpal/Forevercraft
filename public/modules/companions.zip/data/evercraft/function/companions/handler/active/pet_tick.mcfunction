# Companion — Per-pet tick (runs as companion item_display entity)
# OPT: Consolidates 3 entity scans (idle + movement + XP) into 1

# Tag self for cheap XP gain lookup later (avoids re-scanning with predicate)
tag @s add ec.pet_found

# Idle reactivation check (owner not hidden, view_range=0)
execute if entity @p[tag=companion.owner,tag=!companion.hidden] if data entity @s {view_range:0f} run scoreboard players set #pet_idle ec.temp 1
execute if score #pet_idle ec.temp matches 1 run return run function evercraft:companions/handler/active/no_companion_found

# Movement
execute at @s run function evercraft:companions/handler/active/movement
