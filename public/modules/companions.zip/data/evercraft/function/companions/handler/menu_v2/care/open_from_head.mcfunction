# SP5 — A home-view head was clicked. Run as player. #cc_headidx ec.temp = 0 main / 1 subA / 2 subB.
# Resolve the head's absolute roster index from three.* and open Care focused on it. An empty MAIN
# head opens the roster to summon an active companion; an empty SUB head arms assign-to-that-slot mode
# and opens the roster (the next pet clicked fills the slot) — see arm_assign_sub / do_assign_sub.
# (Previously empty heads dumped the player on the Journey tab, which had no assign action — a dead end.)

# Resolve the clicked head's absolute Pets[] index.
scoreboard players set #cc_focus ec.temp -1
execute if score #cc_headidx ec.temp matches 0 store result score #cc_focus ec.temp run data get storage evercraft:companions three.main
execute if score #cc_headidx ec.temp matches 1 store result score #cc_focus ec.temp run data get storage evercraft:companions three.sub[0]
execute if score #cc_headidx ec.temp matches 2 store result score #cc_focus ec.temp run data get storage evercraft:companions three.sub[1]

# Empty slot → open the roster to pick a companion (NOT the Journey tab — that had no assign action).
#   MAIN (headidx 0): -1 = no active companion → open the roster; clicking a pet summons it as active.
#   SUBS (headidx 1/2): 0 = empty sentinel → arm assign-to-this-sub mode, then open the roster; the
#   next pet clicked is routed to journey/assign (see arm_assign_sub → do_assign_sub).
execute if score #cc_headidx ec.temp matches 0 if score #cc_focus ec.temp matches ..-1 run return run function evercraft:companions/handler/menu_v2/open_tab_companions
execute if score #cc_headidx ec.temp matches 1..2 if score #cc_focus ec.temp matches ..0 run return run function evercraft:companions/handler/menu_v2/arm_assign_sub

# Focused on a real companion → set Care focus index and open Care.
scoreboard players operation @s companion.careidx = #cc_focus ec.temp
function evercraft:companions/handler/menu_v2/open_tab_care
