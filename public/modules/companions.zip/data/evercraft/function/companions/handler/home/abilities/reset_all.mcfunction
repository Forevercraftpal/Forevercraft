# ============================================================
# Home Companion Abilities — Remove all modifiers
# Run as: player (called on zone leave or before re-applying)
# Removes all home companion modifiers across all 5 slots
# ============================================================

# SP9: clear the cached Hearth Comfort score so a left/retrieved state never reads stale. The effect
# itself lapses on its own (short-refresh; housing/zone/apply_buffs stops refreshing it out-of-zone).
# When called as the apply_all preamble, comfort_score recomputes a fresh value immediately after.
scoreboard players set @s companion.hcomfort 0

attribute @s attack_damage modifier remove evercraft:home/slot0/attack_damage
attribute @s attack_damage modifier remove evercraft:home/slot1/attack_damage
attribute @s attack_damage modifier remove evercraft:home/slot2/attack_damage
attribute @s attack_damage modifier remove evercraft:home/slot3/attack_damage
attribute @s attack_damage modifier remove evercraft:home/slot4/attack_damage

attribute @s movement_speed modifier remove evercraft:home/slot0/movement_speed
attribute @s movement_speed modifier remove evercraft:home/slot1/movement_speed
attribute @s movement_speed modifier remove evercraft:home/slot2/movement_speed
attribute @s movement_speed modifier remove evercraft:home/slot3/movement_speed
attribute @s movement_speed modifier remove evercraft:home/slot4/movement_speed

attribute @s knockback_resistance modifier remove evercraft:home/slot0/knockback_resistance
attribute @s knockback_resistance modifier remove evercraft:home/slot1/knockback_resistance
attribute @s knockback_resistance modifier remove evercraft:home/slot2/knockback_resistance
attribute @s knockback_resistance modifier remove evercraft:home/slot3/knockback_resistance
attribute @s knockback_resistance modifier remove evercraft:home/slot4/knockback_resistance

attribute @s armor modifier remove evercraft:home/slot0/armor
attribute @s armor modifier remove evercraft:home/slot1/armor
attribute @s armor modifier remove evercraft:home/slot2/armor
attribute @s armor modifier remove evercraft:home/slot3/armor
attribute @s armor modifier remove evercraft:home/slot4/armor

attribute @s armor_toughness modifier remove evercraft:home/slot0/armor_toughness
attribute @s armor_toughness modifier remove evercraft:home/slot1/armor_toughness
attribute @s armor_toughness modifier remove evercraft:home/slot2/armor_toughness
attribute @s armor_toughness modifier remove evercraft:home/slot3/armor_toughness
attribute @s armor_toughness modifier remove evercraft:home/slot4/armor_toughness

attribute @s max_health modifier remove evercraft:home/slot0/max_health
attribute @s max_health modifier remove evercraft:home/slot1/max_health
attribute @s max_health modifier remove evercraft:home/slot2/max_health
attribute @s max_health modifier remove evercraft:home/slot3/max_health
attribute @s max_health modifier remove evercraft:home/slot4/max_health

attribute @s luck modifier remove evercraft:home/slot0/luck
attribute @s luck modifier remove evercraft:home/slot1/luck
attribute @s luck modifier remove evercraft:home/slot2/luck
attribute @s luck modifier remove evercraft:home/slot3/luck
attribute @s luck modifier remove evercraft:home/slot4/luck

attribute @s attack_speed modifier remove evercraft:home/slot0/attack_speed
attribute @s attack_speed modifier remove evercraft:home/slot1/attack_speed
attribute @s attack_speed modifier remove evercraft:home/slot2/attack_speed
attribute @s attack_speed modifier remove evercraft:home/slot3/attack_speed
attribute @s attack_speed modifier remove evercraft:home/slot4/attack_speed

attribute @s step_height modifier remove evercraft:home/slot0/step_height
attribute @s step_height modifier remove evercraft:home/slot1/step_height
attribute @s step_height modifier remove evercraft:home/slot2/step_height
attribute @s step_height modifier remove evercraft:home/slot3/step_height
attribute @s step_height modifier remove evercraft:home/slot4/step_height

attribute @s scale modifier remove evercraft:home/slot0/scale
attribute @s scale modifier remove evercraft:home/slot1/scale
attribute @s scale modifier remove evercraft:home/slot2/scale
attribute @s scale modifier remove evercraft:home/slot3/scale
attribute @s scale modifier remove evercraft:home/slot4/scale

attribute @s entity_interaction_range modifier remove evercraft:home/slot0/entity_interaction_range
attribute @s entity_interaction_range modifier remove evercraft:home/slot1/entity_interaction_range
attribute @s entity_interaction_range modifier remove evercraft:home/slot2/entity_interaction_range
attribute @s entity_interaction_range modifier remove evercraft:home/slot3/entity_interaction_range
attribute @s entity_interaction_range modifier remove evercraft:home/slot4/entity_interaction_range

attribute @s block_interaction_range modifier remove evercraft:home/slot0/block_interaction_range
attribute @s block_interaction_range modifier remove evercraft:home/slot1/block_interaction_range
attribute @s block_interaction_range modifier remove evercraft:home/slot2/block_interaction_range
attribute @s block_interaction_range modifier remove evercraft:home/slot3/block_interaction_range
attribute @s block_interaction_range modifier remove evercraft:home/slot4/block_interaction_range

attribute @s jump_strength modifier remove evercraft:home/slot0/jump_strength
attribute @s jump_strength modifier remove evercraft:home/slot1/jump_strength
attribute @s jump_strength modifier remove evercraft:home/slot2/jump_strength
attribute @s jump_strength modifier remove evercraft:home/slot3/jump_strength
attribute @s jump_strength modifier remove evercraft:home/slot4/jump_strength

attribute @s sneaking_speed modifier remove evercraft:home/slot0/sneaking_speed
attribute @s sneaking_speed modifier remove evercraft:home/slot1/sneaking_speed
attribute @s sneaking_speed modifier remove evercraft:home/slot2/sneaking_speed
attribute @s sneaking_speed modifier remove evercraft:home/slot3/sneaking_speed
attribute @s sneaking_speed modifier remove evercraft:home/slot4/sneaking_speed

attribute @s mining_efficiency modifier remove evercraft:home/slot0/mining_efficiency
attribute @s mining_efficiency modifier remove evercraft:home/slot1/mining_efficiency
attribute @s mining_efficiency modifier remove evercraft:home/slot2/mining_efficiency
attribute @s mining_efficiency modifier remove evercraft:home/slot3/mining_efficiency
attribute @s mining_efficiency modifier remove evercraft:home/slot4/mining_efficiency

attribute @s safe_fall_distance modifier remove evercraft:home/slot0/safe_fall_distance
attribute @s safe_fall_distance modifier remove evercraft:home/slot1/safe_fall_distance
attribute @s safe_fall_distance modifier remove evercraft:home/slot2/safe_fall_distance
attribute @s safe_fall_distance modifier remove evercraft:home/slot3/safe_fall_distance
attribute @s safe_fall_distance modifier remove evercraft:home/slot4/safe_fall_distance

attribute @s gravity modifier remove evercraft:home/slot0/gravity
attribute @s gravity modifier remove evercraft:home/slot1/gravity
attribute @s gravity modifier remove evercraft:home/slot2/gravity
attribute @s gravity modifier remove evercraft:home/slot3/gravity
attribute @s gravity modifier remove evercraft:home/slot4/gravity

attribute @s fall_damage_multiplier modifier remove evercraft:home/slot0/fall_damage_multiplier
attribute @s fall_damage_multiplier modifier remove evercraft:home/slot1/fall_damage_multiplier
attribute @s fall_damage_multiplier modifier remove evercraft:home/slot2/fall_damage_multiplier
attribute @s fall_damage_multiplier modifier remove evercraft:home/slot3/fall_damage_multiplier
attribute @s fall_damage_multiplier modifier remove evercraft:home/slot4/fall_damage_multiplier

attribute @s oxygen_bonus modifier remove evercraft:home/slot0/oxygen_bonus
attribute @s oxygen_bonus modifier remove evercraft:home/slot1/oxygen_bonus
attribute @s oxygen_bonus modifier remove evercraft:home/slot2/oxygen_bonus
attribute @s oxygen_bonus modifier remove evercraft:home/slot3/oxygen_bonus
attribute @s oxygen_bonus modifier remove evercraft:home/slot4/oxygen_bonus

attribute @s submerged_mining_speed modifier remove evercraft:home/slot0/submerged_mining_speed
attribute @s submerged_mining_speed modifier remove evercraft:home/slot1/submerged_mining_speed
attribute @s submerged_mining_speed modifier remove evercraft:home/slot2/submerged_mining_speed
attribute @s submerged_mining_speed modifier remove evercraft:home/slot3/submerged_mining_speed
attribute @s submerged_mining_speed modifier remove evercraft:home/slot4/submerged_mining_speed

attribute @s water_movement_efficiency modifier remove evercraft:home/slot0/water_movement_efficiency
attribute @s water_movement_efficiency modifier remove evercraft:home/slot1/water_movement_efficiency
attribute @s water_movement_efficiency modifier remove evercraft:home/slot2/water_movement_efficiency
attribute @s water_movement_efficiency modifier remove evercraft:home/slot3/water_movement_efficiency
attribute @s water_movement_efficiency modifier remove evercraft:home/slot4/water_movement_efficiency

attribute @s sweeping_damage_ratio modifier remove evercraft:home/slot0/sweeping_damage_ratio
attribute @s sweeping_damage_ratio modifier remove evercraft:home/slot1/sweeping_damage_ratio
attribute @s sweeping_damage_ratio modifier remove evercraft:home/slot2/sweeping_damage_ratio
attribute @s sweeping_damage_ratio modifier remove evercraft:home/slot3/sweeping_damage_ratio
attribute @s sweeping_damage_ratio modifier remove evercraft:home/slot4/sweeping_damage_ratio

attribute @s explosion_knockback_resistance modifier remove evercraft:home/slot0/explosion_knockback_resistance
attribute @s explosion_knockback_resistance modifier remove evercraft:home/slot1/explosion_knockback_resistance
attribute @s explosion_knockback_resistance modifier remove evercraft:home/slot2/explosion_knockback_resistance
attribute @s explosion_knockback_resistance modifier remove evercraft:home/slot3/explosion_knockback_resistance
attribute @s explosion_knockback_resistance modifier remove evercraft:home/slot4/explosion_knockback_resistance

attribute @s attack_knockback modifier remove evercraft:home/slot0/attack_knockback
attribute @s attack_knockback modifier remove evercraft:home/slot1/attack_knockback
attribute @s attack_knockback modifier remove evercraft:home/slot2/attack_knockback
attribute @s attack_knockback modifier remove evercraft:home/slot3/attack_knockback
attribute @s attack_knockback modifier remove evercraft:home/slot4/attack_knockback

