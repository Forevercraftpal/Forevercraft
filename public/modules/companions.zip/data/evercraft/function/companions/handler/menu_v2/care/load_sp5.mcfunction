# SP5 — New Companion GUI: load (objectives + constants). Called from companions/load.
# Registers the SP5-owned per-player scoreboards (DATA-MODEL §1.7) and the bond-tier-name
# render constants the Care GUI reads. ONE-WRITER = this load fn (reseeded each /reload).
#
# SP5 owns the home view (3 floating heads), Care, Skills frame, Journey frame, placed heads.
# It RENDERS over SP4 (three.*), SP1 (skills), SP2 (bond), SP3 (departed). Minimal owned state.

# --- Care focus + rename flow (player-side) ---
scoreboard objectives add companion.careidx dummy "Care focus roster index"
scoreboard objectives add companion.renameidx dummy "Rename target roster index"
scoreboard objectives add ec.cc_renaming dummy "In companion-rename flow latch"
# Care Pet/Feed anti-spam cooldown (ticks). Decremented ONLY in menu_v2/tick while the menu is open
# (existence-gated by companion.inmenuv2), set by care/pet_stored + care/feed_stored. One-writer split:
# SET sites are the two stored-care fns; the lone decrement line is tagged in tick.mcfunction.
scoreboard objectives add ec.cc_petcd dummy "Care stored-pet anti-spam cd"

# --- Skills GUI pager (folds the SP0-named companion.skillpage into SP5 ownership) ---
scoreboard objectives add companion.skillpage dummy "Skills GUI page (0/1)"

# --- Journey GUI: which sub slot the player is configuring (1=A 2=B). One-writer = journey GUI. ---
scoreboard objectives add companion.jrnyslot dummy "Journey GUI selected sub 1/2"

# --- Entity-scored stamps (live on transient menu / placed entities, never on the player) ---
scoreboard objectives add companion.headidx dummy "Home-view head slot 0/1/2"
scoreboard objectives add companion.skillidx dummy "Skills slot stamp 0-11"
scoreboard objectives add companion.careslot dummy "Care prev/next page-relative slot"
scoreboard objectives add pc.mode dummy "Placed head 0=sit 1=wander"
scoreboard objectives add pc.slot dummy "Placed head per-entity slot stamp"
scoreboard objectives add pc.petidx dummy "Placed head companion Pets[] index"
scoreboard objectives add pc.ox dummy "Placed head wander origin X"
scoreboard objectives add pc.oy dummy "Placed head wander origin Y"
scoreboard objectives add pc.oz dummy "Placed head wander origin Z"
scoreboard objectives add pc.petcd dummy "Placed head pet cooldown"
scoreboard objectives add pc.feedcd dummy "Placed head feed cooldown"

# --- Care RP-bar render scratch (segments) ---
scoreboard players set #5000 companion.calc 5000
scoreboard players set #500 companion.calc 500
# --- Skills grid: slots-per-page divisor ---
scoreboard players set #6 companion.calc 6

# Placed-head per-player cap (mirror the home 5-cap discipline, D-GUI-6). One-writer = this load fn.
scoreboard players set #PC_CAP companion.calc 5
