# Arctic Fox - Frost Bite: On hit in cold biomes, apply Slowness I
# Duration scales 3s → 7s

advancement revoke @s only evercraft:companions/abilities/arctic_fox
scoreboard players operation #Search companion.id = @s companion.id

# Only triggers in cold biomes
execute unless predicate evercraft:companions/cold_biome run return 0

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value

scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

execute if score #value companion.calc matches 1..7 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 3 0 true
execute if score #value companion.calc matches 8..12 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 3 0 true
execute if score #value companion.calc matches 13..17 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 3 0 true
execute if score #value companion.calc matches 18..22 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 4 0 true
execute if score #value companion.calc matches 23..27 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 4 0 true
execute if score #value companion.calc matches 28..32 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 4 0 true
execute if score #value companion.calc matches 33..37 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 4 0 true
execute if score #value companion.calc matches 38..42 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 5 0 true
execute if score #value companion.calc matches 43..47 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 5 0 true
execute if score #value companion.calc matches 48..52 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 5 0 true
execute if score #value companion.calc matches 53..57 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 5 0 true
execute if score #value companion.calc matches 58..62 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 6 0 true
execute if score #value companion.calc matches 63..67 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 6 0 true
execute if score #value companion.calc matches 68..72 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 6 0 true
execute if score #value companion.calc matches 73..77 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 6 0 true
execute if score #value companion.calc matches 78..82 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 7 0 true
execute if score #value companion.calc matches 83..87 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 7 0 true
execute if score #value companion.calc matches 88..92 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 7 0 true
execute if score #value companion.calc matches 93..97 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 7 0 true
execute if score #value companion.calc matches 98..100 as @e[distance=..9, predicate=evercraft:companions/is_hurt, type=!player, limit=1, sort=nearest] run effect give @s slowness 7 0 true
