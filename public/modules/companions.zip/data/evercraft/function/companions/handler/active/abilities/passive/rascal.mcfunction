# Rascal Pet Passive Abilities
# - Trickster's Luck: Luck (0.1 → 1.5)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.rascal

# Trickster's Luck: Luck (0.1 → 1.5)
execute if score #value companion.calc matches 1..7 run return run attribute @s luck base set 0.142
execute if score #value companion.calc matches 8..12 run return run attribute @s luck base set 0.227
execute if score #value companion.calc matches 13..17 run return run attribute @s luck base set 0.298
execute if score #value companion.calc matches 18..22 run return run attribute @s luck base set 0.369
execute if score #value companion.calc matches 23..27 run return run attribute @s luck base set 0.439
execute if score #value companion.calc matches 28..32 run return run attribute @s luck base set 0.51
execute if score #value companion.calc matches 33..37 run return run attribute @s luck base set 0.581
execute if score #value companion.calc matches 38..42 run return run attribute @s luck base set 0.652
execute if score #value companion.calc matches 43..47 run return run attribute @s luck base set 0.722
execute if score #value companion.calc matches 48..52 run return run attribute @s luck base set 0.793
execute if score #value companion.calc matches 53..57 run return run attribute @s luck base set 0.864
execute if score #value companion.calc matches 58..62 run return run attribute @s luck base set 0.934
execute if score #value companion.calc matches 63..67 run return run attribute @s luck base set 1.005
execute if score #value companion.calc matches 68..72 run return run attribute @s luck base set 1.076
execute if score #value companion.calc matches 73..77 run return run attribute @s luck base set 1.146
execute if score #value companion.calc matches 78..82 run return run attribute @s luck base set 1.217
execute if score #value companion.calc matches 83..87 run return run attribute @s luck base set 1.288
execute if score #value companion.calc matches 88..92 run return run attribute @s luck base set 1.359
execute if score #value companion.calc matches 93..97 run return run attribute @s luck base set 1.429
execute if score #value companion.calc matches 98..100 run return run attribute @s luck base set 1.486
