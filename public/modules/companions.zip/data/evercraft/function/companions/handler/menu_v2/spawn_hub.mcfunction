# Spawn 4 hub section buttons (Codex-style 2x2 grid)
# Run as player, position context from open.mcfunction

# === Top Row ===

# Companions (top-left) — main pet catalogue
execute rotated ~ 0 positioned ^ ^1.65 ^1.76 positioned ^0.55 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.hub_btn","companion.hub_companions_text","companion.menuelement"],billboard:"center",text:[{text:"\uD83D\uDC3E ",color:"yellow"},{text:"Companion",color:"gold",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.501f,0.501f,0.501f]}}
# [strip] ?: 0.45w split into 3 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.15 ^1.57 ^1.78 positioned ^0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.hub_btn","companion.hub_companions_click","companion.menuelement"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0 ^1.57 ^1.78 positioned ^0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.hub_btn","companion.hub_companions_click","companion.menuelement"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.15 ^1.57 ^1.78 positioned ^0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.hub_btn","companion.hub_companions_click","companion.menuelement"],width:0.15f,height:0.15f,response:1b}

# Buddy (top-right) — best buddy stats + equipment
execute rotated ~ 0 positioned ^ ^1.65 ^1.76 positioned ^-0.55 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.hub_btn","companion.hub_buddy_text","companion.menuelement"],billboard:"center",text:[{text:"\u2764 ",color:"red"},{text:"Buddy",color:"green",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.501f,0.501f,0.501f]}}
# [strip] ?: 0.45w split into 3 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.15 ^1.57 ^1.78 positioned ^-0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.hub_btn","companion.hub_buddy_click","companion.menuelement"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0 ^1.57 ^1.78 positioned ^-0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.hub_btn","companion.hub_buddy_click","companion.menuelement"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.15 ^1.57 ^1.78 positioned ^-0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.hub_btn","companion.hub_buddy_click","companion.menuelement"],width:0.15f,height:0.15f,response:1b}

# === Bottom Row ===

# Summon (bottom-left) — tamed animal summon list
execute rotated ~ 0 positioned ^ ^1.05 ^1.76 positioned ^0.55 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.hub_btn","companion.hub_summon_text","companion.menuelement"],billboard:"center",text:[{text:"\u2728 ",color:"aqua"},{text:"Summon",color:"aqua",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.501f,0.501f,0.501f]}}
# [strip] ?: 0.45w split into 3 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.15 ^0.97 ^1.78 positioned ^0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.hub_btn","companion.hub_summon_click","companion.menuelement"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0 ^0.97 ^1.78 positioned ^0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.hub_btn","companion.hub_summon_click","companion.menuelement"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.15 ^0.97 ^1.78 positioned ^0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.hub_btn","companion.hub_summon_click","companion.menuelement"],width:0.15f,height:0.15f,response:1b}

# Training (bottom-right) — mount training + bond info
execute rotated ~ 0 positioned ^ ^1.05 ^1.76 positioned ^-0.55 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.hub_btn","companion.hub_training_text","companion.menuelement"],billboard:"center",text:[{text:"\u2694 ",color:"light_purple"},{text:"Training",color:"light_purple",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.501f,0.501f,0.501f]}}
# [strip] ?: 0.45w split into 3 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.15 ^0.97 ^1.78 positioned ^-0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.hub_btn","companion.hub_training_click","companion.menuelement"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0 ^0.97 ^1.78 positioned ^-0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.hub_btn","companion.hub_training_click","companion.menuelement"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.15 ^0.97 ^1.78 positioned ^-0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.hub_btn","companion.hub_training_click","companion.menuelement"],width:0.15f,height:0.15f,response:1b}

# Dex progress header (top-center, above the 2x2 grid). Recompute the authoritative species/shiny
# tallies from the roster, then render "<X> / 104 Discovered" (+ a "<Y> / 104 Shiny" line once the
# player owns at least one shiny). #dex_sh stays live for the shiny-line gate inside spawn_dex_header.
function evercraft:companions/dex/recompute
scoreboard players operation #dex_disp ec.temp = @s ec.comp_dex
execute if score #dex_disp ec.temp matches 105.. run scoreboard players set #dex_disp ec.temp 104
execute store result storage evercraft:companions dex_now int 1 run scoreboard players get #dex_disp ec.temp
scoreboard players operation #dex_sh ec.temp = @s ec.comp_dex_shiny
execute if score #dex_sh ec.temp matches 105.. run scoreboard players set #dex_sh ec.temp 104
execute store result storage evercraft:companions dex_shiny int 1 run scoreboard players get #dex_sh ec.temp
function evercraft:companions/handler/menu_v2/spawn_dex_header with storage evercraft:companions

# Assign session IDs to hub elements
scoreboard players operation @e[type=text_display,tag=companion.hub_btn,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.hub_btn,distance=..5] companion.id = @s companion.id
