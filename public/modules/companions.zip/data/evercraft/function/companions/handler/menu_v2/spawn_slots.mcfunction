# Companion Menu V2 - Spawn Slots (4x12 grid, 48 slots per page)
# 12 columns at 0.22 spacing: ^1.21 to ^-1.21
# 4 rows at 0.30 spacing (room for name labels above heads):
#   Row 1 (top):    display Y=2.75, interaction Y=2.60
#   Row 2:          display Y=2.45, interaction Y=2.30
#   Row 3:          display Y=2.15, interaction Y=2.00
#   Row 4 (bottom): display Y=1.85, interaction Y=1.70
# Scale: 0.25f | Interaction: width=0.15f, height=0.12f
# Z depth: item_display=2.28, interaction=2.26
#
# MP-P3.12 NOTE (2026-05-29): the 0.15m hit-below-display offset is INTENTIONAL
# label-above-icon pattern — the item_display Y is the head model anchor, but
# `item_display:"head"` renders the head model centered AROUND the anchor with
# its visual bottom at roughly anchor-0.10. Interaction at anchor-0.15 with h=0.12
# spans [anchor-0.21, anchor-0.09], catching the lower half of the visible head.
# Player heads above each slot use the upper Y for name labels (spawn_names.mcfunction).
# DO NOT apply R.1 recentering — that would push hits ABOVE the heads into the labels.

# === Row 1 (slots 0-11) — Y: display=2.75, interaction=2.60 ===

execute rotated ~ 0 positioned ^ ^2 ^1.78 positioned ^1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[0] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot0"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.85 ^1.76 positioned ^1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[0] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click0"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2 ^1.78 positioned ^0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[1] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot1"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.85 ^1.76 positioned ^0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[1] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click1"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2 ^1.78 positioned ^0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[2] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot2"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.85 ^1.76 positioned ^0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[2] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click2"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2 ^1.78 positioned ^0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[3] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot3"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.85 ^1.76 positioned ^0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[3] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click3"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2 ^1.78 positioned ^0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[4] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot4"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.85 ^1.76 positioned ^0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[4] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click4"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2 ^1.78 positioned ^0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[5] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot5"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.85 ^1.76 positioned ^0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[5] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click5"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2 ^1.78 positioned ^-0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[6] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot6"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.85 ^1.76 positioned ^-0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[6] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click6"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2 ^1.78 positioned ^-0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[7] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot7"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.85 ^1.76 positioned ^-0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[7] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click7"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2 ^1.78 positioned ^-0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[8] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot8"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.85 ^1.76 positioned ^-0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[8] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click8"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2 ^1.78 positioned ^-0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[9] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot9"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.85 ^1.76 positioned ^-0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[9] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click9"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2 ^1.78 positioned ^-0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[10] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot10"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.85 ^1.76 positioned ^-0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[10] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click10"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2 ^1.78 positioned ^-1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[11] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot11"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.85 ^1.76 positioned ^-1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[11] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click11"],width:0.15f,height:0.12f,response:1b}

# === Row 2 (slots 12-23) — Y: display=2.45, interaction=2.30 ===

execute rotated ~ 0 positioned ^ ^1.7 ^1.78 positioned ^1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[12] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot12"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.55 ^1.76 positioned ^1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[12] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click12"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.7 ^1.78 positioned ^0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[13] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot13"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.55 ^1.76 positioned ^0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[13] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click13"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.7 ^1.78 positioned ^0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[14] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot14"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.55 ^1.76 positioned ^0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[14] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click14"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.7 ^1.78 positioned ^0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[15] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot15"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.55 ^1.76 positioned ^0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[15] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click15"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.7 ^1.78 positioned ^0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[16] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot16"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.55 ^1.76 positioned ^0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[16] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click16"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.7 ^1.78 positioned ^0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[17] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot17"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.55 ^1.76 positioned ^0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[17] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click17"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.7 ^1.78 positioned ^-0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[18] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot18"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.55 ^1.76 positioned ^-0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[18] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click18"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.7 ^1.78 positioned ^-0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[19] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot19"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.55 ^1.76 positioned ^-0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[19] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click19"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.7 ^1.78 positioned ^-0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[20] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot20"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.55 ^1.76 positioned ^-0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[20] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click20"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.7 ^1.78 positioned ^-0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[21] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot21"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.55 ^1.76 positioned ^-0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[21] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click21"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.7 ^1.78 positioned ^-0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[22] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot22"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.55 ^1.76 positioned ^-0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[22] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click22"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.7 ^1.78 positioned ^-1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[23] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot23"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.55 ^1.76 positioned ^-1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[23] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click23"],width:0.15f,height:0.12f,response:1b}

# === Row 3 (slots 24-35) — Y: display=2.15, interaction=2.00 ===

execute rotated ~ 0 positioned ^ ^1.4 ^1.78 positioned ^1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[24] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot24"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.25 ^1.76 positioned ^1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[24] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click24"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.4 ^1.78 positioned ^0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[25] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot25"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.25 ^1.76 positioned ^0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[25] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click25"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.4 ^1.78 positioned ^0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[26] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot26"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.25 ^1.76 positioned ^0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[26] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click26"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.4 ^1.78 positioned ^0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[27] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot27"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.25 ^1.76 positioned ^0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[27] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click27"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.4 ^1.78 positioned ^0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[28] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot28"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.25 ^1.76 positioned ^0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[28] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click28"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.4 ^1.78 positioned ^0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[29] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot29"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.25 ^1.76 positioned ^0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[29] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click29"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.4 ^1.78 positioned ^-0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[30] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot30"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.25 ^1.76 positioned ^-0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[30] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click30"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.4 ^1.78 positioned ^-0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[31] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot31"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.25 ^1.76 positioned ^-0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[31] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click31"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.4 ^1.78 positioned ^-0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[32] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot32"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.25 ^1.76 positioned ^-0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[32] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click32"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.4 ^1.78 positioned ^-0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[33] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot33"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.25 ^1.76 positioned ^-0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[33] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click33"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.4 ^1.78 positioned ^-0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[34] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot34"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.25 ^1.76 positioned ^-0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[34] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click34"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.4 ^1.78 positioned ^-1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[35] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot35"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^1.25 ^1.76 positioned ^-1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[35] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click35"],width:0.15f,height:0.12f,response:1b}

# === Row 4 (slots 36-47) — Y: display=1.85, interaction=1.70 ===

execute rotated ~ 0 positioned ^ ^1.1 ^1.78 positioned ^1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[36] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot36"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[36] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click36"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.1 ^1.78 positioned ^0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[37] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot37"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[37] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click37"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.1 ^1.78 positioned ^0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[38] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot38"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[38] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click38"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.1 ^1.78 positioned ^0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[39] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot39"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[39] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click39"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.1 ^1.78 positioned ^0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[40] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot40"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[40] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click40"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.1 ^1.78 positioned ^0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[41] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot41"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[41] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click41"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.1 ^1.78 positioned ^-0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[42] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot42"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^-0.11 ^0 ^0 if data storage evercraft:companions MenuDisplay[42] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click42"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.1 ^1.78 positioned ^-0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[43] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot43"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^-0.33 ^0 ^0 if data storage evercraft:companions MenuDisplay[43] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click43"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.1 ^1.78 positioned ^-0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[44] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot44"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^-0.55 ^0 ^0 if data storage evercraft:companions MenuDisplay[44] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click44"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.1 ^1.78 positioned ^-0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[45] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot45"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^-0.77 ^0 ^0 if data storage evercraft:companions MenuDisplay[45] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click45"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.1 ^1.78 positioned ^-0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[46] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot46"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^-0.99 ^0 ^0 if data storage evercraft:companions MenuDisplay[46] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click46"],width:0.15f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.1 ^1.78 positioned ^-1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[47] run summon item_display ~ ~ ~ {Tags:["companion.petslot","companion.menuelement","companion.tab_content","companion.slot47"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.221f,0.221f,0.221f]}}
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^-1.21 ^0 ^0 if data storage evercraft:companions MenuDisplay[47] run summon interaction ~ ~ ~ {Tags:["companion.petclick","companion.menuelement","companion.tab_content","companion.click47"],width:0.15f,height:0.12f,response:1b}

# Load items into pet slot displays
function evercraft:companions/handler/menu_v2/set_items

# Assign session ownership to all spawned slot entities
# Use #Search (set by tick/click_hub) — @s may be dead hub entity
scoreboard players operation @e[type=item_display,tag=companion.petslot,distance=..5] companion.id = #Search companion.id
scoreboard players operation @e[type=interaction,tag=companion.petclick,distance=..5] companion.id = #Search companion.id

# SP3: gray out any DEPARTED companions (dim brightness silhouette). Runs AFTER ownership is assigned
# (the slotN displays now carry companion.id, so the predicate=check_id edits resolve). #Search is set.
function evercraft:companions/handler/menu_v2/winback/mark_departed_slots

# Assign companion.slot scores to interaction entities (needed for click dispatch)
scoreboard players set @e[type=interaction,tag=companion.click0,distance=..5] companion.slot 0
scoreboard players set @e[type=interaction,tag=companion.click1,distance=..5] companion.slot 1
scoreboard players set @e[type=interaction,tag=companion.click2,distance=..5] companion.slot 2
scoreboard players set @e[type=interaction,tag=companion.click3,distance=..5] companion.slot 3
scoreboard players set @e[type=interaction,tag=companion.click4,distance=..5] companion.slot 4
scoreboard players set @e[type=interaction,tag=companion.click5,distance=..5] companion.slot 5
scoreboard players set @e[type=interaction,tag=companion.click6,distance=..5] companion.slot 6
scoreboard players set @e[type=interaction,tag=companion.click7,distance=..5] companion.slot 7
scoreboard players set @e[type=interaction,tag=companion.click8,distance=..5] companion.slot 8
scoreboard players set @e[type=interaction,tag=companion.click9,distance=..5] companion.slot 9
scoreboard players set @e[type=interaction,tag=companion.click10,distance=..5] companion.slot 10
scoreboard players set @e[type=interaction,tag=companion.click11,distance=..5] companion.slot 11
scoreboard players set @e[type=interaction,tag=companion.click12,distance=..5] companion.slot 12
scoreboard players set @e[type=interaction,tag=companion.click13,distance=..5] companion.slot 13
scoreboard players set @e[type=interaction,tag=companion.click14,distance=..5] companion.slot 14
scoreboard players set @e[type=interaction,tag=companion.click15,distance=..5] companion.slot 15
scoreboard players set @e[type=interaction,tag=companion.click16,distance=..5] companion.slot 16
scoreboard players set @e[type=interaction,tag=companion.click17,distance=..5] companion.slot 17
scoreboard players set @e[type=interaction,tag=companion.click18,distance=..5] companion.slot 18
scoreboard players set @e[type=interaction,tag=companion.click19,distance=..5] companion.slot 19
scoreboard players set @e[type=interaction,tag=companion.click20,distance=..5] companion.slot 20
scoreboard players set @e[type=interaction,tag=companion.click21,distance=..5] companion.slot 21
scoreboard players set @e[type=interaction,tag=companion.click22,distance=..5] companion.slot 22
scoreboard players set @e[type=interaction,tag=companion.click23,distance=..5] companion.slot 23
scoreboard players set @e[type=interaction,tag=companion.click24,distance=..5] companion.slot 24
scoreboard players set @e[type=interaction,tag=companion.click25,distance=..5] companion.slot 25
scoreboard players set @e[type=interaction,tag=companion.click26,distance=..5] companion.slot 26
scoreboard players set @e[type=interaction,tag=companion.click27,distance=..5] companion.slot 27
scoreboard players set @e[type=interaction,tag=companion.click28,distance=..5] companion.slot 28
scoreboard players set @e[type=interaction,tag=companion.click29,distance=..5] companion.slot 29
scoreboard players set @e[type=interaction,tag=companion.click30,distance=..5] companion.slot 30
scoreboard players set @e[type=interaction,tag=companion.click31,distance=..5] companion.slot 31
scoreboard players set @e[type=interaction,tag=companion.click32,distance=..5] companion.slot 32
scoreboard players set @e[type=interaction,tag=companion.click33,distance=..5] companion.slot 33
scoreboard players set @e[type=interaction,tag=companion.click34,distance=..5] companion.slot 34
scoreboard players set @e[type=interaction,tag=companion.click35,distance=..5] companion.slot 35
scoreboard players set @e[type=interaction,tag=companion.click36,distance=..5] companion.slot 36
scoreboard players set @e[type=interaction,tag=companion.click37,distance=..5] companion.slot 37
scoreboard players set @e[type=interaction,tag=companion.click38,distance=..5] companion.slot 38
scoreboard players set @e[type=interaction,tag=companion.click39,distance=..5] companion.slot 39
scoreboard players set @e[type=interaction,tag=companion.click40,distance=..5] companion.slot 40
scoreboard players set @e[type=interaction,tag=companion.click41,distance=..5] companion.slot 41
scoreboard players set @e[type=interaction,tag=companion.click42,distance=..5] companion.slot 42
scoreboard players set @e[type=interaction,tag=companion.click43,distance=..5] companion.slot 43
scoreboard players set @e[type=interaction,tag=companion.click44,distance=..5] companion.slot 44
scoreboard players set @e[type=interaction,tag=companion.click45,distance=..5] companion.slot 45
scoreboard players set @e[type=interaction,tag=companion.click46,distance=..5] companion.slot 46
scoreboard players set @e[type=interaction,tag=companion.click47,distance=..5] companion.slot 47
