# Prowler Pet Passive Abilities
# - Loyal Bite: Attack damage (1.5 → 2.8)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.prowler

# Loyal Bite: Attack damage (1.5 → 2.8)
execute if score #value companion.calc matches 1..7 run return run attribute @s attack_damage base set 1.539
execute if score #value companion.calc matches 8..12 run return run attribute @s attack_damage base set 1.618
execute if score #value companion.calc matches 13..17 run return run attribute @s attack_damage base set 1.684
execute if score #value companion.calc matches 18..22 run return run attribute @s attack_damage base set 1.749
execute if score #value companion.calc matches 23..27 run return run attribute @s attack_damage base set 1.815
execute if score #value companion.calc matches 28..32 run return run attribute @s attack_damage base set 1.881
execute if score #value companion.calc matches 33..37 run return run attribute @s attack_damage base set 1.946
execute if score #value companion.calc matches 38..42 run return run attribute @s attack_damage base set 2.012
execute if score #value companion.calc matches 43..47 run return run attribute @s attack_damage base set 2.078
execute if score #value companion.calc matches 48..52 run return run attribute @s attack_damage base set 2.143
execute if score #value companion.calc matches 53..57 run return run attribute @s attack_damage base set 2.209
execute if score #value companion.calc matches 58..62 run return run attribute @s attack_damage base set 2.275
execute if score #value companion.calc matches 63..67 run return run attribute @s attack_damage base set 2.34
execute if score #value companion.calc matches 68..72 run return run attribute @s attack_damage base set 2.406
execute if score #value companion.calc matches 73..77 run return run attribute @s attack_damage base set 2.472
execute if score #value companion.calc matches 78..82 run return run attribute @s attack_damage base set 2.537
execute if score #value companion.calc matches 83..87 run return run attribute @s attack_damage base set 2.603
execute if score #value companion.calc matches 88..92 run return run attribute @s attack_damage base set 2.669
execute if score #value companion.calc matches 93..97 run return run attribute @s attack_damage base set 2.734
execute if score #value companion.calc matches 98..100 run return run attribute @s attack_damage base set 2.787
