# SP5 — Rename: start the give-name flow for the Care-focused companion. Run as player.
# Mirrors buddy/naming/do_rename + housing/slot/rename/give_deed: stamp the target roster index, give a
# writable_book carrying companion_idx in custom_data (survives the sign round-trip), set the latch, and
# close the menu so the player can write. The signed advancement fires care/rename/extract.

# Stamp the rename target = the current Care focus (one-writer: rename code).
scoreboard players operation @s companion.renameidx = @s companion.careidx
scoreboard players set @s ec.cc_renaming 1

# Carry the target index into the book's custom_data so extract knows which Pets[] entry to rename.
execute store result storage evercraft:companions care.renameidx int 1 run scoreboard players get @s companion.renameidx
function evercraft:companions/handler/menu_v2/care/rename/give_charter with storage evercraft:companions care

# Close the menu so the book GUI can open.
function evercraft:companions/handler/menu_v2/close

data modify storage evercraft:notify stage.c set value [{text:"Write your companion's new name on page 1 and ",color:"yellow"},{text:"sign it",color:"green",bold:true},{text:"!",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.5
