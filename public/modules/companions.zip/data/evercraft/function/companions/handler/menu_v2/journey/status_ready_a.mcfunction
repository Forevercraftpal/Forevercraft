# SP5 — Journey: Sub-A ready status ("<name> — ready to journey"). Run as player.
# journey.qslot (set by render_slot_a) = the assigned Pets[] index. Pull its name.
data modify storage evercraft:companions journey.subname set value "Your companion"
data modify storage evercraft:companions journey.journey_slot set from storage evercraft:companions journey.qslot
execute in overworld run function evercraft:companions/journey/get_subname with storage evercraft:companions journey
function evercraft:companions/handler/menu_v2/journey/status_ready_a_text with storage evercraft:companions journey
