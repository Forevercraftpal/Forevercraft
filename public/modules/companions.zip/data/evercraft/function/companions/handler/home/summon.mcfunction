# ============================================================
# Home Companion — Summon entities at hearthstone position
# Run as: HS.Marker, at hearthstone position
# Requires: storage evercraft:companions home.item set to the pet item data
#           storage evercraft:companions home.slot set to the slot index (0-4)
# ============================================================
# Uses invisible baby chicken for natural wandering AI.
# Item_display (HC.Head) rides as passenger for visuals.
# Interaction (HC.Interact) is a SEPARATE entity (passengers can't be clicked).
# ============================================================

# Summon invisible, silent, invulnerable baby chicken with head passenger
# - Default chicken movement speed (0.25)
# - Permanent baby (Age:-2147483648) so it stays small
# - DeathLootTable empty, CanPickUpLoot false for cleanliness
summon chicken ~1 ~1 ~ {Silent:1b, Invisible:1b, Invulnerable:1b, Age:-2147483648, PersistenceRequired:1b, DeathLootTable:"minecraft:empty", CanPickUpLoot:0b, Tags:[HomeCompanion, Pet, HC.New], Passengers:[{id:"item_display", Tags:[HC.Head, Pet, HC.NewHead], item_display:"ground", billboard:"center", transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]}, CustomNameVisible:1b, item:{id:"player_head", count:1b}}]}

# Force invisible + silent (summon NBT can fail to apply with Passengers)
data merge entity @e[type=chicken, tag=HC.New, sort=nearest, limit=1] {Invisible:1b, Silent:1b}
effect give @e[type=chicken, tag=HC.New, sort=nearest, limit=1] minecraft:invisibility infinite 0 true

# Summon interaction entity separately (NOT a passenger — must be standalone to be clickable)
# Offset Y+0.5 above chicken so its hitbox doesn't overlap the chicken's (baby chicken hitbox ~0.35 tall)
# R12: hitbox widened 0.8f x 0.8f -> 1.4f x 1.0f for parity with the active pet (spawn_selected_companion:97).
# KEEP the Y+0.5 offset (the ~1.5 vs the chicken's ~1) — it stops the chicken intercepting clicks.
summon interaction ~1 ~1.5 ~ {Tags:[HC.Interact, Pet, HC.NewInteract], width:1.4f, height:1.0f, response:1b}

# Copy item data from storage to the head display passenger
data modify entity @e[type=item_display, tag=HC.NewHead, sort=nearest, limit=1] item set from storage evercraft:companions home.item

# Set companion.id on all three entities (chicken, head, interaction)
# Uses #hc_owner_id set by place.mcfunction (since @s here is the HS.Marker, not the player)
scoreboard players operation @e[type=chicken, tag=HC.New, sort=nearest, limit=1] companion.id = #hc_owner_id companion.id
scoreboard players operation @e[type=item_display, tag=HC.NewHead, sort=nearest, limit=1] companion.id = #hc_owner_id companion.id
scoreboard players operation @e[type=interaction, tag=HC.NewInteract, sort=nearest, limit=1] companion.id = #hc_owner_id companion.id

# Set the home slot index on all three entities
execute store result score @e[type=chicken, tag=HC.New, sort=nearest, limit=1] hc.slot run data get storage evercraft:companions home.slot
execute store result score @e[type=item_display, tag=HC.NewHead, sort=nearest, limit=1] hc.slot run data get storage evercraft:companions home.slot
execute store result score @e[type=interaction, tag=HC.NewInteract, sort=nearest, limit=1] hc.slot run data get storage evercraft:companions home.slot

# Copy custom name from item components to the head display
data modify entity @e[type=item_display, tag=HC.NewHead, sort=nearest, limit=1] CustomName set from storage evercraft:companions home.item.components."minecraft:custom_name"

# Initialize passive RP timer to current gametime (on the head display)
execute store result score @e[type=item_display, tag=HC.NewHead, sort=nearest, limit=1] hc.rp_timer run time query gametime

# Clean up temporary tags
tag @e[type=chicken, tag=HC.New, sort=nearest, limit=1] remove HC.New
tag @e[type=item_display, tag=HC.NewHead, sort=nearest, limit=1] remove HC.NewHead
tag @e[type=interaction, tag=HC.NewInteract, sort=nearest, limit=1] remove HC.NewInteract
