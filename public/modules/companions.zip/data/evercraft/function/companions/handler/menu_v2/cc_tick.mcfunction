# === COMPANION CATALOGUE — TICK ===
# Called from main tick when any player has pending use

# Process use flag
execute as @a[scores={ec.cc_use=1..}] at @s run function evercraft:companions/handler/menu_v2/cc_process_use

# Reset use score
scoreboard players set @a[scores={ec.cc_use=1..}] ec.cc_use 0
