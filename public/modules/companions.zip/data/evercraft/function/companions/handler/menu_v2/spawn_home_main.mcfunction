# SP5 — Home view: spawn the MAIN floating head (center, larger, pulled forward).
# Run as player. Requires care.head = the main companion's stored Pets[] item (set by spawn_home).
# headidx 0. Head art mirrors spawn_slots:21 (item_display:"head", billboard center). Tagged
# companion.homehead + companion.menuelement (free teardown via close). Interaction = companion.headslot.

# Head item_display (center, forward Z 1.70, scale 0.34).
execute rotated ~ 0 positioned ^ ^1.90 ^1.70 run summon item_display ~ ~ ~ {Tags:["companion.homehead","companion.menuelement","companion.tab_content","companion.homemain"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.34f,0.34f,0.34f]}}
data modify entity @n[type=item_display,tag=companion.homemain,distance=..5] item set from storage evercraft:companions care.head

# Nameplate below the head.
execute rotated ~ 0 positioned ^ ^1.62 ^1.72 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.homehead","companion.menuelement","companion.tab_content","companion.homemainname"],billboard:"center",background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
data modify entity @n[type=text_display,tag=companion.homemainname,distance=..5] text set from storage evercraft:companions care.head.components."minecraft:custom_name"

# Clickable hitbox (selects this head as Care focus). headidx 0 = MAIN.
# 2026-06-17: dropped from ^1.80 (box [1.80,2.10], center 1.95 — biased ABOVE the head model at ^1.90 so
# the bottom of the rendered head/cow wasn't clickable) to ^1.70 + height 0.34 (box [1.70,2.04], center
# 1.87 ≈ head center) so it catches the bottom of the head. Clears the nameplate (^1.62) + Wayfarer
# banner hitbox (top 1.59) below it.
execute rotated ~ 0 positioned ^ ^1.70 ^1.68 run summon interaction ~ ~ ~ {Tags:["companion.headslot","companion.menuelement","companion.tab_content","companion.homemainclick"],width:0.30f,height:0.34f,response:1b}
scoreboard players set @n[type=interaction,tag=companion.homemainclick,distance=..5] companion.headidx 0

# Clear temp build tags.
tag @e[type=item_display,tag=companion.homemain,distance=..5] remove companion.homemain
tag @e[type=text_display,tag=companion.homemainname,distance=..5] remove companion.homemainname
tag @e[type=interaction,tag=companion.homemainclick,distance=..5] remove companion.homemainclick
