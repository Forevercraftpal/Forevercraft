# Frog Pet Passive Abilities
# - Leap: Jump strength (0.43 → 0.85)
# - Sticky Landing: Safe fall (6 → 11)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.frog

# Leap: Jump strength (0.43 → 0.85)
execute if score #value companion.calc matches 1..7 run attribute @s jump_strength base set 0.443
execute if score #value companion.calc matches 8..12 run attribute @s jump_strength base set 0.468
execute if score #value companion.calc matches 13..17 run attribute @s jump_strength base set 0.489
execute if score #value companion.calc matches 18..22 run attribute @s jump_strength base set 0.511
execute if score #value companion.calc matches 23..27 run attribute @s jump_strength base set 0.532
execute if score #value companion.calc matches 28..32 run attribute @s jump_strength base set 0.553
execute if score #value companion.calc matches 33..37 run attribute @s jump_strength base set 0.574
execute if score #value companion.calc matches 38..42 run attribute @s jump_strength base set 0.595
execute if score #value companion.calc matches 43..47 run attribute @s jump_strength base set 0.617
execute if score #value companion.calc matches 48..52 run attribute @s jump_strength base set 0.638
execute if score #value companion.calc matches 53..57 run attribute @s jump_strength base set 0.659
execute if score #value companion.calc matches 58..62 run attribute @s jump_strength base set 0.68
execute if score #value companion.calc matches 63..67 run attribute @s jump_strength base set 0.702
execute if score #value companion.calc matches 68..72 run attribute @s jump_strength base set 0.723
execute if score #value companion.calc matches 73..77 run attribute @s jump_strength base set 0.744
execute if score #value companion.calc matches 78..82 run attribute @s jump_strength base set 0.765
execute if score #value companion.calc matches 83..87 run attribute @s jump_strength base set 0.786
execute if score #value companion.calc matches 88..92 run attribute @s jump_strength base set 0.808
execute if score #value companion.calc matches 93..97 run attribute @s jump_strength base set 0.829
execute if score #value companion.calc matches 98..100 run attribute @s jump_strength base set 0.846

# Sticky Landing: Safe fall (6 → 11)
execute if score #value companion.calc matches 1..7 run return run attribute @s safe_fall_distance base set 6.152
execute if score #value companion.calc matches 8..12 run return run attribute @s safe_fall_distance base set 6.455
execute if score #value companion.calc matches 13..17 run return run attribute @s safe_fall_distance base set 6.707
execute if score #value companion.calc matches 18..22 run return run attribute @s safe_fall_distance base set 6.96
execute if score #value companion.calc matches 23..27 run return run attribute @s safe_fall_distance base set 7.212
execute if score #value companion.calc matches 28..32 run return run attribute @s safe_fall_distance base set 7.465
execute if score #value companion.calc matches 33..37 run return run attribute @s safe_fall_distance base set 7.717
execute if score #value companion.calc matches 38..42 run return run attribute @s safe_fall_distance base set 7.97
execute if score #value companion.calc matches 43..47 run return run attribute @s safe_fall_distance base set 8.222
execute if score #value companion.calc matches 48..52 run return run attribute @s safe_fall_distance base set 8.475
execute if score #value companion.calc matches 53..57 run return run attribute @s safe_fall_distance base set 8.727
execute if score #value companion.calc matches 58..62 run return run attribute @s safe_fall_distance base set 8.98
execute if score #value companion.calc matches 63..67 run return run attribute @s safe_fall_distance base set 9.232
execute if score #value companion.calc matches 68..72 run return run attribute @s safe_fall_distance base set 9.485
execute if score #value companion.calc matches 73..77 run return run attribute @s safe_fall_distance base set 9.737
execute if score #value companion.calc matches 78..82 run return run attribute @s safe_fall_distance base set 9.99
execute if score #value companion.calc matches 83..87 run return run attribute @s safe_fall_distance base set 10.242
execute if score #value companion.calc matches 88..92 run return run attribute @s safe_fall_distance base set 10.495
execute if score #value companion.calc matches 93..97 run return run attribute @s safe_fall_distance base set 10.747
execute if score #value companion.calc matches 98..100 run return run attribute @s safe_fall_distance base set 10.949
