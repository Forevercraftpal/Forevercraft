# Oracle Pet Passive Abilities
# - Dream Eye: Luck (0.5 → 2.5)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.oracle

# Dream Eye: Luck (0.5 → 2.5)
execute if score #value companion.calc matches 1..7 run return run attribute @s luck base set 0.561
execute if score #value companion.calc matches 8..12 run return run attribute @s luck base set 0.682
execute if score #value companion.calc matches 13..17 run return run attribute @s luck base set 0.783
execute if score #value companion.calc matches 18..22 run return run attribute @s luck base set 0.884
execute if score #value companion.calc matches 23..27 run return run attribute @s luck base set 0.985
execute if score #value companion.calc matches 28..32 run return run attribute @s luck base set 1.086
execute if score #value companion.calc matches 33..37 run return run attribute @s luck base set 1.187
execute if score #value companion.calc matches 38..42 run return run attribute @s luck base set 1.288
execute if score #value companion.calc matches 43..47 run return run attribute @s luck base set 1.389
execute if score #value companion.calc matches 48..52 run return run attribute @s luck base set 1.49
execute if score #value companion.calc matches 53..57 run return run attribute @s luck base set 1.591
execute if score #value companion.calc matches 58..62 run return run attribute @s luck base set 1.692
execute if score #value companion.calc matches 63..67 run return run attribute @s luck base set 1.793
execute if score #value companion.calc matches 68..72 run return run attribute @s luck base set 1.894
execute if score #value companion.calc matches 73..77 run return run attribute @s luck base set 1.995
execute if score #value companion.calc matches 78..82 run return run attribute @s luck base set 2.096
execute if score #value companion.calc matches 83..87 run return run attribute @s luck base set 2.197
execute if score #value companion.calc matches 88..92 run return run attribute @s luck base set 2.298
execute if score #value companion.calc matches 93..97 run return run attribute @s luck base set 2.399
execute if score #value companion.calc matches 98..100 run return run attribute @s luck base set 2.48
