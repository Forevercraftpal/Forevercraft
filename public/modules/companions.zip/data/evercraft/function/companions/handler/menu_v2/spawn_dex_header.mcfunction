# Companion Catalogue — Dex progress header (snapshot via macro). Run as player, hub-center context.
# $(dex_now)   = unique species owned (pre-clamped to 104 by spawn_hub).
# $(dex_shiny) = species owned as shiny; the shiny line only renders once #dex_sh ec.temp >= 1 (i.e. the
#               player has caught their first shiny), so new players never see an empty shiny dex.
# Baked as literals (not live @s scores) to dodge the text_display selector gotcha + cross-player races;
# the hub rebuilds on every open so the snapshot is always current. Tagged companion.menuelement for the
# standard menu teardown. "/ 104" mirrors #comp_dex_total. Sits between the [?] (^2.10) and the grid (^1.65).
$execute rotated ~ 0 positioned ^ ^1.95 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.dex_header"],billboard:"center",text:["",{text:"❖ ",color:"gold"},{text:"$(dex_now)",color:"gold",bold:true},{text:" / 104 Discovered",color:"gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.34f,0.34f,0.34f]}}
$execute if score #dex_sh ec.temp matches 1.. rotated ~ 0 positioned ^ ^1.86 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.dex_header"],billboard:"center",text:["",{text:"✨ ",color:"#FFD700"},{text:"$(dex_shiny)",color:"#FFD700",bold:true},{text:" / 104 Shiny",color:"gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.30f,0.30f,0.30f]}}
scoreboard players operation @e[type=text_display,tag=companion.dex_header,distance=..5] companion.id = @s companion.id
tag @e[type=text_display,tag=companion.dex_header,distance=..5] remove companion.dex_header
