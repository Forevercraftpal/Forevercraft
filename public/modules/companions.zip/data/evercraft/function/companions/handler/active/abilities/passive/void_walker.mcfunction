# Void Walker Pet Passive Abilities
# - Void Touched: Attack damage (2.0 → 5.0)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.void_walker

# Void Touched: Attack damage (2.0 → 5.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s attack_damage base set 2.091
execute if score #value companion.calc matches 8..12 run return run attribute @s attack_damage base set 2.273
execute if score #value companion.calc matches 13..17 run return run attribute @s attack_damage base set 2.424
execute if score #value companion.calc matches 18..22 run return run attribute @s attack_damage base set 2.576
execute if score #value companion.calc matches 23..27 run return run attribute @s attack_damage base set 2.727
execute if score #value companion.calc matches 28..32 run return run attribute @s attack_damage base set 2.879
execute if score #value companion.calc matches 33..37 run return run attribute @s attack_damage base set 3.03
execute if score #value companion.calc matches 38..42 run return run attribute @s attack_damage base set 3.182
execute if score #value companion.calc matches 43..47 run return run attribute @s attack_damage base set 3.333
execute if score #value companion.calc matches 48..52 run return run attribute @s attack_damage base set 3.485
execute if score #value companion.calc matches 53..57 run return run attribute @s attack_damage base set 3.636
execute if score #value companion.calc matches 58..62 run return run attribute @s attack_damage base set 3.788
execute if score #value companion.calc matches 63..67 run return run attribute @s attack_damage base set 3.939
execute if score #value companion.calc matches 68..72 run return run attribute @s attack_damage base set 4.091
execute if score #value companion.calc matches 73..77 run return run attribute @s attack_damage base set 4.242
execute if score #value companion.calc matches 78..82 run return run attribute @s attack_damage base set 4.394
execute if score #value companion.calc matches 83..87 run return run attribute @s attack_damage base set 4.545
execute if score #value companion.calc matches 88..92 run return run attribute @s attack_damage base set 4.697
execute if score #value companion.calc matches 93..97 run return run attribute @s attack_damage base set 4.848
execute if score #value companion.calc matches 98..100 run return run attribute @s attack_damage base set 4.97
