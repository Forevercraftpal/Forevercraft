# Sabertooth Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.sabertooth

# Primal Sweep: Sweep ratio (0.3 → 1.0)
$execute if score #value companion.calc matches 1..7 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.321 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.364 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.399 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.434 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.47 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.505 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.54 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.576 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.611 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.646 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.682 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.717 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.753 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.788 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.823 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.859 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.894 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.929 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.965 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s sweeping_damage_ratio modifier add evercraft:home/slot$(ability_slot)/sweeping_damage_ratio 0.993 add_value

# Predator's Pace: Speed (0.11 → 0.14)
$execute if score #value companion.calc matches 1..7 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.111 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.113 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.114 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.116 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.117 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.119 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.12 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.122 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.123 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.125 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.126 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.128 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.129 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.131 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.132 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.134 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.135 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.137 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.138 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.14 add_value
