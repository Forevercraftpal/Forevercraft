# Nebula Kit Pet Passive Abilities (Exquisite — Gacha Exclusive)
# - Cosmic Awareness: Glowing on hostile mobs within 16 blocks
# - Stellar Agility: Speed I + Jump Boost I + Haste I
# - Star Sight: Luck 1.0 → 5.0

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.nebula_kit

# Cosmic Awareness - Glowing on hostile mobs within 16 blocks
effect give @e[type=#minecraft:hostile,distance=..16] glowing 3 0 true

# Stellar Agility - Speed I + Jump Boost I + Haste I
execute unless score @s ec.h_speed matches 2.. run effect give @s speed 5 0 true
effect give @s jump_boost 5 0 true
execute unless score @s ec.h_haste matches 2.. run effect give @s haste 5 0 true

# Star Sight - Luck scaling (1.0 → 5.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s luck base set 1.0
execute if score #value companion.calc matches 8..12 run return run attribute @s luck base set 1.211
execute if score #value companion.calc matches 13..17 run return run attribute @s luck base set 1.395
execute if score #value companion.calc matches 18..22 run return run attribute @s luck base set 1.579
execute if score #value companion.calc matches 23..27 run return run attribute @s luck base set 1.763
execute if score #value companion.calc matches 28..32 run return run attribute @s luck base set 1.947
execute if score #value companion.calc matches 33..37 run return run attribute @s luck base set 2.132
execute if score #value companion.calc matches 38..42 run return run attribute @s luck base set 2.316
execute if score #value companion.calc matches 43..47 run return run attribute @s luck base set 2.5
execute if score #value companion.calc matches 48..52 run return run attribute @s luck base set 2.684
execute if score #value companion.calc matches 53..57 run return run attribute @s luck base set 2.868
execute if score #value companion.calc matches 58..62 run return run attribute @s luck base set 3.053
execute if score #value companion.calc matches 63..67 run return run attribute @s luck base set 3.237
execute if score #value companion.calc matches 68..72 run return run attribute @s luck base set 3.421
execute if score #value companion.calc matches 73..77 run return run attribute @s luck base set 3.605
execute if score #value companion.calc matches 78..82 run return run attribute @s luck base set 3.789
execute if score #value companion.calc matches 83..87 run return run attribute @s luck base set 3.974
execute if score #value companion.calc matches 88..92 run return run attribute @s luck base set 4.158
execute if score #value companion.calc matches 93..97 run return run attribute @s luck base set 4.342
execute if score #value companion.calc matches 98..100 run return run attribute @s luck base set 5.0
