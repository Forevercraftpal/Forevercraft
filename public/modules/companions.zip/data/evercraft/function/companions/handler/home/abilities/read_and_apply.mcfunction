# ============================================================
# Home Companion Abilities — Read data from entity and apply
# Run as: HomeCompanion item_display entity
# Reads signature, level, slot from entity and dispatches to apply_slot
# ============================================================

# Read companion signature (type name) from profile properties
data modify storage evercraft:companions home.ability_signature set from entity @s item.components."minecraft:profile".properties[{name:"signature"}].value

# Read level from profile properties and convert to integer
data modify storage evercraft:companions math.string set string entity @s item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

# Store slot number to storage for macro
execute store result storage evercraft:companions home.ability_slot int 1 run scoreboard players get @s hc.slot

# Apply abilities as the owner player
execute as @a[predicate=evercraft:companions/check_id, limit=1] run function evercraft:companions/handler/home/abilities/apply_slot with storage evercraft:companions home
