# Output all 25 memories to chat — unlocked (light_purple) or locked (dark_gray ???)
# #mem_bits companion.calc already set by show_info_screen

# Memory 0: First Steps Together
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"First Steps Together","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 1: The Hunt
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #2 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"The Hunt","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 2: Against the Colossus
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b2 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Against the Colossus","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 3: Treasure Found
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b3 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Treasure Found","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 4: New Horizons
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b4 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"New Horizons","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 5: The Long Road
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b5 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"The Long Road","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 6: Into the Depths
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b6 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Into the Depths","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 7: Through the Portal
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b7 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Through the Portal","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 8: A Mythical Discovery
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b8 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"A Mythical Discovery","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 9: Eternal Bond
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b9 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"gold"},{"text":"Eternal Bond","color":"gold","bold":true}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 10: Mountain Summit
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b10 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Mountain Summit","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 11: Ocean Abyss
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b11 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Ocean Abyss","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 12: Pack Leader
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b12 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Pack Leader","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 13: Patron Slayer
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b13 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Patron Slayer","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 14: Near Death Experience
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b14 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Near Death Experience","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 15: Marathon Runner
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b15 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Marathon Runner","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 16: Biome Explorer
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b16 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Biome Explorer","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 17: Golden Feast
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b17 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Golden Feast","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 18: Trial by Fire
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b18 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Trial by Fire","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 19: Starlight Vigil
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b19 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Starlight Vigil","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 20: Warden's Shadow
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b20 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Warden's Shadow","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 21: Homeward Bound
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b21 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Homeward Bound","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 22: Pilgrimage
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b22 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Pilgrimage","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 23: Whiteout
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b23 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Whiteout","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Memory 24: Witching Hour
scoreboard players operation #check companion.calc = #mem_bits companion.calc
scoreboard players operation #check companion.calc /= #mem_b24 companion.calc
scoreboard players operation #check companion.calc %= #2 companion.calc
execute if score #check companion.calc matches 1 run tellraw @s [{"text":"  "},{"text":"\u2726 ","color":"light_purple"},{"text":"Witching Hour","color":"light_purple"}]
execute if score #check companion.calc matches 0 run tellraw @s [{"text":"  "},{"text":"??? ","color":"dark_gray","italic":true}]

# Footer
tellraw @s [{"text":"  "},{"text":"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550","color":"light_purple"}]
