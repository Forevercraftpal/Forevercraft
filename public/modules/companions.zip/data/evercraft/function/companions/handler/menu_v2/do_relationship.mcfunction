# Show active pet's relationship status
# Called as the player

# Must have an active pet
data modify storage evercraft:notify stage.c set value [{text:"Summon a pet first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @s[tag=companion.activepet] run return run function evercraft:util/notify/emit

scoreboard players operation #Search companion.id = @s companion.id

# Load relationship data
function evercraft:companions/handler/relationship/load_rp

# Show particles above pet
function evercraft:companions/handler/relationship/show_status

# Display relationship info in chat
execute if score @s companion.rellevel matches 0 run tellraw @s [{text:"[",color:"dark_gray"},{text:"Pets",color:"gold"},{text:"] ",color:"dark_gray"},{text:"Relationship: ",color:"gray"},{text:"Neutral",color:"white"},{text:" | RP: ",color:"gray"},{score:{name:"@s",objective:"companion.rp"},color:"yellow"},{text:" | Bonus: ",color:"gray"},{score:{name:"@s",objective:"companion.relmult"},color:"green"},{text:"%",color:"green"}]
execute if score @s companion.rellevel matches 1 run tellraw @s [{text:"[",color:"dark_gray"},{text:"Pets",color:"gold"},{text:"] ",color:"dark_gray"},{text:"Relationship: ",color:"gray"},{text:"Friendly",color:"green"},{text:" | RP: ",color:"gray"},{score:{name:"@s",objective:"companion.rp"},color:"yellow"},{text:" | Bonus: ",color:"gray"},{score:{name:"@s",objective:"companion.relmult"},color:"green"},{text:"%",color:"green"}]
execute if score @s companion.rellevel matches 2 run tellraw @s [{text:"[",color:"dark_gray"},{text:"Pets",color:"gold"},{text:"] ",color:"dark_gray"},{text:"Relationship: ",color:"gray"},{text:"Bonded",color:"aqua"},{text:" | RP: ",color:"gray"},{score:{name:"@s",objective:"companion.rp"},color:"yellow"},{text:" | Bonus: ",color:"gray"},{score:{name:"@s",objective:"companion.relmult"},color:"green"},{text:"%",color:"green"}]
execute if score @s companion.rellevel matches 3 run tellraw @s [{text:"[",color:"dark_gray"},{text:"Pets",color:"gold"},{text:"] ",color:"dark_gray"},{text:"Relationship: ",color:"gray"},{text:"Devoted",color:"light_purple"},{text:" | RP: ",color:"gray"},{score:{name:"@s",objective:"companion.rp"},color:"yellow"},{text:" | Bonus: ",color:"gray"},{score:{name:"@s",objective:"companion.relmult"},color:"green"},{text:"%",color:"green"}]
execute if score @s companion.rellevel matches 4 run tellraw @s [{text:"[",color:"dark_gray"},{text:"Pets",color:"gold"},{text:"] ",color:"dark_gray"},{text:"Relationship: ",color:"gray"},{text:"Soulbound",color:"gold"},{text:" | RP: ",color:"gray"},{score:{name:"@s",objective:"companion.rp"},color:"yellow"},{text:" | Bonus: ",color:"gray"},{score:{name:"@s",objective:"companion.relmult"},color:"green"},{text:"%",color:"green"}]
execute if score @s companion.rellevel matches 5 run tellraw @s [{text:"[",color:"dark_gray"},{text:"Pets",color:"gold"},{text:"] ",color:"dark_gray"},{text:"Relationship: ",color:"gray"},{text:"Eternal Bond",color:"yellow",bold:true},{text:" | RP: ",color:"gray"},{score:{name:"@s",objective:"companion.rp"},color:"yellow"},{text:" | Bonus: ",color:"gray"},{score:{name:"@s",objective:"companion.relmult"},color:"green"},{text:"%",color:"green"}]

# Play a feedback sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.2
