# SP5 — Write the bond-tier line onto the freshly-spawned care_bond text_display.
# Run as player. Requires companion.rellevel loaded (care/load_focus_rp). Tier names mirror
# relationship/level_up:8-12 (0 = New Friend default). Display-agnostic: reads whatever max
# companion.rellevel resolves to, so an SP2 bond-rank expansion is reflected without edits here.
execute if score @s companion.rellevel matches 0 run data modify entity @n[type=text_display,tag=companion.care_bond,distance=..5] text set value [{text:"Bond: ",color:"gray"},{text:"New Friend",color:"white"}]
execute if score @s companion.rellevel matches 1 run data modify entity @n[type=text_display,tag=companion.care_bond,distance=..5] text set value [{text:"Bond: ",color:"gray"},{text:"Friendly",color:"green"}]
execute if score @s companion.rellevel matches 2 run data modify entity @n[type=text_display,tag=companion.care_bond,distance=..5] text set value [{text:"Bond: ",color:"gray"},{text:"Bonded",color:"green"}]
execute if score @s companion.rellevel matches 3 run data modify entity @n[type=text_display,tag=companion.care_bond,distance=..5] text set value [{text:"Bond: ",color:"gray"},{text:"Devoted",color:"blue"}]
execute if score @s companion.rellevel matches 4 run data modify entity @n[type=text_display,tag=companion.care_bond,distance=..5] text set value [{text:"Bond: ",color:"gray"},{text:"Soulbound",color:"light_purple"}]
execute if score @s companion.rellevel matches 5.. run data modify entity @n[type=text_display,tag=companion.care_bond,distance=..5] text set value [{text:"Bond: ",color:"gray"},{text:"Eternal Bond",color:"gold"}]
