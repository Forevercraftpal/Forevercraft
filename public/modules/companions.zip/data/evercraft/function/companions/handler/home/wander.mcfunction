# ============================================================
# Home Companion — Wander containment check
# Run as: HomeCompanion chicken entity, at its position
# Called every 2s from home/tick
# The chicken wanders naturally via mob AI — this just prevents
# it from straying too far from the hearthstone.
# ============================================================

# If no hearthstone marker within 64 blocks, teleport back to nearest one
execute unless entity @e[type=marker, tag=HS.Marker, distance=..64] at @e[type=marker, tag=HS.Marker, sort=nearest, limit=1] run tp @s ~1 ~1 ~
