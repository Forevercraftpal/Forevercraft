# Creeper Pet Passive Abilities
# - Blast Proof: Expl KB res (0.05 → 1.0)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.creeper

# Blast Proof: Expl KB res (0.05 → 1.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s explosion_knockback_resistance base set 0.079
execute if score #value companion.calc matches 8..12 run return run attribute @s explosion_knockback_resistance base set 0.136
execute if score #value companion.calc matches 13..17 run return run attribute @s explosion_knockback_resistance base set 0.184
execute if score #value companion.calc matches 18..22 run return run attribute @s explosion_knockback_resistance base set 0.232
execute if score #value companion.calc matches 23..27 run return run attribute @s explosion_knockback_resistance base set 0.28
execute if score #value companion.calc matches 28..32 run return run attribute @s explosion_knockback_resistance base set 0.328
execute if score #value companion.calc matches 33..37 run return run attribute @s explosion_knockback_resistance base set 0.376
execute if score #value companion.calc matches 38..42 run return run attribute @s explosion_knockback_resistance base set 0.424
execute if score #value companion.calc matches 43..47 run return run attribute @s explosion_knockback_resistance base set 0.472
execute if score #value companion.calc matches 48..52 run return run attribute @s explosion_knockback_resistance base set 0.52
execute if score #value companion.calc matches 53..57 run return run attribute @s explosion_knockback_resistance base set 0.568
execute if score #value companion.calc matches 58..62 run return run attribute @s explosion_knockback_resistance base set 0.616
execute if score #value companion.calc matches 63..67 run return run attribute @s explosion_knockback_resistance base set 0.664
execute if score #value companion.calc matches 68..72 run return run attribute @s explosion_knockback_resistance base set 0.712
execute if score #value companion.calc matches 73..77 run return run attribute @s explosion_knockback_resistance base set 0.76
execute if score #value companion.calc matches 78..82 run return run attribute @s explosion_knockback_resistance base set 0.808
execute if score #value companion.calc matches 83..87 run return run attribute @s explosion_knockback_resistance base set 0.856
execute if score #value companion.calc matches 88..92 run return run attribute @s explosion_knockback_resistance base set 0.904
execute if score #value companion.calc matches 93..97 run return run attribute @s explosion_knockback_resistance base set 0.952
execute if score #value companion.calc matches 98..100 run return run attribute @s explosion_knockback_resistance base set 0.99
