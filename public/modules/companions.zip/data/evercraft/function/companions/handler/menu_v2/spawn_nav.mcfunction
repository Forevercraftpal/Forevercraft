# Spawn navigation arrows for pagination
# Flanking the Page text in the center of the action bar
# ^positive = player's left = viewer's left, ^negative = player's right = viewer's right

# Previous page arrow (left of page text)
# MP-P3.12: hit recentered on text_y - h/2 per R.1; was ^1.37 with h=0.06 (AABB top barely touched glyph bottom)
execute rotated ~ 0 positioned ^ ^0.7 ^1.76 positioned ^0.38 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuprev","companion.menuelement","companion.navarrow","companion.tab_content"],billboard:"center",text:{text:"\u25C0",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
execute rotated ~ 0 positioned ^ ^0.67 ^1.78 positioned ^0.38 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuprevclick","companion.menuelement","companion.navarrow","companion.tab_content"],width:0.10f,height:0.06f,response:1b}

# Next page arrow (right of page text)
# MP-P3.12: hit recentered on text_y - h/2 per R.1
execute rotated ~ 0 positioned ^ ^0.7 ^1.76 positioned ^-0.38 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menunext","companion.menuelement","companion.navarrow","companion.tab_content"],billboard:"center",text:{text:"\u25B6",color:"green"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
execute rotated ~ 0 positioned ^ ^0.67 ^1.78 positioned ^-0.38 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menunextclick","companion.menuelement","companion.navarrow","companion.tab_content"],width:0.10f,height:0.06f,response:1b}

# Tag with owner ID
scoreboard players operation @e[type=text_display,tag=companion.navarrow,distance=..7] companion.id = #Search companion.id
scoreboard players operation @e[type=interaction,tag=companion.navarrow,distance=..7] companion.id = #Search companion.id
