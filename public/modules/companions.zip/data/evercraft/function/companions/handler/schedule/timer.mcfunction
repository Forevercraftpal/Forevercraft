# Companion Schedule Timer — Gametime-based (self-scheduling 1s)
# OPT: Was 46 ops/tick (23 decrements + 23 checks = 920 ops/sec). Now ~33 ops/sec total.
# OPT: Long timers (1h+) moved to timer_slow (60s schedule) — saves 5 modulos per second
# OPT: Divisor constants precomputed in load (eliminates 17 set ops/sec)

schedule function evercraft:companions/handler/schedule/timer 1s

# Gate: skip if no active pets (most of the time on non-pet servers)
execute unless entity @a[tag=companion.activepet] unless entity @e[type=item_display,tag=Companion,limit=1] run return 0

# Convert gametime to seconds (÷20)
execute store result score #cst_sec companion.calc run time query gametime
scoreboard players operation #cst_sec companion.calc /= #20 companion.calc

# === SHORT TIMERS (3s-30s) — companion abilities ===
# OPT-77: Even/odd split — all intervals except 3s and 5s are even, so on odd seconds
# we skip 15 modulo operations (saves ~30 scoreboard ops 50% of the time)

# 3s — always check (odd interval)
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #3 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/3s

# 5s — always check (odd interval, also check_for_player)
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #5 companion.calc
execute if score #cst_mod companion.calc matches 0 as @e[type=item_display, tag=Companion] at @s run function evercraft:companions/handler/active/check_for_player
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/5s

# Even-second check: skip ALL even-interval modulos on odd seconds
scoreboard players operation #cst_even companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_even companion.calc %= #2 companion.calc
execute unless score #cst_even companion.calc matches 0 run return 0

# === EVEN TIMERS (only run on even seconds — saves 30 ops/sec half the time) ===
# 10s
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #10 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/10s

# 12s
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #12 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/12s

# 14s
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #14 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/14s

# 16s
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #16 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/16s

# 18s
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #18 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/18s

# 20s
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #20 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/20s

# 22s
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #22 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/22s

# 24s
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #24 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/24s

# 26s
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #26 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/26s

# 28s
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #28 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/28s

# 30s
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #30 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/30s

# === MEDIUM TIMERS (1m-3m) — all even, already gated by even-second check ===

# 1m (60s)
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #60 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/1m

# 1m30s (90s)
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #90 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/1m30s

# 2m (120s)
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #120 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/2m

# 2m30s (150s)
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #150 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/2m30s

# 3m (180s)
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #180 companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/3m

