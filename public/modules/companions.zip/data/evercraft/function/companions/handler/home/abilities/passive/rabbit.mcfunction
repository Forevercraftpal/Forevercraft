# Grasshopper Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.grasshopper

# Locust Song: permanent Haste (Haste II at level >= 50)
effect give @s haste infinite 0 true
execute if score #value companion.calc matches 50.. run effect give @s haste infinite 1 true

# Spring Legs: Jump strength (0.43 → 1.01)
$execute if score #value companion.calc matches 1..7 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.448 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.483 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.512 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.541 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.571 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.6 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.629 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.658 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.688 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.717 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.746 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.776 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.805 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.834 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.864 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.893 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.922 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.951 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.981 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 1.004 add_value

# Spring Legs: Safe fall (6 → 13)
$execute if score #value companion.calc matches 1..7 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 6.212 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 6.636 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 6.99 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 7.343 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 7.697 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 8.051 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 8.404 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 8.758 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 9.111 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 9.465 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 9.818 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 10.172 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 10.525 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 10.879 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 11.232 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 11.586 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 11.939 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 12.293 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 12.646 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 12.929 add_value
