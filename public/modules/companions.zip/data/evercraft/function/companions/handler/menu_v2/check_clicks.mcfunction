# Check for interaction entity clicks
# Interaction entities set attack/interaction data when clicked
# OPT: Pet slot clicks consolidated from 96 selectors to 2 (score-based dispatch)

scoreboard players operation #Search companion.id = @s companion.id

# === BUDDY SYSTEM: Tab clicks (check first, before pet slot clicks) ===
function evercraft:buddy/gui/check_tab_clicks

# Skip companion-specific clicks if not on Tab 1
execute unless score @s ec.bd_tab matches 1 unless score @s ec.bd_tab matches 0 run return fail

# Check action buttons
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
# Deloris Pack button
execute as @e[type=interaction,tag=companion.menupackclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction at @a[tag=companion.inmenuv2] on target run function evercraft:companions/handler/active/abilities/deloris_pack/open
execute as @e[type=interaction,tag=companion.menupackclick,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction

execute as @e[type=interaction,tag=companion.menuhomeclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:companions/handler/home/on_menu_place
execute as @e[type=interaction,tag=companion.menuhomeclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.menuguildclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:companions/handler/guild/on_menu_place
execute as @e[type=interaction,tag=companion.menuguildclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.menuremoveclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/on_remove
execute as @e[type=interaction,tag=companion.menuremoveclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.menuvisclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/on_visibility
execute as @e[type=interaction,tag=companion.menuvisclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.menurelclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/on_relationship
execute as @e[type=interaction,tag=companion.menurelclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.menutreatclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/on_treat
execute as @e[type=interaction,tag=companion.menutreatclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.menuinfoclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/do_info
execute as @e[type=interaction,tag=companion.menuinfoclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# Check navigation arrows
execute as @e[type=interaction,tag=companion.menunextclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/next_page
execute as @e[type=interaction,tag=companion.menunextclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.menuprevclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/prev_page
execute as @e[type=interaction,tag=companion.menuprevclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# OPT: Check ALL pet slot right-clicks in 1 selector (was 48 individual selectors)
# Score-based dispatch: companion.slot stores 0-47, macro reads from storage.
# 2026-06-06: NO `on target` — on_slot_click must run AS the clicked interaction so `@s companion.slot`
# resolves to THAT slot (companion.slot lives on the interaction, set in spawn_slots, never on the player).
# `on target` switched @s to the player → its unset companion.slot → `store result` left click.slot at its
# previous value → every grid click re-summoned the first-selected pet. select_companion re-selects the
# player via @a[inmenuv2], so no player context is needed here (mirrors on_slot_attack on the next line).
execute as @e[type=interaction,tag=companion.petclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run function evercraft:companions/handler/menu_v2/on_slot_click
execute as @e[type=interaction,tag=companion.petclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction

# OPT: Check ALL pet slot left-clicks in 1 selector (was 48 individual selectors)
execute as @e[type=interaction,tag=companion.petclick,predicate=evercraft:companions/check_id] if data entity @s attack run function evercraft:companions/handler/menu_v2/on_slot_attack

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
# (pet slots already answer a punch with the full dossier — companion_info_chat; these cover the action buttons)
execute as @e[type=interaction,tag=companion.menuinfoclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Pet Info",b:"Opens the full info screen for your active pet."}
execute as @e[type=interaction,tag=companion.menuinfoclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.menutreatclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Treat",b:"Gives your active pet a treat — lifts its mood and bond."}
execute as @e[type=interaction,tag=companion.menutreatclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.menurelclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Bond",b:"Shows the bond with your active pet — mood, points, and what they unlock."}
execute as @e[type=interaction,tag=companion.menurelclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.menuvisclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Visibility",b:"Toggles whether your companion walks beside you or stays unseen."}
execute as @e[type=interaction,tag=companion.menuvisclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.menuremoveclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Dismiss",b:"Returns your summoned companion to a head item — it leaves this list until placed again."}
execute as @e[type=interaction,tag=companion.menuremoveclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.menuhomeclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Place at Home",b:"Arms home-placing — the next pet you click settles at your home."}
execute as @e[type=interaction,tag=companion.menuhomeclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.menuguildclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Place at Guild",b:"Arms guild-placing — the next pet you click settles at the guild hall."}
execute as @e[type=interaction,tag=companion.menuguildclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.menupackclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Pack",b:"Opens the pack saddlebags — five slots your llama companion carries for you."}
execute as @e[type=interaction,tag=companion.menupackclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.menuprevclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous Page",b:"Flips to the previous page of companions."}
execute as @e[type=interaction,tag=companion.menuprevclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.menunextclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next Page",b:"Flips to the next page of companions."}
execute as @e[type=interaction,tag=companion.menunextclick,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s attack run data remove entity @s attack
