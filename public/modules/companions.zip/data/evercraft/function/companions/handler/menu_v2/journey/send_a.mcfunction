# SP5 — Journey: Send Sub A on the picked themed run. Run as player. Sets companion.jrnyslot=1, the
# ec.journey_send trigger=1 (SP4 contract), then drives journey/dispatch_send synchronously so the in-flight
# status renders immediately. dispatch_send runs journey/send (which validates assignment / not-already-out /
# not-main / not-home and writes jA_*), then resets+re-enables the trigger. Refresh after.
scoreboard players set @s companion.jrnyslot 1
scoreboard players set @s ec.journey_send 1
function evercraft:companions/journey/dispatch_send
function evercraft:companions/handler/menu_v2/journey/refresh
