# ============================================================
# Guild Companion — Toggle "Place at Guild" mode
# Run as: player in menu
# ============================================================

# Validate: player is in a guild
execute unless score @s ec.guild_id matches 1.. run return run tellraw @s [{text:"[Guild] ",color:"dark_purple"},{text:"You must be in a guild to place companions.",color:"red"}]

# Validate: player is in guild zone
execute unless score @s ec.guild_in_zone matches 1 run return run tellraw @s [{text:"[Guild] ",color:"dark_purple"},{text:"You must be in the guild zone.",color:"red"}]

# Validate: under the 25-companion cap
scoreboard players operation #Search ec.guild_id = @s ec.guild_id
execute positioned 0 -61 0 store result score #gc_count ec.temp run scoreboard players get @e[type=marker,tag=ec.guild,distance=..2,predicate=evercraft:guild/check_id,limit=1] ec.gs_pet_count
execute if score #gc_count ec.temp matches 25.. run return run tellraw @s [{text:"[Guild] ",color:"dark_purple"},{text:"The guild already has 25 companions (max).",color:"red"}]

# Validate: player hasn't exceeded their personal 3-companion limit
execute if score @s ec.gs_my_pets matches 3.. run return run tellraw @s [{text:"[Guild] ",color:"dark_purple"},{text:"You can only place up to 3 companions at the guild.",color:"red"}]

# Toggle the placing mode
execute if entity @s[tag=gc.placing] run return run function evercraft:companions/handler/guild/cancel_place_mode
tag @s add gc.placing

# Cancel home placing mode if active
execute if entity @s[tag=hc.placing] run function evercraft:companions/handler/home/cancel_place_mode

# Update button text to show active state
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=text_display, tag=companion.menuguildtext, predicate=evercraft:companions/check_id] run data modify entity @s text set value [{text:"\u2694 ",color:"aqua"},{text:"Select Pet",color:"white",bold:true}]

tellraw @s [{text:"[Guild] ",color:"dark_purple"},{text:"Click a companion to place at the guild.",color:"yellow"}]
playsound minecraft:ui.button.click master @s ~ ~ ~ 0.5 1.0
