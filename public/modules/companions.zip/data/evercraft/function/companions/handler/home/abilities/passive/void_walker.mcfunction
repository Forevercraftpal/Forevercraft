# Void Walker Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.void_walker

# Void Touched: Attack damage (2.0 → 5.0)
$execute if score #value companion.calc matches 1..7 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.091 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.273 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.424 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.576 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.727 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.879 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.03 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.182 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.333 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.485 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.636 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.788 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.939 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.091 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.242 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.394 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.545 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.697 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.848 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.97 add_value
