$data remove entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[$(remove_slot)].components."minecraft:custom_data".home
