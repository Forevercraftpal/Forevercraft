# Oracle Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.oracle

# Second Sight: permanent Night Vision (oracle). NOTE: owl.json + oracle.json share this handler,
# so owl's "Second Sight" glow (see schedule/3s) and oracle's Second Sight NV are BOTH granted here.
effect give @s night_vision infinite 0 true

# Third Eye: entity/block interaction range (+0.5 → +3.0 over base 3.0, i.e. 3.5 → 6.0)
$execute if score #value companion.calc matches 1..7 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 0.5 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 0.632 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 0.763 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 0.895 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 1.026 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 1.158 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 1.289 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 1.421 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 1.553 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 1.684 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 1.816 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 1.947 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 2.079 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 2.211 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 2.342 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 2.474 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 2.605 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 2.737 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 2.868 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s entity_interaction_range modifier add evercraft:home/slot$(ability_slot)/entity_interaction_range 3.0 add_value
$execute if score #value companion.calc matches 1..7 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 0.5 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 0.632 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 0.763 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 0.895 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 1.026 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 1.158 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 1.289 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 1.421 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 1.553 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 1.684 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 1.816 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 1.947 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 2.079 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 2.211 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 2.342 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 2.474 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 2.605 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 2.737 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 2.868 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s block_interaction_range modifier add evercraft:home/slot$(ability_slot)/block_interaction_range 3.0 add_value

# Dream Eye: Luck (0.5 → 2.5)
$execute if score #value companion.calc matches 1..7 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.561 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.682 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.783 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.884 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.985 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.086 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.187 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.288 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.389 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.49 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.591 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.692 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.793 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.894 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.995 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.096 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.197 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.298 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.399 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.48 add_value
