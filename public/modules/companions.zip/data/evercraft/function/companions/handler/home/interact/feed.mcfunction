# ============================================================
# Home Companion — Feed interaction
# Run as: player, at player position
# Detects food item in hand, routes to feed_process with RP/cd values
# Cooldown is per-companion via hc.feedcd on HC.Interact entity
# ============================================================

# Skip if this specific companion is on cooldown
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=interaction, tag=HC.Interact, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_interact_slot hc.slot run execute if score @s hc.feedcd matches 1.. run return fail

# Check for valid food items (same tiers as active feeding)
# Tier 1: Rotten Flesh (5 RP)
execute if predicate evercraft:companions/food/rotten_flesh run return run function evercraft:companions/handler/home/interact/feed_process {rp:5,cd:600,food:"rotten_flesh"}

# Tier 2: Raw Meat (10 RP)
execute if predicate evercraft:companions/food/raw_meat run return run function evercraft:companions/handler/home/interact/feed_process {rp:10,cd:600,food:"raw_meat"}

# Tier 3: Cooked Meat (20 RP)
execute if predicate evercraft:companions/food/cooked_meat run return run function evercraft:companions/handler/home/interact/feed_process {rp:20,cd:600,food:"cooked_meat"}

# Tier 4: Golden Carrot (30 RP)
execute if predicate evercraft:companions/food/golden_carrot run return run function evercraft:companions/handler/home/interact/feed_process {rp:30,cd:1200,food:"golden_carrot"}

# Tier 5: Golden Apple (50 RP)
execute if predicate evercraft:companions/food/golden_apple run return run function evercraft:companions/handler/home/interact/feed_process {rp:50,cd:6000,food:"golden_apple"}

# Tier 6e: Golden Morsel (300 RP)
execute if predicate evercraft:companions/food/treat_tier5 run return run function evercraft:companions/handler/home/interact/feed_process {rp:300,cd:2400,food:"golden_morsel"}

# Tier 6d: Savory Bone Broth (200 RP)
execute if predicate evercraft:companions/food/treat_tier4 run return run function evercraft:companions/handler/home/interact/feed_process {rp:200,cd:2400,food:"bone_broth"}

# Tier 6c: Honey Cake (150 RP)
execute if predicate evercraft:companions/food/treat_tier3 run return run function evercraft:companions/handler/home/interact/feed_process {rp:150,cd:2400,food:"honey_cake"}

# Tier 6b: Meadow Biscuit (100 RP)
execute if predicate evercraft:companions/food/treat_tier2 run return run function evercraft:companions/handler/home/interact/feed_process {rp:100,cd:2400,food:"meadow_biscuit"}

# Tier 6: Companion Treat (75 RP)
execute if predicate evercraft:companions/food/companion_treat run return run function evercraft:companions/handler/home/interact/feed_process {rp:75,cd:2400,food:"pet_treat"}

# Tier 7: Enchanted Golden Apple (100 RP)
execute if predicate evercraft:companions/food/enchanted_golden_apple run return run function evercraft:companions/handler/home/interact/feed_process {rp:100,cd:12000,food:"enchanted_apple"}

# Not holding valid food — do nothing
return fail
