# SP5 — Care: focus the NEXT owned companion. Run as player (on target from click_care).
# Cycles companion.careidx across the full owned roster [0, count-1] with wrap (D-GUI-4 rec (a):
# full-roster Care). render falls back to slot 0 if a stale index lands on a hole. One-writer = care/*.

scoreboard players add @s companion.careidx 1
execute if score @s companion.careidx >= @s companion.count run scoreboard players set @s companion.careidx 0
function evercraft:companions/handler/menu_v2/care/refresh
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.4 1.8
