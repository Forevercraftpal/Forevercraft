# Apply relationship multiplier as attribute modifier
# Run as player

# Remove old modifier first
attribute @s attack_damage modifier remove evercraft:companions/relationship_bonus

# SP2 / KEYSTONE §4-E re-curve: relmult is now 120..200 (1.2x..2.0x), so the additive attack-damage
# bonus is +20%..+100% (was +10%..+50% on the old 110..150 curve). On-theme "max bond = stronger pet",
# guardrail-bounded (BURST_CAP governs horn bursts; attack damage flows through calc_damage).
scoreboard players operation #bonus companion.calc = #rel_mult companion.calc
scoreboard players remove #bonus companion.calc 100

# Apply modifier based on level
# Level 1: +20% (0.20)
execute if score @s companion.rellevel matches 1 run attribute @s attack_damage modifier add evercraft:companions/relationship_bonus 0.20 add_multiplied_base

# Level 2: +40% (0.40)
execute if score @s companion.rellevel matches 2 run attribute @s attack_damage modifier add evercraft:companions/relationship_bonus 0.40 add_multiplied_base

# Level 3: +60% (0.60)
execute if score @s companion.rellevel matches 3 run attribute @s attack_damage modifier add evercraft:companions/relationship_bonus 0.60 add_multiplied_base

# Level 4: +80% (0.80)
execute if score @s companion.rellevel matches 4 run attribute @s attack_damage modifier add evercraft:companions/relationship_bonus 0.80 add_multiplied_base

# Level 5: +100% (1.00)
execute if score @s companion.rellevel matches 5 run attribute @s attack_damage modifier add evercraft:companions/relationship_bonus 1.00 add_multiplied_base
