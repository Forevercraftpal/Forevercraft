# ============================================================
# Home Companion — Retrieve via sneak + right-click
# Run as: player, at player position
# Requires: #hc_interact_slot hc.slot = the interacted companion's slot
# ============================================================

# Copy interact slot to retrieve slot
scoreboard players operation #hc_retrieve_slot hc.slot = #hc_interact_slot hc.slot

# Copy the HomeCompanion entity's item data to storage for retrieve
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display, tag=HC.Head, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_interact_slot hc.slot run data modify storage evercraft:companions home.retrieve_item set from entity @s item

# Call the retrieve function
function evercraft:companions/handler/home/retrieve
