# ============================================================
# Generate Companion Item — Macro function
# Generates a companion item from loot table using the signature name
# Called with storage evercraft:companions (reads temp_sig)
# ============================================================
# Normal base, unless the placed head was flagged shiny (temp_shiny) — then pull the pool_shiny/ variant
# so the rebuilt item keeps the shiny name/lore/custom_data (the texture is re-applied via temp_profile).
$execute unless data storage evercraft:companions {temp_shiny:1} in overworld run loot insert 0 -63 0 loot evercraft:companions/pool/$(temp_sig)
$execute if data storage evercraft:companions {temp_shiny:1} in overworld run loot insert 0 -63 0 loot evercraft:companions/pool_shiny/$(temp_sig)
