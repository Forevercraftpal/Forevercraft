# ============================================================
# Generate Companion Item — Macro function
# Generates a companion item from loot table using the signature name
# Called with storage evercraft:companions (reads temp_sig)
# ============================================================
$execute in overworld run loot insert 0 -63 0 loot evercraft:companions/pool/$(temp_sig)
