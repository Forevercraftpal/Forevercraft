# Companion Info + Memories — GUI Overlay Screen
# Hides the pet grid and spawns text_display overlay showing pet stats
# Full 25-memory list output to chat
# Run as: player in menu with active pet
# Requires: #Search companion.id already set

tag @s add companion.infoscreen

# === READ PET DATA ===
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] run function evercraft:companions/handler/menu_v2/read_pet_data

# Convert cached level string to score
data modify storage evercraft:companions math.string set from storage evercraft:companions info.level_str
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int
scoreboard players operation #info_level companion.calc = #value companion.calc

# Convert cached exp string to score
data modify storage evercraft:companions math.string set from storage evercraft:companions info.exp_str
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int
scoreboard players operation #info_exp companion.calc = #value companion.calc

# Convert cached exp_next string to score
data modify storage evercraft:companions math.string set from storage evercraft:companions info.exp_next_str
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int
scoreboard players operation #info_next companion.calc = #value companion.calc

# Memory bitfield (default 0 if no memories property)
scoreboard players set #mem_bits companion.calc 0
execute if score #has_memories companion.calc matches 1 run data modify storage evercraft:companions math.string set from storage evercraft:companions info.mem_str
execute if score #has_memories companion.calc matches 1 run scoreboard players set #value companion.calc 0
execute if score #has_memories companion.calc matches 1 run function evercraft:companions/handler/math/string_to_int
execute if score #has_memories companion.calc matches 1 run scoreboard players operation #mem_bits companion.calc = #value companion.calc

# Get memory count
function evercraft:companions/memories/get_count

# Relationship points
scoreboard players set #info_rp companion.calc 0
execute if score #has_relationship companion.calc matches 1 run data modify storage evercraft:companions math.string set from storage evercraft:companions info.rel_str
execute if score #has_relationship companion.calc matches 1 run scoreboard players set #value companion.calc 0
execute if score #has_relationship companion.calc matches 1 run function evercraft:companions/handler/math/string_to_int
execute if score #has_relationship companion.calc matches 1 run scoreboard players operation #info_rp companion.calc = #value companion.calc

# Derive mood from RP
function evercraft:companions/handler/menu_v2/get_mood

# === HIDE PET GRID + ALL TAB CONTENT ===

execute as @e[type=item_display,tag=companion.petslot,predicate=evercraft:companions/check_id] run data modify entity @s transformation.scale set value [0f,0f,0f]
execute as @e[type=interaction,tag=companion.petclick,predicate=evercraft:companions/check_id] run data modify entity @s width set value 0f
execute as @e[type=interaction,tag=companion.petclick,predicate=evercraft:companions/check_id] run data modify entity @s height set value 0f
execute as @e[type=text_display,tag=companion.petname,predicate=evercraft:companions/check_id] run data modify entity @s text set value {text:""}
execute as @e[type=text_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run data modify entity @s text set value {text:""}
execute as @e[type=interaction,tag=companion.tab_content,predicate=evercraft:companions/check_id] run data modify entity @s width set value 0f
execute as @e[type=interaction,tag=companion.tab_content,predicate=evercraft:companions/check_id] run data modify entity @s height set value 0f
execute as @e[type=text_display,tag=companion.navarrow,predicate=evercraft:companions/check_id] run data modify entity @s text set value {text:""}
execute as @e[type=text_display,tag=companion.menupageinfo,predicate=evercraft:companions/check_id] run data modify entity @s text set value {text:""}

# Change [?] to [Back]
execute as @e[type=text_display,tag=companion.menuinfotext,predicate=evercraft:companions/check_id] run data modify entity @s text set value [{text:"[",color:"dark_gray"},{text:"Back",color:"yellow",bold:true},{text:"]",color:"dark_gray"}]

# Change title to pet name
execute as @e[type=text_display,tag=companion.menutitle,predicate=evercraft:companions/check_id] run data modify entity @s text set value [{nbt:"info.name",storage:"evercraft:companions",color:"gold",bold:true},{text:" \u2014 Info",color:"gray"}]

# === SPAWN GUI OVERLAY (stats summary) ===

# Level & EXP
execute if score #info_level companion.calc matches 100 as @e[type=text_display,tag=companion.infonew,distance=..5,limit=1] run data modify entity @s text set value [{text:"Level ",color:"gray"},{text:"100",color:"yellow",bold:true},{text:" "},{"text":"(MAX)","color":"gold","bold":true}]

# Kills

# Relationship

# Separator
execute rotated ~ 0 positioned ^ ^1.43 ^1.76 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.infooverlay","companion.menuelement","companion.infonew"],billboard:"center",text:{text:"\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550",color:"dark_gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.298f,0.298f,0.298f]}}

# Mood
execute rotated ~ 0 positioned ^ ^1.31 ^1.76 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.infooverlay","companion.menuelement","companion.infonew","companion.moodtext"],billboard:"center",text:[{text:"Mood: ",color:"gray"},{text:"Wary",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.298f,0.298f,0.298f]}}
execute if score #mood companion.calc matches 0 as @e[type=text_display,tag=companion.moodtext,tag=companion.infonew,limit=1] run data modify entity @s text set value [{text:"Mood: ",color:"gray"},{text:"Lonely",color:"red",italic:true}]
execute if score #mood companion.calc matches 2 as @e[type=text_display,tag=companion.moodtext,tag=companion.infonew,limit=1] run data modify entity @s text set value [{text:"Mood: ",color:"gray"},{text:"Uneasy",color:"gray"}]
execute if score #mood companion.calc matches 3 as @e[type=text_display,tag=companion.moodtext,tag=companion.infonew,limit=1] run data modify entity @s text set value [{text:"Mood: ",color:"gray"},{text:"Content",color:"green"}]
execute if score #mood companion.calc matches 4 as @e[type=text_display,tag=companion.moodtext,tag=companion.infonew,limit=1] run data modify entity @s text set value [{text:"Mood: ",color:"gray"},{text:"Happy",color:"green"}]
execute if score #mood companion.calc matches 5 as @e[type=text_display,tag=companion.moodtext,tag=companion.infonew,limit=1] run data modify entity @s text set value [{text:"Mood: ",color:"gray"},{text:"Elated",color:"yellow"}]
execute if score #mood companion.calc matches 6 as @e[type=text_display,tag=companion.moodtext,tag=companion.infonew,limit=1] run data modify entity @s text set value [{text:"Mood: ",color:"gray"},{text:"Overjoyed",color:"gold",bold:true}]
tag @e[tag=companion.moodtext] remove companion.moodtext

# Pet Duel stats

# Memories summary line
# === 26.1 fix: {score} blank in text_display -> bake via storage macro ===
scoreboard players add #info_level companion.calc 0
execute store result storage evercraft:scorebake args.v1 int 1 run scoreboard players get #info_level companion.calc
scoreboard players add #info_exp companion.calc 0
execute store result storage evercraft:scorebake args.v2 int 1 run scoreboard players get #info_exp companion.calc
scoreboard players add #info_next companion.calc 0
execute store result storage evercraft:scorebake args.v3 int 1 run scoreboard players get #info_next companion.calc
scoreboard players add @s companion.kills 0
execute store result storage evercraft:scorebake args.v4 int 1 run scoreboard players get @s companion.kills
scoreboard players add #info_rp companion.calc 0
execute store result storage evercraft:scorebake args.v5 int 1 run scoreboard players get #info_rp companion.calc
scoreboard players add @s ec.pd_wins 0
execute store result storage evercraft:scorebake args.v6 int 1 run scoreboard players get @s ec.pd_wins
scoreboard players add @s ec.pd_losses 0
execute store result storage evercraft:scorebake args.v7 int 1 run scoreboard players get @s ec.pd_losses
scoreboard players add @s ec.pd_draws 0
execute store result storage evercraft:scorebake args.v8 int 1 run scoreboard players get @s ec.pd_draws
scoreboard players add @s ec.pd_streak 0
execute store result storage evercraft:scorebake args.v9 int 1 run scoreboard players get @s ec.pd_streak
scoreboard players add @s ec.pd_best_streak 0
execute store result storage evercraft:scorebake args.v10 int 1 run scoreboard players get @s ec.pd_best_streak
scoreboard players add #mem_count companion.calc 0
execute store result storage evercraft:scorebake args.v11 int 1 run scoreboard players get #mem_count companion.calc
function evercraft:companions/handler/menu_v2/show_info_screen_dyn with storage evercraft:scorebake args
execute if score #mem_count companion.calc matches 25 rotated ~ 0 positioned ^ ^1.05 ^1.76 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.infooverlay","companion.menuelement","companion.infonew"],billboard:"center",text:[{text:"\u2726 Memories: ",color:"gold",bold:true},{text:"25/25 ",color:"gold"},{text:"+25% Bond XP",color:"gold",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}

# "View Memories" clickable button
execute rotated ~ 0 positioned ^ ^0.91 ^1.76 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.infooverlay","companion.menuelement","companion.infonew"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"\u2726 View Memories",color:"light_purple",bold:true},{text:" ]",color:"dark_gray"}],background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.298f,0.298f,0.298f]}}
# [strip] ?: 0.45w split into 4 x 0.14 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.155 ^0.84 ^1.78 run summon interaction ~ ~ ~ {Tags:["companion.infooverlay","companion.menuelement","companion.infonew","companion.mem_btn_click"],width:0.14f,height:0.14f,response:1b}
execute rotated ~ 0 positioned ^-0.0517 ^0.84 ^1.78 run summon interaction ~ ~ ~ {Tags:["companion.infooverlay","companion.menuelement","companion.infonew","companion.mem_btn_click"],width:0.14f,height:0.14f,response:1b}
execute rotated ~ 0 positioned ^0.0517 ^0.84 ^1.78 run summon interaction ~ ~ ~ {Tags:["companion.infooverlay","companion.menuelement","companion.infonew","companion.mem_btn_click"],width:0.14f,height:0.14f,response:1b}
execute rotated ~ 0 positioned ^0.155 ^0.84 ^1.78 run summon interaction ~ ~ ~ {Tags:["companion.infooverlay","companion.menuelement","companion.infonew","companion.mem_btn_click"],width:0.14f,height:0.14f,response:1b}

# === ASSIGN OWNERSHIP TO ALL NEW OVERLAY ENTITIES ===
execute as @e[type=text_display,tag=companion.infonew] run scoreboard players operation @s companion.id = #Search companion.id
execute as @e[type=interaction,tag=companion.infonew] run scoreboard players operation @s companion.id = #Search companion.id
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=companion.infonew] run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=companion.infonew] run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
tag @e[tag=companion.infonew] remove companion.infonew

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.0
