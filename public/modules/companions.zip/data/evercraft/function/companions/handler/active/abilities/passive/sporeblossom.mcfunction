# Sporeblossom Pet Passive Abilities

tag @s add companion.sporeblossom

