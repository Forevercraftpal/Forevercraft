# ============================================================
# Home Companion Abilities — Apply all (called on zone enter)
# Run as: player
# Applies abilities from all home companions to the player
# ============================================================

# Clean slate — remove any existing home modifiers first
function evercraft:companions/handler/home/abilities/reset_all

# Find all home companions belonging to this player
scoreboard players operation #Search companion.id = @s companion.id

# For each HomeCompanion entity, read its data and apply abilities
execute as @e[type=item_display, tag=HC.Head, predicate=evercraft:companions/check_id] run function evercraft:companions/handler/home/abilities/read_and_apply

# SP9: recompute the cached Hearth Comfort score (best placed companion's tier+bond). Read each 2s by
# housing/zone/apply_buffs to refresh a modest effect. Recomputed here on every roster change.
function evercraft:companions/handler/home/abilities/comfort_score
