# Process player interaction with pet
# Run as player

scoreboard players operation #Search companion.id = @s companion.id

# === SPIRIT TREAT EVOLUTION CHECK ===
# If holding Spirit Treat, attempt evolution instead of normal interaction
execute if items entity @s weapon.mainhand *[custom_data~{spirit_treat:true}] run function evercraft:companion_evolution/try_evolve
execute if items entity @s weapon.mainhand *[custom_data~{spirit_treat:true}] run return 1

# === ABILITY CHIP APPLY (SP8) ===
# If holding an Ability Chip, slot it into the active companion (add an ability slot bearing the chip's
# effect) instead of normal interaction. apply_chip self-gates on the active-pet distance + capacity.
execute if items entity @s weapon.mainhand *[custom_data~{ability_chip:true}] run return run function evercraft:companions/skills/apply_chip

# === EVOLVED COMPANION TRIGGERED ABILITIES (sneak + right-click own companion) ===
execute if entity @s[tag=ce.evolved_active,predicate=evercraft:is_sneaking] run function evercraft:companion_evolution/trigger_ability
execute if entity @s[tag=ce.evolved_active,predicate=evercraft:is_sneaking] run return 1

# (Pet Duel challenge moved to cross-pet click detection in companions/tick.mcfunction)

# Track whether any interaction succeeded
scoreboard players set #didInteract companion.calc 0

# Check if holding food - try feeding first (works while sneaking too)
execute store success score #didFeed companion.calc run function evercraft:companions/handler/relationship/feed/detect
execute if score #didFeed companion.calc matches 1 run scoreboard players set #didInteract companion.calc 1

# === SHIFT-CLICK: Health Status + Pick Up (only if sneaking with empty hand / no food) ===
execute if score #didFeed companion.calc matches 0 if predicate evercraft:is_sneaking run function evercraft:companions/health/show_status
execute if score #didFeed companion.calc matches 0 if predicate evercraft:is_sneaking run return 1

# If didn't feed (no valid food), try petting
execute if score #didFeed companion.calc matches 0 store success score #didInteract companion.calc run function evercraft:companions/handler/relationship/interact/process

# Achievement tracking — only count if an interaction actually happened (not on cooldown)
execute if score #didInteract companion.calc matches 1 run scoreboard players add @s ach.comp_interacts 1
