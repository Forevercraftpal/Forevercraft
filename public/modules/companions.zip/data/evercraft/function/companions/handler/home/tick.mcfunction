# ============================================================
# Home Companion — Main tick (called from housing/tick, every 2s)
# Handles: wandering, interaction sync, interaction detection, passive RP
# ============================================================

# Process wandering for all home companions
execute as @e[type=chicken, tag=HomeCompanion] at @s run function evercraft:companions/handler/home/wander

# Sync interaction entity positions to their paired chickens (interaction is standalone, not a passenger)
execute as @e[type=chicken, tag=HomeCompanion] at @s run function evercraft:companions/handler/home/sync_interact

# Detect right-click on home companion interaction entities
execute as @e[type=interaction, tag=HC.Interact] at @s if data entity @s interaction on target run function evercraft:companions/handler/home/on_interact
execute as @e[type=interaction, tag=HC.Interact] at @s if data entity @s interaction run data remove entity @s interaction

# Tick down interaction cooldowns for players with home companions but no active pet
# (Active pet AI already handles this every tick — only needed for home-only players)
# Housing tick runs every 2s = 40 ticks, so subtract 40 per cycle
# ONE-WRITER (R9): the tag=!companion.activepet gate makes this DISJOINT from the active-pet
# decrement in handler/active/ai — a player is never both at once, so feedcd/interactcd has
# exactly one live writer per player despite the two physical decrement sites.
execute as @a[scores={hc.count=1..},tag=!companion.activepet] if score @s companion.interactcd matches 1.. run scoreboard players remove @s companion.interactcd 40
execute as @a[scores={hc.count=1..},tag=!companion.activepet] if score @s companion.feedcd matches 1.. run scoreboard players remove @s companion.feedcd 40

# Tick down per-companion pet/feed cooldowns on HC.Interact entities
execute as @e[type=interaction, tag=HC.Interact] if score @s hc.petcd matches 1.. run scoreboard players remove @s hc.petcd 40
execute as @e[type=interaction, tag=HC.Interact] if score @s hc.feedcd matches 1.. run scoreboard players remove @s hc.feedcd 40

# Process passive RP for home companions (gametime-based)
function evercraft:companions/handler/home/passive_rp
