# SP5 — Rename: macro — give the Companion Charter book carrying the target index. Run as player.
# Args: {renameidx:N}. companion_charter:1b is the signed-trigger key (advancement filters on it);
# companion_idx carries the target Pets[] index across the write+sign round-trip (exactly how the home
# deed carries `slot`). evercraft_item:1b marks it a pack item.
$give @s minecraft:writable_book[custom_name={text:"Companion Charter",color:"gold",italic:false},custom_data={companion_charter:1b,evercraft_item:1b,companion_idx:$(renameidx)},writable_book_content={pages:["Write your companion's new name on this page and sign the charter!"]}] 1
