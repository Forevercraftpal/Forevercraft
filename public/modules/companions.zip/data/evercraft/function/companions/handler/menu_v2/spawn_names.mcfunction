# Spawn pet name labels above each populated slot in the grid
# Run as player at player position, after spawn_slots + set_items
# Reads display name from each slot's item_display custom_name

# #Search already set by caller — don't overwrite from @s (may be dead hub entity)

# For each populated pet slot, spawn a name label 0.13 above the head
# Row 1 (slots 0-11): head Y=2.75, name Y=2.88
# Row 2 (slots 12-23): head Y=2.45, name Y=2.58
# Row 3 (slots 24-35): head Y=2.15, name Y=2.28
# Row 4 (slots 36-47): head Y=1.85, name Y=1.98

# Use a helper macro to spawn each name from the slot entity's CustomName
execute as @e[type=item_display,tag=companion.petslot,predicate=evercraft:companions/check_id] at @s run function evercraft:companions/handler/menu_v2/spawn_name_label
