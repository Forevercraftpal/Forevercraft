# Mossy Skeleton Pet Passive Abilities

tag @s add companion.mossy_skeleton

