# SP5 — Shared Back button (◀ Back). Run as player; caller provides facing/rotation context.
# Identical art to the existing tab back button (open_tab_buddy:13-14) so go_back routes it uniformly.
# Used by the SP5 tabs (catalogue hub 8, Care 5, Journey 6, Skills 7). go_back's tab-value branch
# decides where Back lands (sub-tab → catalogue hub; SP5 tab / hub → home view).

scoreboard players operation #Search companion.id = @s companion.id
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.45 ^1.76 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.back_btn_text","companion.menuelement","companion.tab_content"],billboard:"center",text:{text:"◀ Back",color:"yellow"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.4 ^1.78 run summon interaction ~ ~ ~ {Tags:["companion.back_btn_click","companion.menuelement","companion.tab_content"],width:0.35f,height:0.10f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.back_btn_text,distance=..5] companion.id = #Search companion.id
scoreboard players operation @e[type=interaction,tag=companion.back_btn_click,distance=..5] companion.id = #Search companion.id
