# Hub button click detection — runs as player in menu with tab=0 (hub page)
# Called from tick.mcfunction when ec.bd_tab == 0

scoreboard players operation #Search companion.id = @s companion.id

# Check each hub button for interaction data
execute as @e[type=interaction,tag=companion.hub_companions_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/open_home_from_hub
execute as @e[type=interaction,tag=companion.hub_companions_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.hub_buddy_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/open_tab_buddy
execute as @e[type=interaction,tag=companion.hub_buddy_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.hub_summon_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/open_tab_summon
execute as @e[type=interaction,tag=companion.hub_summon_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.hub_training_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/open_tab_training
execute as @e[type=interaction,tag=companion.hub_training_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# Clear interaction data from all hub buttons (prevent re-triggering)
execute as @e[type=interaction,tag=companion.hub_btn,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction
