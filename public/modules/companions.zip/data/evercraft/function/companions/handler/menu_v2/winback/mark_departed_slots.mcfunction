# SP3 — apply the DEPARTED gray-out to every grid slot (0..47).
# Call AFTER set_items / refresh_slots have populated the slot item displays — this pass only
# adjusts brightness on the slotN displays, keyed on each MenuDisplay[N].custom_data.departed.
# A departed companion renders as a dark silhouette (still clickable); all others stay normal.
# PRECONDITION: caller has #Search companion.id set to the owning player (both call sites do:
# set_items time uses #Search for slot ownership; refresh_slots sets it from @s). The slotN edits are
# predicate=check_id keyed off #Search — do NOT re-derive from @s here (spawn_slots' @s is a dead hub).
data modify storage evercraft:companions wb_mark.n set value 0
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 1
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 2
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 3
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 4
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 5
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 6
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 7
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 8
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 9
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 10
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 11
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 12
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 13
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 14
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 15
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 16
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 17
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 18
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 19
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 20
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 21
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 22
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 23
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 24
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 25
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 26
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 27
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 28
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 29
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 30
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 31
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 32
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 33
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 34
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 35
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 36
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 37
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 38
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 39
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 40
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 41
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 42
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 43
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 44
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 45
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 46
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data modify storage evercraft:companions wb_mark.n set value 47
function evercraft:companions/handler/menu_v2/winback/mark_one_slot with storage evercraft:companions wb_mark
data remove storage evercraft:companions wb_mark
