# ============================================================
# Home Companion — Cancel "Place at Home" mode
# Run as: player in menu
# ============================================================

tag @s remove hc.placing

# Reset button text
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=text_display, tag=companion.menuhometext, predicate=evercraft:companions/check_id] run data modify entity @s text set value [{text:"\u2302 ",color:"green"},{text:"Home",color:"white",bold:true}]

data modify storage evercraft:notify stage.c set value [{text:"Place at home cancelled.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.4
