# OPT: No longer triggered by advancement — called from companions/handler/player/main
execute if data storage evercraft:companions uninstalled run return fail

scoreboard players operation #Search companion.id = @s companion.id

# --------------------------------------------------------------------------------- #

data modify storage evercraft:notify stage.c set value [{text:"Your ",color:"dark_green"},{nbt:"item.components.\"minecraft:custom_name\"",entity:"@e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1]",interpret:true},{text:" was left all alone and decided to go back home.",color:"dark_green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

function evercraft:companions/handler/active/abilities/reset_perks

# R1: full teardown via the shared helper. Was wolf+head only — the hp_label passenger and
# the petinteract were NOT killed, so a pet dying at ~0 HP (a player death is a near-0-HP
# moment) orphaned the "❤ 0/Y" label here, the dominant phantom-leak site. #Search is set above.
function evercraft:companions/health/despawn_active_entities

function evercraft:companions/handler/menu_v2/close

tag @s remove companion.activepet