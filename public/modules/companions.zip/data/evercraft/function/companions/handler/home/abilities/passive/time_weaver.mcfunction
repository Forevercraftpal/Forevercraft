# Time Weaver Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.time_weaver

effect give @s haste infinite 1 true

# Temporal Acceleration: Speed (0.11 → 0.15)
$execute if score #value companion.calc matches 1..7 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.111 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.114 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.116 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.118 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.12 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.122 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.124 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.126 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.128 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.13 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.132 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.134 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.136 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.138 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.14 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.142 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.144 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.146 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.148 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.15 add_value
