# SP5 — Care: Feed a STORED (non-summoned) companion with held food. Run as player.
# Mirrors relationship/feed/detect's food→RP ladder exactly (same predicates + same values — SP5 does
# NOT change the values, only surfaces them, DATA-MODEL §1.7 / SP2 owns balance), but routes each match
# to feed_stored_process (writes RP to the Pets[careidx] record) instead of the live-pet process.
# The food→value contract: rotten 5 / raw 10 / cooked 20 (steak) / golden carrot 30 / golden apple 50 /
# treat tiers 75-300 / Notch apple 100. Material fish → raw_meat, steak → cooked_meat, pet treat →
# companion_treat (the generic predicate classes already satisfy "cooking / fishing / treat / steak").

# Cooldown gate (reuse the Care anti-spam cd so feed + pet share one anti-spam window).
data modify storage evercraft:notify stage.c set value [{text:"Give them a moment before more food.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.cc_petcd matches 1.. run return run function evercraft:util/notify/emit

# Food ladder (highest-value first where predicates overlap, mirroring detect's ordering).
execute if predicate evercraft:companions/food/treat_tier5 run return run function evercraft:companions/handler/menu_v2/care/feed_stored_process {rp:300,cd:120,food:"golden_morsel"}
execute if predicate evercraft:companions/food/treat_tier4 run return run function evercraft:companions/handler/menu_v2/care/feed_stored_process {rp:200,cd:120,food:"bone_broth"}
execute if predicate evercraft:companions/food/treat_tier3 run return run function evercraft:companions/handler/menu_v2/care/feed_stored_process {rp:150,cd:120,food:"honey_cake"}
execute if predicate evercraft:companions/food/treat_tier2 run return run function evercraft:companions/handler/menu_v2/care/feed_stored_process {rp:100,cd:120,food:"meadow_biscuit"}
execute if predicate evercraft:companions/food/companion_treat run return run function evercraft:companions/handler/menu_v2/care/feed_stored_process {rp:75,cd:120,food:"pet_treat"}
execute if predicate evercraft:companions/food/enchanted_golden_apple run return run function evercraft:companions/handler/menu_v2/care/feed_stored_process {rp:100,cd:120,food:"enchanted_apple"}
execute if predicate evercraft:companions/food/golden_apple run return run function evercraft:companions/handler/menu_v2/care/feed_stored_process {rp:50,cd:120,food:"golden_apple"}
execute if predicate evercraft:companions/food/golden_carrot run return run function evercraft:companions/handler/menu_v2/care/feed_stored_process {rp:30,cd:120,food:"golden_carrot"}
execute if predicate evercraft:companions/food/cooked_meat run return run function evercraft:companions/handler/menu_v2/care/feed_stored_process {rp:20,cd:120,food:"cooked_meat"}
execute if predicate evercraft:companions/food/raw_meat run return run function evercraft:companions/handler/menu_v2/care/feed_stored_process {rp:10,cd:120,food:"raw_meat"}
execute if predicate evercraft:companions/food/rotten_flesh run return run function evercraft:companions/handler/menu_v2/care/feed_stored_process {rp:5,cd:120,food:"rotten_flesh"}

# No valid food in hand → quick snack instead.
function evercraft:companions/handler/menu_v2/care/pet_stored
