# SP5 — Skills: persist the active slot onto a STORED (non-summoned) companion's Pets[] record.
# Run as player. Writes custom_data.horn_active = companion.skillslot on Pets[careidx] so the choice
# survives until summon (when SP1's skills/load_slots mirrors it back to companion.skillslot). Mirrors
# set_active:14 but keyed by absolute index. SP1 still owns the skillslot/horn_active contract; SP5 only
# routes the GUI pick to the stored record when the companion isn't the live item set_active targets.
execute store result storage evercraft:companions skills.careidx int 1 run scoreboard players get @s companion.careidx
execute store result storage evercraft:companions skills.active int 1 run scoreboard players get @s companion.skillslot
function evercraft:companions/handler/menu_v2/skills/set_active_stored_macro with storage evercraft:companions skills
