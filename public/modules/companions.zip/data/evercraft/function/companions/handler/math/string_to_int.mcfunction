data modify storage evercraft:companions math.char set string storage evercraft:companions math.string 0 1
data modify storage evercraft:companions math.string set string storage evercraft:companions math.string 1

scoreboard players operation #value companion.calc *= #10 companion.calc
execute if data storage evercraft:companions math{char:'1'} run scoreboard players add #value companion.calc 1
execute if data storage evercraft:companions math{char:'2'} run scoreboard players add #value companion.calc 2
execute if data storage evercraft:companions math{char:'3'} run scoreboard players add #value companion.calc 3
execute if data storage evercraft:companions math{char:'4'} run scoreboard players add #value companion.calc 4
execute if data storage evercraft:companions math{char:'5'} run scoreboard players add #value companion.calc 5
execute if data storage evercraft:companions math{char:'6'} run scoreboard players add #value companion.calc 6
execute if data storage evercraft:companions math{char:'7'} run scoreboard players add #value companion.calc 7
execute if data storage evercraft:companions math{char:'8'} run scoreboard players add #value companion.calc 8
execute if data storage evercraft:companions math{char:'9'} run scoreboard players add #value companion.calc 9

execute unless data storage evercraft:companions math{string:''} run function evercraft:companions/handler/math/string_to_int