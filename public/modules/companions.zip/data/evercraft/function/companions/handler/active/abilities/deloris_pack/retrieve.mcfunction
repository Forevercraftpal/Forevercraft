# Deloris Pack — Retrieve Item (macro)
# $(pid) = player ID, $(slot) = s0-s4

execute at @s run summon item ~ ~1 ~ {Tags:["ec.dlpack_restore"],PickupDelay:0,Item:{id:"minecraft:stone",count:1}}
$data modify entity @e[type=item,tag=ec.dlpack_restore,limit=1] Item set from storage evercraft:companions dlpack.$(pid).$(slot).item
tp @e[type=item,tag=ec.dlpack_restore] @s
tag @e[type=item,tag=ec.dlpack_restore] remove ec.dlpack_restore

# Clear the slot
$data modify storage evercraft:companions dlpack.$(pid).$(slot) set value {}

playsound minecraft:item.bundle.remove_one master @s ~ ~ ~ 0.8 1.0
tellraw @s [{"text":"[","color":"dark_gray"},{"text":"Pets","color":"gold"},{"text":"] ","color":"dark_gray"},{"text":"Item retrieved from Deloris' pack!","color":"yellow"}]
