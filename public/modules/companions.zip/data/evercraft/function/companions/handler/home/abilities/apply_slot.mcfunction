# ============================================================
# Home Companion Abilities — Apply abilities for one slot (macro)
# Run as: player
# Args via storage: {ability_signature:"wolf", ability_slot:0}
# Requires: #value companion.calc = companion level (already set)
# ============================================================

$function evercraft:companions/handler/home/abilities/passive/$(ability_signature) with storage evercraft:companions home
