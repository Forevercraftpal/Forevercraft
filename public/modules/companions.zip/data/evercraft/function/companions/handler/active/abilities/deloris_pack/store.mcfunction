# Deloris Pack — Store Item (macro)
# $(pid) = player ID, $(slot) = s0-s4
# Stores ANY item from mainhand

execute unless data entity @s SelectedItem run tellraw @s [{"text":"[","color":"dark_gray"},{"text":"Pets","color":"gold"},{"text":"] ","color":"dark_gray"},{"text":"Hold an item in your mainhand!","color":"red"}]
execute unless data entity @s SelectedItem run return fail

# Copy item name and full NBT
$data modify storage evercraft:companions dlpack.$(pid).$(slot).name set from entity @s SelectedItem.components."minecraft:custom_name"
$execute unless data entity @s SelectedItem.components."minecraft:custom_name" run data modify storage evercraft:companions dlpack.$(pid).$(slot).name set from entity @s SelectedItem.id
$data modify storage evercraft:companions dlpack.$(pid).$(slot).item set from entity @s SelectedItem

# Remove from mainhand
item replace entity @s weapon.mainhand with air

playsound minecraft:item.bundle.insert master @s ~ ~ ~ 0.8 1.0
tellraw @s [{"text":"[","color":"dark_gray"},{"text":"Pets","color":"gold"},{"text":"] ","color":"dark_gray"},{"text":"Item stored in Deloris' pack!","color":"green"}]
