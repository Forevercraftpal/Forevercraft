# SP5 — Home view: SUB-LEFT empty placeholder (no companion assigned to journey slot A).
# 2026-06-06: NO head — blank slots are invisible (no Steve player_head), just a "+ Empty" label.
# Clicking it (headidx 1) arms assign-to-Sub-A mode + opens the roster to pick. Run as player. Tagged companion.homehead.

# "+ Empty" label — pulled in toward screen center (2026-06-06; was out at ^0.62). Slot A sits just LEFT
# of center, paired side-by-side with slot B's label so the two empty prompts read as a centered pair.
execute rotated ~ 0 positioned ^ ^1.70 ^1.82 positioned ^0.30 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.homehead","companion.menuelement","companion.tab_content","companion.homesublname"],billboard:"center",text:[{text:"+ ",color:"dark_gray"},{text:"Empty",color:"gray",italic:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.22f,0.22f,0.22f]}}

execute rotated ~ 0 positioned ^ ^1.68 ^1.78 positioned ^0.30 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.headslot","companion.menuelement","companion.tab_content","companion.homesublclick"],width:0.28f,height:0.14f,response:1b}
scoreboard players set @n[type=interaction,tag=companion.homesublclick,distance=..5] companion.headidx 1

tag @e[type=text_display,tag=companion.homesublname,distance=..5] remove companion.homesublname
tag @e[type=interaction,tag=companion.homesublclick,distance=..5] remove companion.homesublclick
