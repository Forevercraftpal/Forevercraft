# SP5 — Care: process feeding a STORED companion. Run as player. Macro: {rp:N, cd:N, food:"type"}.
# Loads the focused Pets[careidx] record's RP, adds rp, caps 5000, writes it back, consumes 1 food,
# sets the Care anti-spam cd, and gives feedback. Mirrors home/interact/feed_process but data-side.

$scoreboard players set #feedRP companion.calc $(rp)

# Snapshot + load current RP of the focused record.
data remove storage evercraft:companions care.head
execute store result storage evercraft:companions care.probeidx int 1 run scoreboard players get @s companion.careidx
execute store result storage evercraft:companions care.careidx int 1 run scoreboard players get @s companion.careidx
function evercraft:companions/handler/menu_v2/care/snapshot_idx with storage evercraft:companions care
function evercraft:companions/handler/menu_v2/care/load_focus_rp

# Add RP, cap 5000.
scoreboard players operation @s companion.rp += #feedRP companion.calc
execute if score @s companion.rp matches 5001.. run scoreboard players set @s companion.rp 5000

# Save back to the record.
function evercraft:companions/handler/menu_v2/care/save_focus_rp with storage evercraft:companions care

# Consume 1 of the held food item.
item modify entity @s weapon.mainhand evercraft:companions/consume_one

# Anti-spam cd + effects.
scoreboard players set @s ec.cc_petcd 60
# Sanctioned affection vocal — KEEP + GATE.
execute if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:entity.generic.eat master @s ~ ~ ~ 1 1
execute at @s run particle heart ^ ^1 ^1.7 0.2 0.2 0.2 0 3

# Feedback.
$data modify storage evercraft:notify stage.c set value [{text:"Your companion enjoyed the treat! ",color:"green"},{text:"(+$(rp) RP)",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
