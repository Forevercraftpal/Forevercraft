# ============================================================
# Home Companion — Drop as item entity
# Run as: HC.Head item_display entity, at its position
# Spawns a dropped item with the companion's head data
# ============================================================

# Copy item data to storage
data modify storage evercraft:companions home.drop_item set from entity @s item

# Spawn dropped item entity
summon item ~ ~0.5 ~ {Tags:["hc.drop"], PickupDelay:10}
data modify entity @e[type=item, tag=hc.drop, limit=1] Item set from storage evercraft:companions home.drop_item
tag @e[type=item, tag=hc.drop, limit=1] remove hc.drop

# Kill this entity
kill @s
