# Sabertooth - Predator's Frenzy: On kill, gain Speed I + Strength I
# Duration scales 3s → 8s

advancement revoke @s only evercraft:companions/abilities/sabertooth
scoreboard players operation #Search companion.id = @s companion.id

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value

scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

execute if score #value companion.calc matches 1..7 run effect give @s speed 3 0 true
execute if score #value companion.calc matches 1..7 run effect give @s strength 3 0 true
execute if score #value companion.calc matches 8..12 run effect give @s speed 3 0 true
execute if score #value companion.calc matches 8..12 run effect give @s strength 3 0 true
execute if score #value companion.calc matches 13..17 run effect give @s speed 4 0 true
execute if score #value companion.calc matches 13..17 run effect give @s strength 4 0 true
execute if score #value companion.calc matches 18..22 run effect give @s speed 4 0 true
execute if score #value companion.calc matches 18..22 run effect give @s strength 4 0 true
execute if score #value companion.calc matches 23..27 run effect give @s speed 4 0 true
execute if score #value companion.calc matches 23..27 run effect give @s strength 4 0 true
execute if score #value companion.calc matches 28..32 run effect give @s speed 5 0 true
execute if score #value companion.calc matches 28..32 run effect give @s strength 5 0 true
execute if score #value companion.calc matches 33..37 run effect give @s speed 5 0 true
execute if score #value companion.calc matches 33..37 run effect give @s strength 5 0 true
execute if score #value companion.calc matches 38..42 run effect give @s speed 5 0 true
execute if score #value companion.calc matches 38..42 run effect give @s strength 5 0 true
execute if score #value companion.calc matches 43..47 run effect give @s speed 6 0 true
execute if score #value companion.calc matches 43..47 run effect give @s strength 6 0 true
execute if score #value companion.calc matches 48..52 run effect give @s speed 6 0 true
execute if score #value companion.calc matches 48..52 run effect give @s strength 6 0 true
execute if score #value companion.calc matches 53..57 run effect give @s speed 6 0 true
execute if score #value companion.calc matches 53..57 run effect give @s strength 6 0 true
execute if score #value companion.calc matches 58..62 run effect give @s speed 7 0 true
execute if score #value companion.calc matches 58..62 run effect give @s strength 7 0 true
execute if score #value companion.calc matches 63..67 run effect give @s speed 7 0 true
execute if score #value companion.calc matches 63..67 run effect give @s strength 7 0 true
execute if score #value companion.calc matches 68..72 run effect give @s speed 7 0 true
execute if score #value companion.calc matches 68..72 run effect give @s strength 7 0 true
execute if score #value companion.calc matches 73..77 run effect give @s speed 7 0 true
execute if score #value companion.calc matches 73..77 run effect give @s strength 7 0 true
execute if score #value companion.calc matches 78..82 run effect give @s speed 8 0 true
execute if score #value companion.calc matches 78..82 run effect give @s strength 8 0 true
execute if score #value companion.calc matches 83..87 run effect give @s speed 8 0 true
execute if score #value companion.calc matches 83..87 run effect give @s strength 8 0 true
execute if score #value companion.calc matches 88..92 run effect give @s speed 8 0 true
execute if score #value companion.calc matches 88..92 run effect give @s strength 8 0 true
execute if score #value companion.calc matches 93..97 run effect give @s speed 8 0 true
execute if score #value companion.calc matches 93..97 run effect give @s strength 8 0 true
execute if score #value companion.calc matches 98..100 run effect give @s speed 8 0 true
execute if score #value companion.calc matches 98..100 run effect give @s strength 8 0 true
