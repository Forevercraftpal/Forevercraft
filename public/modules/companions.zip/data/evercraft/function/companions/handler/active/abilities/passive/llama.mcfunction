# Llama Pet Passive Abilities
# - Pack Animal: Max health (21 → 26)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.llama

# Pack Animal: Max health (21 → 26)
execute if score #value companion.calc matches 1..7 run return run attribute @s max_health base set 21.152
execute if score #value companion.calc matches 8..12 run return run attribute @s max_health base set 21.455
execute if score #value companion.calc matches 13..17 run return run attribute @s max_health base set 21.707
execute if score #value companion.calc matches 18..22 run return run attribute @s max_health base set 21.96
execute if score #value companion.calc matches 23..27 run return run attribute @s max_health base set 22.212
execute if score #value companion.calc matches 28..32 run return run attribute @s max_health base set 22.465
execute if score #value companion.calc matches 33..37 run return run attribute @s max_health base set 22.717
execute if score #value companion.calc matches 38..42 run return run attribute @s max_health base set 22.97
execute if score #value companion.calc matches 43..47 run return run attribute @s max_health base set 23.222
execute if score #value companion.calc matches 48..52 run return run attribute @s max_health base set 23.475
execute if score #value companion.calc matches 53..57 run return run attribute @s max_health base set 23.727
execute if score #value companion.calc matches 58..62 run return run attribute @s max_health base set 23.98
execute if score #value companion.calc matches 63..67 run return run attribute @s max_health base set 24.232
execute if score #value companion.calc matches 68..72 run return run attribute @s max_health base set 24.485
execute if score #value companion.calc matches 73..77 run return run attribute @s max_health base set 24.737
execute if score #value companion.calc matches 78..82 run return run attribute @s max_health base set 24.99
execute if score #value companion.calc matches 83..87 run return run attribute @s max_health base set 25.242
execute if score #value companion.calc matches 88..92 run return run attribute @s max_health base set 25.495
execute if score #value companion.calc matches 93..97 run return run attribute @s max_health base set 25.747
execute if score #value companion.calc matches 98..100 run return run attribute @s max_health base set 25.949
