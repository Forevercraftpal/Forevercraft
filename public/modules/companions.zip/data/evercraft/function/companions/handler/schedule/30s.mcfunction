scoreboard players operation #Search companion.id = @s companion.id

# Vex "Spectral Flight" (30s): brief Levitation burst (vex passive already grants permanent Slow Falling).
execute as @s[tag=companion.vex] at @s run function evercraft:companions/handler/active/abilities/trigger/vex_flight

execute as @s[tag=companion.zephyr] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[5].extra[{text:"30"}] at @s run return run function evercraft:companions/handler/active/abilities/trigger/chicken

execute as @s[tag=companion.bramble] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[5].extra[{text:"30"}] at @s run return run function evercraft:companions/handler/active/abilities/trigger/pufferfish

# Group-6: Grovekeeper "Overgrowth" (30s): nudge nearby saplings one growth stage (bounded sapling tick).
execute as @s[tag=companion.grovekeeper] at @s run function evercraft:companions/handler/active/abilities/trigger/grovekeeper_overgrowth