# SP5 — Skills: macro — call SP1's skills/set_active with the chosen slot. Run as player. Args: {slot:N}.
$function evercraft:companions/skills/set_active {slot:$(slot)}
