# Copper Golem Pet Passive Abilities
# - Dream Buttons: Luck (1.0 → 5.0)
# - Oxidation Resistance: Armor (0.5 → 3.0)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.copper_golem

# Dream Buttons: Luck (1.0 → 5.0)
execute if score #value companion.calc matches 1..7 run attribute @s luck base set 1.121
execute if score #value companion.calc matches 8..12 run attribute @s luck base set 1.364
execute if score #value companion.calc matches 13..17 run attribute @s luck base set 1.566
execute if score #value companion.calc matches 18..22 run attribute @s luck base set 1.768
execute if score #value companion.calc matches 23..27 run attribute @s luck base set 1.97
execute if score #value companion.calc matches 28..32 run attribute @s luck base set 2.172
execute if score #value companion.calc matches 33..37 run attribute @s luck base set 2.374
execute if score #value companion.calc matches 38..42 run attribute @s luck base set 2.576
execute if score #value companion.calc matches 43..47 run attribute @s luck base set 2.778
execute if score #value companion.calc matches 48..52 run attribute @s luck base set 2.98
execute if score #value companion.calc matches 53..57 run attribute @s luck base set 3.182
execute if score #value companion.calc matches 58..62 run attribute @s luck base set 3.384
execute if score #value companion.calc matches 63..67 run attribute @s luck base set 3.586
execute if score #value companion.calc matches 68..72 run attribute @s luck base set 3.788
execute if score #value companion.calc matches 73..77 run attribute @s luck base set 3.99
execute if score #value companion.calc matches 78..82 run attribute @s luck base set 4.192
execute if score #value companion.calc matches 83..87 run attribute @s luck base set 4.394
execute if score #value companion.calc matches 88..92 run attribute @s luck base set 4.596
execute if score #value companion.calc matches 93..97 run attribute @s luck base set 4.798
execute if score #value companion.calc matches 98..100 run attribute @s luck base set 4.96

# Oxidation Resistance: Armor (0.5 → 3.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s armor base set 0.576
execute if score #value companion.calc matches 8..12 run return run attribute @s armor base set 0.727
execute if score #value companion.calc matches 13..17 run return run attribute @s armor base set 0.854
execute if score #value companion.calc matches 18..22 run return run attribute @s armor base set 0.98
execute if score #value companion.calc matches 23..27 run return run attribute @s armor base set 1.106
execute if score #value companion.calc matches 28..32 run return run attribute @s armor base set 1.232
execute if score #value companion.calc matches 33..37 run return run attribute @s armor base set 1.359
execute if score #value companion.calc matches 38..42 run return run attribute @s armor base set 1.485
execute if score #value companion.calc matches 43..47 run return run attribute @s armor base set 1.611
execute if score #value companion.calc matches 48..52 run return run attribute @s armor base set 1.737
execute if score #value companion.calc matches 53..57 run return run attribute @s armor base set 1.864
execute if score #value companion.calc matches 58..62 run return run attribute @s armor base set 1.99
execute if score #value companion.calc matches 63..67 run return run attribute @s armor base set 2.116
execute if score #value companion.calc matches 68..72 run return run attribute @s armor base set 2.242
execute if score #value companion.calc matches 73..77 run return run attribute @s armor base set 2.369
execute if score #value companion.calc matches 78..82 run return run attribute @s armor base set 2.495
execute if score #value companion.calc matches 83..87 run return run attribute @s armor base set 2.621
execute if score #value companion.calc matches 88..92 run return run attribute @s armor base set 2.747
execute if score #value companion.calc matches 93..97 run return run attribute @s armor base set 2.874
execute if score #value companion.calc matches 98..100 run return run attribute @s armor base set 2.975
