# Decay relationship points over time
# deprecated — no longer scheduled (SP2 Bond & Care retired RP decay; bond RP is now monotonic).
# Kept as the documented retired path; the neglect signal moved to companion.happiness.
# Called once per hour (72000 ticks)
# -1 RP per hour for active pets

execute as @a at @s if entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, distance=..100] run function evercraft:companions/handler/relationship/decay_companion
