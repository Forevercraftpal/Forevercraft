# Called when relationship level increases
# Run as player

scoreboard players operation #Search companion.id = @s companion.id

# Get level name for message
scoreboard players set #levelName companion.calc 0
execute if score @s companion.rellevel matches 1 run data modify storage evercraft:companions temp.levelName set value "Friendly"
execute if score @s companion.rellevel matches 2 run data modify storage evercraft:companions temp.levelName set value "Bonded"
execute if score @s companion.rellevel matches 3 run data modify storage evercraft:companions temp.levelName set value "Devoted"
execute if score @s companion.rellevel matches 4 run data modify storage evercraft:companions temp.levelName set value "Soulbound"
execute if score @s companion.rellevel matches 5 run data modify storage evercraft:companions temp.levelName set value "Eternal Bond"

# Play celebration effects (gated bespoke FX — the chord climbs to the new bond level).
scoreboard players operation #bond_tier ec.temp = @s companion.rellevel
execute at @s run function evercraft:fx/companion/bond_up

# Show message with multiplier
scoreboard players set #ndur ec.temp 45
# SP2 re-curve: ability multiplier labels now follow the 1.2x..2.0x bond curve (was 1.1x..1.5x).
data modify storage evercraft:notify stage.c set value [{text:"Your bond with "},{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" has grown to "},{text:"Friendly",color:"green",bold:true},{text:"! "},{text:"(1.2x ability multiplier)",color:"yellow"}]
execute if score @s companion.rellevel matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Your bond with "},{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" has grown to "},{text:"Bonded",color:"aqua",bold:true},{text:"! "},{text:"(1.4x ability multiplier)",color:"yellow"}]
execute if score @s companion.rellevel matches 2 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Your bond with "},{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" has grown to "},{text:"Devoted",color:"blue",bold:true},{text:"! "},{text:"(1.6x ability multiplier)",color:"yellow"}]
execute if score @s companion.rellevel matches 3 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Your bond with "},{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" has grown to "},{text:"Soulbound",color:"light_purple",bold:true},{text:"! "},{text:"(1.8x ability multiplier)",color:"yellow"}]
execute if score @s companion.rellevel matches 4 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Your bond with "},{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" has reached "},{text:"Eternal Bond",color:"gold",bold:true},{text:"! "},{text:"(2.0x ability multiplier)",color:"yellow"}]
execute if score @s companion.rellevel matches 5 run function evercraft:util/notify/emit_keep

# Eternal Bond grants permanent decay immunity
execute if score @s companion.rellevel matches 5 run scoreboard players set @s ec.pet_bonded 1
data modify storage evercraft:notify stage.c set value [{text:"♡ ",color:"gold"},{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" is now permanently bonded — relationship will never decay!",color:"gold",italic:true},{text:" ♡",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s companion.rellevel matches 5 run function evercraft:util/notify/emit

# Campfire Stories — record Eternal Bond milestone
execute if score @s companion.rellevel matches 5 run data modify storage evercraft:campfire temp.companion set from storage evercraft:companions temp.levelName
execute if score @s companion.rellevel matches 5 run function evercraft:campfire_stories/record/companion_eternal

# Award Dreamweaver's Thread (+1 permanent DR) at Eternal Bond if not already owned
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s companion.rellevel matches 5 unless score @s ec.thread_count matches 1.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/dreamweavers_thread
execute if score @s companion.rellevel matches 5 unless score @s ec.thread_count matches 1.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/dreamweavers_thread
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"light_purple"},{text:"Dreamweaver's Thread",color:"light_purple",bold:true},{text:" received! (+1 Dream Rate)",color:"yellow"},{text:" ✦",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
execute if score @s companion.rellevel matches 5 unless score @s ec.thread_count matches 1.. run function evercraft:util/notify/emit

# Record "Eternal Bond" memory at level 5
execute if score @s companion.rellevel matches 5 run function evercraft:companions/memories/on_bond_eternal

# SP2 Bond & Care: roll a 50% chance to grant ONE permanent set-bond skill on this rank-up (cap 5).
# Fires BEFORE the ability re-apply below, so a newly-granted aura skill is applied by that re-run.
function evercraft:companions/bond/roll_set_skill

# Reapply pet abilities with new multiplier (and the just-loaded/rolled set-bond auras + happy passive)
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] run function evercraft:companions/handler/active/abilities/companion_selector with entity @s item.components."minecraft:profile".properties[{name:"name"}]
