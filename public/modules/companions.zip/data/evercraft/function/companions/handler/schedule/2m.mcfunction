scoreboard players operation #Search companion.id = @s companion.id

# Spirit Wolf "Soul Howl" (2min): undead within 20 take damage + glow.
execute as @s[tag=companion.spirit_wolf] at @s run function evercraft:companions/handler/active/abilities/trigger/spirit_wolf_howl

execute as @s[tag=companion.endwalker] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[9].extra[{text:"120"}] run return run function evercraft:companions/handler/active/abilities/trigger/blue_dragon

execute as @s[tag=companion.ashborn] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[9].extra[{text:"120"}] run return run function evercraft:companions/handler/active/abilities/trigger/red_dragon