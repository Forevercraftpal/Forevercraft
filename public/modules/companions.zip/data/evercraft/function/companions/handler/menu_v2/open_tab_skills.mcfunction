# SP5 — Open the SKILLS tab (ec.bd_tab 7). Run as player (on target from the Care Skills button).
# The 2-pages-of-6 ability-slot loadout picker. SP1 owns the ability data + set_active; SP5 owns the
# frame, the slot grid, paging, and the click→set_active routing. Reads the focused companion's slot
# descriptor (companion.slots = unlocked count, companion.skillslot = active) — for the live MAIN these
# come from skills/load_slots; for a stored focus, from the stored item's custom_data (snapshot-side).

scoreboard players operation #Search companion.id = @s companion.id

# Kill the home view / prior tab content so Skills has a clean frame.
execute as @e[type=item_display,tag=companion.homehead,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.homehead,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.headslot,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.home_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.home_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=item_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s

# Set the Skills tab + default the pager to page 0.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players set @s ec.bd_tab 7
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] unless score @s companion.skillpage matches 0..1 run scoreboard players set @s companion.skillpage 0

# Load the focused companion's slot descriptor into companion.slots / companion.skillslot.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run function evercraft:companions/handler/menu_v2/skills/load_focus_slots

# Render the slot grid + pager + back.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] at @s facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet run function evercraft:companions/handler/menu_v2/skills/render

# Session-stamp the new elements.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

playsound minecraft:block.note_block.hat master @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.6
