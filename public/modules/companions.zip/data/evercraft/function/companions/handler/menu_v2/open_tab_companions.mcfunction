# Open Companions tab — the pet catalogue (full roster) grid.
# Run as player, tears down the prior screen, spawns pet grid + nav + names + back button.
# 2026-06-06: now launched from the HOME view's "Companions" nav (not the hub), so it tears down the
# home heads/nav + the home's Back button (companion.tab_content) as well as any stray hub buttons.
# IMPORTANT: Uses facing entity <anchor> feet to prevent yaw drift when the player has turned their head.

# Need #Search for the check_id predicate (set from the player; caller routes here via `on target`).
scoreboard players operation #Search companion.id = @s companion.id

# Kill the prior screen: home view (heads/nav), any stray hub buttons, and all prior tab content
# (which includes the home view's Back button).
execute as @e[type=text_display,tag=companion.hub_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.hub_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=item_display,tag=companion.homehead,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.homehead,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.headslot,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.home_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.home_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=item_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s

# Set tab (find actual player — @s may be dead hub interaction entity)
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players set @s ec.bd_tab 1

# The grid always opens on page 1, so reset companion.menupage (2026-06-17). Page nav bumps menupage but
# Back never reset it, so re-entering the grid after paging left menupage stale — the abs-index math
# (slot + (menupage-1)*48) used by both summon AND journey-sub-assign then resolved to the wrong pet.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players set @s companion.menupage 1

# Load page 1 pet data from marker storage
scoreboard players set #PageToLoad companion.menu 1
execute in overworld positioned 0 -60 0 as @n[distance=..10,type=marker,tag=companion.marker,predicate=evercraft:companions/check_id] run function evercraft:companions/handler/menu_v2/load_companions

# Spawn pet slots (uses facing anchor internally)
# Pass rotation context via facing the anchor, NOT at @s (which resets rotation)
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet run function evercraft:companions/handler/menu_v2/spawn_slots

# Spawn pet name labels (uses facing anchor internally)
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet run function evercraft:companions/handler/menu_v2/spawn_names

# Spawn navigation (prev/next arrows)
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet run function evercraft:companions/handler/menu_v2/spawn_nav

# Spawn page info text
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.7 ^1.76 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menupageinfo","companion.menuelement","companion.tab_content"],billboard:"center",text:{text:"Page 1",color:"gray"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.418f,0.418f,0.418f]}}
scoreboard players operation @e[type=text_display,tag=companion.menupageinfo,distance=..5] companion.id = #Search companion.id

# Set page text
execute store result storage evercraft:companions page_text.maxpage int 1 run scoreboard players get #MaxPage companion.menu
data modify storage evercraft:companions page_text.page set value 1
function evercraft:companions/handler/menu_v2/set_page_text with storage evercraft:companions page_text

# Set initial arrow colors
execute as @e[type=text_display,tag=companion.menuprev,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s text set value {text:"\u25C0",color:"gray"}
execute if score #MaxPage companion.menu matches 2.. as @e[type=text_display,tag=companion.menunext,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s text set value {text:"\u25B6",color:"green"}
execute if score #MaxPage companion.menu matches ..1 as @e[type=text_display,tag=companion.menunext,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s text set value {text:"\u25B6",color:"gray"}

# Spawn Remove button
# MP-P3.12: hit recentered on text_y - h/2 per R.1 (was ^1.37 with h=0.06; AABB sat below glyph)
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.7 ^1.76 positioned ^1.2 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuremovetext","companion.menuelement","companion.tab_content"],billboard:"center",text:{text:"Remove",color:"red",bold:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.67 ^1.78 positioned ^1.2 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuremoveclick","companion.menuelement","companion.tab_content"],width:0.20f,height:0.06f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.menuremovetext,distance=..5] companion.id = #Search companion.id
scoreboard players operation @e[type=interaction,tag=companion.menuremoveclick,distance=..5] companion.id = #Search companion.id

# Spawn Relationship button
# MP-P3.12: hit recentered on text_y - h/2 per R.1; h bumped 0.05 -> 0.10 to enclose glyph
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.7 ^1.76 positioned ^0.7 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menureltext","companion.menuelement","companion.tab_content"],billboard:"center",text:{text:"\u2764",color:"red"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.418f,0.418f,0.418f]}}
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.65 ^1.78 positioned ^0.7 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menurelclick","companion.menuelement","companion.tab_content"],width:0.10f,height:0.10f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.menureltext,distance=..5] companion.id = #Search companion.id
scoreboard players operation @e[type=interaction,tag=companion.menurelclick,distance=..5] companion.id = #Search companion.id

# Spawn Treat button
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.7 ^1.76 positioned ^-0.7 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menutreattext","companion.menuelement","companion.tab_content"],billboard:"center",text:{text:"\uD83C\uDF56",color:"yellow"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.418f,0.418f,0.418f]}}
# MP-P3.12: hit recentered on text_y - h/2 per R.1; h bumped 0.05 -> 0.10 to enclose glyph
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.65 ^1.78 positioned ^-0.7 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menutreatclick","companion.menuelement","companion.tab_content"],width:0.10f,height:0.10f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.menutreattext,distance=..5] companion.id = #Search companion.id
scoreboard players operation @e[type=interaction,tag=companion.menutreatclick,distance=..5] companion.id = #Search companion.id

# Spawn Visibility toggle
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.7 ^1.76 positioned ^-1.2 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuvistext","companion.menuelement","companion.tab_content"],billboard:"center",text:{text:"Visible",color:"green",bold:true},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
# MP-P3.12: hit recentered on text_y - h/2 per R.1
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.67 ^1.78 positioned ^-1.2 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuvisclick","companion.menuelement","companion.tab_content"],width:0.20f,height:0.06f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.menuvistext,distance=..5] companion.id = #Search companion.id
scoreboard players operation @e[type=interaction,tag=companion.menuvisclick,distance=..5] companion.id = #Search companion.id
execute if entity @s[tag=companion.hidden] as @e[type=text_display,tag=companion.menuvistext,distance=..3] run data modify entity @s text set value {text:"Hidden",color:"red",bold:true}

# Spawn Home/Guild placement buttons
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.49 ^1.76 positioned ^0.45 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuhometext","companion.menuelement","companion.tab_content"],billboard:"center",text:[{text:"\u2302 ",color:"green"},{text:"Home",color:"white",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
# MP-P3.12: hit recentered on text_y - h/2 per R.1
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.46 ^1.78 positioned ^0.45 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuhomeclick","companion.menuelement","companion.tab_content"],width:0.20f,height:0.06f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.menuhometext,distance=..5] companion.id = #Search companion.id
scoreboard players operation @e[type=interaction,tag=companion.menuhomeclick,distance=..5] companion.id = #Search companion.id

execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.49 ^1.76 positioned ^-0.45 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuguildtext","companion.menuelement","companion.tab_content"],billboard:"center",text:[{text:"\u2694 ",color:"dark_purple"},{text:"Guild",color:"white",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
# MP-P3.12: hit recentered on text_y - h/2 per R.1
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.46 ^1.78 positioned ^-0.45 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuguildclick","companion.menuelement","companion.tab_content"],width:0.20f,height:0.06f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.menuguildtext,distance=..5] companion.id = #Search companion.id
scoreboard players operation @e[type=interaction,tag=companion.menuguildclick,distance=..5] companion.id = #Search companion.id

# Pack button \u2014 shown for any pack-carrying companion (Deloris OR Llama; Llama "Extra Storage" reuses the
# same companion.id-keyed 5-slot pack). Transient companion.has_pack tag lets one block cover both without
# duplicating the spawn lines; it is removed immediately after.
execute if entity @s[tag=companion.deloris] run tag @s add companion.has_pack
execute if entity @s[tag=companion.llama] run tag @s add companion.has_pack
execute if entity @s[tag=companion.has_pack] facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.35 ^1.76 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menupacktext","companion.menuelement","companion.tab_content"],billboard:"center",text:[{text:"\uD83D\uDCE6 ",color:"light_purple"},{text:"Pack",color:"white",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
execute if entity @s[tag=companion.has_pack] facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.3 ^1.78 run summon interaction ~ ~ ~ {Tags:["companion.menupackclick","companion.menuelement","companion.tab_content"],width:0.20f,height:0.1f,response:1b}
execute if entity @s[tag=companion.has_pack] run scoreboard players operation @e[type=text_display,tag=companion.menupacktext,distance=..5] companion.id = #Search companion.id
execute if entity @s[tag=companion.has_pack] run scoreboard players operation @e[type=interaction,tag=companion.menupackclick,distance=..5] companion.id = #Search companion.id
tag @s remove companion.has_pack

# Spawn back button (bottom-center, returns to hub — matches codex style)
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.45 ^1.76 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.back_btn_text","companion.menuelement","companion.tab_content"],billboard:"center",text:{text:"\u25C0 Back",color:"yellow"},background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.358f,0.358f,0.358f]}}
# MP-P3.12: hit recentered on text_y - h/2 per R.1 (was ^1.12 with h=0.08; AABB sat below glyph)
execute facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet rotated ~ 0 positioned ^ ^0.41 ^1.78 run summon interaction ~ ~ ~ {Tags:["companion.back_btn_click","companion.menuelement","companion.tab_content"],width:0.25f,height:0.08f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.back_btn_text,distance=..5] companion.id = #Search companion.id
scoreboard players operation @e[type=interaction,tag=companion.back_btn_click,distance=..5] companion.id = #Search companion.id

# Session stamp (use player's session via @a with ID match, not @s which may be dead hub entity)
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=companion.tab_content,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=companion.tab_content,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=companion.tab_content,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.6
