# SP5 — Journey: Sub-B ready status. Run as player. journey.qslot = assigned Pets[] index.
data modify storage evercraft:companions journey.subname set value "Your companion"
data modify storage evercraft:companions journey.journey_slot set from storage evercraft:companions journey.qslot
execute in overworld run function evercraft:companions/journey/get_subname with storage evercraft:companions journey
function evercraft:companions/handler/menu_v2/journey/status_ready_b_text with storage evercraft:companions journey
