# SP5 — Journey: render the Sub-B row. Run as player, facing-anchor context. Mirror of render_slot_a.
# Reads SP4 state: companion.subB_slot (assigned, 0 empty), companion.jB_end (return gametime, 0 idle).

execute rotated ~ 0 positioned ^ ^1.50 ^1.74 positioned ^0.85 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.jr_b_label"],billboard:"center",text:[{text:"Slot B",color:"gold"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}
scoreboard players operation @e[type=text_display,tag=companion.jr_b_label,distance=..5] companion.id = @s companion.id

execute rotated ~ 0 positioned ^ ^1.50 ^1.74 positioned ^0.15 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.jr_b_status"],billboard:"center",background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
scoreboard players operation @e[type=text_display,tag=companion.jr_b_status,distance=..5] companion.id = @s companion.id

execute if score @s companion.subB_slot matches 0 run data modify entity @n[type=text_display,tag=companion.jr_b_status,distance=..5] text set value [{text:"Empty — assign on the home view (click a + head)",color:"dark_gray",italic:true}]
execute if score @s companion.jB_end matches 1.. run scoreboard players operation #cc_left ec.temp = @s companion.jB_end
execute if score @s companion.jB_end matches 1.. run scoreboard players operation #cc_left ec.temp -= #cc_now ec.temp
execute if score @s companion.jB_end matches 1.. if score #cc_left ec.temp matches ..0 run scoreboard players set #cc_left ec.temp 0
execute if score @s companion.jB_end matches 1.. run scoreboard players operation #cc_left ec.temp /= #1200 companion.calc
execute if score @s companion.jB_end matches 1.. run scoreboard players add #cc_left ec.temp 1
execute if score @s companion.jB_end matches 1.. store result storage evercraft:companions journey.mins int 1 run scoreboard players get #cc_left ec.temp
execute if score @s companion.jB_end matches 1.. run function evercraft:companions/handler/menu_v2/journey/status_inflight_b with storage evercraft:companions journey
execute if score @s companion.subB_slot matches 1.. if score @s companion.jB_end matches ..0 store result storage evercraft:companions journey.qslot int 1 run scoreboard players get @s companion.subB_slot
execute if score @s companion.subB_slot matches 1.. if score @s companion.jB_end matches ..0 run function evercraft:companions/handler/menu_v2/journey/status_ready_b with storage evercraft:companions journey

execute rotated ~ 0 positioned ^ ^1.50 ^1.74 positioned ^-0.90 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.jr_b_send_text"],billboard:"center",text:[{text:"▶ Send",color:"green"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
execute rotated ~ 0 positioned ^ ^1.46 ^1.76 positioned ^-0.90 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.jr_b_send_click"],width:0.30f,height:0.12f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.jr_b_send_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.jr_b_send_click,distance=..5] companion.id = @s companion.id
