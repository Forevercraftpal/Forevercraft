# Sync active pet relationship (RP) from live entity back to companion.marker storage.
# Without this, RP gains live on the entity NBT only — when the pet is unsummoned/killed
# the NBT dies with it, and the next summon re-reads the OLD value from Pets[] storage.
# This is also why the catalogue grid (which reads from Pets[] storage) was showing stale RP.
#
# Run as: player with active pet. Uses companion.activeslot (set at spawn) to know which
# Pets[] index to update.

scoreboard players operation #Search companion.id = @s companion.id

# Skip if no relationship property on the live entity (uninitialized pet)
execute unless data entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:profile".properties[{name:"relationship"}] run return 0

# Copy live entity relationship value into sync staging storage
data modify storage evercraft:companions sync.relationship set from entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:profile".properties[{name:"relationship"}].value

# Stage active slot for the macro
execute store result storage evercraft:companions sync.slot_index int 1 run scoreboard players get @s companion.activeslot

# Write back to companion.marker at the correct slot index (mirrors sync_memories_to_marker)
execute in overworld positioned 0 -60 0 as @n[distance=..10,type=marker,tag=companion.marker,predicate=evercraft:companions/check_id] run function evercraft:companions/handler/active/sync_relationship_write with storage evercraft:companions sync

# SP2 Bond & Care: ALSO flush the per-instance bond state (bond_skills + happiness + happydays) from
# the live entity into Pets[] on this same sync, so unsummon/switch never loses an in-session change
# (DATA-MODEL §12.2 — extend this fn to mirror the new properties). Guarded on each property existing
# on the live entity (pre-SP2 companions back-fill them via bond/load_skills before any sync).
execute if data entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:profile".properties[{name:"bond_skills"}] run function evercraft:companions/bond/sync_skills_to_marker
execute if data entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:profile".properties[{name:"happiness"}] run function evercraft:companions/bond/sync_happiness_passthrough
