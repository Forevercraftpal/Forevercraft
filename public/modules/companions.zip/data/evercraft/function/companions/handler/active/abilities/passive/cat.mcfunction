# Glider Pet Passive Abilities
# - Membrane Wings: Fall dmg (0.95 → 0.0)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.glider

# Membrane Wings: Fall dmg (0.95 → 0.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s fall_damage_multiplier base set 0.921
execute if score #value companion.calc matches 8..12 run return run attribute @s fall_damage_multiplier base set 0.864
execute if score #value companion.calc matches 13..17 run return run attribute @s fall_damage_multiplier base set 0.816
execute if score #value companion.calc matches 18..22 run return run attribute @s fall_damage_multiplier base set 0.768
execute if score #value companion.calc matches 23..27 run return run attribute @s fall_damage_multiplier base set 0.72
execute if score #value companion.calc matches 28..32 run return run attribute @s fall_damage_multiplier base set 0.672
execute if score #value companion.calc matches 33..37 run return run attribute @s fall_damage_multiplier base set 0.624
execute if score #value companion.calc matches 38..42 run return run attribute @s fall_damage_multiplier base set 0.576
execute if score #value companion.calc matches 43..47 run return run attribute @s fall_damage_multiplier base set 0.528
execute if score #value companion.calc matches 48..52 run return run attribute @s fall_damage_multiplier base set 0.48
execute if score #value companion.calc matches 53..57 run return run attribute @s fall_damage_multiplier base set 0.432
execute if score #value companion.calc matches 58..62 run return run attribute @s fall_damage_multiplier base set 0.384
execute if score #value companion.calc matches 63..67 run return run attribute @s fall_damage_multiplier base set 0.336
execute if score #value companion.calc matches 68..72 run return run attribute @s fall_damage_multiplier base set 0.288
execute if score #value companion.calc matches 73..77 run return run attribute @s fall_damage_multiplier base set 0.24
execute if score #value companion.calc matches 78..82 run return run attribute @s fall_damage_multiplier base set 0.192
execute if score #value companion.calc matches 83..87 run return run attribute @s fall_damage_multiplier base set 0.144
execute if score #value companion.calc matches 88..92 run return run attribute @s fall_damage_multiplier base set 0.096
execute if score #value companion.calc matches 93..97 run return run attribute @s fall_damage_multiplier base set 0.048
execute if score #value companion.calc matches 98..100 run return run attribute @s fall_damage_multiplier base set 0.01
