# SP5 — Care: Pet a STORED (non-summoned) companion → +5 RP to its Pets[] record. Run as player.
# Clone of home/interact/pet's RP path, keyed by companion.careidx (the focused roster index) instead
# of an HC.Head live entity. Anti-spam via ec.cc_petcd (menu-tick-decremented).

# Cooldown gate (5s).
data modify storage evercraft:notify stage.c set value [{text:"Give them a moment before more affection.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.cc_petcd matches 1.. run return run function evercraft:util/notify/emit

# Re-snapshot the focused record + load its current RP (data-side).
data remove storage evercraft:companions care.head
execute store result storage evercraft:companions care.probeidx int 1 run scoreboard players get @s companion.careidx
execute store result storage evercraft:companions care.careidx int 1 run scoreboard players get @s companion.careidx
function evercraft:companions/handler/menu_v2/care/snapshot_idx with storage evercraft:companions care
function evercraft:companions/handler/menu_v2/care/load_focus_rp

# +5 RP, cap 5000.
scoreboard players add @s companion.rp 5
execute if score @s companion.rp matches 5001.. run scoreboard players set @s companion.rp 5000

# Save back to the record (keyed by careidx).
function evercraft:companions/handler/menu_v2/care/save_focus_rp with storage evercraft:companions care

# Cooldown + feedback.
scoreboard players set @s ec.cc_petcd 100
execute at @s run particle heart ^ ^1 ^1.7 0.2 0.2 0.2 0 3
# Sanctioned affection vocal — KEEP + GATE.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.cat.purr master @s ~ ~ ~ 0.5 1.2
data modify storage evercraft:notify stage.c set value [{text:"Your companion enjoyed the affection! ",color:"green"},{text:"(+5 RP)",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
