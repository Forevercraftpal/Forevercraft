# Breeze Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.breeze

# Wind Rush: Speed (0.11 → 0.14)
$execute if score #value companion.calc matches 1..7 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.111 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.113 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.114 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.116 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.117 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.119 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.12 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.122 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.123 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.125 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.126 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.128 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.129 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.131 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.132 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.134 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.135 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.137 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.138 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/movement_speed 0.14 add_value

# Wind Shield: KB res (0.1 → 0.5)
$execute if score #value companion.calc matches 1..7 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.112 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.136 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.157 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.177 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.197 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.217 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.237 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.258 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.278 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.298 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.318 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.338 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.359 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.379 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.399 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.419 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.439 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.46 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.48 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.496 add_value
