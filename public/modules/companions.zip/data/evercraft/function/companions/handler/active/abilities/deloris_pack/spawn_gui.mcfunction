# Deloris Pack — Spawn GUI
# @s = player, position context set

# Background panel
execute rotated ~ 0 positioned ^ ^2.0 ^1.8 run summon item_display ~ ~ ~ {Tags:["ec.dlpack_el"],billboard:"center",item:{id:"purple_stained_glass_pane",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[2.5f,2.2f,0.01f]}}

# Title
execute rotated ~ 0 positioned ^ ^2.6 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.dlpack_el"],billboard:"center",text:[{text:"\u2726 ",color:"dark_purple"},{text:"Deloris Pack",color:"light_purple",bold:true},{text:" \u2726",color:"dark_purple"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.54f,0.54f,0.54f]}}

# Instruction
execute rotated ~ 0 positioned ^ ^1.45 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.dlpack_el"],billboard:"center",text:[{text:"Hold item + click slot to store | Click stored item to retrieve",color:"gray",italic:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}

# 5 slots
execute rotated ~ 0 positioned ^ ^2.4 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.dlpack_el","ec.dlpack_s0_txt"],billboard:"center",text:[{text:"1. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]}}
execute rotated ~ 0 positioned ^ ^2.3 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.dlpack_el","ec.dlpack_slot","ec.dlpack_s0"],width:0.8f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2.23 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.dlpack_el","ec.dlpack_s1_txt"],billboard:"center",text:[{text:"2. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]}}
execute rotated ~ 0 positioned ^ ^2.13 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.dlpack_el","ec.dlpack_slot","ec.dlpack_s1"],width:0.8f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^2.06 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.dlpack_el","ec.dlpack_s2_txt"],billboard:"center",text:[{text:"3. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]}}
execute rotated ~ 0 positioned ^ ^1.96 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.dlpack_el","ec.dlpack_slot","ec.dlpack_s2"],width:0.8f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.89 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.dlpack_el","ec.dlpack_s3_txt"],billboard:"center",text:[{text:"4. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]}}
execute rotated ~ 0 positioned ^ ^1.79 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.dlpack_el","ec.dlpack_slot","ec.dlpack_s3"],width:0.8f,height:0.12f,response:1b}

execute rotated ~ 0 positioned ^ ^1.72 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.dlpack_el","ec.dlpack_s4_txt"],billboard:"center",text:[{text:"5. ",color:"gray"},{text:"[Empty]",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]}}
execute rotated ~ 0 positioned ^ ^1.62 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.dlpack_el","ec.dlpack_slot","ec.dlpack_s4"],width:0.8f,height:0.12f,response:1b}

# Close button
execute rotated ~ 0 positioned ^ ^1.55 ^1.78 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["ec.dlpack_el","ec.dlpack_close_txt"],billboard:"center",text:[{text:"[ ",color:"dark_gray"},{text:"Close",color:"gray",bold:true},{text:" ]",color:"dark_gray"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.405f,0.405f,0.405f]}}
execute rotated ~ 0 positioned ^ ^1.45 ^1.8 run summon interaction ~ ~ ~ {Tags:["ec.dlpack_el","ec.dlpack_close_btn"],width:0.5f,height:0.12f,response:1b}

# Session isolation
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=ec.dlpack_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=ec.dlpack_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=ec.dlpack_el,distance=..5] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
