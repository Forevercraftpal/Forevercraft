# Monolith Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.monolith

# Stone Aegis: Armor (1.0 → 6.0)
$execute if score #value companion.calc matches 1..7 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 1.152 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 1.455 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 1.707 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 1.96 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 2.212 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 2.465 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 2.717 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 2.97 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 3.222 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 3.475 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 3.727 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 3.98 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 4.232 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 4.485 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 4.737 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 4.99 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 5.242 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 5.495 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 5.747 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s armor modifier add evercraft:home/slot$(ability_slot)/armor 5.949 add_value

# Stone Aegis: Toughness (0.5 → 3.0)
$execute if score #value companion.calc matches 1..7 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 0.576 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 0.727 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 0.854 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 0.98 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 1.106 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 1.232 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 1.359 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 1.485 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 1.611 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 1.737 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 1.864 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 1.99 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 2.116 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 2.242 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 2.369 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 2.495 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 2.621 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 2.747 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 2.874 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s armor_toughness modifier add evercraft:home/slot$(ability_slot)/armor_toughness 2.975 add_value
