# Check custom_data match first (new format)
$execute in overworld if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(name)"}}}] run return run function evercraft:companions/duplicate_to_shard

# Fallback: profile match (old format / backward compat)
$execute in overworld if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:profile":{properties:[{},{value:"$(name)"}]}}}] run return run function evercraft:companions/duplicate_to_shard

execute run return run function evercraft:companions/handler/database/store_companion
