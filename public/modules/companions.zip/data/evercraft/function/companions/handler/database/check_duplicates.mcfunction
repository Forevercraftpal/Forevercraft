# Shiny-aware duplicate handling (Joseph 2026-06-06). A SHINY is a distinct keeper: it converts to shards
# ONLY if you already own the shiny of this species. A NORMAL converts if you own the species in any form.
# So you can hold both a normal and its shiny, but never two of the same variant.
scoreboard players operation #Search companion.id = @s companion.id
scoreboard players set #inc_shiny ec.temp 0
execute if data storage evercraft:companions generatedItem.components."minecraft:custom_data"{shiny:1b} run scoreboard players set #inc_shiny ec.temp 1

# Probe ownership: this species (any variant, both storage formats) + the shiny variant specifically.
scoreboard players set #own_species ec.temp 0
scoreboard players set #own_shiny ec.temp 0
$execute in overworld if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(name)"}}}] run scoreboard players set #own_species ec.temp 1
$execute in overworld if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:profile":{properties:[{},{value:"$(name)"}]}}}] run scoreboard players set #own_species ec.temp 1
$execute in overworld if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(name)",shiny:1b}}}] run scoreboard players set #own_shiny ec.temp 1

# Duplicate cases. An owned duplicate does DOUBLE DUTY (dupe_absorb): it FUSES into the specific pet
# (+1% power, rarity-capped) AND advances evolution where applicable — each on the record's custom_data so
# both travel when traded. Shards are the fallback ONLY when fusion is capped AND evolution is done/N-A.
#   incoming shiny  + already own the shiny variant  = true shiny duplicate
#   incoming normal + already own the species        = normal duplicate
execute if score #inc_shiny ec.temp matches 1 if score #own_shiny ec.temp matches 1 run return run function evercraft:companions/handler/database/dupe_absorb
execute if score #inc_shiny ec.temp matches 0 if score #own_species ec.temp matches 1 run return run function evercraft:companions/handler/database/dupe_absorb

# Keep it. Bump the realm pet counter ONLY when the species is genuinely new (a first shiny of an
# already-owned species is a keeper but not a new realm discovery), then store.
execute if score #own_species ec.temp matches 0 run function evercraft:milestones/increment/companion_found
# New-species catalogue reveal — channel-gated (Off/Reduced/Full/Cracked). Genuinely-new only;
# a first-shiny-of-owned or a dupe-keep is a keeper but not a new dex entry, so it skips this.
execute if score #own_species ec.temp matches 0 at @s run function evercraft:fx/collect/companion_dex
return run function evercraft:companions/handler/database/store_companion
