# tag @s remove companion.activepet

# --------------------------------------------------------------------------------- #

data modify entity @s view_range set value 1f