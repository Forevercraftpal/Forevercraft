# SP5 — Skills: route a live-MAIN active-slot pick into SP1's skills/set_active. Run as player.
# Reads #cc_clicked ec.temp → macro {slot:N}. set_active is SP1's sole writer of companion.skillslot +
# custom_data.horn_active; SP5 only forwards the GUI click (thin renderer, DATA-MODEL §1.1).
execute store result storage evercraft:companions skills.slot int 1 run scoreboard players get #cc_clicked ec.temp
function evercraft:companions/handler/menu_v2/skills/set_active_live_macro with storage evercraft:companions skills
