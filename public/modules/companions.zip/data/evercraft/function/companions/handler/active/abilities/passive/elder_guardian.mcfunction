# Abyssal Pet Passive Abilities
# - Deep Pressure: Submerge mine (0.24 → 1.0)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.abyssal

# Deep Pressure: Submerge mine (0.24 → 1.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s submerged_mining_speed base set 0.263
execute if score #value companion.calc matches 8..12 run return run attribute @s submerged_mining_speed base set 0.309
execute if score #value companion.calc matches 13..17 run return run attribute @s submerged_mining_speed base set 0.347
execute if score #value companion.calc matches 18..22 run return run attribute @s submerged_mining_speed base set 0.386
execute if score #value companion.calc matches 23..27 run return run attribute @s submerged_mining_speed base set 0.424
execute if score #value companion.calc matches 28..32 run return run attribute @s submerged_mining_speed base set 0.463
execute if score #value companion.calc matches 33..37 run return run attribute @s submerged_mining_speed base set 0.501
execute if score #value companion.calc matches 38..42 run return run attribute @s submerged_mining_speed base set 0.539
execute if score #value companion.calc matches 43..47 run return run attribute @s submerged_mining_speed base set 0.578
execute if score #value companion.calc matches 48..52 run return run attribute @s submerged_mining_speed base set 0.616
execute if score #value companion.calc matches 53..57 run return run attribute @s submerged_mining_speed base set 0.655
execute if score #value companion.calc matches 58..62 run return run attribute @s submerged_mining_speed base set 0.693
execute if score #value companion.calc matches 63..67 run return run attribute @s submerged_mining_speed base set 0.731
execute if score #value companion.calc matches 68..72 run return run attribute @s submerged_mining_speed base set 0.77
execute if score #value companion.calc matches 73..77 run return run attribute @s submerged_mining_speed base set 0.808
execute if score #value companion.calc matches 78..82 run return run attribute @s submerged_mining_speed base set 0.846
execute if score #value companion.calc matches 83..87 run return run attribute @s submerged_mining_speed base set 0.885
execute if score #value companion.calc matches 88..92 run return run attribute @s submerged_mining_speed base set 0.923
execute if score #value companion.calc matches 93..97 run return run attribute @s submerged_mining_speed base set 0.962
execute if score #value companion.calc matches 98..100 run return run attribute @s submerged_mining_speed base set 0.992
