# Wolf Pet Passive Abilities
# - Pack Leader: Attack damage (1.5 → 4.0)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.wolf

# Pack Leader: Attack damage (1.5 → 4.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s attack_damage base set 1.576
execute if score #value companion.calc matches 8..12 run return run attribute @s attack_damage base set 1.727
execute if score #value companion.calc matches 13..17 run return run attribute @s attack_damage base set 1.854
execute if score #value companion.calc matches 18..22 run return run attribute @s attack_damage base set 1.98
execute if score #value companion.calc matches 23..27 run return run attribute @s attack_damage base set 2.106
execute if score #value companion.calc matches 28..32 run return run attribute @s attack_damage base set 2.232
execute if score #value companion.calc matches 33..37 run return run attribute @s attack_damage base set 2.359
execute if score #value companion.calc matches 38..42 run return run attribute @s attack_damage base set 2.485
execute if score #value companion.calc matches 43..47 run return run attribute @s attack_damage base set 2.611
execute if score #value companion.calc matches 48..52 run return run attribute @s attack_damage base set 2.737
execute if score #value companion.calc matches 53..57 run return run attribute @s attack_damage base set 2.864
execute if score #value companion.calc matches 58..62 run return run attribute @s attack_damage base set 2.99
execute if score #value companion.calc matches 63..67 run return run attribute @s attack_damage base set 3.116
execute if score #value companion.calc matches 68..72 run return run attribute @s attack_damage base set 3.242
execute if score #value companion.calc matches 73..77 run return run attribute @s attack_damage base set 3.369
execute if score #value companion.calc matches 78..82 run return run attribute @s attack_damage base set 3.495
execute if score #value companion.calc matches 83..87 run return run attribute @s attack_damage base set 3.621
execute if score #value companion.calc matches 88..92 run return run attribute @s attack_damage base set 3.747
execute if score #value companion.calc matches 93..97 run return run attribute @s attack_damage base set 3.874
execute if score #value companion.calc matches 98..100 run return run attribute @s attack_damage base set 3.975
