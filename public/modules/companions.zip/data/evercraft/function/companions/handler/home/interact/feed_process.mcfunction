# ============================================================
# Home Companion — Process feeding (macro)
# Run as: player, at player position
# Args: {rp:N, cd:N, food:"type"}
# Requires: #hc_interact_slot hc.slot = target companion's slot
# ============================================================

$scoreboard players set #feedRP companion.calc $(rp)

# Set cooldown on this companion's interact entity (per-pet, not per-player)
scoreboard players operation #Search companion.id = @s companion.id
$execute as @e[type=interaction, tag=HC.Interact, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_interact_slot hc.slot run scoreboard players set @s hc.feedcd $(cd)

# Load current RP from home companion
function evercraft:companions/handler/home/interact/load_rp

# Store old level for comparison
scoreboard players operation #oldLevel companion.calc = @s companion.rellevel

# Add RP
scoreboard players operation @s companion.rp += #feedRP companion.calc

# Cap at 5000
execute if score @s companion.rp > #5000 companion.calc run scoreboard players set @s companion.rp 5000

# Save new RP (also syncs to marker)
function evercraft:companions/handler/home/interact/save_rp

# Recalculate level
function evercraft:companions/handler/home/interact/load_rp

# Consume 1 of the food item
item modify entity @s weapon.mainhand evercraft:companions/consume_one

# Play effects (sanctioned affection vocal — KEEP + GATE).
execute if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:entity.generic.eat master @s ~ ~ ~ 1 1
execute as @e[type=chicken, tag=HomeCompanion, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_interact_slot hc.slot at @s run particle heart ~ ~0.5 ~ 0.3 0.3 0.3 0 3

# Show message
$data modify storage evercraft:notify stage.c set value [{text:"Your home companion enjoyed the treat! ",color:"green"},{text:"(+$(rp) RP)",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Check for level up
execute unless score @s companion.rellevel = #oldLevel companion.calc run function evercraft:companions/handler/relationship/level_up

# Achievement tracking
scoreboard players add @s ach.comp_feeds 1
