# SP5 — Write the Care-focused companion's RP back to its STORED Pets[] record (data-side).
# Run as player. Macro arg: {careidx:<absolute Pets[] index>}. Reads @s companion.rp, clamps 0..5000,
# converts to NBT string, and writes it into Pets[careidx].profile.relationship.value on the marker.
# Mirrors home/interact/save_rp:22 but keyed by absolute index (no live entity needed).
#
# Initializes the relationship property if the record lacks it (so the first stored-pet/feed never
# silently no-ops on a fresh companion).

# Clamp.
execute if score @s companion.rp matches ..-1 run scoreboard players set @s companion.rp 0
execute if score @s companion.rp matches 5001.. run scoreboard players set @s companion.rp 5000

# Convert score → NBT string into math.string.
scoreboard players operation #value companion.calc = @s companion.rp
function evercraft:companions/handler/math/int_to_string

# Ensure the relationship property exists on the target record, then write the value.
scoreboard players operation #Search companion.id = @s companion.id
function evercraft:companions/handler/menu_v2/care/save_focus_rp_macro with storage evercraft:companions care
