# ============================================================
# Home Companion — Save RP back to home companion entity
# Run as: player
# Requires: #hc_interact_slot hc.slot = target companion's slot
# Reads from: @s companion.rp
# ============================================================

scoreboard players operation #Search companion.id = @s companion.id

# Clamp RP to 0-5000
execute if score @s companion.rp < #0 companion.calc run scoreboard players set @s companion.rp 0
execute if score @s companion.rp > #5000 companion.calc run scoreboard players set @s companion.rp 5000

# Convert score to NBT string
scoreboard players operation #value companion.calc = @s companion.rp
function evercraft:companions/handler/math/int_to_string

# Find the target HomeCompanion by slot
execute as @e[type=item_display, tag=HC.Head, predicate=evercraft:companions/check_id] if score @s hc.slot = #hc_interact_slot hc.slot run tag @s add hc.target

# Update pet entity NBT
data modify entity @e[type=item_display, tag=hc.target, limit=1] item.components."minecraft:profile".properties[{name:"relationship"}].value set from storage evercraft:companions math.string

# Sync back to marker storage (HomePets[] and Pets[])
execute as @e[type=item_display, tag=hc.target, limit=1] run function evercraft:companions/handler/home/sync_rp

tag @e[tag=hc.target] remove hc.target
