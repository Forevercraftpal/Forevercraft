# Cow Pet Passive Abilities
# - Effect: saturation

tag @s add companion.cow

effect give @s saturation infinite 0 true

