# SP8 — Wayfarer Track: place one cell at its col/row. Run as player (facing-anchor context from render).
# Reads storage evercraft:companions wf.{col,row,node,icon,color,label}. Spawns the cell text_display
# (icon + "Node N" + reward label) and a click hitbox tagged companion.wf_cell_click stamped with the
# node number (companion.wf_clicknode) for claim routing. 5 cols x 2 rows.
# Col X offset: 0→+0.88, 1→+0.44, 2→0, 3→-0.44, 4→-0.88. Row Y: 0→1.30, 1→0.92.

# Resolve row Y into storage.
data modify storage evercraft:companions wf.yy set value "1.30"
execute if data storage evercraft:companions wf{row:1} run data modify storage evercraft:companions wf.yy set value "0.92"

# Resolve col X offset into storage.
data modify storage evercraft:companions wf.dx set value "0.0"
execute if data storage evercraft:companions wf{col:0} run data modify storage evercraft:companions wf.dx set value "0.88"
execute if data storage evercraft:companions wf{col:1} run data modify storage evercraft:companions wf.dx set value "0.44"
execute if data storage evercraft:companions wf{col:2} run data modify storage evercraft:companions wf.dx set value "0.0"
execute if data storage evercraft:companions wf{col:3} run data modify storage evercraft:companions wf.dx set value "-0.44"
execute if data storage evercraft:companions wf{col:4} run data modify storage evercraft:companions wf.dx set value "-0.88"

# Place via the macro (positions, spawns text + hitbox, stamps node).
function evercraft:companions/handler/menu_v2/wayfarer/place_cell_at with storage evercraft:companions wf
