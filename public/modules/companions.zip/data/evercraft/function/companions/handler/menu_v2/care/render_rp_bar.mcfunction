# SP5 — Render the Care RP progress bar (10 segments) + the "N / 5000" number.
# Run as player. Requires companion.rp loaded (care/load_focus_rp). Spawns a text_display nameplate
# under the bond line. Tagged companion.menuelement + companion.tab_content + companion.care_rpbar
# (re-killable on every Care refresh). Filled segments = floor(rp / 500), clamped 0..10.

# Filled-segment count.
scoreboard players operation #cc_fill companion.calc = @s companion.rp
scoreboard players operation #cc_fill companion.calc /= #500 companion.calc
execute if score #cc_fill companion.calc matches 11.. run scoreboard players set #cc_fill companion.calc 10
execute if score #cc_fill companion.calc matches ..0 run scoreboard players set #cc_fill companion.calc 0

# Build the bar string into care.bar (filled ▓, empty ░) via a per-count branch.
data modify storage evercraft:companions care.bar set value "░░░░░░░░░░"
execute if score #cc_fill companion.calc matches 1 run data modify storage evercraft:companions care.bar set value "▓░░░░░░░░░"
execute if score #cc_fill companion.calc matches 2 run data modify storage evercraft:companions care.bar set value "▓▓░░░░░░░░"
execute if score #cc_fill companion.calc matches 3 run data modify storage evercraft:companions care.bar set value "▓▓▓░░░░░░░"
execute if score #cc_fill companion.calc matches 4 run data modify storage evercraft:companions care.bar set value "▓▓▓▓░░░░░░"
execute if score #cc_fill companion.calc matches 5 run data modify storage evercraft:companions care.bar set value "▓▓▓▓▓░░░░░"
execute if score #cc_fill companion.calc matches 6 run data modify storage evercraft:companions care.bar set value "▓▓▓▓▓▓░░░░"
execute if score #cc_fill companion.calc matches 7 run data modify storage evercraft:companions care.bar set value "▓▓▓▓▓▓▓░░░"
execute if score #cc_fill companion.calc matches 8 run data modify storage evercraft:companions care.bar set value "▓▓▓▓▓▓▓▓░░"
execute if score #cc_fill companion.calc matches 9 run data modify storage evercraft:companions care.bar set value "▓▓▓▓▓▓▓▓▓░"
execute if score #cc_fill companion.calc matches 10.. run data modify storage evercraft:companions care.bar set value "▓▓▓▓▓▓▓▓▓▓"

# Stash the numeric RP as a storage string for the readout.
execute store result storage evercraft:companions care.rpnum int 1 run scoreboard players get @s companion.rp

# Spawn the bar text_display (centered, below the bond line / above the name + four buttons).
execute rotated ~ 0 positioned ^ ^1.29 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.care_rpbar"],billboard:"center",background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.30f,0.30f,0.30f]}}
function evercraft:companions/handler/menu_v2/care/render_rp_bar_text with storage evercraft:companions care
scoreboard players operation @e[type=text_display,tag=companion.care_rpbar,distance=..5] companion.id = @s companion.id
