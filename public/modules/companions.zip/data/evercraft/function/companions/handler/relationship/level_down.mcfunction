# Called when relationship level decreases due to neglect
# Run as player

scoreboard players operation #Search companion.id = @s companion.id

# Play sad effects (gated bespoke FX — the chord falls; REPLACES the off-palette wolf.whine).
execute at @s run function evercraft:fx/companion/bond_down

# Message
scoreboard players set #ndur ec.temp 45
data modify storage evercraft:notify stage.c set value [{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" seems distant... Feed or pet them to restore your bond!",color:"gray",italic:true}]
execute if score @s companion.rellevel matches 0 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Your bond with "},{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" has weakened slightly.",color:"gray",italic:true}]
execute if score @s companion.rellevel matches 1..4 run function evercraft:util/notify/emit

# Reapply abilities with lower multiplier
execute as @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] run function evercraft:companions/handler/active/abilities/companion_selector with entity @s item.components."minecraft:profile".properties[{name:"name"}]
