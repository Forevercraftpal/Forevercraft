# SP8 — Wayfarer Track: render the node ladder for the current page (companion.wf_page 0/1/2).
# Run as player, facing-anchor context from open_tab_wayfarer. 10 nodes/page (2 rows x 5). Each cell
# shows the node #, reward label, XP threshold, and state: locked (dim padlock) / CLAIMABLE (glowing
# gold, clickable → track/claim) / claimed (green check). Header = "Wayfarer XP: X / next" + Dream Rank.
# Reuses the menu frame (no new GUI framework).

scoreboard players operation #Search companion.id = @s companion.id

# === Title ===
execute rotated ~ 0 positioned ^ ^1.95 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.wf_title"],billboard:"center",text:[{text:"🧭 Wayfarer's Track",color:"gold",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.40f,0.40f,0.40f]}}
scoreboard players operation @e[type=text_display,tag=companion.wf_title,distance=..5] companion.id = @s companion.id

# === Header: XP + Dream Rank (mirrors the codex profile header DR read). NON-BOLD. ===
function evercraft:companions/handler/menu_v2/wayfarer/render_header

# === Base node index for this page (page 0 → nodes 1..10, page 1 → 11..20, page 2 → 21..30). ===
scoreboard players operation #wf_cbase companion.menu = @s companion.wf_page
scoreboard players operation #wf_cbase companion.menu *= #10 ec.const
scoreboard players add #wf_cbase companion.menu 1

# === Render 10 cells (2 rows x 5 cols). render_cell reads #wf_cell (the node number) + grid offsets. ===
scoreboard players operation #wf_cell companion.menu = #wf_cbase companion.menu
function evercraft:companions/handler/menu_v2/wayfarer/render_cell {col:0,row:0}
scoreboard players add #wf_cell companion.menu 1
function evercraft:companions/handler/menu_v2/wayfarer/render_cell {col:1,row:0}
scoreboard players add #wf_cell companion.menu 1
function evercraft:companions/handler/menu_v2/wayfarer/render_cell {col:2,row:0}
scoreboard players add #wf_cell companion.menu 1
function evercraft:companions/handler/menu_v2/wayfarer/render_cell {col:3,row:0}
scoreboard players add #wf_cell companion.menu 1
function evercraft:companions/handler/menu_v2/wayfarer/render_cell {col:4,row:0}
scoreboard players add #wf_cell companion.menu 1
function evercraft:companions/handler/menu_v2/wayfarer/render_cell {col:0,row:1}
scoreboard players add #wf_cell companion.menu 1
function evercraft:companions/handler/menu_v2/wayfarer/render_cell {col:1,row:1}
scoreboard players add #wf_cell companion.menu 1
function evercraft:companions/handler/menu_v2/wayfarer/render_cell {col:2,row:1}
scoreboard players add #wf_cell companion.menu 1
function evercraft:companions/handler/menu_v2/wayfarer/render_cell {col:3,row:1}
scoreboard players add #wf_cell companion.menu 1
function evercraft:companions/handler/menu_v2/wayfarer/render_cell {col:4,row:1}

# === Page toggle (◀ / Page N / 3 / ▶) — sits just above the Back button (^0.45) ===
execute rotated ~ 0 positioned ^ ^0.62 ^1.74 positioned ^0.55 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.wf_pageprev_text"],billboard:"center",text:[{text:"◀",color:"aqua"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
execute rotated ~ 0 positioned ^ ^0.59 ^1.76 positioned ^0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.wf_pageprev_click"],width:0.22f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^ ^0.62 ^1.74 positioned ^-0.55 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.wf_pagenext_text"],billboard:"center",text:[{text:"▶",color:"aqua"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.32f,0.32f,0.32f]}}
execute rotated ~ 0 positioned ^ ^0.59 ^1.76 positioned ^-0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.wf_pagenext_click"],width:0.22f,height:0.12f,response:1b}
function evercraft:companions/handler/menu_v2/wayfarer/render_page_label
scoreboard players operation @e[type=text_display,tag=companion.wf_pageprev_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.wf_pageprev_click,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=text_display,tag=companion.wf_pagenext_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.wf_pagenext_click,distance=..5] companion.id = @s companion.id

# === [✦ Claim Page] — claims every unlocked, unclaimed node on THIS page (RE-P8,
#     Joseph verdict 2026-06-10: claim-all-on-page; per-node stays canonical). Sits
#     left of the ◀ arrow; same tag/stamp idiom as the page arrows. NON-BOLD. ===
execute rotated ~ 0 positioned ^ ^0.62 ^1.74 positioned ^1.25 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.wf_claimall_text"],billboard:"center",text:[{text:"✦ Claim Page",color:"gold"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.30f,0.30f,0.30f]}}
execute rotated ~ 0 positioned ^ ^0.59 ^1.76 positioned ^1.25 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.wf_claimall_click"],width:0.5f,height:0.12f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.wf_claimall_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.wf_claimall_click,distance=..5] companion.id = @s companion.id

# === Back ===
function evercraft:companions/handler/menu_v2/spawn_back_btn
