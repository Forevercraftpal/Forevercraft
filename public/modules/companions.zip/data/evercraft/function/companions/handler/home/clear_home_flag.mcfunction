# ============================================================
# Home Companion — Clear home:1b flag from matching Pets[] entry
# Run as: player (with #Search companion.id set)
# Uses home.remove_slot set in retrieve.mcfunction — direct index removal,
# no name scan needed (avoids profile properties matching issues)
# ============================================================

function evercraft:companions/handler/home/clear_home_flag_direct with storage evercraft:companions home
