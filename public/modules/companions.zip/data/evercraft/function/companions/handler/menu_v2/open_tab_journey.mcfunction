# SP5 — Open the JOURNEY tab (ec.bd_tab 6). Run as player (on target from a nav/head click).
# SP5 owns the frame + buttons; SP4's journey/* owns the content (assign + send + timers). This tab
# surfaces the two sub slots (A/B) with their assigned companion + in-flight status, a 5-theme picker,
# and a per-slot Send. Drives journey/assign + ec.journey_type + ec.journey_send (SP4 contracts).

scoreboard players operation #Search companion.id = @s companion.id

# Kill the home view / prior tab content.
execute as @e[type=item_display,tag=companion.homehead,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.homehead,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.headslot,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.home_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.home_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=item_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s

# Set the Journey tab + refresh the 3-slot loadout (so assigned subs render).
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players set @s ec.bd_tab 6
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run function evercraft:companions/journey/sync_three

# Render.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] at @s facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet run function evercraft:companions/handler/menu_v2/journey/render

# Session-stamp.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

playsound minecraft:block.note_block.hat master @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.6
