# Companion Schedule Timer — Long timers (60s self-schedule)
# OPT: Moved from 1s timer — these only fire once per hour/day, no need to check every second

schedule function evercraft:companions/handler/schedule/timer_slow 60s

# R2: mid-session orphan-label sweep (60s). orphan_sweep was reload-only — a player who died far
# away, kept a home pet, and never re-summoned kept a stuck "❤ 0/Y" ghost indefinitely (selector
# kills can't reach unloaded chunks). Run it here too, existence-gated so non-pet servers pay
# nothing. Must precede the active-pet early-return below: an orphan label can outlive its head
# with NO active pet, which is exactly the case this catches. Player-isolated post-R3 (ids >= 1).
execute if entity @e[type=text_display,tag=companion.hp_label,limit=1] run function evercraft:companions/health/orphan_sweep

# SP5 (E5): mid-session placed-head orphan sweep (60s). Reaps a PC.Head / PC.Interact whose parent
# PlacedCompanion chicken no longer exists (e.g. the chicken was killed without its passenger/interaction).
# Existence-gated so non-placed servers pay nothing. Mirrors the hp_label sweep above.
execute if entity @e[type=item_display,tag=PC.Head,limit=1] run function evercraft:companions/handler/placed/orphan_sweep
execute if entity @e[type=interaction,tag=PC.Interact,limit=1] run function evercraft:companions/handler/placed/orphan_sweep

# Gate: skip if no active pets
execute unless entity @a[tag=companion.activepet] unless entity @e[type=item_display,tag=Companion,limit=1] run return 0

# Convert gametime to seconds (÷20)
execute store result score #cst_sec companion.calc run time query gametime
scoreboard players operation #cst_sec companion.calc /= #20 companion.calc

# 1h (3600s)
scoreboard players set #ct_div companion.calc 3600
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #ct_div companion.calc
execute if score #cst_mod companion.calc matches 0 run function evercraft:companions/handler/schedule/1h

# 12h (43200s)
scoreboard players set #ct_div companion.calc 43200
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #ct_div companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/12h

# 18h (64800s)
scoreboard players set #ct_div companion.calc 64800
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #ct_div companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/18h

# 1d (86400s)
scoreboard players set #ct_div companion.calc 86400
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #ct_div companion.calc
execute if score #cst_mod companion.calc matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/handler/schedule/1d

# 3d (259200s)
scoreboard players set #ct_div companion.calc 259200
scoreboard players operation #cst_mod companion.calc = #cst_sec companion.calc
scoreboard players operation #cst_mod companion.calc %= #ct_div companion.calc
execute if score #cst_mod companion.calc matches 0 run function evercraft:companions/handler/schedule/3d
