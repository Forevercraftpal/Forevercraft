# Remove relationship multiplier
attribute @s attack_damage modifier remove evercraft:companions/relationship_bonus

attribute @s knockback_resistance base reset
attribute @s safe_fall_distance base reset
attribute @s jump_strength base reset
attribute @s oxygen_bonus base reset
attribute @s attack_damage base reset
attribute @s fall_damage_multiplier base reset
attribute @s sneaking_speed base reset
attribute @s water_movement_efficiency base reset
attribute @s mining_efficiency base reset
attribute @s movement_speed base reset
attribute @s sweeping_damage_ratio base reset
attribute @s step_height base reset
attribute @s entity_interaction_range base reset
attribute @s max_health base reset
attribute @s scale base reset
attribute @s luck base reset
attribute @s attack_speed base reset
attribute @s attack_knockback base reset
attribute @s explosion_knockback_resistance base reset
tag @s remove companion.freezeimmune
attribute @s block_interaction_range base reset
attribute @s armor base reset
attribute @s armor_toughness base reset
attribute @s gravity base reset
attribute @s submerged_mining_speed base reset

effect clear @s absorption
effect clear @s night_vision
effect clear @s dolphins_grace
effect clear @s fire_resistance
effect clear @s resistance
effect clear @s water_breathing
effect clear @s conduit_power
effect clear @s slow_falling
effect clear @s haste
effect clear @s invisibility
effect clear @s speed
effect clear @s strength
effect clear @s regeneration
effect clear @s jump_boost

# Reset Panther evasion bonus (stored in companion.temp, variable by level)
execute if entity @s[tag=companion.panther] run scoreboard players operation @s adv.evasion -= @s companion.temp
execute if entity @s[tag=companion.panther] run scoreboard players set @s companion.temp 0

tag @s remove companion.endwalker
tag @s remove companion.zephyr
tag @s remove companion.claude
tag @s remove companion.prowler
tag @s remove companion.cindershell
tag @s remove companion.juggernaut
tag @s remove companion.frostweaver
tag @s remove companion.emberheart
tag @s remove companion.bramble
tag @s remove companion.wraith
tag @s remove companion.ashborn
tag @s remove companion.sentinel
tag @s remove companion.golden_dragon
tag @s remove companion.void_walker
tag @s remove companion.time_weaver
tag @s remove companion.wither
tag @s remove companion.snow_fox_spirit
tag @s remove companion.spirit_wolf

# New Pets (Session 33)
tag @s remove companion.duck
tag @s remove companion.chick
tag @s remove companion.mushroom
tag @s remove companion.baby_potato
tag @s remove companion.rascal
tag @s remove companion.sporeblossom
tag @s remove companion.camel
tag @s remove companion.blaze
tag @s remove companion.piglin
tag @s remove companion.zoglin
tag @s remove companion.wooly_cow
tag @s remove companion.mossy_skeleton
tag @s remove companion.creeper
tag @s remove companion.enderman
tag @s remove companion.monkey
tag @s remove companion.hoglin
tag @s remove companion.mule
tag @s remove companion.frozen_zombie
tag @s remove companion.mossy_zombie
tag @s remove companion.knight
tag @s remove companion.panther
tag @s remove companion.giraffe
tag @s remove companion.koala
tag @s remove companion.skeleton_horse
tag @s remove companion.arctic_fox
tag @s remove companion.vex
tag @s remove companion.deloris
tag @s remove companion.moobloom
tag @s remove companion.infernus
tag @s remove companion.voidshade
tag @s remove companion.stormcaller
tag @s remove companion.grovekeeper
tag @s remove companion.crystalheart
tag @s remove companion.alien
tag @s remove companion.snowman
tag @s remove companion.regal_tiger
tag @s remove companion.butterfly
tag @s remove companion.red_panda
tag @s remove companion.cow_of_eden

# Existing pets that were missing
tag @s remove companion.allay
tag @s remove companion.armadillo
tag @s remove companion.bee
tag @s remove companion.breeze
tag @s remove companion.copper_golem
tag @s remove companion.cow
tag @s remove companion.creaking
tag @s remove companion.ender_dragon
tag @s remove companion.evoker
tag @s remove companion.fox
tag @s remove companion.frog
tag @s remove companion.goat
tag @s remove companion.iron_golem
tag @s remove companion.leviathan
tag @s remove companion.llama
tag @s remove companion.mooshroom
tag @s remove companion.ocelot
tag @s remove companion.pig
tag @s remove companion.polar_bear
tag @s remove companion.ravager
tag @s remove companion.silverfish
tag @s remove companion.sniffer
tag @s remove companion.squid
tag @s remove companion.strider
tag @s remove companion.wolf

# New ability tags
tag @s remove companion.pixie
tag @s remove companion.titan
tag @s remove companion.oracle
tag @s remove companion.bulwark
tag @s remove companion.glider
tag @s remove companion.grasshopper
tag @s remove companion.naiad
tag @s remove companion.moldwarp
tag @s remove companion.shade
tag @s remove companion.abyssal
tag @s remove companion.sabertooth

# Clean up Claude ore markers
kill @e[type=armor_stand, tag=companion.oremarker]

team leave @s

weather clear