# SP8 — Wayfarer Track: spawn one cell's text + click hitbox at the resolved offset. Run as player.
# Macro args: {dx:"X", yy:"Y", node:N, icon:"...", color:"...", label:"..."} (from storage wf).
# The cell text = "<icon> Node N" (top) with the reward label beneath; one clickable interaction tagged
# companion.wf_cell_click stamped companion.wf_clicknode = node. Positioned ^dx ^yy ^1.74 from the menu
# facing-anchor (set up by render via `at @s facing entity ... feet`).
$execute rotated ~ 0 positioned ^$(dx) ^$(yy) ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.wf_cell"],billboard:"center",text:[{text:"$(icon) ",color:"$(color)",italic:false},{text:"#$(node)",color:"white",italic:false},{text:"\n$(label)",color:"gray",italic:false}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.165f,0.165f,0.165f]}}
# Spawn the hitbox with a transient wf_new tag so we can isolate + stamp exactly THIS cell (cells are
# 0.44 apart, so a distance filter would catch neighbours — the unique tag is the reliable isolator).
$execute rotated ~ 0 positioned ^$(dx) ^$(yy) ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.wf_cell_click","companion.wf_new"],width:0.40f,height:0.32f,response:1b}
# Stamp id on the cell text (id-uniform, so catching neighbours is fine) + node number on the
# uniquely-tagged hitbox. distance=..5 (NOT ..2): a top-row outer cell sits ~2.34 blocks from the
# player's feet (√(0.88²+1.30²+1.74²)), so ..2 missed it → it never got companion.id → go_back's
# check_id-filtered kill skipped it → cells floated after leaving the page. ..5 matches render's sibling stamps.
scoreboard players operation @e[type=text_display,tag=companion.wf_cell,distance=..5] companion.id = @s companion.id
$execute as @e[type=interaction,tag=companion.wf_new] run scoreboard players set @s companion.wf_clicknode $(node)
execute as @e[type=interaction,tag=companion.wf_new] run scoreboard players operation @s companion.id = #Search companion.id
tag @e[type=interaction,tag=companion.wf_new] remove companion.wf_new
