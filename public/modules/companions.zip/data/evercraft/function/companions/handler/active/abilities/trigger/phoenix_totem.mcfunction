execute store result score #totems companion.calc run clear @a[tag=companion.timerowner] totem_of_undying 0
execute if score #totems companion.calc matches 1 run return fail

tellraw @a[tag=companion.timerowner] {text:"Your Emberheart has granted you with a Totem of Undying.", color:"dark_red"}
give @a[tag=companion.timerowner] totem_of_undying 1
# Achievement tracking
scoreboard players add @s ach.comp_abilities 1
