# SP5 — Home view: spawn SUB-RIGHT floating head (three.sub[1]). headidx 2. Smaller, behind+right.
# Run as player. Requires care.head = sub B stored Pets[] item. Tagged companion.homehead + menuelement.

execute rotated ~ 0 positioned ^ ^1.75 ^1.80 positioned ^-0.62 ^0 ^0 run summon item_display ~ ~ ~ {Tags:["companion.homehead","companion.menuelement","companion.tab_content","companion.homesubr"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.22f,0.22f,0.22f]}}
data modify entity @n[type=item_display,tag=companion.homesubr,distance=..5] item set from storage evercraft:companions care.head

execute rotated ~ 0 positioned ^ ^1.57 ^1.82 positioned ^-0.62 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.homehead","companion.menuelement","companion.tab_content","companion.homesubrname"],billboard:"center",background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}
data modify entity @n[type=text_display,tag=companion.homesubrname,distance=..5] text set from storage evercraft:companions care.head.components."minecraft:custom_name"

execute rotated ~ 0 positioned ^ ^1.68 ^1.78 positioned ^-0.62 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.headslot","companion.menuelement","companion.tab_content","companion.homesubrclick"],width:0.22f,height:0.22f,response:1b}
scoreboard players set @n[type=interaction,tag=companion.homesubrclick,distance=..5] companion.headidx 2

tag @e[type=item_display,tag=companion.homesubr,distance=..5] remove companion.homesubr
tag @e[type=text_display,tag=companion.homesubrname,distance=..5] remove companion.homesubrname
tag @e[type=interaction,tag=companion.homesubrclick,distance=..5] remove companion.homesubrclick
