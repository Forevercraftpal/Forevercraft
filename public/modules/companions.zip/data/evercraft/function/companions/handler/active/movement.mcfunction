# Active Companion Movement — Wolf-based
# Wolf AI handles following + wandering. We just sync the interaction entity.
# Run as the item_display (Companion) entity — rides as wolf passenger

# Find our wolf base and sync interaction entity to wolf position
execute as @e[type=wolf, tag=CompanionWolf, predicate=evercraft:companions/check_id, limit=1] at @s run tp @e[type=interaction, tag=companion.petinteract, predicate=evercraft:companions/check_id, limit=1] ~ ~0.5 ~

# Prevent wolf from sitting (right-click on wolf makes it sit — reset every tick)
execute as @e[type=wolf, tag=CompanionWolf, predicate=evercraft:companions/check_id, nbt={Sitting:1b}, limit=1] run data modify entity @s Sitting set value 0b
