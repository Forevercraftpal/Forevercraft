# Active Companion Movement — Floating Entity
# Run as the companion item_display entity (@s = companion)
# Player has companion.owner tag during ai.mcfunction execution

# Teleport companion to player's feet area.
# positioned ~ ~0.3 ~ shifts Y up 0.3 blocks (just above ground); rotated ~ 0 = owner yaw, level pitch.
# Local coords below are ^left ^up ^forward in that owner-frame.
# teleport_duration:5 on entity (set at summon) handles smooth interpolation — low value keeps the
#   RENDER near the true position so the interaction hitbox synced below stays under the visible pet.
# ID check prevents companion from following the wrong player in multiplayer.
#
# Where it floats depends on whether the owner is wielding a weapon (evercraft:companions/owner_holding_weapon
# = mainhand in #evercraft:combat_held: swords/axes/mace/trident/bow/crossbow):
#   ARMED   → tuck ~1.6 blocks DIRECTLY BEHIND the player so neither the pet nor its interaction hitbox
#             sits in the swing arc / under the crosshair during a fight (^0 ^0 ^-1.6).
#   UNARMED → original front-left escort that orbits the player as they turn — best for petting/feeding
#             (^-1 ^0 ^0.5).

# ARMED: tuck behind
execute at @a[tag=companion.owner, limit=1] positioned ~ ~0.3 ~ rotated ~ 0 if entity @p[tag=companion.owner, predicate=evercraft:companions/owner_holding_weapon] if score @p[tag=companion.owner] companion.id = #Search companion.id run tp @s ^0 ^0 ^-1.6

# UNARMED: front-left escort
execute at @a[tag=companion.owner, limit=1] positioned ~ ~0.3 ~ rotated ~ 0 unless entity @p[tag=companion.owner, predicate=evercraft:companions/owner_holding_weapon] if score @p[tag=companion.owner] companion.id = #Search companion.id run tp @s ^-1 ^0 ^0.5

# Sync interaction entity to companion's new position
execute at @s run tp @e[type=interaction, tag=companion.petinteract, predicate=evercraft:companions/check_id, limit=1] ~ ~ ~
