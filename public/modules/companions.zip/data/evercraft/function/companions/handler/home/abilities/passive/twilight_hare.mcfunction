# Twilight Hare Pet Passive Abilities (Exquisite — Gacha Exclusive)
# - Dusk Runner: Movement speed 0.11 -> 0.20
# - Twilight Dodge: Evasion (applied as luck bonus for DR system)
# - Fading Light: Luck 1.0 -> 5.0

tag @s add companion.twilight_hare

# Dusk Runner - Movement speed scaling (0.11 -> 0.20)
$execute if score #value companion.calc matches 1..10 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.11 add_value
$execute if score #value companion.calc matches 11..20 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.12 add_value
$execute if score #value companion.calc matches 21..30 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.13 add_value
$execute if score #value companion.calc matches 31..40 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.14 add_value
$execute if score #value companion.calc matches 41..50 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.15 add_value
$execute if score #value companion.calc matches 51..60 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.16 add_value
$execute if score #value companion.calc matches 61..70 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.17 add_value
$execute if score #value companion.calc matches 71..80 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.18 add_value
$execute if score #value companion.calc matches 81..90 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.19 add_value
$execute if score #value companion.calc matches 91..100 run attribute @s movement_speed modifier add evercraft:home/slot$(ability_slot)/speed 0.20 add_value

# Fading Light - Luck scaling (1.0 -> 5.0)
$execute if score #value companion.calc matches 1..10 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1 add_value
$execute if score #value companion.calc matches 11..20 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.444 add_value
$execute if score #value companion.calc matches 21..30 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.889 add_value
$execute if score #value companion.calc matches 31..40 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.333 add_value
$execute if score #value companion.calc matches 41..50 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.778 add_value
$execute if score #value companion.calc matches 51..60 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.222 add_value
$execute if score #value companion.calc matches 61..70 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.667 add_value
$execute if score #value companion.calc matches 71..80 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.111 add_value
$execute if score #value companion.calc matches 81..90 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.556 add_value
$execute if score #value companion.calc matches 91..100 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 5 add_value
