# Load pets from marker storage for the current page
# Called with @s = companion.marker at 0 -60 0
# Reads #PageToLoad companion.menu (1-based page number)
# Outputs: evercraft:companions MenuDisplay[] with up to 48 pets for current page

# Clear previous display data
data remove storage evercraft:companions MenuDisplay

# Compute start index: (page - 1) * 48
scoreboard players operation #page_start companion.menu = #PageToLoad companion.menu
scoreboard players remove #page_start companion.menu 1
scoreboard players operation #page_start companion.menu *= #48 companion.calc

# Load 48 slots (idx = start + 0 through start + 47)
# Each call appends one pet to MenuDisplay; missing indices are silently skipped
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc

scoreboard players add #page_start companion.menu 1
execute store result storage evercraft:companions page_calc.idx int 1 run scoreboard players get #page_start companion.menu
function evercraft:companions/handler/menu_v2/load_page_slot with storage evercraft:companions page_calc
