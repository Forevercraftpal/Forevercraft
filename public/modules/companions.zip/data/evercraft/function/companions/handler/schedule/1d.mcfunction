scoreboard players operation #Search companion.id = @s companion.id

# SP2 Bond & Care: once-per-in-game-day happiness tick — decay -8 (active pet only; stored pets never
# decay; Eternal Bond is immune), advance/reset the 7-day continuous-happy clock, and unlock the
# species-passive bonus at 7 days. Existence-gated inside (only runs with a live active head nearby).
function evercraft:companions/bond/happiness/tick

execute as @s[tag=companion.emberheart] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[9].extra[{text:"12"}] run return run function evercraft:companions/handler/active/abilities/trigger/phoenix_totem