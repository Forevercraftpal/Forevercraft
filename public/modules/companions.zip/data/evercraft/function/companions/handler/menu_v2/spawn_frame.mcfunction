# Spawn the menu frame/background
# Creates a semi-transparent dark background panel

# Background panel (using tinted glass item display)
# Sized to 4.0x2.5 to match Codex hub frame (hub-style navigation with larger content area)
summon item_display ~ ~ ~ {Tags:["companion.menubg","companion.menuelement"],billboard:"center",item:{id:"black_stained_glass_pane",count:1},item_display:"fixed",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,-0.02f],scale:[4.0f,2.5f,0.01f]}}
