# AUTO (render_page_label.mcfunction): data-modify text_display rows with {score} baked as macro args (26.1 fix, cat B).
# Invoked `with storage evercraft:scorebake bargs` from the parent.
$data modify entity @n[type=text_display,tag=companion.wf_pagelabel,distance=..5] text set value [{text:"Page ",color:"gray"},{text:"$(v1)",color:"gray"},{text:" / ",color:"gray"},{text:"$(v2)",color:"gray"}]
