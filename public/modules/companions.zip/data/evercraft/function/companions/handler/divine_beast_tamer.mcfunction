# Challenge-complete brag names the owner (@p) → direct render in the owner's context (§5b).
execute as @p[tag=companion.owner, limit=1] run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has completed the challenge ",color:"white"},{text:"Divine Beast Tamer",color:"gold"},{text:"!",color:"white"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @p[tag=companion.owner, limit=1] run execute as @a run scoreboard players set #nttl ec.temp 600
execute as @p[tag=companion.owner, limit=1] run execute as @a run function evercraft:util/notify/emit_keep