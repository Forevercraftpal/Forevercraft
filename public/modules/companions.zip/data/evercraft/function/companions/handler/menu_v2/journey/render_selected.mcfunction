# SP5 — Journey: write the "Selected: <slot> · Theme: <theme>" indicator. Run as player.
# Shows which sub Send will dispatch (companion.jrnyslot 1=A / 2=B, default A) and the picked theme
# (ec.journey_type 1-5, default Wandering). The jr_sel text_display was already spawned by render.

# Slot label.
data modify storage evercraft:companions journey.sellabel set value "Slot A"
execute if score @s companion.jrnyslot matches 2 run data modify storage evercraft:companions journey.sellabel set value "Slot B"

# Theme label (resolve via the SP4 theme_name table is overkill here — inline the 5 names).
data modify storage evercraft:companions journey.seltheme set value "Wandering Trek"
execute if score @s ec.journey_type matches 1 run data modify storage evercraft:companions journey.seltheme set value "Forge Run"
execute if score @s ec.journey_type matches 2 run data modify storage evercraft:companions journey.seltheme set value "Forage Trek"
execute if score @s ec.journey_type matches 3 run data modify storage evercraft:companions journey.seltheme set value "Deep Delve"
execute if score @s ec.journey_type matches 4 run data modify storage evercraft:companions journey.seltheme set value "Tide Run"
execute if score @s ec.journey_type matches 5 run data modify storage evercraft:companions journey.seltheme set value "Wandering Trek"

function evercraft:companions/handler/menu_v2/journey/render_selected_text with storage evercraft:companions journey
