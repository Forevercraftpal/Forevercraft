# ============================================================
# Home Companion — Sync RP from entity back to marker storage
# Run as: HomeCompanion item_display entity
# Copies current relationship value from entity's item NBT
# back to both HomePets[] and Pets[] on the marker
# ============================================================

# Read current RP from entity's item profile properties
data modify storage evercraft:companions home.sync_rp set from entity @s item.components."minecraft:profile".properties[{name:"relationship"}].value

# Read the companion name for matching
data modify storage evercraft:companions home.sync_name set from entity @s item.components."minecraft:profile".properties[{name:"name"}].value

# Read the full item data to update HomePets[] entry
data modify storage evercraft:companions home.sync_item set from entity @s item

# Update the HomePets[] entry — find by slot
execute store result score #hc_sync_slot hc.slot run scoreboard players get @s hc.slot

# We need to find the HomePets entry with matching slot and update its item data
# This is done via the filter/rebuild approach
scoreboard players operation #Search companion.id = @s companion.id
function evercraft:companions/handler/home/sync_rp_update
