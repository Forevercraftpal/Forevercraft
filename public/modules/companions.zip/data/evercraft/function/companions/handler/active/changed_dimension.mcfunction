advancement revoke @s only evercraft:companions/changed_dimension
execute if data storage evercraft:companions uninstalled run return fail

scoreboard players operation #Search companion.id = @s companion.id
tp @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id] @s