# SP5 — Care: Call the focused companion. Run as player (on target from click_care).
# A single toggle (Joseph's spec), reusing the two canonical functions:
#   focused == active MAIN → dismiss (do_unsummon).
#   focused != main        → bring it to MAIN (spawn_selected_companion), which saves+syncs the previous
#                            main, kills the old trio, and summons the new one. three.* updates via the
#                            sync_three call inside spawn_selected_companion's close→reopen path (next open).
#
# spawn_selected_companion takes a PAGE-RELATIVE slot + reads companion.menupage + MenuDisplay[slot], so
# we convert the absolute careidx → page + relative slot, set the page, load that page's MenuDisplay, then
# call it. This is the same coordinate math used everywhere (abs = (page-1)*48 + slot).

# Dismiss if the focus IS the live MAIN.
execute if score #cc_is_main ec.temp matches 1 run return run function evercraft:companions/handler/menu_v2/do_unsummon

# --- Bring the focused companion to MAIN ---
# page = floor(careidx / 48) + 1 ; relslot = careidx mod 48.
scoreboard players operation #cc_abs companion.menu = @s companion.careidx
scoreboard players operation #cc_page companion.menu = #cc_abs companion.menu
scoreboard players operation #cc_page companion.menu /= #48 companion.calc
scoreboard players add #cc_page companion.menu 1
scoreboard players operation #cc_rel companion.menu = #cc_abs companion.menu
scoreboard players operation #cc_rel companion.menu %= #48 companion.calc

# Point the menu at that page + load its MenuDisplay so spawn_selected_companion can read the slot.
scoreboard players operation @s companion.menupage = #cc_page companion.menu
scoreboard players operation #PageToLoad companion.menu = #cc_page companion.menu
execute in overworld positioned 0 -60 0 as @n[distance=..10,type=marker,tag=companion.marker,predicate=evercraft:companions/check_id] run function evercraft:companions/handler/menu_v2/load_companions

# Summon as MAIN via the canonical path (it closes the menu on success).
execute store result storage evercraft:companions care.relslot int 1 run scoreboard players get #cc_rel companion.menu
function evercraft:companions/handler/menu_v2/care/call_spawn with storage evercraft:companions care
