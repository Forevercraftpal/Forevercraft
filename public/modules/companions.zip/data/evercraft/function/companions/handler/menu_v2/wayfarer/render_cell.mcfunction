# SP8 — Wayfarer Track: render one node cell. Run as player. Macro: {col:0-4, row:0-1}.
# Reads #wf_cell companion.menu (the 1-based node number). State:
#   CLAIMED   (bit set in ec.wf_claimed)      → green ✔, not clickable.
#   CLAIMABLE (unlocked + not claimed)        → glowing gold ★, clickable → track/claim.
#   LOCKED    (ec.wf_node < node)             → dim 🔒, not clickable.
# col 0..4 → X +0.88/+0.44/0/-0.44/-0.88 ; row 0/1 → Y 1.30/0.92. (5x2 grid, 10 cells/page.)

# Guard: only render nodes that exist (1..250). On the last page some cells are beyond node_max.
execute unless score #wf_cell companion.menu matches 1..250 run return 0

# --- Classify via the per-player claimed advancement + the unlock score. ---
# CLAIMED (state 2) = advancement claimed/n<node> granted. CLAIMABLE (state 1) = unlocked + not claimed.
execute store result storage evercraft:companions wfm.tnode int 1 run scoreboard players get #wf_cell companion.menu
scoreboard players set #wf_state ec.temp 0
function evercraft:companions/handler/menu_v2/wayfarer/cell_claimed_macro with storage evercraft:companions wfm
# unlocked (and not claimed) → claimable (state 1).
execute if score #wf_state ec.temp matches 0 if score @s ec.wf_node >= #wf_cell companion.menu run scoreboard players set #wf_state ec.temp 1

# --- Icon + color by state. ---
data modify storage evercraft:companions wf.icon set value "🔒"
data modify storage evercraft:companions wf.color set value "dark_gray"
execute if score #wf_state ec.temp matches 1 run data modify storage evercraft:companions wf.icon set value "★"
execute if score #wf_state ec.temp matches 1 run data modify storage evercraft:companions wf.color set value "gold"
execute if score #wf_state ec.temp matches 2 run data modify storage evercraft:companions wf.icon set value "✔"
execute if score #wf_state ec.temp matches 2 run data modify storage evercraft:companions wf.color set value "green"

# --- Reward label from the table (index = node-1). ---
scoreboard players operation #wf_ridx companion.menu = #wf_cell companion.menu
scoreboard players remove #wf_ridx companion.menu 1
execute store result storage evercraft:companions wf.ridx int 1 run scoreboard players get #wf_ridx companion.menu
data modify storage evercraft:companions wf.label set value ""
function evercraft:companions/handler/menu_v2/wayfarer/read_label with storage evercraft:companions wf

# --- Node number for the label. ---
execute store result storage evercraft:companions wf.node int 1 run scoreboard players get #wf_cell companion.menu

# --- Spawn the cell (icon + node# + reward label) + a click hitbox stamped with the node number. ---
$data modify storage evercraft:companions wf.col set value $(col)
$data modify storage evercraft:companions wf.row set value $(row)
function evercraft:companions/handler/menu_v2/wayfarer/place_cell
