# Process feeding - called with macro {rp:N, cd:N, food:"type"}
# Run as player who is feeding

$scoreboard players set #feedRP companion.calc $(rp)
# ONE-WRITER (R9): feedcd is SET here on a successful active-pet feed; decremented in
# handler/active/ai (active) + home/tick (home-only, disjoint). do_treat sets it too, also on
# an active-pet feed path — same disjoint context, not a concurrent second writer.
$scoreboard players set @s companion.feedcd $(cd)

# Check for favorite food bonus (2x RP)
function evercraft:companions/handler/relationship/feed/check_favorite

# Load current RP
function evercraft:companions/handler/relationship/load_rp

# Store old level for comparison
scoreboard players operation #oldLevel companion.calc = @s companion.rellevel

# Apply memory bonus to RP gain (modifies #feedRP if 5+ memories)
function evercraft:companions/memories/apply_bonus

# Add RP
scoreboard players operation @s companion.rp += #feedRP companion.calc

# Cap at 5000
execute if score @s companion.rp > #5000 companion.calc run scoreboard players set @s companion.rp 5000

# Save new RP
function evercraft:companions/handler/relationship/save_rp

# Recalculate level
function evercraft:companions/handler/relationship/load_rp

# Consume 1 of the food item
item modify entity @s weapon.mainhand evercraft:companions/consume_one

# Play effects (sanctioned affection vocal — KEEP + GATE).
execute if score @s ec.fx_snd matches 1.. at @s run playsound minecraft:entity.generic.eat master @s ~ ~ ~ 1 1
scoreboard players operation #Search companion.id = @s companion.id
execute at @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] run particle heart ~ ~0.5 ~ 0.3 0.3 0.3 0 3

# Show message
$data modify storage evercraft:notify stage.c set value [{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" really enjoyed the treat! ",color:"green"},{text:"(+$(rp) RP)",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Check for level up
execute unless score @s companion.rellevel = #oldLevel companion.calc run function evercraft:companions/handler/relationship/level_up

# Heal companion HP (uses #feedRP companion.calc)
function evercraft:companions/health/feed_heal

# SP2 Bond & Care: feeding tops up happiness +50 (anti-chore upkeep — one Pet + one Feed = full).
# Routed through the single happiness writer (bond/happiness/add). NOTE: this runs AFTER feed_heal,
# which uses #feedRP companion.calc — bond/happiness/add reloads state and doesn't touch #feedRP, so
# the order is safe; placed here so the +50 lands on every successful feed.
function evercraft:companions/bond/happiness/add {amount:50}

# Achievement tracking
scoreboard players add @s ach.comp_feeds 1
