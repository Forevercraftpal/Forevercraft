# ============================================================
# Raycast — Find placed companion head (max 16 blocks, 80 steps at 0.2)
# Run anchored eyes from add_to_db
# ============================================================
scoreboard players add #comp_ray companion.calc 1

# Check for player_head (floor) or player_wall_head (wall) at current position
execute if block ~ ~ ~ minecraft:player_head run function evercraft:companions/handler/database/found_companion_head
execute unless score #comp_found companion.calc matches 1 if block ~ ~ ~ minecraft:player_wall_head run function evercraft:companions/handler/database/found_companion_head

# Continue raycast if not found and under limit
execute if score #comp_ray companion.calc matches ..80 unless score #comp_found companion.calc matches 1 positioned ^ ^ ^0.2 run function evercraft:companions/handler/database/raycast_companion
