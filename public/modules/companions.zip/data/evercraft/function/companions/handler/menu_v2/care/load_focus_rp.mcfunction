# SP5 — Load the Care-focused companion's RP + bond level from its STORED Pets[] record (data-side).
# Run as player. Requires care.head = the focused companion's stored item (snapshot by care/render).
# Sets: companion.rp, companion.rellevel on the player (read-only render — does NOT write the record).
# Mirrors load_rp:11-22 / home/interact/load_rp but reads care.head (storage) instead of a live entity,
# so it works for ANY owned companion (main, sub, off-roster) without summoning it.

# Read the relationship value string from the snapshot (absent → treated as 0 RP).
scoreboard players set #value companion.calc 0
data modify storage evercraft:companions math.string set value "0"
execute if data storage evercraft:companions care.head.components."minecraft:profile".properties[{name:"relationship"}] run data modify storage evercraft:companions math.string set string storage evercraft:companions care.head.components."minecraft:profile".properties[{name:"relationship"}].value
function evercraft:companions/handler/math/string_to_int
scoreboard players operation @s companion.rp = #value companion.calc

# Clamp 0..5000 (defensive).
execute if score @s companion.rp matches ..-1 run scoreboard players set @s companion.rp 0
execute if score @s companion.rp matches 5001.. run scoreboard players set @s companion.rp 5000

# Compute bond level 0-5 (same thresholds as load_rp:17-22).
scoreboard players set @s companion.rellevel 0
execute if score @s companion.rp >= #RelLvl1 companion.calc run scoreboard players set @s companion.rellevel 1
execute if score @s companion.rp >= #RelLvl2 companion.calc run scoreboard players set @s companion.rellevel 2
execute if score @s companion.rp >= #RelLvl3 companion.calc run scoreboard players set @s companion.rellevel 3
execute if score @s companion.rp >= #RelLvl4 companion.calc run scoreboard players set @s companion.rellevel 4
execute if score @s companion.rp >= #RelLvl5 companion.calc run scoreboard players set @s companion.rellevel 5
