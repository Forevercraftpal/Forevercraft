# ============================================================
# Home Companion — Filter HomePets entry during removal
# Macro: {idx} — index into temp_pets[] to check
# Re-appends to HomePets[] if slot doesn't match the removal target
# ============================================================

# Read this entry's slot
$execute store result score #hc_check_slot hc.slot run data get storage evercraft:companions home.temp_pets[$(idx)].slot

# If slot doesn't match the one being removed, keep it
# (Split into two steps: copy to temp, then append — avoids entity selector in macro line)
$execute unless score #hc_check_slot hc.slot = #hc_remove_target hc.slot run data modify storage evercraft:companions home.keep_entry set from storage evercraft:companions home.temp_pets[$(idx)]
execute unless score #hc_check_slot hc.slot = #hc_remove_target hc.slot positioned 0 -60 0 run data modify entity @n[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id] data.HomePets append from storage evercraft:companions home.keep_entry

# If slot DOES match, save the item data for home flag clearing
$execute if score #hc_check_slot hc.slot = #hc_remove_target hc.slot run data modify storage evercraft:companions home.retrieve_item set from storage evercraft:companions home.temp_pets[$(idx)].item
