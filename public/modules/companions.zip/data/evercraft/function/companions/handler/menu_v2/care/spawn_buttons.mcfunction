# SP5 — Care: spawn the four action buttons (Pet · Feed · Call · Skills) in a CENTERED 2x2 grid,
# underneath the bond/progress bar (2026-06-06 — was a right-side column). Run as player, facing-anchor
# context from render. text_display + interaction trio each (spawn_hub style). All tagged
# companion.menuelement + companion.tab_content + a per-button click tag. Columns ^+0.42 / ^-0.42 (centered).

# --- Row top-left: Pet ---
execute rotated ~ 0 positioned ^ ^0.90 ^1.74 positioned ^0.42 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.care_btn","companion.care_pet_text"],billboard:"center",text:[{text:"✋ ",color:"yellow"},{text:"Pet",color:"green",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.34f,0.34f,0.34f]}}
execute rotated ~ 0 positioned ^ ^0.86 ^1.76 positioned ^0.42 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_btn","companion.care_pet_click"],width:0.34f,height:0.13f,response:1b}

# --- Row top-right: Feed ---
execute rotated ~ 0 positioned ^ ^0.90 ^1.74 positioned ^-0.42 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.care_btn","companion.care_feed_text"],billboard:"center",text:[{text:"🍖 ",color:"gold"},{text:"Feed",color:"gold",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.34f,0.34f,0.34f]}}
execute rotated ~ 0 positioned ^ ^0.86 ^1.76 positioned ^-0.42 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_btn","companion.care_feed_click"],width:0.34f,height:0.13f,response:1b}

# --- Row bottom-left: Call ---
execute rotated ~ 0 positioned ^ ^0.72 ^1.74 positioned ^0.42 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.care_btn","companion.care_call_text"],billboard:"center",text:[{text:"📣 ",color:"aqua"},{text:"Call",color:"aqua",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.34f,0.34f,0.34f]}}
execute rotated ~ 0 positioned ^ ^0.68 ^1.76 positioned ^0.42 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_btn","companion.care_call_click"],width:0.34f,height:0.13f,response:1b}

# --- Row bottom-right: Skills ---
execute rotated ~ 0 positioned ^ ^0.72 ^1.74 positioned ^-0.42 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.care_btn","companion.care_skills_text"],billboard:"center",text:[{text:"✦ ",color:"light_purple"},{text:"Skills",color:"light_purple",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.34f,0.34f,0.34f]}}
execute rotated ~ 0 positioned ^ ^0.68 ^1.76 positioned ^-0.42 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_btn","companion.care_skills_click"],width:0.34f,height:0.13f,response:1b}

# Stamp ids.
scoreboard players operation @e[type=text_display,tag=companion.care_btn,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.care_btn,distance=..5] companion.id = @s companion.id
