# Write synced relationship value to companion.marker at the correct slot index
# Run as: companion.marker entity at 0 -60 0
# Args: $(slot_index) from sync.slot_index; reads relationship value from sync.relationship
# Called via: function ... with storage evercraft:companions sync
$data modify entity @s data.Pets[$(slot_index)].components."minecraft:profile".properties[{name:"relationship"}].value set from storage evercraft:companions sync.relationship
