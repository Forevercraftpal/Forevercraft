# Try custom_data match first (new format — immune to profile resolution)
$execute in overworld store result score #rm_ok companion.calc run data remove entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:custom_data":{pet_name:"$(name)"}}}]

# Fallback to profile match (old format / backward compat for pets added before this fix)
$execute if score #rm_ok companion.calc matches 0 in overworld run data remove entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:profile":{properties:[{},{value:"$(name)"}]}}}]

scoreboard players remove @s companion.count 1
