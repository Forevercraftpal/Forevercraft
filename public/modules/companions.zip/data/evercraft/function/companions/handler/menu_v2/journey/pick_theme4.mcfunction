# SP5 — Journey: pick the Tide theme. Run as player. Sets ec.journey_type (SP4 contract) + refresh.
scoreboard players set @s ec.journey_type 4
function evercraft:companions/handler/menu_v2/journey/refresh
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.4 1.8
