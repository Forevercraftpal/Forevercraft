# SP5 — Journey: macro — write the selected-slot/theme indicator. Args: {sellabel:"...", seltheme:"..."}.
$data modify entity @n[type=text_display,tag=companion.jr_sel,distance=..5] text set value [{text:"Send → ",color:"gray"},{text:"$(sellabel)",color:"gold"},{text:"  ·  Theme: ",color:"gray"},{text:"$(seltheme)",color:"aqua"}]
