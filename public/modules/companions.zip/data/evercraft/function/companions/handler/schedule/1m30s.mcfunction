scoreboard players operation #Search companion.id = @s companion.id

# Regal Tiger "Territorial Roar" (90s): nearby hostiles get Weakness II + small knockback.
execute as @s[tag=companion.regal_tiger] at @s run function evercraft:companions/handler/active/abilities/trigger/regal_tiger_roar

execute as @s[tag=companion.endwalker] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[9].extra[{text:"90"}] run return run function evercraft:companions/handler/active/abilities/trigger/blue_dragon

execute as @s[tag=companion.ashborn] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[9].extra[{text:"90"}] run return run function evercraft:companions/handler/active/abilities/trigger/red_dragon