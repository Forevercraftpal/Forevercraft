# OPT: Consolidated pet slot right-click handler
# Runs as: clicked interaction entity (companion.petclick with interaction data)
# Reads slot score, writes to storage, dispatches via macro

# Store slot index to storage for macro call
execute store result storage evercraft:companions click.slot int 1 run scoreboard players get @s companion.slot

# Dispatch to select_companion with slot as macro arg (it clears interaction data internally)
function evercraft:companions/handler/menu_v2/select_companion with storage evercraft:companions click
