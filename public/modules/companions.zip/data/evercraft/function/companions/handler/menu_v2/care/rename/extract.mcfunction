# SP5 — Rename: extract the signed name + apply it to the REAL persistent Pets[] record. Run as @s =
# the player who just signed the Companion Charter. Clone of buddy/naming/extract_name +
# housing/slot/rename/extract. The name lands on the STORED item (both custom_name + custom_data.pet_name)
# so a renamed companion KEEPS its name when later removed from the collection (Joseph's exact ask).

# Revoke for re-fire.
advancement revoke @s only evercraft:companions/signed_charter

# Verify the player is in the rename flow (latch from rename/start).
execute unless score @s ec.cc_renaming matches 1 run return fail

# Verify a signed Companion Charter is actually held (SelectedItem = the signed book).
execute unless data entity @s SelectedItem.components."minecraft:custom_data".companion_charter run return fail

# Read the target Pets[] index from the book's custom_data (carried across the sign round-trip).
execute store result score #cc_rename_idx companion.menu run data get entity @s SelectedItem.components."minecraft:custom_data".companion_idx

# Read page-1 raw text into rn.name (reset first so a missing/empty page resolves to "" and is caught).
data modify storage evercraft:companions rn.name set value ""
data modify storage evercraft:companions rn.name set from entity @s SelectedItem.components."minecraft:written_book_content".pages[0].raw

# Guard: a blank name would un-name the companion — refuse, leave the book so the player can re-sign.
data modify storage evercraft:notify stage.c set value [{text:"Write a name on page 1, then sign the charter.",color:"red"}]
scoreboard players set #ndur ec.temp 50
execute if data storage evercraft:companions {rn:{name:""}} run return run function evercraft:util/notify/emit

# Consume the charter.
clear @s minecraft:written_book[custom_data~{companion_charter:1b}] 1

# Clear the latch.
scoreboard players set @s ec.cc_renaming 0

# Apply the name to the stored Pets[] record (both name fields).
scoreboard players operation #Search companion.id = @s companion.id
execute store result storage evercraft:companions rn.idx int 1 run scoreboard players get #cc_rename_idx companion.menu
function evercraft:companions/handler/menu_v2/care/rename/apply with storage evercraft:companions rn

# If the renamed companion is the live MAIN, update its head CustomName immediately (no re-summon needed).
execute if entity @s[tag=companion.activepet] if score @s companion.activeslot = #cc_rename_idx companion.menu run function evercraft:companions/handler/menu_v2/care/rename/apply_live with storage evercraft:companions rn

# NOTE: a companion that is currently PLACED (home HC.Head or placed PC.Head) carries home:1b / is out of
# the roster-render path, so it cannot be the live MAIN renamed above. The stored Pets[] record IS updated,
# so the head shows the new name on its next retrieve/re-place. Live placed-head rename is a cosmetic gap
# (the head's floating name lags until pick-up) — deferred, not load-bearing.

# Feedback (gated bespoke amethyst rename touch).
function evercraft:companions/handler/menu_v2/care/rename/feedback with storage evercraft:companions rn
scoreboard players set #rename_mode ec.temp 0
execute at @s run function evercraft:fx/companion/rename
