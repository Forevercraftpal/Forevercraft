# SP5 — Home view: the 3 bottom nav buttons. Run as player, position context from open/spawn_home.
# Center "Companions" → the full roster grid (tab 1; 2026-06-06 — the hub now sits ABOVE the home view,
# so this nav drills down into the all-pets grid). Left "Journey" → Journey tab. Right "Care" → Care tab.

# === Center: Companions (gold) — opens the full roster grid ===
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.home_btn","companion.home_companions_text","companion.menuelement","companion.tab_content"],billboard:"center",text:[{text:"🐾 ",color:"yellow"},{text:"Companions",color:"gold",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.501f,0.501f,0.501f]}}
# [strip] ?: 0.45w split into 3 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.15 ^0.87 ^1.78 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_companions_click","companion.menuelement","companion.tab_content"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0 ^0.87 ^1.78 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_companions_click","companion.menuelement","companion.tab_content"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.15 ^0.87 ^1.78 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_companions_click","companion.menuelement","companion.tab_content"],width:0.15f,height:0.15f,response:1b}

# === Left: Journey (aqua) ===
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^0.78 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.home_btn","companion.home_journey_text","companion.menuelement","companion.tab_content"],billboard:"center",text:[{text:"🧭 ",color:"aqua"},{text:"Journey",color:"aqua",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
# [strip] ?: 0.4w split into 3 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.125 ^0.87 ^1.78 positioned ^0.78 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_journey_click","companion.menuelement","companion.tab_content"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0 ^0.87 ^1.78 positioned ^0.78 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_journey_click","companion.menuelement","companion.tab_content"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.125 ^0.87 ^1.78 positioned ^0.78 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_journey_click","companion.menuelement","companion.tab_content"],width:0.15f,height:0.15f,response:1b}

# === Right: Care (red) ===
execute rotated ~ 0 positioned ^ ^0.95 ^1.76 positioned ^-0.78 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.home_btn","companion.home_care_text","companion.menuelement","companion.tab_content"],billboard:"center",text:[{text:"❤ ",color:"red"},{text:"Care",color:"red",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
# [strip] ?: 0.4w split into 3 x 0.15 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.125 ^0.87 ^1.78 positioned ^-0.78 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_care_click","companion.menuelement","companion.tab_content"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0 ^0.87 ^1.78 positioned ^-0.78 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_care_click","companion.menuelement","companion.tab_content"],width:0.15f,height:0.15f,response:1b}
execute rotated ~ 0 positioned ^0.125 ^0.87 ^1.78 positioned ^-0.78 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_care_click","companion.menuelement","companion.tab_content"],width:0.15f,height:0.15f,response:1b}

# === Top banner: Wayfarer's Track (gold compass) — SP8. Sits ABOVE the locked Companions/Journey/Care
# trio so it doesn't disturb the DECISIONS-Batch-D layout. Opens the Wayfarer track view (tab 9). ===
execute rotated ~ 0 positioned ^ ^1.50 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.home_btn","companion.home_wayfarer_text","companion.menuelement","companion.tab_content"],billboard:"center",text:[{text:"🧭 ",color:"gold"},{text:"Wayfarer's Track",color:"gold",bold:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.42f,0.42f,0.42f]}}
# [strip] BUGFIX 2026-06-15 (Joseph: "makes a sound, doesn't nav"): the hitboxes were summoned at the
# text's Y (^1.50) with height 0.16, so their CENTER sat at 1.58 — a full half-box ABOVE the visible
# banner glyph (text center 1.50). Aiming at the banner missed them entirely, so the click never matched
# home_wayfarer_click (the "sound" was just the umbrella menuelement click-FX grazing a neighbour). Fix =
# the same "recenter hit on text_y - h/2" convention every other button uses: drop to ^1.41 (box
# [1.41,1.59], center 1.50) and widen to 5 x 0.22 cubes (span ~0.86) to cover the wide banner text.
# (interaction AABBs can't rotate + width is a square X/Z footprint.)
execute rotated ~ 0 positioned ^-0.32 ^1.41 ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_wayfarer_click","companion.menuelement","companion.tab_content"],width:0.22f,height:0.18f,response:1b}
execute rotated ~ 0 positioned ^-0.16 ^1.41 ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_wayfarer_click","companion.menuelement","companion.tab_content"],width:0.22f,height:0.18f,response:1b}
execute rotated ~ 0 positioned ^0 ^1.41 ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_wayfarer_click","companion.menuelement","companion.tab_content"],width:0.22f,height:0.18f,response:1b}
execute rotated ~ 0 positioned ^0.16 ^1.41 ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_wayfarer_click","companion.menuelement","companion.tab_content"],width:0.22f,height:0.18f,response:1b}
execute rotated ~ 0 positioned ^0.32 ^1.41 ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.home_btn","companion.home_wayfarer_click","companion.menuelement","companion.tab_content"],width:0.22f,height:0.18f,response:1b}

# Stamp ids on the nav buttons.
scoreboard players operation @e[type=text_display,tag=companion.home_btn,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.home_btn,distance=..5] companion.id = @s companion.id
