# Cow of Eden Pet Passive Abilities
# - Pastoral Dreams: Luck (0.5 → 3.0)
# - Effect: regeneration

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.cow_of_eden

effect give @s regeneration infinite 1 true

# Pastoral Dreams: Luck (0.5 → 3.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s luck base set 0.576
execute if score #value companion.calc matches 8..12 run return run attribute @s luck base set 0.727
execute if score #value companion.calc matches 13..17 run return run attribute @s luck base set 0.854
execute if score #value companion.calc matches 18..22 run return run attribute @s luck base set 0.98
execute if score #value companion.calc matches 23..27 run return run attribute @s luck base set 1.106
execute if score #value companion.calc matches 28..32 run return run attribute @s luck base set 1.232
execute if score #value companion.calc matches 33..37 run return run attribute @s luck base set 1.359
execute if score #value companion.calc matches 38..42 run return run attribute @s luck base set 1.485
execute if score #value companion.calc matches 43..47 run return run attribute @s luck base set 1.611
execute if score #value companion.calc matches 48..52 run return run attribute @s luck base set 1.737
execute if score #value companion.calc matches 53..57 run return run attribute @s luck base set 1.864
execute if score #value companion.calc matches 58..62 run return run attribute @s luck base set 1.99
execute if score #value companion.calc matches 63..67 run return run attribute @s luck base set 2.116
execute if score #value companion.calc matches 68..72 run return run attribute @s luck base set 2.242
execute if score #value companion.calc matches 73..77 run return run attribute @s luck base set 2.369
execute if score #value companion.calc matches 78..82 run return run attribute @s luck base set 2.495
execute if score #value companion.calc matches 83..87 run return run attribute @s luck base set 2.621
execute if score #value companion.calc matches 88..92 run return run attribute @s luck base set 2.747
execute if score #value companion.calc matches 93..97 run return run attribute @s luck base set 2.874
execute if score #value companion.calc matches 98..100 run return run attribute @s luck base set 2.975
