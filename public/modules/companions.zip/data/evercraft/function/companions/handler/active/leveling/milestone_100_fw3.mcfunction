# Pet Level 100 — Staggered firework 3 + cleanup
execute as @a[tag=ec.pet_milestone100] at @s run summon firework_rocket ~-1 ~ ~-1 {LifeTime:0,FireworkItem:{id:"firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"burst",colors:[I;16750848,65535],has_twinkle:1b,has_trail:1b}],flight_duration:2b}}}}
tag @a[tag=ec.pet_milestone100] remove ec.pet_milestone100
