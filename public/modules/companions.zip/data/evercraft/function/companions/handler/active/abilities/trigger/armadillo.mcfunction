# Armadillo - Curl Defense: On damage taken, chance to gain Resistance I for 3s
# Chance scales 10% → 30% with level

advancement revoke @s only evercraft:companions/abilities/armadillo
scoreboard players operation #Search companion.id = @s companion.id

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value

scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

execute if score #value companion.calc matches 1..7 if predicate {condition:"random_chance",chance:0.1} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 8..12 if predicate {condition:"random_chance",chance:0.111} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 13..17 if predicate {condition:"random_chance",chance:0.121} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 18..22 if predicate {condition:"random_chance",chance:0.132} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 23..27 if predicate {condition:"random_chance",chance:0.142} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 28..32 if predicate {condition:"random_chance",chance:0.153} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 33..37 if predicate {condition:"random_chance",chance:0.163} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 38..42 if predicate {condition:"random_chance",chance:0.174} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 43..47 if predicate {condition:"random_chance",chance:0.184} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 48..52 if predicate {condition:"random_chance",chance:0.195} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 53..57 if predicate {condition:"random_chance",chance:0.205} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 58..62 if predicate {condition:"random_chance",chance:0.216} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 63..67 if predicate {condition:"random_chance",chance:0.226} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 68..72 if predicate {condition:"random_chance",chance:0.237} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 73..77 if predicate {condition:"random_chance",chance:0.247} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 78..82 if predicate {condition:"random_chance",chance:0.258} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 83..87 if predicate {condition:"random_chance",chance:0.268} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 88..92 if predicate {condition:"random_chance",chance:0.279} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 93..97 if predicate {condition:"random_chance",chance:0.289} run effect give @s resistance 3 0 true
execute if score #value companion.calc matches 98..100 if predicate {condition:"random_chance",chance:0.3} run effect give @s resistance 3 0 true
