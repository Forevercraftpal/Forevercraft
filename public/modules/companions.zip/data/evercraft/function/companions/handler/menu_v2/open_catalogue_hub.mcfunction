# Open the catalogue hub (the Companions/Buddy/Summon/Training 4-button grid). ec.bd_tab 8.
# 2026-06-06: the hub is the LANDING again (open.mcfunction spawns it directly), so it is the ROOT and
# carries NO Back button — the menu closes on item-switch. This function now only runs from go_back when
# returning UP to the hub (from the home view 0, or Buddy/Summon/Training 2-4). go_back already reaps the
# prior screen, so the home-element kills below are defensive no-ops.

# Kill the home-view heads + nav (companion.homehead / companion.home_btn).
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=item_display,tag=companion.homehead,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.homehead,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.headslot,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.home_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.home_btn,predicate=evercraft:companions/check_id] run kill @s

# Set the catalogue-hub tab (find the real player — @s may be the dead nav interaction).
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players set @s ec.bd_tab 8

# Spawn the 4-button hub. No Back button — the hub is the root (closes on item-switch).
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] at @s facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet run function evercraft:companions/handler/menu_v2/spawn_hub

# Session-stamp the new hub buttons (mirror go_back:23-25).
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=companion.hub_btn,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=companion.hub_btn,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

playsound minecraft:block.note_block.hat master @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.6
