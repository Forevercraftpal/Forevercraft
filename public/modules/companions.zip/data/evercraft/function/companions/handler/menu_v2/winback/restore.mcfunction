# SP3 Win-back — RESTORE (the Notch-apple consume handler). Run as @s = player with companion.wb_pending,
# holding an enchanted_golden_apple, having clicked the departed slot a second time (gated in offer).
# Brings the companion home: consume the apple, clear the departed flag, restore RP to a floor (never 0),
# top happiness, reunion dialogue, refresh the grid, and auto-summon the returned companion.

scoreboard players operation #Search companion.id = @s companion.id

# --- Validate (belt-and-suspenders; offer already gated all three) ---
execute unless entity @s[tag=companion.wb_pending] run return fail
execute unless predicate evercraft:companions/winback/holding_notch_apple run return fail

# --- Consume exactly one Notch apple (handed over, not eaten — no food effects, no advancement) ---
clear @s minecraft:enchanted_golden_apple 1

# --- Compute the restored RP = max(#WINBACK_RP_FLOOR, lastRP), clamped 0..5000 (DECISIONS P22) ---
# Read the departed companion's still-durable last RP off its Pets[wb_slot] entry (Pattern B).
execute store result storage evercraft:companions winback.slot int 1 run scoreboard players get @s companion.wb_slot
execute in overworld positioned 0 -60 0 as @n[distance=..10,type=marker,tag=companion.marker,predicate=evercraft:companions/check_id] run function evercraft:companions/handler/menu_v2/winback/read_slot_rp with storage evercraft:companions winback
# #value companion.calc now = lastRP. Floor to RelLvl1 (500) so a decayed pet returns at least "Friend",
# while a once-Devoted pet keeps its higher RP.
execute if score #value companion.calc < #WINBACK_RP_FLOOR companion.calc run scoreboard players operation #value companion.calc = #WINBACK_RP_FLOOR companion.calc
execute if score #value companion.calc > #5000 companion.calc run scoreboard players operation #value companion.calc = #5000 companion.calc
# Stage the RP string for the macro write (int → NBT string in math.string).
function evercraft:companions/handler/math/int_to_string
data modify storage evercraft:companions winback.rp set from storage evercraft:companions math.string
# Top happiness back to full so the returned pet is not immediately Forlorn again.
scoreboard players operation #value companion.calc = #HAPPY_FULL ec.const
function evercraft:companions/handler/math/int_to_string
data modify storage evercraft:companions winback.happy set from storage evercraft:companions math.string

# --- Write the restored state onto Pets[wb_slot]: clear departed + RP + happiness, all same slot ---
execute in overworld positioned 0 -60 0 as @n[distance=..10,type=marker,tag=companion.marker,predicate=evercraft:companions/check_id] run function evercraft:companions/handler/menu_v2/winback/restore_slot_write with storage evercraft:companions winback

# --- Reunion FX (gated bespoke revive — a homecoming swell) + dialogue (action-bar, NON-BOLD) ---
execute at @s run function evercraft:fx/companion/revive
scoreboard players set #ndur ec.temp 55
data modify storage evercraft:notify stage.c set value [{nbt:"winback.cname",storage:"evercraft:companions",interpret:true},{text:" has come home! They missed you.",color:"green"}]
function evercraft:util/notify/emit

# --- Drop the win-back latch + scratch ---
tag @s remove companion.wb_pending
scoreboard players set @s companion.wb_timer 0

# --- Refresh the grid so the slot re-renders un-grayed (MenuDisplay must be rebuilt from the now-cleared
# Pets[] entry: reload the current page, repaint slots, then re-run the gray-out pass). ---
scoreboard players operation #PageToLoad companion.menu = @s companion.menupage
execute in overworld positioned 0 -60 0 as @n[distance=..10,type=marker,tag=companion.marker,predicate=evercraft:companions/check_id] run function evercraft:companions/handler/menu_v2/load_companions
function evercraft:companions/handler/menu_v2/refresh_slots
function evercraft:companions/handler/menu_v2/winback/mark_departed_slots

# --- Auto-summon the returned companion so the reunion is immediate (D-SP3-4). The departed flag is now
# cleared, so spawn_selected_companion will summon normally. Convert the absolute Pets[] index back to a
# page-relative slot: rel = wb_slot - (menupage-1)*48 — the inverse of the #abs_slot math. ---
scoreboard players operation #rel_slot companion.menu = @s companion.wb_slot
scoreboard players operation #abs_page companion.menu = @s companion.menupage
scoreboard players remove #abs_page companion.menu 1
scoreboard players operation #abs_page companion.menu *= #48 companion.calc
scoreboard players operation #rel_slot companion.menu -= #abs_page companion.menu
execute store result storage evercraft:companions winback.relslot int 1 run scoreboard players get #rel_slot companion.menu
function evercraft:companions/handler/menu_v2/winback/auto_summon with storage evercraft:companions winback

# NOTE: do NOT clear `winback` scratch here. The reunion action-bar frame resolves the {nbt:"winback.cname"}
# reference at DISPLAY time (a later tick) — removing it now would render the name empty. It is transient
# scratch, harmlessly overwritten by the next offer/restore cycle.
