# SP5 — Snapshot a roster companion's stored item by absolute Pets[] index into care.head.
# Run as player. Macro arg: {probeidx:<absolute index>}. Reads from the companion.marker.
# care.head ends up as the full Pets[] entry (item with components) OR is left absent if the
# index is out of range (the `set from` silently no-ops on a missing path → care.head stays removed).
# Used by spawn_home (the 3 heads) and care/render (the focused head). Pure render scratch.
$execute in overworld run data modify storage evercraft:companions care.head set from entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[$(probeidx)]
