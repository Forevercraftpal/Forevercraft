scoreboard players operation #Search companion.id = @s companion.id

execute as @s[tag=companion.zephyr] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[5].extra[{text:"10"}] at @s run return run function evercraft:companions/handler/active/abilities/trigger/chicken

execute as @s[tag=companion.bramble] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[5].extra[{text:"10"}] at @s run return run function evercraft:companions/handler/active/abilities/trigger/pufferfish

execute as @s[tag=companion.wraith] run function evercraft:companions/handler/active/abilities/trigger/reaper_aura

# Claude - Ore Sight (scans for nearby ores every 10s)
execute as @s[tag=companion.claude] at @s run function evercraft:companions/handler/active/abilities/trigger/claude_ore_sight