# Deloris Pack — Check Clicks
# @s = player in deloris pack menu

# Close button
execute as @e[type=interaction,tag=ec.dlpack_close_btn,distance=..5,limit=1] if data entity @s interaction run function evercraft:companions/handler/active/abilities/deloris_pack/close
execute as @e[type=interaction,tag=ec.dlpack_close_btn,distance=..5,limit=1] if data entity @s interaction run data remove entity @s interaction

# Slot clicks
execute as @e[type=interaction,tag=ec.dlpack_s0,distance=..5,limit=1] if data entity @s interaction run data modify storage evercraft:companions dlpack_temp.slot set value "s0"
execute as @e[type=interaction,tag=ec.dlpack_s0,distance=..5,limit=1] if data entity @s interaction run function evercraft:companions/handler/active/abilities/deloris_pack/on_slot_click
execute as @e[type=interaction,tag=ec.dlpack_s0,distance=..5] if data entity @s interaction run data remove entity @s interaction

execute as @e[type=interaction,tag=ec.dlpack_s1,distance=..5,limit=1] if data entity @s interaction run data modify storage evercraft:companions dlpack_temp.slot set value "s1"
execute as @e[type=interaction,tag=ec.dlpack_s1,distance=..5,limit=1] if data entity @s interaction run function evercraft:companions/handler/active/abilities/deloris_pack/on_slot_click
execute as @e[type=interaction,tag=ec.dlpack_s1,distance=..5] if data entity @s interaction run data remove entity @s interaction

execute as @e[type=interaction,tag=ec.dlpack_s2,distance=..5,limit=1] if data entity @s interaction run data modify storage evercraft:companions dlpack_temp.slot set value "s2"
execute as @e[type=interaction,tag=ec.dlpack_s2,distance=..5,limit=1] if data entity @s interaction run function evercraft:companions/handler/active/abilities/deloris_pack/on_slot_click
execute as @e[type=interaction,tag=ec.dlpack_s2,distance=..5] if data entity @s interaction run data remove entity @s interaction

execute as @e[type=interaction,tag=ec.dlpack_s3,distance=..5,limit=1] if data entity @s interaction run data modify storage evercraft:companions dlpack_temp.slot set value "s3"
execute as @e[type=interaction,tag=ec.dlpack_s3,distance=..5,limit=1] if data entity @s interaction run function evercraft:companions/handler/active/abilities/deloris_pack/on_slot_click
execute as @e[type=interaction,tag=ec.dlpack_s3,distance=..5] if data entity @s interaction run data remove entity @s interaction

execute as @e[type=interaction,tag=ec.dlpack_s4,distance=..5,limit=1] if data entity @s interaction run data modify storage evercraft:companions dlpack_temp.slot set value "s4"
execute as @e[type=interaction,tag=ec.dlpack_s4,distance=..5,limit=1] if data entity @s interaction run function evercraft:companions/handler/active/abilities/deloris_pack/on_slot_click
execute as @e[type=interaction,tag=ec.dlpack_s4,distance=..5] if data entity @s interaction run data remove entity @s interaction
