# SP5 — Render the CARE screen for the focused companion (companion.careidx). Run as player,
# facing-anchor context from open_tab_care. Snapshots the focused stored Pets[] item, loads its RP +
# bond, then lays out (centered stack, 2026-06-06): big head (◀prev / next▶ flanking) · bond line ·
# RP bar · clickable name + "click to rename" · Pet/Feed/Call/Skills · Take Out · Back. Empty slot →
# "empty" label, no head. All elements tagged companion.menuelement + companion.tab_content.

scoreboard players operation #Search companion.id = @s companion.id

# Snapshot the focused companion's stored item into care.head.
data remove storage evercraft:companions care.head
execute store result storage evercraft:companions care.probeidx int 1 run scoreboard players get @s companion.careidx
function evercraft:companions/handler/menu_v2/care/snapshot_idx with storage evercraft:companions care

# If the focused index has no companion (out of range), fall back to slot 0 and re-snapshot.
execute unless data storage evercraft:companions care.head.components run scoreboard players set @s companion.careidx 0
execute unless data storage evercraft:companions care.head.components run data modify storage evercraft:companions care.probeidx set value 0
execute unless data storage evercraft:companions care.head.components run function evercraft:companions/handler/menu_v2/care/snapshot_idx with storage evercraft:companions care

# Load RP + bond level from the snapshot (data-side).
function evercraft:companions/handler/menu_v2/care/load_focus_rp

# === HEAD (big, centered, top) — item_display:"head" from the snapshot. Empty slot (no companion) →
# render NO head (no Steve) and a centered "empty" label instead. ===
execute if data storage evercraft:companions care.head.components rotated ~ 0 positioned ^ ^1.76 ^1.72 run summon item_display ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_head"],item_display:"head",billboard:"center",transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.46f,0.46f,0.46f]}}
execute if data storage evercraft:companions care.head.components run data modify entity @n[type=item_display,tag=companion.care_head,distance=..5] item set from storage evercraft:companions care.head
execute if data storage evercraft:companions care.head.components run scoreboard players operation @e[type=item_display,tag=companion.care_head,distance=..5] companion.id = @s companion.id
execute unless data storage evercraft:companions care.head.components rotated ~ 0 positioned ^ ^1.70 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.care_head"],billboard:"center",text:[{text:"empty",color:"gray",italic:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]}}
execute unless data storage evercraft:companions care.head.components run scoreboard players operation @e[type=text_display,tag=companion.care_head,distance=..5] companion.id = @s companion.id

# === NAME (clickable → rename) — centered, BELOW the progress bar, ABOVE the four buttons. Only shown
# when a companion occupies the slot (an empty slot has nothing to rename). ===
execute if data storage evercraft:companions care.head.components rotated ~ 0 positioned ^ ^1.09 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.care_name"],billboard:"center",background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.36f,0.36f,0.36f]}}
execute if data storage evercraft:companions care.head.components run data modify entity @n[type=text_display,tag=companion.care_name,distance=..5] text set from storage evercraft:companions care.head.components."minecraft:custom_name"
execute if data storage evercraft:companions care.head.components run scoreboard players operation @e[type=text_display,tag=companion.care_name,distance=..5] companion.id = @s companion.id
# "✎ click to rename" hint + the clickable name hitbox (centered, just under the name).
execute if data storage evercraft:companions care.head.components rotated ~ 0 positioned ^ ^0.99 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.care_namehint"],billboard:"center",text:[{text:"✎ click to rename",color:"dark_gray",italic:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.22f,0.22f,0.22f]}}
execute if data storage evercraft:companions care.head.components run scoreboard players operation @e[type=text_display,tag=companion.care_namehint,distance=..5] companion.id = @s companion.id
# [strip] ?: 0.5w split into 3 x 0.18 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute if data storage evercraft:companions care.head.components rotated ~ 0 positioned ^-0.16 ^1.07 ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_nameclick"],width:0.18f,height:0.18f,response:1b}
execute if data storage evercraft:companions care.head.components rotated ~ 0 positioned ^0 ^1.07 ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_nameclick"],width:0.18f,height:0.18f,response:1b}
execute if data storage evercraft:companions care.head.components rotated ~ 0 positioned ^0.16 ^1.07 ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_nameclick"],width:0.18f,height:0.18f,response:1b}
execute if data storage evercraft:companions care.head.components run scoreboard players operation @e[type=interaction,tag=companion.care_nameclick,distance=..5] companion.id = @s companion.id

# === BOND LINE === (tier name by rellevel) — centered, just below the head, above the progress bar.
execute rotated ~ 0 positioned ^ ^1.43 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.care_bond"],billboard:"center",background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.30f,0.30f,0.30f]}}
function evercraft:companions/handler/menu_v2/care/render_bond_line
scoreboard players operation @e[type=text_display,tag=companion.care_bond,distance=..5] companion.id = @s companion.id

# === RP BAR + NUMBER ===
function evercraft:companions/handler/menu_v2/care/render_rp_bar

# === FOUR BUTTONS: Pet · Feed · Call · Skills (centered 2x2, under the bond/progress bar) ===
function evercraft:companions/handler/menu_v2/care/spawn_buttons

# === Take Out (place the head into your hand) — centered, just above the Back button ===
execute rotated ~ 0 positioned ^ ^0.62 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.care_takeout_text"],billboard:"center",text:[{text:"⬇ Take Out",color:"yellow"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.28f,0.28f,0.28f]}}
# [strip] ?: 0.4w split into 4 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.14 ^0.59 ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_takeout_click"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.0467 ^0.59 ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_takeout_click"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.0467 ^0.59 ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_takeout_click"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.14 ^0.59 ^1.76 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_takeout_click"],width:0.12f,height:0.12f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.care_takeout_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.care_takeout_click,distance=..5] companion.id = @s companion.id

# === prev / next companion arrows === — flank the big centered head (◀ left, ▶ right)
execute rotated ~ 0 positioned ^ ^1.72 ^1.74 positioned ^1.05 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.care_prev_text"],billboard:"center",text:[{text:"◀ prev",color:"aqua"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
execute rotated ~ 0 positioned ^ ^1.69 ^1.76 positioned ^1.05 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_prev_click"],width:0.30f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^ ^1.72 ^1.74 positioned ^-1.05 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.care_next_text"],billboard:"center",text:[{text:"next ▶",color:"aqua"}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.26f,0.26f,0.26f]}}
execute rotated ~ 0 positioned ^ ^1.69 ^1.76 positioned ^-1.05 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.care_next_click"],width:0.30f,height:0.12f,response:1b}
scoreboard players operation @e[type=text_display,tag=companion.care_prev_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.care_prev_click,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=text_display,tag=companion.care_next_text,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.care_next_click,distance=..5] companion.id = @s companion.id

# === Back ===
function evercraft:companions/handler/menu_v2/spawn_back_btn
