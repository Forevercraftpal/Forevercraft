# SP5 — Open Care from the home-view Care nav button: default the focus to the active MAIN (or the first
# roster pet), then open Care. Run as player. Distinct from open_from_head (which sets a specific focus).
execute if entity @s[tag=companion.activepet] run scoreboard players operation @s companion.careidx = @s companion.activeslot
execute unless entity @s[tag=companion.activepet] run scoreboard players set @s companion.careidx 0
function evercraft:companions/handler/menu_v2/open_tab_care
