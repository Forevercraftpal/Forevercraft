# SP5 — Skills: set the clicked slot as the companion's HIGHLIGHTED ability slot. Run as player.
# #cc_clicked ec.temp = the chosen global slot index (0-11). Guard: must be unlocked (< companion.slots).
# BLEND-ALL NOTE: the horn now fires the signature AND every unlocked chip slot together (see
# horn/fire) — companion.skillslot/horn_active NO LONGER gate which ability fires. This picker is now a
# VIEWER: clicking a slot only moves the cosmetic gold-star highlight (a "focus" marker), it does not
# change what the horn casts. Kept wired so the Skills tab stays interactive + the highlight persists.
# Routes through SP1's skills/set_active for the live MAIN (it persists horn_active on the live item +
# writes companion.skillslot). For a stored focus, persist horn_active onto the Pets[] record directly
# and mirror companion.skillslot. Then re-render so the gold highlight moves.

# Guard: only an unlocked slot can be activated.
data modify storage evercraft:notify stage.c set value [{text:"That ability slot isn't unlocked yet.",color:"red"}]
scoreboard players set #ndur ec.temp 40
execute unless score #cc_clicked ec.temp < @s companion.slots run return run function evercraft:util/notify/emit

# --- Live MAIN: SP1's set_active (one-writer of companion.skillslot + custom_data.horn_active) ---
execute if score #cc_is_main ec.temp matches 1 run function evercraft:companions/handler/menu_v2/skills/set_active_live

# --- Stored focus: write horn_active to the Pets[] record + mirror companion.skillslot ---
execute if score #cc_is_main ec.temp matches 0 run scoreboard players operation @s companion.skillslot = #cc_clicked ec.temp
execute if score #cc_is_main ec.temp matches 0 run function evercraft:companions/handler/menu_v2/skills/set_active_stored

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 2

# Re-render the Skills grid so the active highlight updates.
function evercraft:companions/handler/menu_v2/skills/refresh
