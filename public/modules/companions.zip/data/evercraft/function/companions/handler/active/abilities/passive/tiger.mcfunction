# Sabertooth Pet Passive Abilities
# - Primal Sweep: Sweep ratio (0.3 → 1.0)
# - Predator's Pace: Speed (0.11 → 0.14)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.sabertooth

# Primal Sweep: Sweep ratio (0.3 → 1.0)
execute if score #value companion.calc matches 1..7 run attribute @s sweeping_damage_ratio base set 0.321
execute if score #value companion.calc matches 8..12 run attribute @s sweeping_damage_ratio base set 0.364
execute if score #value companion.calc matches 13..17 run attribute @s sweeping_damage_ratio base set 0.399
execute if score #value companion.calc matches 18..22 run attribute @s sweeping_damage_ratio base set 0.434
execute if score #value companion.calc matches 23..27 run attribute @s sweeping_damage_ratio base set 0.47
execute if score #value companion.calc matches 28..32 run attribute @s sweeping_damage_ratio base set 0.505
execute if score #value companion.calc matches 33..37 run attribute @s sweeping_damage_ratio base set 0.54
execute if score #value companion.calc matches 38..42 run attribute @s sweeping_damage_ratio base set 0.576
execute if score #value companion.calc matches 43..47 run attribute @s sweeping_damage_ratio base set 0.611
execute if score #value companion.calc matches 48..52 run attribute @s sweeping_damage_ratio base set 0.646
execute if score #value companion.calc matches 53..57 run attribute @s sweeping_damage_ratio base set 0.682
execute if score #value companion.calc matches 58..62 run attribute @s sweeping_damage_ratio base set 0.717
execute if score #value companion.calc matches 63..67 run attribute @s sweeping_damage_ratio base set 0.753
execute if score #value companion.calc matches 68..72 run attribute @s sweeping_damage_ratio base set 0.788
execute if score #value companion.calc matches 73..77 run attribute @s sweeping_damage_ratio base set 0.823
execute if score #value companion.calc matches 78..82 run attribute @s sweeping_damage_ratio base set 0.859
execute if score #value companion.calc matches 83..87 run attribute @s sweeping_damage_ratio base set 0.894
execute if score #value companion.calc matches 88..92 run attribute @s sweeping_damage_ratio base set 0.929
execute if score #value companion.calc matches 93..97 run attribute @s sweeping_damage_ratio base set 0.965
execute if score #value companion.calc matches 98..100 run attribute @s sweeping_damage_ratio base set 0.993

# Predator's Pace: Speed (0.11 → 0.14)
execute if score #value companion.calc matches 1..7 run return run attribute @s movement_speed base set 0.111
execute if score #value companion.calc matches 8..12 run return run attribute @s movement_speed base set 0.113
execute if score #value companion.calc matches 13..17 run return run attribute @s movement_speed base set 0.114
execute if score #value companion.calc matches 18..22 run return run attribute @s movement_speed base set 0.116
execute if score #value companion.calc matches 23..27 run return run attribute @s movement_speed base set 0.117
execute if score #value companion.calc matches 28..32 run return run attribute @s movement_speed base set 0.119
execute if score #value companion.calc matches 33..37 run return run attribute @s movement_speed base set 0.12
execute if score #value companion.calc matches 38..42 run return run attribute @s movement_speed base set 0.122
execute if score #value companion.calc matches 43..47 run return run attribute @s movement_speed base set 0.123
execute if score #value companion.calc matches 48..52 run return run attribute @s movement_speed base set 0.125
execute if score #value companion.calc matches 53..57 run return run attribute @s movement_speed base set 0.126
execute if score #value companion.calc matches 58..62 run return run attribute @s movement_speed base set 0.128
execute if score #value companion.calc matches 63..67 run return run attribute @s movement_speed base set 0.129
execute if score #value companion.calc matches 68..72 run return run attribute @s movement_speed base set 0.131
execute if score #value companion.calc matches 73..77 run return run attribute @s movement_speed base set 0.132
execute if score #value companion.calc matches 78..82 run return run attribute @s movement_speed base set 0.134
execute if score #value companion.calc matches 83..87 run return run attribute @s movement_speed base set 0.135
execute if score #value companion.calc matches 88..92 run return run attribute @s movement_speed base set 0.137
execute if score #value companion.calc matches 93..97 run return run attribute @s movement_speed base set 0.138
execute if score #value companion.calc matches 98..100 run return run attribute @s movement_speed base set 0.14
