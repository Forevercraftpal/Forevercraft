# Pixie Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.pixie

# Pixie Dust: Scale (0.975 → 0.5)
$execute if score #value companion.calc matches 1..7 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.961 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.932 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.908 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.884 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.86 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.836 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.812 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.788 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.764 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.74 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.716 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.692 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.668 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.644 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.62 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.596 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.572 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.548 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.524 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s scale modifier add evercraft:home/slot$(ability_slot)/scale 0.505 add_value

# Fairy Blessing: Dream Rate (Luck 0.142 -> 1.486)
$execute if score #value companion.calc matches 1..7 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.142 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.227 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.298 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.369 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.439 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.51 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.581 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.652 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.722 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.793 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.864 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.934 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.005 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.076 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.146 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.217 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.288 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.359 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.429 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.486 add_value
