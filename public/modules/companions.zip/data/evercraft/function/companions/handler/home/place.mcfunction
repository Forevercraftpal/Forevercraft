# ============================================================
# Home Companion — Place a companion at home
# Run as: player
# Macro: {pets_slot} — index into Pets[] array
# Requires: player has a home (hs.tier >= 1) and hc.count < 5
# ============================================================

# Validate: player has a home
data modify storage evercraft:notify stage.c set value [{text:"You need a Hearthstone to place companions at home.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s hs.tier matches 1.. run return run function evercraft:util/notify/emit

# Validate: under the 5-companion cap
data modify storage evercraft:notify stage.c set value [{text:"You can only place up to 5 companions at home.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s hc.count matches 5.. run return run function evercraft:util/notify/emit

# Validate: companion is not already placed at home
data modify storage evercraft:notify stage.c set value [{text:"This companion is already placed at home.",color:"red"}]
scoreboard players set #ndur ec.temp 45
$execute if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[$(pets_slot)].components."minecraft:custom_data".home run return run function evercraft:util/notify/emit

# Find the next available home slot (0-4)
scoreboard players set #hc_next_slot hc.slot 0
execute as @e[type=chicken, tag=HomeCompanion, predicate=evercraft:companions/check_id] run execute if score @s hc.slot >= #hc_next_slot hc.slot run scoreboard players operation #hc_next_slot hc.slot = @s hc.slot
execute as @e[type=chicken, tag=HomeCompanion, predicate=evercraft:companions/check_id] run execute if score @s hc.slot = #hc_next_slot hc.slot run scoreboard players add #hc_next_slot hc.slot 1

# Copy pet item data to storage for summon function
$data modify storage evercraft:companions home.item set from entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[$(pets_slot)]
execute store result storage evercraft:companions home.slot int 1 run scoreboard players get #hc_next_slot hc.slot

# Store gametime for passive RP tracking
execute store result storage evercraft:companions home.placed_at long 1 run time query gametime
execute store result storage evercraft:companions home.last_rp_tick long 1 run time query gametime

# Build HomePets[] entry in storage
data modify storage evercraft:companions home.entry set value {}
data modify storage evercraft:companions home.entry.item set from storage evercraft:companions home.item
execute store result storage evercraft:companions home.entry.slot int 1 run scoreboard players get #hc_next_slot hc.slot
data modify storage evercraft:companions home.entry.placed_at set from storage evercraft:companions home.placed_at
data modify storage evercraft:companions home.entry.last_rp_tick set from storage evercraft:companions home.last_rp_tick

# Append to HomePets[] on the marker
data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets append from storage evercraft:companions home.entry

# Mark the Pets[] entry with home:1b flag
$data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[$(pets_slot)].components."minecraft:custom_data".home set value 1b

# Find the player's HS.Marker and summon the home companion there
# Save player's companion.id before switching @s to the HS.Marker
scoreboard players operation #hc_owner_id companion.id = @s companion.id
scoreboard players operation #hs_search hc.slot = @s hs.gs_id
execute as @e[type=marker, tag=HS.Marker] if score @s ec.gs_id = #hs_search hc.slot at @s run function evercraft:companions/handler/home/summon

# Increment home companion count
scoreboard players add @s hc.count 1

# If player is in home zone, apply the new companion's abilities immediately
execute if score @s hs.in_zone matches 1 run function evercraft:companions/handler/home/abilities/apply_all

# Notify player
data modify storage evercraft:notify stage.c set value [{text:"Your companion has been placed at your home!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
# Companion bell pair (the companion-leveling bell identity; FX pass 2, 2026-06-09 — was ungated levelup).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.45 1.122
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.35 1.335
