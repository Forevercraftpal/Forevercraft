# Remove the active pet - convert back to head item and remove from pet list
# Called as the player

# Must have an active pet to remove
data modify storage evercraft:notify stage.c set value [{text:"Summon a pet first to remove it.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @s[tag=companion.activepet] run return run function evercraft:util/notify/emit

scoreboard players operation #Search companion.id = @s companion.id

# Store the pet's name for array removal
# Try custom_data first (reliable — immune to profile resolution), fallback to profile properties
data remove storage evercraft:companions name
data modify storage evercraft:companions name set from entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:custom_data".pet_name
execute unless data storage evercraft:companions name run data modify storage evercraft:companions name set from entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"name"}].value

# Remove from marker's pet list (uses existing database function)
function evercraft:companions/handler/database/remove_companion with storage evercraft:companions

# Convert the active pet back to a dropped item (retains level data)
function evercraft:companions/handler/active/convert

# Close the menu
function evercraft:companions/handler/menu_v2/close

# Notify
data modify storage evercraft:notify stage.c set value [{text:"Pet removed and returned to you!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
