# Crystalheart Pet Passive Abilities
# - Prismatic Ward: Armor (1.0 → 4.0)
# - Crystal Fortitude: KB res (0.1 → 0.5)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.crystalheart

# Prismatic Ward: Armor (1.0 → 4.0)
execute if score #value companion.calc matches 1..7 run attribute @s armor base set 1.091
execute if score #value companion.calc matches 8..12 run attribute @s armor base set 1.273
execute if score #value companion.calc matches 13..17 run attribute @s armor base set 1.424
execute if score #value companion.calc matches 18..22 run attribute @s armor base set 1.576
execute if score #value companion.calc matches 23..27 run attribute @s armor base set 1.727
execute if score #value companion.calc matches 28..32 run attribute @s armor base set 1.879
execute if score #value companion.calc matches 33..37 run attribute @s armor base set 2.03
execute if score #value companion.calc matches 38..42 run attribute @s armor base set 2.182
execute if score #value companion.calc matches 43..47 run attribute @s armor base set 2.333
execute if score #value companion.calc matches 48..52 run attribute @s armor base set 2.485
execute if score #value companion.calc matches 53..57 run attribute @s armor base set 2.636
execute if score #value companion.calc matches 58..62 run attribute @s armor base set 2.788
execute if score #value companion.calc matches 63..67 run attribute @s armor base set 2.939
execute if score #value companion.calc matches 68..72 run attribute @s armor base set 3.091
execute if score #value companion.calc matches 73..77 run attribute @s armor base set 3.242
execute if score #value companion.calc matches 78..82 run attribute @s armor base set 3.394
execute if score #value companion.calc matches 83..87 run attribute @s armor base set 3.545
execute if score #value companion.calc matches 88..92 run attribute @s armor base set 3.697
execute if score #value companion.calc matches 93..97 run attribute @s armor base set 3.848
execute if score #value companion.calc matches 98..100 run attribute @s armor base set 3.97

# Crystal Fortitude: KB res (0.1 → 0.5)
execute if score #value companion.calc matches 1..7 run return run attribute @s knockback_resistance base set 0.112
execute if score #value companion.calc matches 8..12 run return run attribute @s knockback_resistance base set 0.136
execute if score #value companion.calc matches 13..17 run return run attribute @s knockback_resistance base set 0.157
execute if score #value companion.calc matches 18..22 run return run attribute @s knockback_resistance base set 0.177
execute if score #value companion.calc matches 23..27 run return run attribute @s knockback_resistance base set 0.197
execute if score #value companion.calc matches 28..32 run return run attribute @s knockback_resistance base set 0.217
execute if score #value companion.calc matches 33..37 run return run attribute @s knockback_resistance base set 0.237
execute if score #value companion.calc matches 38..42 run return run attribute @s knockback_resistance base set 0.258
execute if score #value companion.calc matches 43..47 run return run attribute @s knockback_resistance base set 0.278
execute if score #value companion.calc matches 48..52 run return run attribute @s knockback_resistance base set 0.298
execute if score #value companion.calc matches 53..57 run return run attribute @s knockback_resistance base set 0.318
execute if score #value companion.calc matches 58..62 run return run attribute @s knockback_resistance base set 0.338
execute if score #value companion.calc matches 63..67 run return run attribute @s knockback_resistance base set 0.359
execute if score #value companion.calc matches 68..72 run return run attribute @s knockback_resistance base set 0.379
execute if score #value companion.calc matches 73..77 run return run attribute @s knockback_resistance base set 0.399
execute if score #value companion.calc matches 78..82 run return run attribute @s knockback_resistance base set 0.419
execute if score #value companion.calc matches 83..87 run return run attribute @s knockback_resistance base set 0.439
execute if score #value companion.calc matches 88..92 run return run attribute @s knockback_resistance base set 0.46
execute if score #value companion.calc matches 93..97 run return run attribute @s knockback_resistance base set 0.48
execute if score #value companion.calc matches 98..100 run return run attribute @s knockback_resistance base set 0.496
