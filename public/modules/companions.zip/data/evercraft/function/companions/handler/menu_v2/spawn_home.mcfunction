# SP5 — Home view: the three floating companion heads (player-profile style).
# Run as player, position context from open.mcfunction (replaces spawn_hub at open:70).
# MAIN center+larger+forward, SUB-LEFT and SUB-RIGHT smaller behind. Reads SP4 three.* storage
# (rebuilt by journey/sync_three). Head art = spawn_slots:21 pattern. Each head: item_display:"head"
# + a text_display nameplate + a companion.headslot interaction stamped with companion.headidx
# (0=main 1=subA 2=subB). All tagged companion.menuelement so close:11-21 reaps them.

# Refresh the 3-slot loadout from the live state before rendering.
function evercraft:companions/journey/sync_three

# === MAIN head (center, larger, pulled forward) — three.main = absolute Pets[] index, -1 = none ===
# Snapshot the main companion's stored item into care.head. -1/0-with-no-pet → care.head empty.
data remove storage evercraft:companions care.head
execute store result score #cc_probe ec.temp run data get storage evercraft:companions three.main
data modify storage evercraft:companions care.probeidx set from storage evercraft:companions three.main
execute if score #cc_probe ec.temp matches 0.. run function evercraft:companions/handler/menu_v2/care/snapshot_idx with storage evercraft:companions care
execute if data storage evercraft:companions care.head.components run function evercraft:companions/handler/menu_v2/spawn_home_main
# No active main → a CENTERED "+ Empty" assign placeholder (2026-06-06, no Steve head).
execute unless data storage evercraft:companions care.head.components run function evercraft:companions/handler/menu_v2/spawn_home_main_empty

# === SUB-LEFT head (three.sub[0]) — 0 = empty sentinel ===
data remove storage evercraft:companions care.head
execute store result score #cc_probe ec.temp run data get storage evercraft:companions three.sub[0]
data modify storage evercraft:companions care.probeidx set from storage evercraft:companions three.sub[0]
execute if score #cc_probe ec.temp matches 1.. run function evercraft:companions/handler/menu_v2/care/snapshot_idx with storage evercraft:companions care
execute if data storage evercraft:companions care.head.components run function evercraft:companions/handler/menu_v2/spawn_home_sub_left
execute unless data storage evercraft:companions care.head.components run function evercraft:companions/handler/menu_v2/spawn_home_sub_left_empty

# === SUB-RIGHT head (three.sub[1]) ===
data remove storage evercraft:companions care.head
execute store result score #cc_probe ec.temp run data get storage evercraft:companions three.sub[1]
data modify storage evercraft:companions care.probeidx set from storage evercraft:companions three.sub[1]
execute if score #cc_probe ec.temp matches 1.. run function evercraft:companions/handler/menu_v2/care/snapshot_idx with storage evercraft:companions care
execute if data storage evercraft:companions care.head.components run function evercraft:companions/handler/menu_v2/spawn_home_sub_right
execute unless data storage evercraft:companions care.head.components run function evercraft:companions/handler/menu_v2/spawn_home_sub_right_empty

# Spawn the bottom nav row (Companions / Journey / Care).
function evercraft:companions/handler/menu_v2/spawn_home_nav

# Stamp companion.id on all freshly-spawned head elements + interactions for ownership.
scoreboard players operation @e[type=item_display,tag=companion.homehead,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=text_display,tag=companion.homehead,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.headslot,distance=..5] companion.id = @s companion.id

# Back button (◀ Back → catalogue hub). The home view is now a sub-page of the hub (2026-06-06), so it
# carries a Back button. go_back from tab 0 routes to open_catalogue_hub. self-faces the anchor internally.
function evercraft:companions/handler/menu_v2/spawn_back_btn
