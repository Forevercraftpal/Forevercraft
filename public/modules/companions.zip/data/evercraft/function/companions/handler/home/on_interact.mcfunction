# ============================================================
# Home Companion — Handle right-click interaction
# Run as: HC.Interact interaction entity, at its position
# Routes to: sneak+click → retrieve, holding food → feed, else → pet
# ============================================================

# Clear interaction data to prevent re-triggering
data remove entity @s interaction

# Find the owner player
scoreboard players operation #Search companion.id = @s companion.id
execute store result score #hc_interact_slot hc.slot run scoreboard players get @s hc.slot

# Route to owner player for processing
execute as @a[predicate=evercraft:companions/check_id, distance=..10, limit=1] at @s run function evercraft:companions/handler/home/interact/route
