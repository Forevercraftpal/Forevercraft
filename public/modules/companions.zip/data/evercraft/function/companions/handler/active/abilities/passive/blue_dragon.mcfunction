# Endwalker Pet Passive Abilities
# - Void Strike: Attack damage (2.5 → 6.5, End)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.endwalker

# Void Strike: Attack damage (2.5 → 6.5, End)
execute if score #value companion.calc matches 1..7 run return run attribute @s attack_damage base set 2.621
execute if score #value companion.calc matches 8..12 run return run attribute @s attack_damage base set 2.864
execute if score #value companion.calc matches 13..17 run return run attribute @s attack_damage base set 3.066
execute if score #value companion.calc matches 18..22 run return run attribute @s attack_damage base set 3.268
execute if score #value companion.calc matches 23..27 run return run attribute @s attack_damage base set 3.47
execute if score #value companion.calc matches 28..32 run return run attribute @s attack_damage base set 3.672
execute if score #value companion.calc matches 33..37 run return run attribute @s attack_damage base set 3.874
execute if score #value companion.calc matches 38..42 run return run attribute @s attack_damage base set 4.076
execute if score #value companion.calc matches 43..47 run return run attribute @s attack_damage base set 4.278
execute if score #value companion.calc matches 48..52 run return run attribute @s attack_damage base set 4.48
execute if score #value companion.calc matches 53..57 run return run attribute @s attack_damage base set 4.682
execute if score #value companion.calc matches 58..62 run return run attribute @s attack_damage base set 4.884
execute if score #value companion.calc matches 63..67 run return run attribute @s attack_damage base set 5.086
execute if score #value companion.calc matches 68..72 run return run attribute @s attack_damage base set 5.288
execute if score #value companion.calc matches 73..77 run return run attribute @s attack_damage base set 5.49
execute if score #value companion.calc matches 78..82 run return run attribute @s attack_damage base set 5.692
execute if score #value companion.calc matches 83..87 run return run attribute @s attack_damage base set 5.894
execute if score #value companion.calc matches 88..92 run return run attribute @s attack_damage base set 6.096
execute if score #value companion.calc matches 93..97 run return run attribute @s attack_damage base set 6.298
execute if score #value companion.calc matches 98..100 run return run attribute @s attack_damage base set 6.46
