# Shade Pet Passive Abilities
# - Shadow Step: Sneak speed (0.335 → 1.0)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.shade

# Shadow Step: Sneak speed (0.335 → 1.0)
execute if score #value companion.calc matches 1..7 run return run attribute @s sneaking_speed base set 0.355
execute if score #value companion.calc matches 8..12 run return run attribute @s sneaking_speed base set 0.395
execute if score #value companion.calc matches 13..17 run return run attribute @s sneaking_speed base set 0.429
execute if score #value companion.calc matches 18..22 run return run attribute @s sneaking_speed base set 0.463
execute if score #value companion.calc matches 23..27 run return run attribute @s sneaking_speed base set 0.496
execute if score #value companion.calc matches 28..32 run return run attribute @s sneaking_speed base set 0.53
execute if score #value companion.calc matches 33..37 run return run attribute @s sneaking_speed base set 0.563
execute if score #value companion.calc matches 38..42 run return run attribute @s sneaking_speed base set 0.597
execute if score #value companion.calc matches 43..47 run return run attribute @s sneaking_speed base set 0.631
execute if score #value companion.calc matches 48..52 run return run attribute @s sneaking_speed base set 0.664
execute if score #value companion.calc matches 53..57 run return run attribute @s sneaking_speed base set 0.698
execute if score #value companion.calc matches 58..62 run return run attribute @s sneaking_speed base set 0.731
execute if score #value companion.calc matches 63..67 run return run attribute @s sneaking_speed base set 0.765
execute if score #value companion.calc matches 68..72 run return run attribute @s sneaking_speed base set 0.798
execute if score #value companion.calc matches 73..77 run return run attribute @s sneaking_speed base set 0.832
execute if score #value companion.calc matches 78..82 run return run attribute @s sneaking_speed base set 0.866
execute if score #value companion.calc matches 83..87 run return run attribute @s sneaking_speed base set 0.899
execute if score #value companion.calc matches 88..92 run return run attribute @s sneaking_speed base set 0.933
execute if score #value companion.calc matches 93..97 run return run attribute @s sneaking_speed base set 0.966
execute if score #value companion.calc matches 98..100 run return run attribute @s sneaking_speed base set 0.993
