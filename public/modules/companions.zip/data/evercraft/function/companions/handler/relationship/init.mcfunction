# Initialize relationship data for a new pet
# Called when pet is first added to database
# Sets starting RP to 500 (Friendly level)

# Add relationship property to pet NBT
# Properties[4] = relationship points
# Properties[5] = last interaction gametime
data modify entity @s item.components."minecraft:profile".properties append value {name:"relationship",value:"500"}
data modify entity @s item.components."minecraft:profile".properties append value {name:"last_interact",value:"0"}
data modify entity @s item.components."minecraft:profile".properties append value {name:"memories",value:"0"}
# SP2 Bond & Care: per-instance care state (mirrored to Pets[] via sync_relationship_to_marker).
#   bond_skills = set-bond-skill bits 0..11 + happypass bit 15 (monotonic OR-only, one-writer per range)
#   happiness   = 0..100 care meter (starts full)
#   happydays   = 0..7 continuous-happy day clock
data modify entity @s item.components."minecraft:profile".properties append value {name:"bond_skills",value:"0"}
data modify entity @s item.components."minecraft:profile".properties append value {name:"happiness",value:"100"}
data modify entity @s item.components."minecraft:profile".properties append value {name:"happydays",value:"0"}
