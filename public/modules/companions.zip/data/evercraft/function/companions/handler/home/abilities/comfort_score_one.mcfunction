# ============================================================
# Home Companion — Hearth Comfort: per-placed-companion contribution (SP9)
# Run as: HC.Head item_display entity (one placed home companion)
# Raises the owner's companion.hcomfort to max(current, thisCompanion's tier + bondLvl).
# The owner is the player whose companion.id == this head's companion.id (the standard check_id pair).
# ============================================================
# This is the framework-sharing read: the SAME persistent axes the active companion uses —
#   TIER  ← combat/get_tier_stats (#pc_tier 1..6) keyed on the `name` profile property
#   BOND  ← the `relationship` profile property decoded against #RelLvl1..5 (bond level 0..5)
# travel on the placed head's item, so a placed companion's tier + bond are never dropped.

# --- TIER: copy this companion's species name into the tier engine's input slot, then read #pc_tier ---
# Same source the journey tier-read uses (read_tier_macro:4): the `name` profile property's .value.
data modify storage evercraft:companion_combat companion_name set from entity @s item.components."minecraft:profile".properties[{name:"name"}].value
function evercraft:companions/combat/get_tier_stats
scoreboard players operation #hcomfort_one companion.calc = #pc_tier ec.var

# --- BOND: decode the placed companion's relationship RP → bond level 0..5 (same thresholds as load_rp) ---
data modify storage evercraft:companions math.string set string entity @s item.components."minecraft:profile".properties[{name:"relationship"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int
scoreboard players set #hcomfort_bond companion.calc 0
execute if score #value companion.calc >= #RelLvl1 companion.calc run scoreboard players set #hcomfort_bond companion.calc 1
execute if score #value companion.calc >= #RelLvl2 companion.calc run scoreboard players set #hcomfort_bond companion.calc 2
execute if score #value companion.calc >= #RelLvl3 companion.calc run scoreboard players set #hcomfort_bond companion.calc 3
execute if score #value companion.calc >= #RelLvl4 companion.calc run scoreboard players set #hcomfort_bond companion.calc 4
execute if score #value companion.calc >= #RelLvl5 companion.calc run scoreboard players set #hcomfort_bond companion.calc 5

# score = tier (1..6) + bondLvl (0..5) → 1..11
scoreboard players operation #hcomfort_one companion.calc += #hcomfort_bond companion.calc

# Raise the owner's cached comfort to this companion's score if it is higher (best-placed wins).
# Owner = the player matching this head's id (set #Search from @s, then the check_id predicate pairs them).
scoreboard players operation #Search companion.id = @s companion.id
execute as @a[predicate=evercraft:companions/check_id, limit=1] if score #hcomfort_one companion.calc > @s companion.hcomfort run scoreboard players operation @s companion.hcomfort = #hcomfort_one companion.calc
