execute store result storage evercraft:companions math.mining_increase int 4 run scoreboard players get #current_level companion.exp

data modify entity @s item.components."minecraft:lore"[5].extra[0].text set string storage evercraft:companions math.mining_increase
data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:profile":{properties:[{},{value:"Abyssal"}]}}}].components."minecraft:lore"[5].extra[0].text set string storage evercraft:companions math.mining_increase

execute as @a[tag=companion.owner, limit=1] at @s run function evercraft:companions/handler/active/abilities/passive/elder_guardian