# Moobloom Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.moobloom

# Floral Fortune: Luck (0.5 → 3.0)
$execute if score #value companion.calc matches 1..7 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.576 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.727 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.854 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 0.98 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.106 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.232 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.359 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.485 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.611 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.737 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.864 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 1.99 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.116 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.242 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.369 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.495 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.621 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.747 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.874 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.975 add_value
