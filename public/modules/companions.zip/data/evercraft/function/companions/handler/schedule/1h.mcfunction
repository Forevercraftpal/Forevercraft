# Every hour — (RP decay RETIRED in SP2 Bond & Care, Wave 2).
#
# MONOTONIC BOND: bond RP now ONLY ever rises (DECISIONS: "monotonic bond — no RP decay"). The old
# -25 RP/hr decay (relationship/decay → decay_companion) is no longer called — neglect is signaled by
# the separate HAPPINESS meter (companion.happiness), which decays -8/in-game-day in
# bond/happiness/tick and is trivially refilled by one Pet + one Feed. RP and happiness are distinct:
# happiness decays, RP does not. This removes the chore feeling of grinding a rank only to lose it.
#
# relationship/decay + decay_companion are left in place (unreferenced) as the documented retired path;
# level_down is still used by other systems. No hourly work remains for the relationship system.
