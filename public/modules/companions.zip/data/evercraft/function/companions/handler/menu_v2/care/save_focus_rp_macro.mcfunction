# SP5 — Macro: write math.string into Pets[$(careidx)].profile relationship value on the marker.
# Args: {careidx:N}. Run after care/save_focus_rp set up math.string + #Search. If the focused record
# has no `relationship` property yet, append it (mirrors relationship/init); else overwrite its value.

# Ensure the relationship property exists (append a default if missing — first interaction case).
# in overworld: the companion.marker lives at 0 -60 0 in the OVERWORLD; a plain @e is dimension-scoped,
# so reads/writes must run in overworld or they silently no-op when the player is in the Nether/End.
$execute in overworld unless data entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[$(careidx)].components."minecraft:profile".properties[{name:"relationship"}] run data modify entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[$(careidx)].components."minecraft:profile".properties append value {name:"relationship",value:"0"}

# Overwrite the value with the new RP string.
$execute in overworld run data modify entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[$(careidx)].components."minecraft:profile".properties[{name:"relationship"}].value set from storage evercraft:companions math.string
