# Deloris Pack — Close Menu
# @s = player

tag @s remove ec.dlpack_in_menu

execute at @s run kill @e[type=text_display,tag=ec.dlpack_el,distance=..5]
execute at @s run kill @e[type=interaction,tag=ec.dlpack_el,distance=..5]
execute at @s run kill @e[type=item_display,tag=ec.dlpack_el,distance=..5]

playsound minecraft:entity.llama.chest master @s ~ ~ ~ 0.5 0.8
