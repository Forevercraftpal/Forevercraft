# Golden Dragon Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.golden_dragon

effect give @s resistance infinite 0 true
effect give @s fire_resistance infinite 0 true

# Fortune's Blessing: Luck (2.0 → 7.0)
$execute if score #value companion.calc matches 1..7 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.152 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.455 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.707 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 2.96 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.212 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.465 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.717 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 3.97 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.222 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.475 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.727 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 4.98 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 5.232 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 5.485 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 5.737 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 5.99 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 6.242 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 6.495 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 6.747 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s luck modifier add evercraft:home/slot$(ability_slot)/luck 6.949 add_value

# Draconic Might: Attack damage (2.5 → 6.0)
$execute if score #value companion.calc matches 1..7 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.606 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.818 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.995 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.172 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.348 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.525 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.702 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 3.879 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.056 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.232 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.409 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.586 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.763 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 4.939 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 5.116 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 5.293 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 5.47 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 5.646 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 5.823 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 5.965 add_value
