# === COMPANION CATALOGUE — ON USE (using_item reward) ===
# Sets a flag for tick processing (same pattern as Eternal Codex)
# Does NOT open menu directly — tick function handles it next frame
advancement revoke @s only evercraft:companions/menu_v2/spawn
scoreboard players set @s ec.cc_use 1
