# Baby Potato Pet Passive Abilities
# - Tiny Spud: Scale (0.98 → 0.85)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.baby_potato

# Tiny Spud: Scale (0.98 → 0.85)
execute if score #value companion.calc matches 1..7 run return run attribute @s scale base set 0.976
execute if score #value companion.calc matches 8..12 run return run attribute @s scale base set 0.968
execute if score #value companion.calc matches 13..17 run return run attribute @s scale base set 0.962
execute if score #value companion.calc matches 18..22 run return run attribute @s scale base set 0.955
execute if score #value companion.calc matches 23..27 run return run attribute @s scale base set 0.948
execute if score #value companion.calc matches 28..32 run return run attribute @s scale base set 0.942
execute if score #value companion.calc matches 33..37 run return run attribute @s scale base set 0.935
execute if score #value companion.calc matches 38..42 run return run attribute @s scale base set 0.929
execute if score #value companion.calc matches 43..47 run return run attribute @s scale base set 0.922
execute if score #value companion.calc matches 48..52 run return run attribute @s scale base set 0.916
execute if score #value companion.calc matches 53..57 run return run attribute @s scale base set 0.909
execute if score #value companion.calc matches 58..62 run return run attribute @s scale base set 0.903
execute if score #value companion.calc matches 63..67 run return run attribute @s scale base set 0.896
execute if score #value companion.calc matches 68..72 run return run attribute @s scale base set 0.889
execute if score #value companion.calc matches 73..77 run return run attribute @s scale base set 0.883
execute if score #value companion.calc matches 78..82 run return run attribute @s scale base set 0.876
execute if score #value companion.calc matches 83..87 run return run attribute @s scale base set 0.87
execute if score #value companion.calc matches 88..92 run return run attribute @s scale base set 0.863
execute if score #value companion.calc matches 93..97 run return run attribute @s scale base set 0.857
execute if score #value companion.calc matches 98..100 run return run attribute @s scale base set 0.851
