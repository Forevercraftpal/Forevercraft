# ============================================================
# Home Companion — Handle hearthstone destruction
# Run as: owner player
# Drops all home companions as items, cleans up entities and data
# ============================================================

# Skip if no home companions
execute unless score @s hc.count matches 1.. run return fail

scoreboard players operation #Search companion.id = @s companion.id

# Drop each home companion as a head item at its current position (via HC.Head)
execute as @e[type=item_display, tag=HC.Head, predicate=evercraft:companions/check_id] at @s run function evercraft:companions/handler/home/drop_as_item

# Kill chicken entities and remaining interaction entities
kill @e[type=chicken, tag=HomeCompanion, predicate=evercraft:companions/check_id]
kill @e[type=interaction, tag=HC.Interact, predicate=evercraft:companions/check_id]

# Clear HomePets[] on the marker
execute positioned 0 -60 0 run data modify entity @n[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id] data.HomePets set value []

# Remove home:1b flag from Pets[] entries
execute positioned 0 -60 0 as @n[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id] run function evercraft:companions/handler/home/cleanup_clear_flags

# Reset home companion count
scoreboard players set @s hc.count 0

# Remove abilities if player was in zone
execute if score @s hs.in_zone matches 1 run function evercraft:companions/handler/home/abilities/reset_all

data modify storage evercraft:notify stage.c set value [{text:"Your home companions have been returned as items.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
