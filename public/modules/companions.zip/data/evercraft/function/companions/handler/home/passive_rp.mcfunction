# ============================================================
# Home Companion — Passive RP gain (gametime-based)
# Called from home/tick every 2s
# +1 RP every 10 minutes (12000 ticks)
# ============================================================

# Get current gametime
execute store result score #now hc.rp_timer run time query gametime

# Process each home companion
execute as @e[type=item_display, tag=HC.Head] run function evercraft:companions/handler/home/passive_rp_check
