# Pet Level 100 Milestone Celebration (enhanced)
# @s = pet item_display, owner = @p[tag=companion.owner]

# Realm-wide announcement (gold, bold)
tellraw @a [{text:"[Pets] ",color:"gold",bold:true},{selector:"@p[tag=companion.owner,limit=1]",color:"yellow",bold:true},{text:"'s ",color:"gold",bold:true},{nbt:"leveling.display_name",storage:"evercraft:companions",color:"gold",bold:true},{text:" reached level 100!",color:"gold",bold:true}]

# Tag owner for staggered firework tracking
tag @p[tag=companion.owner,limit=1] add ec.pet_milestone100

# 3 staggered fireworks at owner's location
execute at @p[tag=companion.owner,limit=1] run summon firework_rocket ~ ~ ~ {LifeTime:0,FireworkItem:{id:"firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",colors:[I;16776960,16750848],has_twinkle:1b,has_trail:1b}],flight_duration:1b}}}}
schedule function evercraft:companions/handler/active/leveling/milestone_100_fw2 10t
schedule function evercraft:companions/handler/active/leveling/milestone_100_fw3 20t

# Totem of undying particles on owner
execute at @p[tag=companion.owner,limit=1] run particle totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.1 50
