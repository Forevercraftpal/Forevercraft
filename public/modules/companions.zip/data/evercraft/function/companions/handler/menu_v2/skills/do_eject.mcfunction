# SP8 — Skills: eject the newest chip from the live MAIN companion. Run as player.
# Calls SP1's eject_chip_slot (single slot write path): returns the chip + costs -5 companion levels
# (floor 1), frees the slot. Then re-loads the slot read-cache + re-renders the grid so the freed slot
# shows. eject_chip_slot self-guards (fail if no chip-sourced slot), so a stray click is a no-op.
execute store success score #cc_ej ec.var run function evercraft:companions/skills/eject_chip_slot
execute if score #cc_ej ec.var matches 0 run return fail

# Confirm popup (centered, NON-BOLD) + sound. The chip is back in inventory, slot freed, -5 levels.
function evercraft:companions/skills/chip_name
data modify storage evercraft:notify stage.c set value [{text:"⤓ ",color:"yellow"},{text:"Chip ejected (-5 levels). Returned to your inventory.",color:"yellow",italic:false}]
scoreboard players set #ndur ec.temp 55
function evercraft:util/notify/emit
# Gated bespoke amethyst skill-chip touch (eject — the lighter break note).
scoreboard players set #rename_mode ec.temp 1
execute at @s run function evercraft:fx/companion/rename

# Re-load the live-MAIN slot descriptor + re-render the grid.
function evercraft:companions/handler/menu_v2/skills/load_focus_slots
function evercraft:companions/handler/menu_v2/skills/refresh
return 1
