scoreboard players operation #Search companion.id = @s companion.id

# Time Weaver "Temporal Stasis" (60s): freeze nearby mobs ~2s.
execute as @s[tag=companion.time_weaver] at @s run function evercraft:companions/handler/active/abilities/trigger/time_weaver_stasis

# Bee "Swarm Call" (60s): poison nearby hostiles.
execute as @s[tag=companion.bee] at @s run function evercraft:companions/handler/active/abilities/trigger/bee_swarm

# Group-6: Deloris "Spit Barrage" (~periodic): direct-damage + KB-FX volley on nearby hostiles. The audit
# called for ~45s; the closest existing dispatch without adding a modulo op is this 60s schedule, which
# reads fine for a heavy llama-spit volley.
execute as @s[tag=companion.deloris] at @s run function evercraft:companions/handler/active/abilities/trigger/deloris_barrage

execute as @s[tag=companion.endwalker] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[9].extra[{text:"60"}] run return run function evercraft:companions/handler/active/abilities/trigger/blue_dragon

execute as @s[tag=companion.ashborn] if data entity @e[distance=..25,  type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[9].extra[{text:"60"}] run return run function evercraft:companions/handler/active/abilities/trigger/red_dragon