# Wayfarer GUI — read the next-node XP threshold thr[$(nn)] into #wf_next (macro). Run as @s.
$execute store result score #wf_next ec.temp run scoreboard players get #wf_thr_$(nn) ec.const
