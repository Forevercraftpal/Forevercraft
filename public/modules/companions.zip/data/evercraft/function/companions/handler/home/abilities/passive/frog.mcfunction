# Frog Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.frog

# Leap: Jump strength (0.43 → 0.85)
$execute if score #value companion.calc matches 1..7 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.443 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.468 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.489 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.511 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.532 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.553 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.574 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.595 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.617 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.638 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.659 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.68 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.702 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.723 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.744 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.765 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.786 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.808 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.829 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s jump_strength modifier add evercraft:home/slot$(ability_slot)/jump_strength 0.846 add_value

# Sticky Landing: Safe fall (6 → 11)
$execute if score #value companion.calc matches 1..7 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 6.152 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 6.455 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 6.707 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 6.96 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 7.212 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 7.465 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 7.717 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 7.97 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 8.222 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 8.475 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 8.727 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 8.98 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 9.232 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 9.485 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 9.737 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 9.99 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 10.242 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 10.495 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 10.747 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s safe_fall_distance modifier add evercraft:home/slot$(ability_slot)/safe_fall_distance 10.949 add_value
