# SP5 — Re-render the Care screen in place (kill the current Care content, rebuild). Run as player.
# Used after Pet/Feed (RP bar update) and after prev/next (new focused companion). Keeps the frame
# (menubg/title/anchor) — only kills companion.tab_content elements, exactly like go_back's content kill.

scoreboard players operation #Search companion.id = @s companion.id

# Kill all Care tab content (everything tagged companion.tab_content for this player).
execute as @e[type=text_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=item_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s

# Re-render + session-stamp the new elements.
execute at @s facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet run function evercraft:companions/handler/menu_v2/care/render
scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
