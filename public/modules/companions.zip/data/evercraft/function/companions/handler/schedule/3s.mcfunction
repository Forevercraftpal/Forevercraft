scoreboard players operation #Search companion.id = @s companion.id

# Monolith (handler file warden.mcfunction). Ancient Ward: the owner joins the warden-immunity team
# (friendlyFire off; the trigger adds nearby wardens to it). Self-clean owners who swapped pets away.
execute as @s[tag=companion.monolith] run team join companion.immunetowarden @s
execute as @s[team=companion.immunetowarden, tag=!companion.monolith] run team leave @s
# Tremor Sense / Ancient Ward: run the detection + immunity trigger for monolith owners.
execute as @s[tag=companion.monolith] at @s as @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id] run return run function evercraft:companions/handler/active/abilities/trigger/warden

# ============================================================
# Group-4 conditional / periodic / immunity companion abilities (3s cadence).
# @s is the active-pet owner (player). Effect durations are 4s (>= the 3s cadence) so they never lapse.
# ============================================================

# Oracle/Owl "Second Sight" (handler owl.mcfunction): glow nearby hostiles through walls (owl's half of
# the shared reskin-pair ability; oracle's NV half is granted in the equip-time passive).
execute as @s[tag=companion.oracle] at @s run effect give @e[type=#minecraft:hostile,distance=..16] glowing 4 0 true

# Infernus "Nether Sense": Night Vision while in the Nether.
execute as @s[tag=companion.infernus] at @s if dimension the_nether run effect give @s night_vision 12 0 true

# Abyssal "Deep Vision": Night Vision while underwater. (handler elder_guardian.mcfunction)
execute as @s[tag=companion.abyssal] if predicate evercraft:in_water run effect give @s night_vision 12 0 true

# Abyssal "Pressure Armor": +4 armor while underwater (fixed — the 3s schedule has no per-owner level
# score, so this is a flat mid-tier grant, not level-banded). Remove-then-conditional-add self-strips
# the cycle after the owner leaves water; reset_perks also removes it on unequip.
execute as @s[tag=companion.abyssal] run attribute @s armor modifier remove evercraft:companion/abyssal_pressure
execute as @s[tag=companion.abyssal] if predicate evercraft:in_water run attribute @s armor modifier add evercraft:companion/abyssal_pressure 4 add_value

# Moldwarp "Earth Sense": Night Vision below Y=50. (handler worm.mcfunction)
execute as @s[tag=companion.moldwarp] at @s positioned ~ 50 ~ unless entity @s[dy=255] run effect give @s night_vision 12 0 true

# Naiad/Dolphin "Tidal Heal": Regeneration II while in water (fixed — no per-owner level score on the
# 3s schedule). (handler dolphin.mcfunction)
execute as @s[tag=companion.naiad] if predicate evercraft:in_water run effect give @s regeneration 4 1 true

# Koala "Drowsy": Slowness immunity.
execute as @s[tag=companion.koala] run effect clear @s slowness

# Sporeblossom "Spore Shield": Poison immunity.
execute as @s[tag=companion.sporeblossom] run effect clear @s poison

# Zoglin "Undead Resilience": Wither immunity.
execute as @s[tag=companion.zoglin] run effect clear @s wither

# Frost Ward / Ice Veins (frozen_zombie / polar_bear / wooly_cow): NOT implemented — `data merge entity @s`
# is blocked for players ("Can't change player data"), and vanilla has no datapack hook to reset a player's
# freeze. Lore for these three needs trimming. (The dragon_boots artifact uses the same broken pattern.)

# ============================================================
# Group-5 continuous / conditional auras (3s cadence). Same conventions as the Group-4 block above:
# @s is the owner; effect durations are 4s (>= cadence) so they never lapse; attribute modifiers are
# remove-then-conditional-add so they self-strip when the condition ends; reset_perks also removes them.
# ============================================================

# Ender Dragon "Draconic Presence": nearby hostiles get Weakness (reduced damage). Continuous aura.
execute as @s[tag=companion.ender_dragon] at @s run effect give @e[type=#minecraft:hostile,distance=..12] weakness 4 0 true

# Snowman "Permafrost Aura": chill nearby hostiles with Slowness. (Frost-walker block placement is omitted
# — placing/removing ice under the owner each tick is too invasive and litters the world; slow-aura only.)
execute as @s[tag=companion.snowman] at @s run effect give @e[type=#minecraft:hostile,distance=..6] slowness 4 0 true

# Ravager "Berserker": +attack speed below 50% HP (fixed mid-tier — no per-owner level score here).
execute as @s[tag=companion.ravager] run attribute @s attack_speed modifier remove evercraft:companion/ravager_berserk
execute as @s[tag=companion.ravager] store result score #rv_hp companion.calc run data get entity @s Health 100
execute as @s[tag=companion.ravager] store result score #rv_max companion.calc run attribute @s max_health get 100
execute as @s[tag=companion.ravager] run scoreboard players operation #rv_hp companion.calc *= #100 companion.calc
execute as @s[tag=companion.ravager] if score #rv_max companion.calc matches 1.. run scoreboard players operation #rv_hp companion.calc /= #rv_max companion.calc
execute as @s[tag=companion.ravager] if score #rv_hp companion.calc matches ..49 run attribute @s attack_speed modifier add evercraft:companion/ravager_berserk 1.0 add_value

# Copper Golem "Lightning Rod": +attack speed during a thunderstorm. (Base ability — distinct from the
# evolved on-hurt zap, which is tagged ce.evo_copper_golem.)
execute as @s[tag=companion.copper_golem] run attribute @s attack_speed modifier remove evercraft:companion/copper_lightning_rod
# (`execute if weather` is NOT a vanilla subcommand — it parse-failed this whole file at /reload,
# 2026-06-09 prod log. Weather checks are weather_check PREDICATES, like everywhere else in the pack.)
execute as @s[tag=companion.copper_golem] if predicate evercraft:buddy/is_thundering run attribute @s attack_speed modifier add evercraft:companion/copper_lightning_rod 1.0 add_value

# Bee "Honey Shield": proactive low-HP Absorption buffer (APPROXIMATION of on-lethal — no per-tick
# pre-death hook exists in the schedule-only companion system; self-gates on HP% + a cooldown inside).
execute as @s[tag=companion.bee] at @s run function evercraft:companions/handler/active/abilities/trigger/bee_shield

# ============================================================
# Group-6 expensive companion abilities (3s cadence). @s is the owner; effect/burn durations are 4s
# (>= cadence) so they never lapse while the condition holds. Each trigger fn is existence-gated inside.
# ============================================================

# Ashborn (red_dragon) "Cinder Trail": ignite nearby hostiles (no world fire blocks).
execute as @s[tag=companion.ashborn] at @s run function evercraft:companions/handler/active/abilities/trigger/ashborn_cinder

# Creeper "Delayed Detonation": stall nearby ignited creepers' fuses so they take longer to blow.
execute as @s[tag=companion.creeper] at @s run function evercraft:companions/handler/active/abilities/trigger/creeper_delay

# Arctic Fox "Aurora Blessing": at NIGHT (#visual_time 13000..23000) AND in a cold/snowy biome, grant a
# small bundle of positive effects (Regen/Resistance/Speed I). Double-gated at the call site so the buff
# fn only runs when both conditions hold; effects self-expire ~1s after either condition ends.
execute as @s[tag=companion.arctic_fox] at @s if score #visual_time ec.var matches 13000..23000 if predicate evercraft:companions/in_cold_biome run function evercraft:companions/handler/active/abilities/trigger/arctic_fox_aurora