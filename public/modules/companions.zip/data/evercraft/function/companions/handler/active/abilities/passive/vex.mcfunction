# Vex Pet Passive Abilities
# - Effect: slow_falling

tag @s add companion.vex

effect give @s slow_falling infinite 0 true

