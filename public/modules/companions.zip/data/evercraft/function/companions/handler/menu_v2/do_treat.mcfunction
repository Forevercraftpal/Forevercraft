# Companion the active pet (give affection, like petting)
# Called as the player
# This is the menu equivalent of the petting action — a quick "treat" that gives 5 RP

# Must have an active pet
data modify storage evercraft:notify stage.c set value [{text:"Summon a pet first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @s[tag=companion.activepet] run return run function evercraft:util/notify/emit

scoreboard players operation #Search companion.id = @s companion.id

# Check cooldown — use the SHORT Care anti-spam cd (ec.cc_petcd, 5s, menu-tick-decremented), NOT the
# heavy world-feed cooldown companion.feedcd. (2026-06-17 bugfix) feedcd is set to 600-12000t (30s-10min)
# by a real world feed; gating this light affection tap on it made Care "Pet"/"Feed-snack" silently dead
# for up to minutes after a feed ("press 20×, nothing, then works after a minute"). Petting is a separate
# action from feeding (world pet=interactcd, world feed=feedcd are already disjoint), so decouple here too.
data modify storage evercraft:notify stage.c set value [{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" needs a moment before more treats.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.cc_petcd matches 1.. run return run function evercraft:util/notify/emit

# Load current RP
function evercraft:companions/handler/relationship/load_rp

# Store old level
scoreboard players operation #oldLevel companion.calc = @s companion.rellevel

# Add 5 RP (same as petting)
scoreboard players set #feedRP companion.calc 5
scoreboard players operation @s companion.rp += #feedRP companion.calc

# Cap at 5000
execute if score @s companion.rp matches 5001.. run scoreboard players set @s companion.rp 5000

# Save RP
function evercraft:companions/handler/relationship/save_rp

# Set short cooldown (100 ticks = 5 seconds) on the Care anti-spam cd (decremented in menu_v2/tick).
scoreboard players set @s ec.cc_petcd 100

# Play petting effects (sanctioned affection vocal — KEEP + GATE).
execute at @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] run particle heart ~ ~0.5 ~ 0.2 0.2 0.2 0 2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.cat.purr master @s ~ ~ ~ 0.5 1.2

# Show message
data modify storage evercraft:notify stage.c set value [{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" enjoyed the affection! ",color:"green"},{text:"(+5 RP)",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Recalculate level and check for level up
function evercraft:companions/handler/relationship/load_rp
execute unless score @s companion.rellevel = #oldLevel companion.calc run function evercraft:companions/handler/relationship/level_up

# Buddy system: +5 friendship for treating
function evercraft:buddy/points/feeding

# Buddy ability: Shared Meal (+2 hunger at tier 2+)
function evercraft:buddy/abilities/shared_meal
