# SP3 Win-back — write the returned companion's restored state onto its Pets[slot] entry.
# Run as @s = companion.marker. Macro: {slot} — the Pets[] index. The RP + happiness STRINGS are read
# straight from staging storage (set from, NOT a macro substitution) to avoid any quote ambiguity — only
# the array index needs a macro. Staging is set by restore.mcfunction: winback.rp / winback.happy.
#   - clear the `departed` flag (mirrors clear_home_flag_direct verbatim, renamed) → un-grays + summonable
#   - write the floored RP string into the relationship profile property (the durable per-instance RP)
#   - write the topped-up happiness string so the returned pet isn't Forlorn on its next summon
# All three writes target the SAME Pets[slot], so the next render reads a clean, un-grayed, ≥Friend pet.
$data remove entity @s data.Pets[$(slot)].components."minecraft:custom_data".departed
$data modify entity @s data.Pets[$(slot)].components."minecraft:profile".properties[{name:"relationship"}].value set from storage evercraft:companions winback.rp
$data modify entity @s data.Pets[$(slot)].components."minecraft:profile".properties[{name:"happiness"}].value set from storage evercraft:companions winback.happy
