# Prowler Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.prowler

# Loyal Bite: Attack damage (1.5 → 2.8)
$execute if score #value companion.calc matches 1..7 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.539 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.618 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.684 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.749 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.815 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.881 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 1.946 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.012 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.078 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.143 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.209 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.275 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.34 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.406 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.472 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.537 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.603 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.669 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.734 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s attack_damage modifier add evercraft:home/slot$(ability_slot)/attack_damage 2.787 add_value
