# SP5 — Arm "assign a companion to journey sub-slot N" mode, then open the roster to pick one.
# Run as player, with #cc_headidx ec.temp = 1 (Sub A) or 2 (Sub B) from the clicked empty + head
# (set in care/open_from_head, still live in this run-function call chain).
# Mirrors the home/guild place-mode arm-then-click pattern (hc.placing/gc.placing): the next pet
# clicked in the roster is consumed by spawn_selected_companion → do_assign_sub → journey/assign.
scoreboard players operation @s companion.assign_slot = #cc_headidx ec.temp
tag @s add companion.assign_sub

# Tell the player the next pick fills the slot.
data modify storage evercraft:notify stage.c set value [{text:"Pick a companion to send to this journey slot.",color:"#7FE0FF"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Open the roster (pet catalogue). Runs as @s player (same context as care/open_from_head).
function evercraft:companions/handler/menu_v2/open_tab_companions
