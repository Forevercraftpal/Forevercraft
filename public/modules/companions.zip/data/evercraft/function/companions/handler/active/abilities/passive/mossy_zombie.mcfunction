# Mossy Zombie Pet Passive Abilities
# - Effect: regeneration

tag @s add companion.mossy_zombie

effect give @s regeneration infinite 0 true

