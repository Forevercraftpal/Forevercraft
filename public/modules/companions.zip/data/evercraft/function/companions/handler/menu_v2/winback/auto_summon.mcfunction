# SP3 Win-back — auto-summon the returned companion (D-SP3-4). Run as @s = player.
# Macro: {relslot} — the page-relative slot (0..47) of the returned companion on the current page.
# Routes through the normal summon funnel now that the departed flag is cleared (MenuDisplay was just
# rebuilt by restore's page reload). spawn_selected_companion re-derives #abs_slot + closes the menu.
$function evercraft:companions/handler/menu_v2/spawn_selected_companion {slot:$(relslot)}
