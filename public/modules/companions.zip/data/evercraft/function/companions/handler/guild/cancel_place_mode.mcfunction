# ============================================================
# Guild Companion — Cancel "Place at Guild" mode
# Run as: player in menu
# ============================================================

tag @s remove gc.placing

# Reset button text
scoreboard players operation #Search companion.id = @s companion.id
execute as @e[type=text_display, tag=companion.menuguildtext, predicate=evercraft:companions/check_id] run data modify entity @s text set value [{text:"\u2694 ",color:"dark_purple"},{text:"Guild",color:"white",bold:true}]

tellraw @s [{text:"[Guild] ",color:"dark_purple"},{text:"Place at guild cancelled.",color:"gray"}]
playsound minecraft:ui.button.click master @s ~ ~ ~ 0.5 0.8
