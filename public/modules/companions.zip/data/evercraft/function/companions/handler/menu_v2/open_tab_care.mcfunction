# SP5 — Open the CARE tab (ec.bd_tab 5). Run as player (on target from a nav/head click).
# Per-companion screen: head + name to the LEFT; RP bar + number; bond level; Pet/Feed/Call/Skills;
# prev/next to cycle the full owned roster. Focus index = companion.careidx (defaults to MAIN).
# Kills the home view, sets the tab, then renders.

scoreboard players operation #Search companion.id = @s companion.id

# Kill the home-view heads + nav + the home's Back button (companion.tab_content) so Care has a clean
# frame. The tab_content kills also cover the home elements (all tagged tab_content) — 2026-06-06.
execute as @e[type=item_display,tag=companion.homehead,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.homehead,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.headslot,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.home_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.home_btn,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=text_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=interaction,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s
execute as @e[type=item_display,tag=companion.tab_content,predicate=evercraft:companions/check_id] run kill @s

# Set the Care tab (find the real player — @s may be a dead interaction).
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players set @s ec.bd_tab 5

# Default the Care focus to the active MAIN if it was never set (or points past the roster).
# careidx -1/unset → use the active companion's slot, else 0 (first roster pet).
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] unless score @s companion.careidx matches 0.. if entity @s[tag=companion.activepet] run scoreboard players operation @s companion.careidx = @s companion.activeslot
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] unless score @s companion.careidx matches 0.. run scoreboard players set @s companion.careidx 0

# Render the Care screen as the real player.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] at @s facing entity @n[type=marker,tag=companion.menuanchor,predicate=evercraft:companions/check_id] feet run function evercraft:companions/handler/menu_v2/care/render

# Session-stamp the new Care elements.
execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1] run scoreboard players operation #gui_stamp ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=item_display,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp
execute as @e[type=interaction,tag=companion.tab_content,distance=..6] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_stamp ec.temp

playsound minecraft:block.note_block.hat master @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id,limit=1,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.6
