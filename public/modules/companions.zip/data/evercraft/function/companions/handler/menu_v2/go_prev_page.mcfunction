# Go to previous page (generic multi-page)
# Called as player

# Recompute max pages (multiplayer safety)
scoreboard players operation #MaxPage companion.menu = @s companion.count
scoreboard players add #MaxPage companion.menu 47
scoreboard players operation #MaxPage companion.menu /= #48 companion.calc
execute if score #MaxPage companion.menu matches ..0 run scoreboard players set #MaxPage companion.menu 1

# Block if already on first page
data modify storage evercraft:notify stage.c set value [{text:"Already on first page.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s companion.menupage matches ..1 run return run function evercraft:util/notify/emit

# Decrement page
scoreboard players remove @s companion.menupage 1

# Play sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.5 1.8

# Update page info text (Page X/Y)
scoreboard players operation #Search companion.id = @s companion.id
execute store result storage evercraft:companions page_text.page int 1 run scoreboard players get @s companion.menupage
execute store result storage evercraft:companions page_text.maxpage int 1 run scoreboard players get #MaxPage companion.menu
function evercraft:companions/handler/menu_v2/set_page_text with storage evercraft:companions page_text

# Update arrow colors
# Next is always green (we moved back from a later page)
execute as @e[type=text_display,tag=companion.menunext,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s text set value {text:"\u25B6",color:"green"}
# Prev: green if not on first page, gray if on first page
execute unless score @s companion.menupage matches ..1 as @e[type=text_display,tag=companion.menuprev,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s text set value {text:"\u25C0",color:"green"}
execute if score @s companion.menupage matches ..1 as @e[type=text_display,tag=companion.menuprev,predicate=evercraft:companions/check_id,limit=1] run data modify entity @s text set value {text:"\u25C0",color:"gray"}

# Load the new page's pets
scoreboard players operation #PageToLoad companion.menu = @s companion.menupage
execute in overworld positioned 0 -60 0 as @n[distance=..10,type=marker,tag=companion.marker,predicate=evercraft:companions/check_id] run function evercraft:companions/handler/menu_v2/load_companions

# Refresh displayed slot entities
function evercraft:companions/handler/menu_v2/refresh_slots

# SP3: re-apply the DEPARTED gray-out for the new page's slots (#Search set by refresh_slots).
function evercraft:companions/handler/menu_v2/winback/mark_departed_slots
