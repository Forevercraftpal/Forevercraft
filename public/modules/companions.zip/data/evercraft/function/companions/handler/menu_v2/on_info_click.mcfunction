# [?] Button Click Handler — Context-Sensitive
# Run as player in menu. Shows different info based on current tab.
# Toggles: if info screen is already open, close it instead.

# === TOGGLE: If info screen is showing, close it and return ===
execute if entity @s[tag=companion.infoscreen] run return run function evercraft:companions/handler/menu_v2/close_info_screen

# === TAB 8 (Hub): General companion catalogue help (the 4-button landing) ===
execute if score @s ec.bd_tab matches 8 run tellraw @s [{"text":""},{"text":"═══ ","color":"gold"},{"text":"The Companion Catalogue","color":"gold","bold":true},{"text":" ═══","color":"gold"}]
execute if score @s ec.bd_tab matches 8 run tellraw @s [{"text":"  "},{"text":"Companions ","color":"yellow"},{"text":"— Browse & manage your pet collection","color":"gray"}]
execute if score @s ec.bd_tab matches 8 run tellraw @s [{"text":"  "},{"text":"Buddies ","color":"#FFD700"},{"text":"— Bond with your pets for combat perks","color":"gray"}]
execute if score @s ec.bd_tab matches 8 run tellraw @s [{"text":"  "},{"text":"Summon ","color":"aqua"},{"text":"— Call your named pets to your side","color":"gray"}]
execute if score @s ec.bd_tab matches 8 run tellraw @s [{"text":"  "},{"text":"Training ","color":"#8B4513"},{"text":"— Track your mount bond & training progress","color":"gray"}]
execute if score @s ec.bd_tab matches 8 run tellraw @s [{"text":"  "},{"text":"Tip: ","color":"green"},{"text":"Open the Buddy tab and press [Bond Nearest Animal] to befriend the closest pet!","color":"dark_green"}]

# === TAB 0 (Home view): the 3-head overview reached from the hub's Companions button ===
execute if score @s ec.bd_tab matches 0 run tellraw @s [{"text":""},{"text":"═══ ","color":"gold"},{"text":"Your Companions","color":"gold","bold":true},{"text":" ═══","color":"gold"}]
execute if score @s ec.bd_tab matches 0 run tellraw @s [{"text":"  "},{"text":"Click a head ","color":"yellow"},{"text":"to open its Care screen","color":"gray"}]
execute if score @s ec.bd_tab matches 0 run tellraw @s [{"text":"  "},{"text":"Companions ","color":"gold"},{"text":"— browse your full roster","color":"gray"}]
execute if score @s ec.bd_tab matches 0 run tellraw @s [{"text":"  "},{"text":"Journey ","color":"aqua"},{"text":"— send companions out on journeys","color":"gray"}]
execute if score @s ec.bd_tab matches 0 run tellraw @s [{"text":"  "},{"text":"Care ","color":"red"},{"text":"— pet, feed & bond with them","color":"gray"}]
execute if score @s ec.bd_tab matches 0 run tellraw @s [{"text":"  "},{"text":"Wayfarer's Track ","color":"gold"},{"text":"— claim milestone rewards","color":"gray"}]

# === TAB 1 (Companions): Show active pet info or pet collection help ===
execute if score @s ec.bd_tab matches 1 if entity @s[tag=companion.activepet] run function evercraft:companions/handler/menu_v2/show_info_screen
execute if score @s ec.bd_tab matches 1 unless entity @s[tag=companion.activepet] run tellraw @s [{"text":""},{"text":"═══ ","color":"gold"},{"text":"Pet Collection","color":"gold","bold":true},{"text":" ═══","color":"gold"}]
execute if score @s ec.bd_tab matches 1 unless entity @s[tag=companion.activepet] run tellraw @s [{"text":"  "},{"text":"Right-click ","color":"yellow"},{"text":"a pet head to summon it","color":"gray"}]
execute if score @s ec.bd_tab matches 1 unless entity @s[tag=companion.activepet] run tellraw @s [{"text":"  "},{"text":"Left-click ","color":"yellow"},{"text":"a pet head for detailed info","color":"gray"}]
execute if score @s ec.bd_tab matches 1 unless entity @s[tag=companion.activepet] run tellraw @s [{"text":"  "},{"text":"Feed treats ","color":"green"},{"text":"to increase relationship points","color":"gray"}]
execute if score @s ec.bd_tab matches 1 unless entity @s[tag=companion.activepet] run tellraw @s [{"text":"  "},{"text":"Max bond + Level 100 ","color":"light_purple"},{"text":"= eligible for Evolution!","color":"gray"}]

# === TAB 2 (Buddy): Buddy system help ===
execute if score @s ec.bd_tab matches 2 run tellraw @s [{"text":""},{"text":"═══ ","color":"#FFD700"},{"text":"Buddy System","color":"#FFD700","bold":true},{"text":" ═══","color":"#FFD700"}]
execute if score @s ec.bd_tab matches 2 run tellraw @s [{"text":"  "},{"text":"Name ","color":"yellow"},{"text":"a pet to track it in your catalogue","color":"gray"}]
execute if score @s ec.bd_tab matches 2 run tellraw @s [{"text":"  "},{"text":"[Bond Nearest Animal] ","color":"yellow"},{"text":"bonds the closest tamed pet — stand near it and click","color":"gray"}]
execute if score @s ec.bd_tab matches 2 run tellraw @s [{"text":"  "},{"text":"Bond tiers: ","color":"aqua"},{"text":"Familiar > Companion > Trusted > Devoted > Soulmate > Spiritbound","color":"gray"}]
execute if score @s ec.bd_tab matches 2 run tellraw @s [{"text":"  "},{"text":"Spiritbound (10,000 pts) ","color":"light_purple"},{"text":"lets you promote to Best Buddy for combat!","color":"gray"}]

# === TAB 3 (Summon): Pet summoning help ===
execute if score @s ec.bd_tab matches 3 run tellraw @s [{"text":""},{"text":"═══ ","color":"aqua"},{"text":"Summon System","color":"aqua","bold":true},{"text":" ═══","color":"aqua"}]
execute if score @s ec.bd_tab matches 3 run tellraw @s [{"text":"  "},{"text":"Name ","color":"yellow"},{"text":"your pets with a name tag to see them here","color":"gray"}]
execute if score @s ec.bd_tab matches 3 run tellraw @s [{"text":"  "},{"text":"Regular summons: ","color":"aqua"},{"text":"1/day  |  ","color":"gray"},{"text":"Buddy: ","color":"green"},{"text":"4/day  |  ","color":"gray"},{"text":"Best Buddy: ","color":"gold"},{"text":"unlimited","color":"gray"}]
execute if score @s ec.bd_tab matches 3 run tellraw @s [{"text":"  "},{"text":"Summoned pets teleport to you from anywhere!","color":"dark_green"}]

# === TAB 4 (Training): Mount training help ===
execute if score @s ec.bd_tab matches 4 run tellraw @s [{"text":""},{"text":"═══ ","color":"#8B4513"},{"text":"Mount Training","color":"#8B4513","bold":true},{"text":" ═══","color":"#8B4513"}]
execute if score @s ec.bd_tab matches 4 run tellraw @s [{"text":"  "},{"text":"Ride a horse ","color":"yellow"},{"text":"for 5+ minutes to bond with it","color":"gray"}]
execute if score @s ec.bd_tab matches 4 run tellraw @s [{"text":"  "},{"text":"Bond tiers ","color":"aqua"},{"text":"unlock speed boosts, recall whistle, and mount armor","color":"gray"}]
execute if score @s ec.bd_tab matches 4 run tellraw @s [{"text":"  "},{"text":"Feed upgrade carrots ","color":"green"},{"text":"for +50 bond points each","color":"gray"}]

# === TAB 9 (Wayfarer's Track): how to earn Wayfarer XP + claim nodes ===
execute if score @s ec.bd_tab matches 9 run tellraw @s [{"text":""},{"text":"═══ ","color":"gold"},{"text":"🧭 Wayfarer's Track","color":"gold","bold":true},{"text":" ═══","color":"gold"}]
execute if score @s ec.bd_tab matches 9 run tellraw @s [{"text":"  "},{"text":"Wayfarer XP ","color":"gold"},{"text":"— climbs with your Dream Rank as you make progress anywhere in Forevercraft","color":"gray"}]
execute if score @s ec.bd_tab matches 9 run tellraw @s [{"text":"  "},{"text":"Earn it by ","color":"yellow"},{"text":"— slaying mobs & bosses, finishing quests, crafting, exploring, raising companions, building & playtime","color":"gray"}]
execute if score @s ec.bd_tab matches 9 run tellraw @s [{"text":"  "},{"text":"Claiming ","color":"aqua"},{"text":"— each node unlocks at an XP goal; click a glowing node (or ✦ Claim Page) to take its reward","color":"gray"}]
execute if score @s ec.bd_tab matches 9 run tellraw @s [{"text":"  "},{"text":"Tip: ","color":"green"},{"text":"No separate grind — every adventure feeds the Track. Your live XP shows in the header up top.","color":"dark_green"}]

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.2
