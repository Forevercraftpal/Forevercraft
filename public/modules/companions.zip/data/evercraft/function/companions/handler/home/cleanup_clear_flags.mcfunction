# ============================================================
# Home Companion — Clear home:1b flag from ALL Pets[] entries
# Run as: companion.marker entity (positioned at 0 -60 0)
# Called by cleanup_all — removes home flag from up to 5 entries
# ============================================================

# Each line removes home from the FIRST Pets[] entry that has home:1b
# Running 5 times handles the max of 5 home companions
data remove entity @s data.Pets[{components:{"minecraft:custom_data":{home:1b}}}].components."minecraft:custom_data".home
data remove entity @s data.Pets[{components:{"minecraft:custom_data":{home:1b}}}].components."minecraft:custom_data".home
data remove entity @s data.Pets[{components:{"minecraft:custom_data":{home:1b}}}].components."minecraft:custom_data".home
data remove entity @s data.Pets[{components:{"minecraft:custom_data":{home:1b}}}].components."minecraft:custom_data".home
data remove entity @s data.Pets[{components:{"minecraft:custom_data":{home:1b}}}].components."minecraft:custom_data".home
