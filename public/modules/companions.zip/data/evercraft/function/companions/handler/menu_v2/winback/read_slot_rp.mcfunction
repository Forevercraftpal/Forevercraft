# SP3 Win-back — read the stored RP off a specific Pets[slot] entry into #value companion.calc.
# Run as @s = companion.marker. Macro: {slot} — the Pets[] index. Mirrors load_rp's string→int read,
# but targets an arbitrary (non-active) slot via macro since the departed companion isn't summoned.
# Result: #value companion.calc = stored RP (0 if the entry has no relationship property yet).
data remove storage evercraft:companions math.string
$data modify storage evercraft:companions math.string set string entity @s data.Pets[$(slot)].components."minecraft:profile".properties[{name:"relationship"}].value
scoreboard players set #value companion.calc 0
execute if data storage evercraft:companions math.string run function evercraft:companions/handler/math/string_to_int
