execute store result storage evercraft:companions math.step_height float 0.009 run scoreboard players get #current_level companion.exp

data modify entity @s item.components."minecraft:lore"[6].extra[0].text set string storage evercraft:companions math.step_height 0 -1
data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets[{components:{"minecraft:profile":{properties:[{},{value:"Cragmite"}]}}}].components."minecraft:lore"[6].extra[0].text set string storage evercraft:companions math.step_height 0 -1

execute as @a[tag=companion.owner, limit=1] if score @s companion.id = #Search companion.id at @s run function evercraft:companions/handler/active/abilities/passive/hamster