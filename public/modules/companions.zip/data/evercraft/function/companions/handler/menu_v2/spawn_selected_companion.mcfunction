# Spawn the selected pet
# Called as player with {slot:N} macro (0-17 page-relative slot)

# Check pet data exists
$execute unless data storage evercraft:companions MenuDisplay[$(slot)] run return fail

# Copy pet data to spawn storage
$data modify storage evercraft:companions SelectedPet set from storage evercraft:companions MenuDisplay[$(slot)]

scoreboard players operation #Search companion.id = @s companion.id

# Compute absolute Pets[] index: (page - 1) * 48 + slot
$scoreboard players set #abs_slot companion.menu $(slot)
scoreboard players operation #abs_page companion.menu = @s companion.menupage
scoreboard players remove #abs_page companion.menu 1
scoreboard players operation #abs_page companion.menu *= #48 companion.calc
scoreboard players operation #abs_slot companion.menu += #abs_page companion.menu

# If companion is placed at home, block summoning
data modify storage evercraft:notify stage.c set value [{text:"This companion is placed at home. Retrieve it first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if data storage evercraft:companions SelectedPet.components."minecraft:custom_data".home run return run function evercraft:util/notify/emit

# If companion is placed at guild, block summoning
data modify storage evercraft:notify stage.c set value [{text:"This companion is placed at the guild. Retrieve it first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if data storage evercraft:companions SelectedPet.components."minecraft:custom_data".guild_pet run return run function evercraft:util/notify/emit

# SP5: if companion is placed out in the world (a placed head), block summoning. Pick it up first.
data modify storage evercraft:notify stage.c set value [{text:"This companion is set down in the world. Pick it up first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if data storage evercraft:companions SelectedPet.components."minecraft:custom_data".placed_out run return run function evercraft:util/notify/emit

# SP3: if this companion has DEPARTED, do NOT summon — open the win-back offer instead (sibling of the
# home/guild_pet guards above). #abs_slot companion.menu (the absolute Pets[] index) was computed above
# and is read by winback/offer. The departed companion stays exactly as-is until a Notch apple is given.
execute if data storage evercraft:companions SelectedPet.components."minecraft:custom_data".departed run return run function evercraft:companions/handler/menu_v2/winback/offer

# If in "place at home" mode, route to home placement instead
$execute if entity @s[tag=hc.placing] run return run function evercraft:companions/handler/home/do_place {slot:$(slot)}

# If in "place at guild" mode, route to guild placement instead
$execute if entity @s[tag=gc.placing] run return run function evercraft:companions/handler/guild/do_place {slot:$(slot)}

# If in "assign to journey sub-slot" mode (armed from an empty + head), route to sub-assignment instead
# of summoning. Sits AFTER the home/guild/placed/departed guards above (so an unavailable companion is
# rejected with its own message first) and BEFORE the active-pet unsummon check (so clicking the active
# pet here is caught by journey/assign's "can't journey your active companion" guard, not unsummoned).
$execute if entity @s[tag=companion.assign_sub] run return run function evercraft:companions/handler/menu_v2/do_assign_sub {slot:$(slot)}

# If the clicked slot is the already-active pet — unsummon instead of re-spawning
execute if entity @s[tag=companion.activepet] if score @s companion.activeslot = #abs_slot companion.menu run return run function evercraft:companions/handler/menu_v2/do_unsummon

# Save HP of previous active pet before switching
execute if entity @s[tag=companion.activepet] run function evercraft:companions/health/save

# Sync memories AND relationship of previous active pet back to marker before killing it
execute if entity @s[tag=companion.activepet] run function evercraft:companions/handler/active/sync_memories_to_marker
execute if entity @s[tag=companion.activepet] run function evercraft:companions/handler/active/sync_relationship_to_marker

# Kill existing pet entities (floating head + interaction + hp_label passenger)
# hp_label kill runs UNCONDITIONALLY (not gated on activepet) so orphan labels from prior
# death/strip cycles get swept on every fresh summon, not just when a pet was already active.
# Also kill any hp_label near the player REGARDLESS of companion.id — an orphan with a stale
# or unset companion.id (from older code paths or scoreboard wipes) would slip past the
# predicate kill. Joseph saw a "0♡" ghost stuck above the working ❤ X/Y label exactly
# because such an orphan persisted with no matching id.
kill @e[type=text_display,tag=companion.hp_label,predicate=evercraft:companions/check_id]
execute at @s run kill @e[type=text_display,tag=companion.hp_label,distance=..3]
execute if entity @s[tag=companion.activepet] run kill @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id]
execute if entity @s[tag=companion.activepet] run kill @e[type=interaction,tag=companion.petinteract,predicate=evercraft:companions/check_id]
# Clear evolution tags from previous pet
execute if entity @s[tag=companion.activepet] run function evercraft:companion_evolution/on_unsummon

# Clear any lingering level data from previous pet
scoreboard players reset #current_level companion.exp
scoreboard players reset #current_exp companion.exp
scoreboard players reset #exp_to_next_level companion.exp

# Set tags for pet spawn
tag @s add companion.activepet
tag @s add companion.owner

# Clean up any stale entities before summoning
kill @e[type=item_display, tag=companion.newpet]

# === FLOATING ENTITY COMPANION SPAWN ===
# Summon at PLAYER position (at @s), not at GUI interaction entity position
# teleport_duration:5 for smooth-but-tight following (was 12 — high values lag the RENDER up to
#   ~0.6s/~3 blocks behind the entity's true position while the player moves, so the synced
#   interaction hitbox below ends up ahead of where the pet visually appears → "chase the pet to feed it".
#   5t keeps the visual on top of the hitbox. Lower = tighter/snappier, higher = floatier/laggier. (2026-06-04)
# The head carries a text_display passenger (companion.hp_label) showing "❤ X/Y" below the floating name.
# Passenger translation Y is negative so it sits beneath the CustomName overlay.
execute at @s run summon item_display ~ ~0.3 ~ {teleport_duration:5, Tags:[companion.newpet, Pet, Companion], CustomNameVisible:1b, item_display:"ground", billboard:"center", transformation:{left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.883f,0.883f,0.883f]}, item:{id:"player_head", count:1b}, Passengers:[{id:"text_display", Tags:[companion.hp_label, companion.newhplabel, Pet], billboard:"center", shadow:1b, brightness:{block:15,sky:15}, text:[{text:"❤ ",color:"red"},{text:"...",color:"gray"}], transformation:{left_rotation:[0f,0f,0f,1f], right_rotation:[0f,0f,0f,1f], translation:[0f,-0.55f,0f], scale:[0.45f,0.45f,0.45f]}}]}

# Copy pet item data from storage to the head display
data modify entity @e[type=item_display, tag=companion.newpet, sort=nearest, limit=1] item set from storage evercraft:companions SelectedPet

# Set companion.id on head AND on its hp_label passenger so predicate lookups match
scoreboard players operation @e[type=item_display, tag=companion.newpet, sort=nearest, limit=1] companion.id = @s companion.id
scoreboard players operation @e[type=text_display, tag=companion.newhplabel, sort=nearest, limit=1] companion.id = @s companion.id
tag @e[type=text_display, tag=companion.newhplabel, sort=nearest, limit=1] remove companion.newhplabel

# Store absolute Pets[] index as active slot (used for unsummon detection and memory sync)
scoreboard players operation @s companion.activeslot = #abs_slot companion.menu

# Spawn interaction entity for petting/feeding (same Y as head, at player position)
# Hitbox history: 0.8→1.4 wide × 1.0 tall (2026-06-04) widened for click-reliability while the pet
#   drifts from the synced box; trimmed to 0.9 × 0.9 (2026-06-20) because the generous box was eating
#   melee swings in combat. The real swing fix is handler/active/movement tucking the pet BEHIND the
#   owner whenever they hold a weapon — this trim just tightens the click target the rest of the time.
#   Synced to the pet every tick by handler/active/movement. (Tunable: bump back up if petting feels finicky.)
execute at @s run summon interaction ~ ~0.3 ~ {width:0.9f, height:0.9f, response:1b, Tags:[companion.petinteract, companion.newinteract]}
scoreboard players operation @e[type=interaction, tag=companion.newinteract, limit=1] companion.id = @s companion.id
tag @e[type=interaction, tag=companion.newinteract, limit=1] remove companion.newinteract

# Set visibility if hidden
execute if entity @s[tag=companion.hidden] run data modify entity @e[type=item_display, tag=companion.newpet, sort=nearest, limit=1] view_range set value 0f

# Set custom name from item data
data modify entity @e[type=item_display, tag=companion.newpet, sort=nearest, limit=1] CustomName set from storage evercraft:companions SelectedPet.components."minecraft:custom_name"

# Run ability selector
function evercraft:companions/handler/active/abilities/companion_selector with entity @e[type=item_display, tag=companion.newpet, sort=nearest, limit=1] item.components."minecraft:profile".properties[{name:"name"}]

# Clean up temp tags
tag @e[type=item_display, tag=companion.newpet, sort=nearest, limit=1] remove companion.newpet
tag @s remove companion.owner

# Initialize companion HP system
function evercraft:companions/health/init

# Compute the ability-slot read-cache (companion.slots) at SUMMON time so the Eternal Codex (and anything
# else reading the cache) shows the correct natural-tier baseline immediately, instead of a stale 0 that
# only got recomputed the first time a chip/horn unlock ran load_slots. Mirrors skills/unlock_slot's 3-step
# sequence exactly (route signature → tier stats → load_slots). The head + its companion.id are already set
# above (lines ~98/101), so check_id matches and get_tier_stats/load_slots read THIS companion and its
# earned slots (custom_data.horn_slots). load_slots remains the sole writer of companion.slots.
data modify storage evercraft:companion_combat companion_name set from entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:profile".properties[{name:"name"}].signature
function evercraft:companions/combat/get_tier_stats
function evercraft:companions/skills/load_slots

# SP2 set-bond skill #5 (Vigor): +4 companion max HP if owned — runs AFTER health/init recomputes
# companion.maxhp, so it isn't overwritten. companion.bondskills was cached by companion_selector above.
function evercraft:companions/bond/apply_vigor

# Refresh the in-world ❤ X/Y label now that HP is initialized
function evercraft:companions/health/refresh_label

# Check if summoned companion is an evolved form
function evercraft:companion_evolution/on_summon

# Record "First Steps Together" memory if this pet has no memories yet
function evercraft:companions/memories/on_summon

# Close the menu
function evercraft:companions/handler/menu_v2/close

# Give Command Whistle on first-ever pet summon
# (run the first-summon HORN STANCE prompt BEFORE stamping has_whistle, so the `unless` gate matches)
execute unless entity @s[tag=companion.has_whistle] run function evercraft:companions/horn/prompt_stance
execute unless entity @s[tag=companion.has_whistle] run function evercraft:companions/combat/give_whistle
execute unless entity @s[tag=companion.has_whistle] run tag @s add companion.has_whistle

# Notify player
data modify storage evercraft:notify stage.c set value [{text:"Pet summoned!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
