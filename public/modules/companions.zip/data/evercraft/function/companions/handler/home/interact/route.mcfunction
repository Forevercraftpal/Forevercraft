# ============================================================
# Home Companion — Route interaction type
# Run as: owner player, at player position
# #hc_interact_slot hc.slot = slot of the interacted companion
# ============================================================

# Sneak + click → retrieve companion from home (regardless of held item)
execute if predicate evercraft:companions/is_sneaking run return run function evercraft:companions/handler/home/interact/retrieve_click

# Holding food → try feeding (only returns if food was valid)
execute unless items entity @s weapon.mainhand air if function evercraft:companions/handler/home/interact/feed run return 1

# Empty hand, or holding non-food item → pet
function evercraft:companions/handler/home/interact/pet
