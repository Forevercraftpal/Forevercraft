# SP5 — Rename: macro — confirm the rename. Run as player. Args: {name:"..."}. Centered NON-BOLD toast.
$data modify storage evercraft:notify stage.c set value [{text:"Renamed to ",color:"green"},{text:"$(name)",color:"gold"},{text:"!",color:"green"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
