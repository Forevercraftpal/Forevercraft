# SP5 — Journey: Sub-B in-flight status. Run as player. journey.mins = minutes-left.
data modify storage evercraft:companions journey.subname set value "Your companion"
execute store result storage evercraft:companions journey.journey_slot int 1 run scoreboard players get @s companion.jB_slot
execute in overworld run function evercraft:companions/journey/get_subname with storage evercraft:companions journey
function evercraft:companions/handler/menu_v2/journey/status_inflight_b_text with storage evercraft:companions journey
