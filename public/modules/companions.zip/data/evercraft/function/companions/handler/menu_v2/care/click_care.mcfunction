# SP5 — Care tab click dispatch (ec.bd_tab 5). Run as player in menu. Mirrors check_clicks/click_hub.
# Buttons: Pet · Feed · Call · Skills · rename (name) · Take Out · prev/next companion.

scoreboard players operation #Search companion.id = @s companion.id

# Is the focused companion the live active MAIN? (focus == activeslot AND a pet is summoned)
scoreboard players set #cc_is_main ec.temp 0
execute if entity @s[tag=companion.activepet] if score @s companion.careidx = @s companion.activeslot run scoreboard players set #cc_is_main ec.temp 1

# === Pet ===
execute as @e[type=interaction,tag=companion.care_pet_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/care/do_pet
execute as @e[type=interaction,tag=companion.care_pet_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === Feed (left-click = quick snack; the right-click-with-food path is also handled in do_feed) ===
execute as @e[type=interaction,tag=companion.care_feed_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/care/do_feed
execute as @e[type=interaction,tag=companion.care_feed_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === Call (to-main / dismiss toggle) ===
execute as @e[type=interaction,tag=companion.care_call_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/care/call
execute as @e[type=interaction,tag=companion.care_call_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === Skills → open the Skills tab ===
execute as @e[type=interaction,tag=companion.care_skills_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/open_tab_skills
execute as @e[type=interaction,tag=companion.care_skills_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === Name → rename flow ===
execute as @e[type=interaction,tag=companion.care_nameclick,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/care/rename/start
execute as @e[type=interaction,tag=companion.care_nameclick,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === Take Out → place the head into the player's hand (placeable head item) ===
execute as @e[type=interaction,tag=companion.care_takeout_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/placed/take_out
execute as @e[type=interaction,tag=companion.care_takeout_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === prev / next companion ===
execute as @e[type=interaction,tag=companion.care_prev_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/care/cycle_prev
execute as @e[type=interaction,tag=companion.care_prev_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.care_next_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/care/cycle_next
execute as @e[type=interaction,tag=companion.care_next_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=companion.care_call_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Call",b:"Calls your companion to your side."}
execute as @e[type=interaction,tag=companion.care_call_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.care_pet_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Pet",b:"Pets your companion — a little affection, a little bond."}
execute as @e[type=interaction,tag=companion.care_pet_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.care_feed_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Feed",b:"Feeds your companion from the food you carry."}
execute as @e[type=interaction,tag=companion.care_feed_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.care_nameclick,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Rename",b:"Begins renaming your companion."}
execute as @e[type=interaction,tag=companion.care_nameclick,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.care_takeout_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Take Out",b:"Picks your placed companion back up."}
execute as @e[type=interaction,tag=companion.care_takeout_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.care_skills_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Skills",b:"Opens the bond skills tab."}
execute as @e[type=interaction,tag=companion.care_skills_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.care_prev_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous Pet",b:"Cycles care to the previous companion."}
execute as @e[type=interaction,tag=companion.care_prev_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.care_next_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next Pet",b:"Cycles care to the next companion."}
execute as @e[type=interaction,tag=companion.care_next_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
