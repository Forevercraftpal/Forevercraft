# SP8 — Wayfarer Track: click detection on tab 9. Run as player (from tick when ec.bd_tab == 9).
# Routes: ◀/▶ page arrows → page change + re-render; a node cell → track/claim with the stamped node.

scoreboard players operation #Search companion.id = @s companion.id
scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# === Page prev ===
scoreboard players set #wf_pg ec.temp 0
execute as @e[type=interaction,tag=companion.wf_pageprev_click,predicate=evercraft:companions/check_id,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run scoreboard players set #wf_pg ec.temp 1
execute as @e[type=interaction,tag=companion.wf_pageprev_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute if score #wf_pg ec.temp matches 1 if score @s companion.wf_page matches 1.. run scoreboard players remove @s companion.wf_page 1
execute if score #wf_pg ec.temp matches 1 run function evercraft:companions/handler/menu_v2/wayfarer/refresh

# === Page next ===
scoreboard players set #wf_pg ec.temp 0
execute as @e[type=interaction,tag=companion.wf_pagenext_click,predicate=evercraft:companions/check_id,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run scoreboard players set #wf_pg ec.temp 1
execute as @e[type=interaction,tag=companion.wf_pagenext_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
# Page-next clamp: max page = ceil(node_max/10) - 1 (= 24 at 250 nodes). Allow next only while below it.
scoreboard players operation #wf_maxpg ec.temp = #wf_node_max ec.const
scoreboard players add #wf_maxpg ec.temp 9
scoreboard players operation #wf_maxpg ec.temp /= #10 ec.const
scoreboard players remove #wf_maxpg ec.temp 1
execute if score #wf_pg ec.temp matches 1 if score @s companion.wf_page < #wf_maxpg ec.temp run scoreboard players add @s companion.wf_page 1
execute if score #wf_pg ec.temp matches 1 run function evercraft:companions/handler/menu_v2/wayfarer/refresh

# === [✦ Claim Page] → claim every unlocked, unclaimed node on the current page (RE-P8,
#     Joseph verdict 2026-06-10). Mirrors the page-arrow detection idiom. ===
scoreboard players set #wf_ca ec.temp 0
execute as @e[type=interaction,tag=companion.wf_claimall_click,predicate=evercraft:companions/check_id,limit=1] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run scoreboard players set #wf_ca ec.temp 1
execute as @e[type=interaction,tag=companion.wf_claimall_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute if score #wf_ca ec.temp matches 1 run function evercraft:companions/track/claim_page

# === Node cell click → claim the stamped node ===
scoreboard players set #wf_claimidx ec.temp 0
execute as @e[type=interaction,tag=companion.wf_cell_click,predicate=evercraft:companions/check_id] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run scoreboard players operation #wf_claimidx ec.temp = @s companion.wf_clicknode
execute as @e[type=interaction,tag=companion.wf_cell_click,predicate=evercraft:companions/check_id] if data entity @s interaction run data remove entity @s interaction
execute if score #wf_claimidx ec.temp matches 1.. run function evercraft:companions/track/claim
# Re-render after a claim so the cell flips to claimed (state changes are score-driven, render reads them).
execute if score #wf_claimidx ec.temp matches 1.. run function evercraft:companions/handler/menu_v2/wayfarer/refresh

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=companion.wf_cell_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Wayfarer Reward",b:"Claims this Wayfarer Track cell once its points are reached."}
execute as @e[type=interaction,tag=companion.wf_cell_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.wf_claimall_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Claim All",b:"Claims every Wayfarer reward your points have reached."}
execute as @e[type=interaction,tag=companion.wf_claimall_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.wf_pageprev_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Previous Page",b:"Flips to the previous Wayfarer page."}
execute as @e[type=interaction,tag=companion.wf_pageprev_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.wf_pagenext_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Next Page",b:"Flips to the next Wayfarer page."}
execute as @e[type=interaction,tag=companion.wf_pagenext_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
