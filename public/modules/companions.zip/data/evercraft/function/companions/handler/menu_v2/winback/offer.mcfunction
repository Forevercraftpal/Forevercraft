# SP3 Win-back — OFFER. Run as @s = player (from spawn_selected_companion's departed guard, which runs
# `as @a[tag=companion.inmenuv2,predicate=check_id]`). The clicked companion is DEPARTED; instead of
# summoning, we present the win-back offer. Read-only on the collection — NOTHING is changed on the
# companion here; the departed companion stays exactly as-is until a Notch apple is actually consumed.

scoreboard players operation #Search companion.id = @s companion.id

# --- Second-click consume gate ---
# If an offer is already live for THIS same departed slot AND the player is holding a Notch apple in the
# main hand, this click is the "hand over the apple" action → route to restore (path A: GUI click +
# held-item check, no advancement, no /trigger). Mainhand-only mirrors do_restore's mainhand-priority.
execute if entity @s[tag=companion.wb_pending] if score @s companion.wb_slot = #abs_slot companion.menu if predicate evercraft:companions/winback/holding_notch_apple run return run function evercraft:companions/handler/menu_v2/winback/restore

# Cache the pending win-back target Pets[] index (the absolute slot computed in spawn_selected_companion).
scoreboard players operation @s companion.wb_slot = #abs_slot companion.menu

# Cache the clicked pet's display name for the offer + reunion copy (custom_name component, interpret).
data modify storage evercraft:companions winback.cname set from storage evercraft:companions SelectedPet.components."minecraft:custom_name"

# Latch the live offer + arm the auto-expiry timer (~30s). The winback expiry tick decrements wb_timer
# while wb_pending is held; reaching 0 (or closing the menu) drops the latch. The departed flag persists
# regardless, so the offer is always re-openable by clicking the slot again — nothing is lost on expiry.
tag @s add companion.wb_pending
scoreboard players operation @s companion.wb_timer = #WB_TIMER companion.calc

# Offer dialogue (action-bar, NON-BOLD per popup-law) — two sequenced frames.
scoreboard players set #ndur ec.temp 55
data modify storage evercraft:notify stage.c set value [{nbt:"winback.cname",storage:"evercraft:companions",interpret:true},{text:" seems to have wandered off...",color:"gray",italic:true}]
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Hold a Notch Apple and click them again to win them over.",color:"gold"}]
function evercraft:util/notify/emit

# Soft cue (reuses reminder_player's chime lineage). Keep the menu open so the apple can be handed over.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.0
