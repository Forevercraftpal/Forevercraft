# SP5 — Journey tab click dispatch (ec.bd_tab 6). Run as player in menu. Mirrors check_clicks.
# Theme buttons → set ec.journey_type (SP4 contract). Send A/B → set companion.jrnyslot + ec.journey_send,
# then drive journey/dispatch_send synchronously (so the in-flight status renders immediately) + refresh.

scoreboard players operation #Search companion.id = @s companion.id

# === Theme picks → set ec.journey_type (1-5) ===
execute as @e[type=interaction,tag=companion.jr_theme1_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/journey/pick_theme1
execute as @e[type=interaction,tag=companion.jr_theme1_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.jr_theme2_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/journey/pick_theme2
execute as @e[type=interaction,tag=companion.jr_theme2_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.jr_theme3_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/journey/pick_theme3
execute as @e[type=interaction,tag=companion.jr_theme3_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.jr_theme4_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/journey/pick_theme4
execute as @e[type=interaction,tag=companion.jr_theme4_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=interaction,tag=companion.jr_theme5_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/journey/pick_theme5
execute as @e[type=interaction,tag=companion.jr_theme5_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === Send Sub A ===
execute as @e[type=interaction,tag=companion.jr_a_send_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/journey/send_a
execute as @e[type=interaction,tag=companion.jr_a_send_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# === Send Sub B ===
execute as @e[type=interaction,tag=companion.jr_b_send_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction on target run function evercraft:companions/handler/menu_v2/journey/send_b
execute as @e[type=interaction,tag=companion.jr_b_send_click,predicate=evercraft:companions/check_id,limit=1] if data entity @s interaction run data remove entity @s interaction

# ===== INSPECT (left-click = what does this button do?) — gui/inspect pattern 2026-06-11 =====
execute as @e[type=interaction,tag=companion.jr_theme1_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Journey Theme 1",b:"Right-click to pick theme 1 for this expedition — the theme name is on the row label."}
execute as @e[type=interaction,tag=companion.jr_theme1_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.jr_theme2_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Journey Theme 2",b:"Right-click to pick theme 2 for this expedition — the theme name is on the row label."}
execute as @e[type=interaction,tag=companion.jr_theme2_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.jr_theme3_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Journey Theme 3",b:"Right-click to pick theme 3 for this expedition — the theme name is on the row label."}
execute as @e[type=interaction,tag=companion.jr_theme3_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.jr_theme4_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Journey Theme 4",b:"Right-click to pick theme 4 for this expedition — the theme name is on the row label."}
execute as @e[type=interaction,tag=companion.jr_theme4_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.jr_theme5_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Journey Theme 5",b:"Right-click to pick theme 5 for this expedition — the theme name is on the row label."}
execute as @e[type=interaction,tag=companion.jr_theme5_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.jr_a_send_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Send on Quick Journey",b:"Right-click to send your companion on the quick journey option — it returns later with the finds. The journey timing and rewards are on the row above."}
execute as @e[type=interaction,tag=companion.jr_a_send_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
execute as @e[type=interaction,tag=companion.jr_b_send_click,predicate=evercraft:companions/check_id] if data entity @s attack on attacker run function evercraft:gui/inspect/card {t:"Send on Long Journey",b:"Right-click to send your companion on the long journey option — it returns later with the finds. The journey timing and rewards are on the row above."}
execute as @e[type=interaction,tag=companion.jr_b_send_click,predicate=evercraft:companions/check_id] if data entity @s attack run data remove entity @s attack
