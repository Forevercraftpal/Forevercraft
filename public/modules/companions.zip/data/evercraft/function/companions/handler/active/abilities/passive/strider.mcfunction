# Strider Pet Passive Abilities
# - Effect: fire_resistance

tag @s add companion.strider

effect give @s fire_resistance infinite 0 true

