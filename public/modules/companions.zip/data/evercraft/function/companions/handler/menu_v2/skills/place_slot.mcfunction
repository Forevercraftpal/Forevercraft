# SP5 — Skills: place one slot's icon + hitbox at its grid cell. Run as player, facing-anchor context.
# Reads skills.{col,row,icon,color,idx} from storage. col 0/1/2 → X +0.55/0/-0.55 ; row 0/1 → Y 1.62/1.32.
# Spawns the icon text_display (companion.skillcell) + a companion.skill_btn interaction stamped
# companion.skillidx (= the global 0-11 slot index this cell represents).

# --- Row 0 (Y 1.62 icon / 1.58 hitbox) ---
execute if data storage evercraft:companions {skills:{col:0,row:0}} rotated ~ 0 positioned ^ ^1.62 ^1.74 positioned ^0.55 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.skillcellnew"],billboard:"center",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.46f,0.46f,0.46f]}}
execute if data storage evercraft:companions {skills:{col:0,row:0}} rotated ~ 0 positioned ^ ^1.58 ^1.76 positioned ^0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.skill_btn","companion.skillnew"],width:0.30f,height:0.18f,response:1b}
execute if data storage evercraft:companions {skills:{col:1,row:0}} rotated ~ 0 positioned ^ ^1.62 ^1.74 positioned ^0 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.skillcellnew"],billboard:"center",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.46f,0.46f,0.46f]}}
execute if data storage evercraft:companions {skills:{col:1,row:0}} rotated ~ 0 positioned ^ ^1.58 ^1.76 positioned ^0 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.skill_btn","companion.skillnew"],width:0.30f,height:0.18f,response:1b}
execute if data storage evercraft:companions {skills:{col:2,row:0}} rotated ~ 0 positioned ^ ^1.62 ^1.74 positioned ^-0.55 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.skillcellnew"],billboard:"center",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.46f,0.46f,0.46f]}}
execute if data storage evercraft:companions {skills:{col:2,row:0}} rotated ~ 0 positioned ^ ^1.58 ^1.76 positioned ^-0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.skill_btn","companion.skillnew"],width:0.30f,height:0.18f,response:1b}

# --- Row 1 (Y 1.32 icon / 1.28 hitbox) ---
execute if data storage evercraft:companions {skills:{col:0,row:1}} rotated ~ 0 positioned ^ ^1.32 ^1.74 positioned ^0.55 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.skillcellnew"],billboard:"center",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.46f,0.46f,0.46f]}}
execute if data storage evercraft:companions {skills:{col:0,row:1}} rotated ~ 0 positioned ^ ^1.28 ^1.76 positioned ^0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.skill_btn","companion.skillnew"],width:0.30f,height:0.18f,response:1b}
execute if data storage evercraft:companions {skills:{col:1,row:1}} rotated ~ 0 positioned ^ ^1.32 ^1.74 positioned ^0 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.skillcellnew"],billboard:"center",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.46f,0.46f,0.46f]}}
execute if data storage evercraft:companions {skills:{col:1,row:1}} rotated ~ 0 positioned ^ ^1.28 ^1.76 positioned ^0 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.skill_btn","companion.skillnew"],width:0.30f,height:0.18f,response:1b}
execute if data storage evercraft:companions {skills:{col:2,row:1}} rotated ~ 0 positioned ^ ^1.32 ^1.74 positioned ^-0.55 ^0 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.menuelement","companion.tab_content","companion.skillcellnew"],billboard:"center",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.46f,0.46f,0.46f]}}
execute if data storage evercraft:companions {skills:{col:2,row:1}} rotated ~ 0 positioned ^ ^1.28 ^1.76 positioned ^-0.55 ^0 ^0 run summon interaction ~ ~ ~ {Tags:["companion.menuelement","companion.tab_content","companion.skill_btn","companion.skillnew"],width:0.30f,height:0.18f,response:1b}

# Write the icon text onto the just-spawned cell (skillcellnew = only THIS cell), then stamp ids +
# skillidx, convert the build tags to permanent (companion.skillcell), and clear the build tags.
function evercraft:companions/handler/menu_v2/skills/place_slot_text with storage evercraft:companions skills
scoreboard players operation #Search companion.id = @s companion.id
scoreboard players operation @e[type=text_display,tag=companion.skillcellnew,distance=..5] companion.id = @s companion.id
scoreboard players operation @e[type=interaction,tag=companion.skillnew,distance=..5] companion.id = @s companion.id
execute store result score @n[type=interaction,tag=companion.skillnew,distance=..5] companion.skillidx run data get storage evercraft:companions skills.idx
tag @e[type=text_display,tag=companion.skillcellnew,distance=..5] add companion.skillcell
tag @e[type=text_display,tag=companion.skillcellnew,distance=..5] remove companion.skillcellnew
tag @e[type=interaction,tag=companion.skillnew,distance=..5] remove companion.skillnew
