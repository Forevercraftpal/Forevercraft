# Read Pet Data — runs as the companion item_display entity
# OPT: Caches all profile properties to storage in 1 entity resolution
# (was ~12 separate predicate selector resolutions)

# Level
data modify storage evercraft:companions info.level_str set string entity @s item.components."minecraft:profile".properties[{name:"level"}].value

# Current EXP
data modify storage evercraft:companions info.exp_str set string entity @s item.components."minecraft:profile".properties[{name:"exp"}].value

# EXP needed for next level (stored in signature field)
data modify storage evercraft:companions info.exp_next_str set string entity @s item.components."minecraft:profile".properties[{name:"exp"}].signature

# Display name
data modify storage evercraft:companions info.name set from entity @s item.components."minecraft:profile".properties[{name:"name"}].value

# Memory bitfield (check existence + read)
execute store result score #has_memories companion.calc if data entity @s item.components."minecraft:profile".properties[{name:"memories"}]
execute if score #has_memories companion.calc matches 1 run data modify storage evercraft:companions info.mem_str set string entity @s item.components."minecraft:profile".properties[{name:"memories"}].value

# Relationship points (check existence + read)
execute store result score #has_relationship companion.calc if data entity @s item.components."minecraft:profile".properties[{name:"relationship"}]
execute if score #has_relationship companion.calc matches 1 run data modify storage evercraft:companions info.rel_str set string entity @s item.components."minecraft:profile".properties[{name:"relationship"}].value
