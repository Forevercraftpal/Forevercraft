# 2026-06-06 — Home view: MAIN empty placeholder (no active main companion). A CENTERED "+ Empty"
# assign label (no head — blank slots are invisible, no Steve player_head). Clicking it (headidx 0)
# opens the roster to summon an active companion. Run as player. Tagged companion.homehead so teardown/close reaps it.
# Mirrors spawn_home_main's center position so the empty slot reads as the (centered) main slot.

execute rotated ~ 0 positioned ^ ^1.78 ^1.74 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["companion.homehead","companion.menuelement","companion.tab_content","companion.homemainname"],billboard:"center",text:[{text:"+ ",color:"dark_gray"},{text:"Empty",color:"gray",italic:true}],background:0,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.30f,0.30f,0.30f]}}

execute rotated ~ 0 positioned ^ ^1.76 ^1.70 run summon interaction ~ ~ ~ {Tags:["companion.headslot","companion.menuelement","companion.tab_content","companion.homemainclick"],width:0.34f,height:0.30f,response:1b}
scoreboard players set @n[type=interaction,tag=companion.homemainclick,distance=..5] companion.headidx 0

tag @e[type=text_display,tag=companion.homemainname,distance=..5] remove companion.homemainname
tag @e[type=interaction,tag=companion.homemainclick,distance=..5] remove companion.homemainclick
