# ============================================================
# Home Companion — Update HomePets[] entry with synced item data
# Run as: context with #Search companion.id set
# Requires: storage evercraft:companions home.sync_item, home.sync_slot
# ============================================================

# Update HomePets[] — find entry with matching slot and replace its item
# Check each possible index (max 5)
execute store result score #hc_target_slot hc.slot run scoreboard players get #hc_sync_slot hc.slot

execute if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[0] run execute store result score #hc_check hc.slot run data get entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[0].slot
execute if score #hc_check hc.slot = #hc_target_slot hc.slot run data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[0].item set from storage evercraft:companions home.sync_item

execute if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[1] run execute store result score #hc_check hc.slot run data get entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[1].slot
execute if score #hc_check hc.slot = #hc_target_slot hc.slot run data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[1].item set from storage evercraft:companions home.sync_item

execute if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[2] run execute store result score #hc_check hc.slot run data get entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[2].slot
execute if score #hc_check hc.slot = #hc_target_slot hc.slot run data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[2].item set from storage evercraft:companions home.sync_item

execute if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[3] run execute store result score #hc_check hc.slot run data get entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[3].slot
execute if score #hc_check hc.slot = #hc_target_slot hc.slot run data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[3].item set from storage evercraft:companions home.sync_item

execute if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[4] run execute store result score #hc_check hc.slot run data get entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[4].slot
execute if score #hc_check hc.slot = #hc_target_slot hc.slot run data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.HomePets[4].item set from storage evercraft:companions home.sync_item

# Also sync RP to the Pets[] entry (uses name-based scan)
# The Pets[] entry's profile relationship value should match the entity's
data modify storage evercraft:companions home.scan_name set from storage evercraft:companions home.sync_name
function evercraft:companions/handler/home/sync_rp_to_pets with storage evercraft:companions home
