# Cragmite Pet Passive Abilities
# - Sure-Footed: Step height (0.645 → 1.5)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.cragmite

# Sure-Footed: Step height (0.645 → 1.5)
execute if score #value companion.calc matches 1..7 run return run attribute @s step_height base set 0.671
execute if score #value companion.calc matches 8..12 run return run attribute @s step_height base set 0.723
execute if score #value companion.calc matches 13..17 run return run attribute @s step_height base set 0.766
execute if score #value companion.calc matches 18..22 run return run attribute @s step_height base set 0.809
execute if score #value companion.calc matches 23..27 run return run attribute @s step_height base set 0.852
execute if score #value companion.calc matches 28..32 run return run attribute @s step_height base set 0.895
execute if score #value companion.calc matches 33..37 run return run attribute @s step_height base set 0.939
execute if score #value companion.calc matches 38..42 run return run attribute @s step_height base set 0.982
execute if score #value companion.calc matches 43..47 run return run attribute @s step_height base set 1.025
execute if score #value companion.calc matches 48..52 run return run attribute @s step_height base set 1.068
execute if score #value companion.calc matches 53..57 run return run attribute @s step_height base set 1.111
execute if score #value companion.calc matches 58..62 run return run attribute @s step_height base set 1.155
execute if score #value companion.calc matches 63..67 run return run attribute @s step_height base set 1.198
execute if score #value companion.calc matches 68..72 run return run attribute @s step_height base set 1.241
execute if score #value companion.calc matches 73..77 run return run attribute @s step_height base set 1.284
execute if score #value companion.calc matches 78..82 run return run attribute @s step_height base set 1.327
execute if score #value companion.calc matches 83..87 run return run attribute @s step_height base set 1.37
execute if score #value companion.calc matches 88..92 run return run attribute @s step_height base set 1.414
execute if score #value companion.calc matches 93..97 run return run attribute @s step_height base set 1.457
execute if score #value companion.calc matches 98..100 run return run attribute @s step_height base set 1.491
