# Companion Catalogue — Delayed Item Restore
# consume_item fires before item removal — this runs 1 tick later to give item back.
# Restores to the same hand the player was holding it in.
#
# AU5-P3.2 (Joseph 2026-05-30): Race-hardened. Pre-fix the `loot replace weapon.<hand>` ran
# unconditionally; if the player swapped to another item in the 1-tick gap between consume_item
# (which removes the menu item from the target hand) and this fn, the loot replace would destroy
# whatever they swapped to. Now the replace only fires if the target hand is currently empty
# (`if items entity @s weapon.<hand> minecraft:air`) — meaning consume_item's removal is still
# the most recent change. Players who swap keep their swapped item; the menu item is forfeit,
# which is the correct intent (they explicitly grabbed another item).

tag @s remove companion.restore_menu

# Restore to correct hand — only if that hand is still empty (no swap happened in the 1-tick gap)
execute if entity @s[tag=companion.restore_mainhand] if items entity @s weapon.mainhand minecraft:air run loot replace entity @s weapon.mainhand loot evercraft:companions/menu
execute unless entity @s[tag=companion.restore_mainhand] if items entity @s weapon.offhand minecraft:air run loot replace entity @s weapon.offhand loot evercraft:companions/menu
tag @s remove companion.restore_mainhand
