# ============================================================
# Active Companion — Passive RP gain (gametime-based)
# Run as: player with companion.activepet tag
# +1 RP every 5 minutes (6000 ticks)
# ============================================================

# Get current gametime
execute store result score #now hc.rp_timer run time query gametime

# Initialize timer if not set
execute unless score @s hc.active_rp matches 0.. run scoreboard players operation @s hc.active_rp = #now hc.rp_timer

# Calculate elapsed time
scoreboard players operation #elapsed hc.rp_timer = #now hc.rp_timer
scoreboard players operation #elapsed hc.rp_timer -= @s hc.active_rp

# Check if 5 minutes (6000 ticks) have passed
execute unless score #elapsed hc.rp_timer matches 6000.. run return fail

# Update timer to now
scoreboard players operation @s hc.active_rp = #now hc.rp_timer

# Load current RP from active companion
function evercraft:companions/handler/relationship/load_rp

# Store old level for comparison
scoreboard players operation #oldLevel companion.calc = @s companion.rellevel

# Add 1 RP, cap at 5000
scoreboard players add @s companion.rp 1

# Home Ecosystem: Companion gains +1 bonus RP at home (pets love being home!)
execute if score @s hs.in_zone matches 1 run scoreboard players add @s companion.rp 1

execute if score @s companion.rp > #5000 companion.calc run scoreboard players set @s companion.rp 5000

# Save RP
function evercraft:companions/handler/relationship/save_rp

# Recalculate level
function evercraft:companions/handler/relationship/load_rp

# Check for level up
execute unless score @s companion.rellevel = #oldLevel companion.calc run function evercraft:companions/handler/relationship/level_up
