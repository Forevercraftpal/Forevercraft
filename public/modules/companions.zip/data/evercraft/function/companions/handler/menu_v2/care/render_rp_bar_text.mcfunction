# SP5 — Macro: write the RP-bar text onto the freshly-spawned bar text_display.
# Args: {bar:"▓▓░…", rpnum:N}. Run as player (the bar entity is @n near the player).
$data modify entity @n[type=text_display,tag=companion.care_rpbar,distance=..5] text set value [{text:"$(bar)",color:"red"},{text:"  $(rpnum) / 5000",color:"gray"}]
