# Bulwark Pet Passive Abilities (Home)

# [Home skip: level read from active] data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
# [Home skip: level init] scoreboard players set #value companion.calc 0
# [Home skip: level convert] function evercraft:companions/handler/math/string_to_int

tag @s add companion.bulwark

# Iron Stance: KB res (0.05 → 1.0)
$execute if score #value companion.calc matches 1..7 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.079 add_value
$execute if score #value companion.calc matches 8..12 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.136 add_value
$execute if score #value companion.calc matches 13..17 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.184 add_value
$execute if score #value companion.calc matches 18..22 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.232 add_value
$execute if score #value companion.calc matches 23..27 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.28 add_value
$execute if score #value companion.calc matches 28..32 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.328 add_value
$execute if score #value companion.calc matches 33..37 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.376 add_value
$execute if score #value companion.calc matches 38..42 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.424 add_value
$execute if score #value companion.calc matches 43..47 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.472 add_value
$execute if score #value companion.calc matches 48..52 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.52 add_value
$execute if score #value companion.calc matches 53..57 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.568 add_value
$execute if score #value companion.calc matches 58..62 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.616 add_value
$execute if score #value companion.calc matches 63..67 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.664 add_value
$execute if score #value companion.calc matches 68..72 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.712 add_value
$execute if score #value companion.calc matches 73..77 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.76 add_value
$execute if score #value companion.calc matches 78..82 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.808 add_value
$execute if score #value companion.calc matches 83..87 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.856 add_value
$execute if score #value companion.calc matches 88..92 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.904 add_value
$execute if score #value companion.calc matches 93..97 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.952 add_value
$execute if score #value companion.calc matches 98..100 run attribute @s knockback_resistance modifier add evercraft:home/slot$(ability_slot)/knockback_resistance 0.99 add_value
