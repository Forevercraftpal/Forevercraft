# SP3 — gray-out a single catalogue grid slot if its companion has DEPARTED. Run as @s = player in
# the menu (#Search companion.id set by caller). Macro: {n} — slot index 0..47.
# Render-time only: reads MenuDisplay[$(n)].custom_data.departed (the display copy mirrors the source
# Pets[idx] flag, copied by set_items/refresh_slots) and applies a dim brightness silhouette to the
# slotN item_display, else clears the override back to ambient lighting (un-gray on win-back/refresh).
# Touches NO source Pets[] data. brightness is proven on this exact entity class (hp_label passenger).
$execute if data storage evercraft:companions MenuDisplay[$(n)].components."minecraft:custom_data".departed as @e[type=item_display,tag=companion.slot$(n),predicate=evercraft:companions/check_id,limit=1] run data modify entity @s brightness set value {block:0,sky:0}
$execute unless data storage evercraft:companions MenuDisplay[$(n)].components."minecraft:custom_data".departed as @e[type=item_display,tag=companion.slot$(n),predicate=evercraft:companions/check_id,limit=1] run data remove entity @s brightness
