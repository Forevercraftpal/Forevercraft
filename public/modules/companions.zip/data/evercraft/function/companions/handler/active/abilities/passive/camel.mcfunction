# Camel Pet Passive Abilities
# - Desert Stride: Step height (0.6 → 1.5)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.camel

# Desert Stride: Step height (0.6 → 1.5)
execute if score #value companion.calc matches 1..7 run return run attribute @s step_height base set 0.627
execute if score #value companion.calc matches 8..12 run return run attribute @s step_height base set 0.682
execute if score #value companion.calc matches 13..17 run return run attribute @s step_height base set 0.727
execute if score #value companion.calc matches 18..22 run return run attribute @s step_height base set 0.773
execute if score #value companion.calc matches 23..27 run return run attribute @s step_height base set 0.818
execute if score #value companion.calc matches 28..32 run return run attribute @s step_height base set 0.864
execute if score #value companion.calc matches 33..37 run return run attribute @s step_height base set 0.909
execute if score #value companion.calc matches 38..42 run return run attribute @s step_height base set 0.955
execute if score #value companion.calc matches 43..47 run return run attribute @s step_height base set 1.0
execute if score #value companion.calc matches 48..52 run return run attribute @s step_height base set 1.045
execute if score #value companion.calc matches 53..57 run return run attribute @s step_height base set 1.091
execute if score #value companion.calc matches 58..62 run return run attribute @s step_height base set 1.136
execute if score #value companion.calc matches 63..67 run return run attribute @s step_height base set 1.182
execute if score #value companion.calc matches 68..72 run return run attribute @s step_height base set 1.227
execute if score #value companion.calc matches 73..77 run return run attribute @s step_height base set 1.273
execute if score #value companion.calc matches 78..82 run return run attribute @s step_height base set 1.318
execute if score #value companion.calc matches 83..87 run return run attribute @s step_height base set 1.364
execute if score #value companion.calc matches 88..92 run return run attribute @s step_height base set 1.409
execute if score #value companion.calc matches 93..97 run return run attribute @s step_height base set 1.455
execute if score #value companion.calc matches 98..100 run return run attribute @s step_height base set 1.491
