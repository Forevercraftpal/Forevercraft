# SP5 — Skills: macro — write the icon onto the just-spawned cell (companion.skillcellnew). Run as player.
# Args: {icon:"★/✦/🔒", color:"..."}. Only the fresh cell carries skillcellnew, so this targets one cell.
$data modify entity @n[type=text_display,tag=companion.skillcellnew,distance=..5] text set value [{text:"$(icon)",color:"$(color)"}]
