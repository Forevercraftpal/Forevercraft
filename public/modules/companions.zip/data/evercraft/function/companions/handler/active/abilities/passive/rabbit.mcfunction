# Grasshopper Pet Passive Abilities
# - Spring Legs: Jump strength (0.43 → 1.01)
# - Spring Legs: Safe fall (6 → 13)

data modify storage evercraft:companions math.string set string entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:profile".properties[{name:"level"}].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int

tag @s add companion.grasshopper

# Spring Legs: Jump strength (0.43 → 1.01)
execute if score #value companion.calc matches 1..7 run attribute @s jump_strength base set 0.448
execute if score #value companion.calc matches 8..12 run attribute @s jump_strength base set 0.483
execute if score #value companion.calc matches 13..17 run attribute @s jump_strength base set 0.512
execute if score #value companion.calc matches 18..22 run attribute @s jump_strength base set 0.541
execute if score #value companion.calc matches 23..27 run attribute @s jump_strength base set 0.571
execute if score #value companion.calc matches 28..32 run attribute @s jump_strength base set 0.6
execute if score #value companion.calc matches 33..37 run attribute @s jump_strength base set 0.629
execute if score #value companion.calc matches 38..42 run attribute @s jump_strength base set 0.658
execute if score #value companion.calc matches 43..47 run attribute @s jump_strength base set 0.688
execute if score #value companion.calc matches 48..52 run attribute @s jump_strength base set 0.717
execute if score #value companion.calc matches 53..57 run attribute @s jump_strength base set 0.746
execute if score #value companion.calc matches 58..62 run attribute @s jump_strength base set 0.776
execute if score #value companion.calc matches 63..67 run attribute @s jump_strength base set 0.805
execute if score #value companion.calc matches 68..72 run attribute @s jump_strength base set 0.834
execute if score #value companion.calc matches 73..77 run attribute @s jump_strength base set 0.864
execute if score #value companion.calc matches 78..82 run attribute @s jump_strength base set 0.893
execute if score #value companion.calc matches 83..87 run attribute @s jump_strength base set 0.922
execute if score #value companion.calc matches 88..92 run attribute @s jump_strength base set 0.951
execute if score #value companion.calc matches 93..97 run attribute @s jump_strength base set 0.981
execute if score #value companion.calc matches 98..100 run attribute @s jump_strength base set 1.004

# Spring Legs: Safe fall (6 → 13)
execute if score #value companion.calc matches 1..7 run return run attribute @s safe_fall_distance base set 6.212
execute if score #value companion.calc matches 8..12 run return run attribute @s safe_fall_distance base set 6.636
execute if score #value companion.calc matches 13..17 run return run attribute @s safe_fall_distance base set 6.99
execute if score #value companion.calc matches 18..22 run return run attribute @s safe_fall_distance base set 7.343
execute if score #value companion.calc matches 23..27 run return run attribute @s safe_fall_distance base set 7.697
execute if score #value companion.calc matches 28..32 run return run attribute @s safe_fall_distance base set 8.051
execute if score #value companion.calc matches 33..37 run return run attribute @s safe_fall_distance base set 8.404
execute if score #value companion.calc matches 38..42 run return run attribute @s safe_fall_distance base set 8.758
execute if score #value companion.calc matches 43..47 run return run attribute @s safe_fall_distance base set 9.111
execute if score #value companion.calc matches 48..52 run return run attribute @s safe_fall_distance base set 9.465
execute if score #value companion.calc matches 53..57 run return run attribute @s safe_fall_distance base set 9.818
execute if score #value companion.calc matches 58..62 run return run attribute @s safe_fall_distance base set 10.172
execute if score #value companion.calc matches 63..67 run return run attribute @s safe_fall_distance base set 10.525
execute if score #value companion.calc matches 68..72 run return run attribute @s safe_fall_distance base set 10.879
execute if score #value companion.calc matches 73..77 run return run attribute @s safe_fall_distance base set 11.232
execute if score #value companion.calc matches 78..82 run return run attribute @s safe_fall_distance base set 11.586
execute if score #value companion.calc matches 83..87 run return run attribute @s safe_fall_distance base set 11.939
execute if score #value companion.calc matches 88..92 run return run attribute @s safe_fall_distance base set 12.293
execute if score #value companion.calc matches 93..97 run return run attribute @s safe_fall_distance base set 12.646
execute if score #value companion.calc matches 98..100 run return run attribute @s safe_fall_distance base set 12.929
