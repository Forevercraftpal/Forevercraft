scoreboard players operation #Search companion.id = @s companion.id

execute as @s[tag=companion.endwalker] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[9].extra[{text:"180"}] run return run function evercraft:companions/handler/active/abilities/trigger/blue_dragon

execute as @s[tag=companion.ashborn] if data entity @e[distance=..25, type=item_display, tag=Companion, predicate=evercraft:companions/check_id, limit=1] item.components."minecraft:lore"[9].extra[{text:"180"}] run return run function evercraft:companions/handler/active/abilities/trigger/red_dragon