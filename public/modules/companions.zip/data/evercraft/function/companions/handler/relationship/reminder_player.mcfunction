# Send pet feeding reminder to a single player
# Run as player

scoreboard players operation #Search companion.id = @s companion.id

# Only remind if player has an active pet
execute unless entity @e[type=item_display, tag=Companion, predicate=evercraft:companions/check_id, distance=..100] run return fail

# Load relationship to check status
function evercraft:companions/handler/relationship/load_rp

# Different messages based on relationship level
scoreboard players set #ndur ec.temp 45
data modify storage evercraft:notify stage.c set value [{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" is feeling neglected! Remember to feed and pet them today.",color:"yellow"}]
execute if score @s companion.rellevel matches 0 run function evercraft:util/notify/emit

data modify storage evercraft:notify stage.c set value [{text:"Good morning! Don't forget to spend some time with ",color:"aqua"},{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" today.",color:"aqua"}]
execute if score @s companion.rellevel matches 1..2 run function evercraft:util/notify/emit

data modify storage evercraft:notify stage.c set value [{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" is excited to see you! A quick treat would make their day.",color:"green"}]
execute if score @s companion.rellevel matches 3..4 run function evercraft:util/notify/emit

data modify storage evercraft:notify stage.c set value [{selector:"@e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1]"},{text:" loves you! Keep up the great bond with a morning treat.",color:"light_purple"}]
execute if score @s companion.rellevel matches 5 run function evercraft:util/notify/emit

# Play a gentle sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.5 1.2
