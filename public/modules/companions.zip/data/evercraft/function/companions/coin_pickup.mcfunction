# Companion Coin Pickup — Once per 3 real days, active pet finds a coin
# Runs as @s = player with companion.activepet tag, every 5s (from tick_5s_player)
# 3 real days = 3 x 72000 = 216000 game ticks

# Calculate elapsed time since last pickup
execute store result score #now ec.temp run time query gametime
scoreboard players operation #elapsed ec.temp = #now ec.temp
scoreboard players operation #elapsed ec.temp -= @s ec.pet_coin_cd

# If less than 3 days have passed, skip
execute unless score #elapsed ec.temp matches 216000.. run return 0

# Random chance per check (~5% per 5s check for flavor delay)
execute store result score #roll ec.temp run random value 1..20
execute unless score #roll ec.temp matches 1 run return 0

# Grant 1 Forever Coin
scoreboard players set #coin_amount ec.temp 1
function evercraft:gacha/coin/grant

# Update cooldown timestamp
execute store result score @s ec.pet_coin_cd run time query gametime

# Flavor message
function evercraft:companions/coin_pickup_msg
