# Companion Gift — Give a small thematic item from pet
# @s = player, at player position

# Roll random item (1-20)
execute store result score #gift_item ec.temp run random value 1..20

execute if score #gift_item ec.temp matches 1 run give @s wheat_seeds 4
execute if score #gift_item ec.temp matches 2 run give @s melon_seeds 4
execute if score #gift_item ec.temp matches 3 run give @s pumpkin_seeds 4
execute if score #gift_item ec.temp matches 4 run give @s poppy 2
execute if score #gift_item ec.temp matches 5 run give @s dandelion 2
execute if score #gift_item ec.temp matches 6 run give @s cornflower 2
execute if score #gift_item ec.temp matches 7 run give @s azure_bluet 2
execute if score #gift_item ec.temp matches 8 run give @s feather 3
execute if score #gift_item ec.temp matches 9 run give @s bone 3
execute if score #gift_item ec.temp matches 10 run give @s string 3
execute if score #gift_item ec.temp matches 11 run give @s stick 5
execute if score #gift_item ec.temp matches 12 run give @s sugar_cane 3
execute if score #gift_item ec.temp matches 13 run give @s bamboo 4
execute if score #gift_item ec.temp matches 14 run give @s glow_berries 4
execute if score #gift_item ec.temp matches 15 run give @s sweet_berries 4
execute if score #gift_item ec.temp matches 16 run give @s honeycomb 2
execute if score #gift_item ec.temp matches 17 run give @s amethyst_shard 2
execute if score #gift_item ec.temp matches 18 run give @s copper_ingot 3
execute if score #gift_item ec.temp matches 19 run give @s flint 3
execute if score #gift_item ec.temp matches 20 run give @s orange_dye 2

# Notification
tellraw @s [{text:"[Pets] ",color:"aqua"},{text:"Your companion found a little gift for you!",color:"green",italic:true}]
playsound minecraft:entity.item.pickup master @s ~ ~ ~ 0.5 1.2
