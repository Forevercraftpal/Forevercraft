# Companion Gift — Weekly crate chance (level-scaled odds)
# @s = player, at player position

# Read active pet level via string_to_int
data modify storage evercraft:companions math.string set string entity @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id,limit=1] item.components."minecraft:profile".properties[2].value
scoreboard players set #value companion.calc 0
function evercraft:companions/handler/math/string_to_int
scoreboard players operation #gift_level ec.temp = #value companion.calc

# Determine tier bracket (affects crate quality odds)
# Level 1-49: tier 0, Level 50-99: tier 1, Level 100: tier 2
scoreboard players set #gift_tier ec.temp 0
execute if score #gift_level ec.temp matches 50..99 run scoreboard players set #gift_tier ec.temp 1
execute if score #gift_level ec.temp matches 100 run scoreboard players set #gift_tier ec.temp 2

# Roll 1-1000 for crate quality
execute store result score #gift_crate ec.temp run random value 1..1000

# Tier 0 (Level 1-49): 600 common, 220 uncommon, 120 rare, 40 ornate, 15 exquisite, 5 mythical
# Tier 1 (Level 50-99): 450 common, 250 uncommon, 160 rare, 90 ornate, 35 exquisite, 15 mythical
# Tier 2 (Level 100): 300 common, 250 uncommon, 200 rare, 140 ornate, 70 exquisite, 40 mythical

# Default tier 0 thresholds
scoreboard players set #c_uncommon ec.temp 601
scoreboard players set #c_rare ec.temp 821
scoreboard players set #c_ornate ec.temp 941
scoreboard players set #c_exquisite ec.temp 981
scoreboard players set #c_mythical ec.temp 996

# Tier 1 thresholds
execute if score #gift_tier ec.temp matches 1 run scoreboard players set #c_uncommon ec.temp 451
execute if score #gift_tier ec.temp matches 1 run scoreboard players set #c_rare ec.temp 701
execute if score #gift_tier ec.temp matches 1 run scoreboard players set #c_ornate ec.temp 861
execute if score #gift_tier ec.temp matches 1 run scoreboard players set #c_exquisite ec.temp 951
execute if score #gift_tier ec.temp matches 1 run scoreboard players set #c_mythical ec.temp 986

# Tier 2 thresholds
execute if score #gift_tier ec.temp matches 2 run scoreboard players set #c_uncommon ec.temp 301
execute if score #gift_tier ec.temp matches 2 run scoreboard players set #c_rare ec.temp 551
execute if score #gift_tier ec.temp matches 2 run scoreboard players set #c_ornate ec.temp 751
execute if score #gift_tier ec.temp matches 2 run scoreboard players set #c_exquisite ec.temp 891
execute if score #gift_tier ec.temp matches 2 run scoreboard players set #c_mythical ec.temp 961

# Give crate based on roll
execute if score #gift_crate ec.temp < #c_uncommon ec.temp run loot give @s loot evercraft:crates/items/common
execute if score #gift_crate ec.temp < #c_uncommon ec.temp run tellraw @s [{text:"[Pets] ",color:"aqua"},{text:"Your companion unearthed a ",color:"yellow"},{text:"Common Crate",color:"white"},{text:"!",color:"yellow"}]

execute if score #gift_crate ec.temp >= #c_uncommon ec.temp if score #gift_crate ec.temp < #c_rare ec.temp run loot give @s loot evercraft:crates/items/uncommon
execute if score #gift_crate ec.temp >= #c_uncommon ec.temp if score #gift_crate ec.temp < #c_rare ec.temp run tellraw @s [{text:"[Pets] ",color:"aqua"},{text:"Your companion unearthed an ",color:"yellow"},{text:"Uncommon Crate",color:"blue"},{text:"!",color:"yellow"}]

execute if score #gift_crate ec.temp >= #c_rare ec.temp if score #gift_crate ec.temp < #c_ornate ec.temp run loot give @s loot evercraft:crates/items/rare
execute if score #gift_crate ec.temp >= #c_rare ec.temp if score #gift_crate ec.temp < #c_ornate ec.temp run tellraw @s [{text:"[Pets] ",color:"aqua"},{text:"Your companion unearthed a ",color:"yellow"},{text:"Rare Crate",color:"aqua"},{text:"!",color:"yellow"}]

execute if score #gift_crate ec.temp >= #c_ornate ec.temp if score #gift_crate ec.temp < #c_exquisite ec.temp run loot give @s loot evercraft:crates/items/ornate
execute if score #gift_crate ec.temp >= #c_ornate ec.temp if score #gift_crate ec.temp < #c_exquisite ec.temp run tellraw @s [{text:"[Pets] ",color:"aqua"},{text:"Your companion unearthed an ",color:"yellow"},{text:"Ornate Crate",color:"dark_purple"},{text:"!",color:"yellow"}]

execute if score #gift_crate ec.temp >= #c_exquisite ec.temp if score #gift_crate ec.temp < #c_mythical ec.temp run loot give @s loot evercraft:crates/items/exquisite
execute if score #gift_crate ec.temp >= #c_exquisite ec.temp if score #gift_crate ec.temp < #c_mythical ec.temp run tellraw @s [{text:"[Pets] ",color:"aqua"},{text:"Your companion unearthed an ",color:"yellow"},{text:"Exquisite Crate",color:"light_purple"},{text:"!",color:"yellow"}]

execute if score #gift_crate ec.temp >= #c_mythical ec.temp run loot give @s loot evercraft:crates/items/mythical
execute if score #gift_crate ec.temp >= #c_mythical ec.temp run tellraw @s [{text:"[Pets] ",color:"gold"},{text:"Your companion unearthed a ",color:"gold",bold:true},{text:"Mythical Crate",color:"gold",bold:true},{text:"!!",color:"gold",bold:true}]
execute if score #gift_crate ec.temp >= #c_mythical ec.temp at @s run playsound ui.toast.challenge_complete master @s ~ ~ ~ 1 1.0

# Record day for cooldown
execute store result score @s ec.pet_gift_day run time query day

# Sound
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 1.2
