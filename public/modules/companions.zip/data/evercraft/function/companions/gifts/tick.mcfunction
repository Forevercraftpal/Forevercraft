# Companion Gift System — Check if gift timer has elapsed
# @s = player with active pet, at player position
# Timer: gametime-based. 108000 ticks = 1.5 hours at 20tps

# Initialize timer on first run (0 = not set yet)
execute unless score @s ec.pet_gift matches 1.. store result score @s ec.pet_gift run time query gametime

# Check elapsed time
execute store result score #gift_now ec.temp run time query gametime
scoreboard players operation #gift_elapsed ec.temp = #gift_now ec.temp
scoreboard players operation #gift_elapsed ec.temp -= @s ec.pet_gift

# 108000 ticks = 1.5 hours (90 min × 60 sec × 20 tps)
execute unless score #gift_elapsed ec.temp matches 108000.. run return 0

# Time's up — give a gift!
function evercraft:companions/gifts/give_gift

# Reset timer
execute store result score @s ec.pet_gift run time query gametime

# Check for weekly crate chance
execute store result score #gift_day ec.temp run time query day
scoreboard players operation #gift_day_diff ec.temp = #gift_day ec.temp
scoreboard players operation #gift_day_diff ec.temp -= @s ec.pet_gift_day

# 7+ days since last crate → eligible
execute if score #gift_day_diff ec.temp matches 7.. run function evercraft:companions/gifts/give_crate
