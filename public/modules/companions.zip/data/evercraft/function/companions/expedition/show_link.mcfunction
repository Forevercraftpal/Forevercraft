# Pet Expedition — Show "Send on Expedition" link in companion info chat
# Called as interaction entity with {slot:N} macro (page-relative 0-17)
# Computes real slot = page * 18 + slot, then shows clickable link

# Get the player who has the menu open
$execute as @a[tag=companion.inmenuv2,predicate=evercraft:companions/check_id] run function evercraft:companions/expedition/compute_link {slot:$(slot)}
