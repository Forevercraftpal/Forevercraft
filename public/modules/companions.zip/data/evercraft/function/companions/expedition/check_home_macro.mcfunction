# Pet Expedition — Macro: check if pet slot is at home
# $(exp_slot) = 0-based pet slot index
$execute if data entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[$(exp_slot)].components."minecraft:custom_data".home run scoreboard players set #exp_is_home ec.temp 1
