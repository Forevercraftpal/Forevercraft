# Companion Letter — Uncommon tier messages (41-65, mild interest)
execute store result score #ltr_msg ec.temp run random value 1..5
execute if score #ltr_msg ec.temp matches 1 run data modify storage evercraft:companions letter.message set value "Found some interesting things along the trail. Packing them up!"
execute if score #ltr_msg ec.temp matches 2 run data modify storage evercraft:companions letter.message set value "Spotted some unusual stones near a riverbed. Could be worth something."
execute if score #ltr_msg ec.temp matches 3 run data modify storage evercraft:companions letter.message set value "The locals pointed me to a good foraging spot. Not bad!"
execute if score #ltr_msg ec.temp matches 4 run data modify storage evercraft:companions letter.message set value "Making good progress. Found a few trinkets you might like."
execute if score #ltr_msg ec.temp matches 5 run data modify storage evercraft:companions letter.message set value "There's more out here than I expected. Filling my pockets."
