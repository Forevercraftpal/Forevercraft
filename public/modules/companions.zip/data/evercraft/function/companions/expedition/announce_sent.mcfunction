# Pet Expedition — Announce pet sent
tellraw @s [{text:"[Forevercraft] ",color:"gold"},{text:"Your pet has been sent on an expedition!",color:"green"}]
tellraw @s [{text:"  They'll return in about 30 minutes with rewards.",color:"gray",italic:true}]
tellraw @s [{text:"  Active expeditions: ",color:"gray"},{score:{name:"@s",objective:"ec.exp_count"},color:"yellow"},{text:"/3",color:"gray"}]
playsound minecraft:entity.villager.celebrate master @s ~ ~ ~ 0.7 1.2
playsound minecraft:item.trident.throw master @s ~ ~ ~ 0.5 0.8
