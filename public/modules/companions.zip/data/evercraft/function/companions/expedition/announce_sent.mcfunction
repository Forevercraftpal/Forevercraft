# Pet Expedition — Announce pet sent
data modify storage evercraft:notify stage.c set value [{text:"Your pet has been sent on an expedition!",color:"green"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"They'll return in about 30 minutes with rewards.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Active expeditions: ",color:"gray"},{score:{name:"@s",objective:"ec.exp_count"},color:"yellow"},{text:"/3",color:"gray"}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.villager.celebrate master @s ~ ~ ~ 0.7 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.trident.throw master @s ~ ~ ~ 0.5 0.8
