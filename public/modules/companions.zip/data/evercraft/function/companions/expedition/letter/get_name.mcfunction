# Companion Letter — Get pet display name from marker by slot index (Macro)
# $(slot) = 0-based pet slot index
$data modify storage evercraft:companions letter.name set from entity @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id,limit=1] data.Pets[$(slot)].components."minecraft:profile".properties[{name:"name"}].value
