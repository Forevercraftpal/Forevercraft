# Pet Expedition Narrative — Random biome + story flavor text
# @s = player

# Roll random biome (1-12)
execute store result score #exp_biome ec.temp run random value 1..12
execute if score #exp_biome ec.temp matches 1 run data modify storage evercraft:companions expedition.biome_name set value "Plains"
execute if score #exp_biome ec.temp matches 2 run data modify storage evercraft:companions expedition.biome_name set value "Forest"
execute if score #exp_biome ec.temp matches 3 run data modify storage evercraft:companions expedition.biome_name set value "Desert"
execute if score #exp_biome ec.temp matches 4 run data modify storage evercraft:companions expedition.biome_name set value "Jungle"
execute if score #exp_biome ec.temp matches 5 run data modify storage evercraft:companions expedition.biome_name set value "Mountains"
execute if score #exp_biome ec.temp matches 6 run data modify storage evercraft:companions expedition.biome_name set value "Ocean Shore"
execute if score #exp_biome ec.temp matches 7 run data modify storage evercraft:companions expedition.biome_name set value "Swamp"
execute if score #exp_biome ec.temp matches 8 run data modify storage evercraft:companions expedition.biome_name set value "Taiga"
execute if score #exp_biome ec.temp matches 9 run data modify storage evercraft:companions expedition.biome_name set value "Savanna"
execute if score #exp_biome ec.temp matches 10 run data modify storage evercraft:companions expedition.biome_name set value "Dark Forest"
execute if score #exp_biome ec.temp matches 11 run data modify storage evercraft:companions expedition.biome_name set value "Mushroom Fields"
execute if score #exp_biome ec.temp matches 12 run data modify storage evercraft:companions expedition.biome_name set value "Frozen Peaks"

# Roll random story (1-8)
execute store result score #exp_story ec.temp run random value 1..8
execute if score #exp_story ec.temp matches 1 run data modify storage evercraft:companions expedition.story set value "found a curious glowing stone..."
execute if score #exp_story ec.temp matches 2 run data modify storage evercraft:companions expedition.story set value "made a new friend along the way..."
execute if score #exp_story ec.temp matches 3 run data modify storage evercraft:companions expedition.story set value "discovered an ancient path..."
execute if score #exp_story ec.temp matches 4 run data modify storage evercraft:companions expedition.story set value "rested under the stars before heading home..."
execute if score #exp_story ec.temp matches 5 run data modify storage evercraft:companions expedition.story set value "chased butterflies all afternoon..."
execute if score #exp_story ec.temp matches 6 run data modify storage evercraft:companions expedition.story set value "discovered a hidden cave..."
execute if score #exp_story ec.temp matches 7 run data modify storage evercraft:companions expedition.story set value "got into a scuffle with a local critter..."
execute if score #exp_story ec.temp matches 8 run data modify storage evercraft:companions expedition.story set value "found something shiny buried in the dirt..."

# Display narrative
function evercraft:companions/expedition/narrative_display with storage evercraft:companions expedition
