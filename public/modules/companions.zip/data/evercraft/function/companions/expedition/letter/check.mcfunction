# Companion Letter — Check if a letter should be delivered
# Inputs: #ltr_end, #ltr_count, #ltr_tier, #ltr_slot (ec.temp)
# Outputs: #ltr_count (updated if letter sent)
# @s = player

# Already sent max letters (2)
execute if score #ltr_count ec.temp matches 2.. run return 0

# Calculate elapsed: now - (end - 36000) = now - end + 36000
execute store result score #ltr_elapsed ec.temp run time query gametime
scoreboard players operation #ltr_elapsed ec.temp -= #ltr_end ec.temp
scoreboard players add #ltr_elapsed ec.temp 36000

# Snapshot count before delivery — prevents both letters firing in same tick
# (e.g., player logs in after being offline past both thresholds)
scoreboard players operation #ltr_orig ec.temp = #ltr_count ec.temp

# Letter 1: elapsed >= 12000 (~10 min), not yet sent
execute if score #ltr_orig ec.temp matches 0 if score #ltr_elapsed ec.temp matches 12000.. run function evercraft:companions/expedition/letter/deliver

# Letter 2: elapsed >= 24000 (~20 min), only 1 sent, 50% chance
execute if score #ltr_orig ec.temp matches 1 if score #ltr_elapsed ec.temp matches 24000.. run function evercraft:companions/expedition/letter/try_second
