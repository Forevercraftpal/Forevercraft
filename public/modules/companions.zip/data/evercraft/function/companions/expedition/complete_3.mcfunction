# Pet Expedition — Complete slot 3
scoreboard players operation #exp_roll ec.temp = @s ec.exp3_tier
scoreboard players set @s ec.exp3_end 0
scoreboard players set @s ec.exp3_tier 0
scoreboard players set @s ec.exp3_ltr 0
scoreboard players remove @s ec.exp_count 1
function evercraft:companions/expedition/reward
