# Companion Letter — Common tier messages (1-40, mundane vibes)
execute store result score #ltr_msg ec.temp run random value 1..5
execute if score #ltr_msg ec.temp matches 1 run data modify storage evercraft:companions letter.message set value "Nothing too exciting so far. Mostly just nice views."
execute if score #ltr_msg ec.temp matches 2 run data modify storage evercraft:companions letter.message set value "Picked some wildflowers. That's about all there is out here."
execute if score #ltr_msg ec.temp matches 3 run data modify storage evercraft:companions letter.message set value "Very peaceful. A bit too peaceful, honestly. Might nap."
execute if score #ltr_msg ec.temp matches 4 run data modify storage evercraft:companions letter.message set value "Saw a few squirrels. One of them stole my lunch."
execute if score #ltr_msg ec.temp matches 5 run data modify storage evercraft:companions letter.message set value "It's quiet out here. I'll bring back what I can find."
