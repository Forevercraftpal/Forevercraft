# Companion Letter — Rare tier messages (66-85, promising discovery)
execute store result score #ltr_msg ec.temp run random value 1..5
execute if score #ltr_msg ec.temp matches 1 run data modify storage evercraft:companions letter.message set value "Discovered something hidden behind a waterfall. You'll want to see this."
execute if score #ltr_msg ec.temp matches 2 run data modify storage evercraft:companions letter.message set value "Followed a strange trail off the path. Led to something buried underground."
execute if score #ltr_msg ec.temp matches 3 run data modify storage evercraft:companions letter.message set value "The ground here is different. Dug a little and found something promising."
execute if score #ltr_msg ec.temp matches 4 run data modify storage evercraft:companions letter.message set value "There are old markers leading somewhere. I think I'm close to something."
execute if score #ltr_msg ec.temp matches 5 run data modify storage evercraft:companions letter.message set value "Found a sealed chest tucked inside a hollow tree. Can't wait to open it."
