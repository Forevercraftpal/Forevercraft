# Pet Expedition — Check individual player's expeditions for completion
# @s = player with active expeditions

execute store result score #exp_now ec.temp run time query gametime

# Check expedition 1
execute if score @s ec.exp1_end matches 1.. run scoreboard players operation #exp_check ec.temp = #exp_now ec.temp
execute if score @s ec.exp1_end matches 1.. run scoreboard players operation #exp_check ec.temp -= @s ec.exp1_end
execute if score @s ec.exp1_end matches 1.. if score #exp_check ec.temp matches 0.. run function evercraft:companions/expedition/complete_1

# Check expedition 2
execute if score @s ec.exp2_end matches 1.. run scoreboard players operation #exp_check ec.temp = #exp_now ec.temp
execute if score @s ec.exp2_end matches 1.. run scoreboard players operation #exp_check ec.temp -= @s ec.exp2_end
execute if score @s ec.exp2_end matches 1.. if score #exp_check ec.temp matches 0.. run function evercraft:companions/expedition/complete_2

# Check expedition 3
execute if score @s ec.exp3_end matches 1.. run scoreboard players operation #exp_check ec.temp = #exp_now ec.temp
execute if score @s ec.exp3_end matches 1.. run scoreboard players operation #exp_check ec.temp -= @s ec.exp3_end
execute if score @s ec.exp3_end matches 1.. if score #exp_check ec.temp matches 0.. run function evercraft:companions/expedition/complete_3

# Check letters — expedition 1
execute if score @s ec.exp1_end matches 1.. run scoreboard players operation #ltr_end ec.temp = @s ec.exp1_end
execute if score @s ec.exp1_end matches 1.. run scoreboard players operation #ltr_count ec.temp = @s ec.exp1_ltr
execute if score @s ec.exp1_end matches 1.. run scoreboard players operation #ltr_tier ec.temp = @s ec.exp1_tier
execute if score @s ec.exp1_end matches 1.. run scoreboard players operation #ltr_slot ec.temp = @s ec.exp1_slot
execute if score @s ec.exp1_end matches 1.. run function evercraft:companions/expedition/letter/check
execute if score @s ec.exp1_end matches 1.. run scoreboard players operation @s ec.exp1_ltr = #ltr_count ec.temp

# Check letters — expedition 2
execute if score @s ec.exp2_end matches 1.. run scoreboard players operation #ltr_end ec.temp = @s ec.exp2_end
execute if score @s ec.exp2_end matches 1.. run scoreboard players operation #ltr_count ec.temp = @s ec.exp2_ltr
execute if score @s ec.exp2_end matches 1.. run scoreboard players operation #ltr_tier ec.temp = @s ec.exp2_tier
execute if score @s ec.exp2_end matches 1.. run scoreboard players operation #ltr_slot ec.temp = @s ec.exp2_slot
execute if score @s ec.exp2_end matches 1.. run function evercraft:companions/expedition/letter/check
execute if score @s ec.exp2_end matches 1.. run scoreboard players operation @s ec.exp2_ltr = #ltr_count ec.temp

# Check letters — expedition 3
execute if score @s ec.exp3_end matches 1.. run scoreboard players operation #ltr_end ec.temp = @s ec.exp3_end
execute if score @s ec.exp3_end matches 1.. run scoreboard players operation #ltr_count ec.temp = @s ec.exp3_ltr
execute if score @s ec.exp3_end matches 1.. run scoreboard players operation #ltr_tier ec.temp = @s ec.exp3_tier
execute if score @s ec.exp3_end matches 1.. run scoreboard players operation #ltr_slot ec.temp = @s ec.exp3_slot
execute if score @s ec.exp3_end matches 1.. run function evercraft:companions/expedition/letter/check
execute if score @s ec.exp3_end matches 1.. run scoreboard players operation @s ec.exp3_ltr = #ltr_count ec.temp

# Check trigger for sending
execute if score @s ec.exp_send matches 1.. run function evercraft:companions/expedition/send
scoreboard players enable @s ec.exp_send
