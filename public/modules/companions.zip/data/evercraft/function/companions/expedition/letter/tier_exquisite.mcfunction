# Companion Letter — Exquisite tier messages (96-100, extraordinary)
execute store result score #ltr_msg ec.temp run random value 1..5
execute if score #ltr_msg ec.temp matches 1 run data modify storage evercraft:companions letter.message set value "I've found something extraordinary. You won't believe your eyes."
execute if score #ltr_msg ec.temp matches 2 run data modify storage evercraft:companions letter.message set value "Heart's racing. This might be the greatest find of my life."
execute if score #ltr_msg ec.temp matches 3 run data modify storage evercraft:companions letter.message set value "The air itself is humming with energy. Something legendary is here."
execute if score #ltr_msg ec.temp matches 4 run data modify storage evercraft:companions letter.message set value "I'm trembling. Whatever this is, it's beyond anything I've ever seen."
execute if score #ltr_msg ec.temp matches 5 run data modify storage evercraft:companions letter.message set value "Don't tell anyone about this. What I've found... it changes everything."
