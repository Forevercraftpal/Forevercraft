# Companion Letter — Rare lore letter (unique expedition-only flavor text)
# letter.name already set in storage

# Roll rare message (1-8)
execute store result score #ltr_msg ec.temp run random value 1..8
execute if score #ltr_msg ec.temp matches 1 run data modify storage evercraft:companions letter.rare_msg set value "I found old carvings on the canyon wall. They show creatures I've never seen before. The stone was warm to the touch."
execute if score #ltr_msg ec.temp matches 2 run data modify storage evercraft:companions letter.rare_msg set value "There was a tower here once. I can see the foundation stones overgrown with moss. Something made the builders leave in a hurry."
execute if score #ltr_msg ec.temp matches 3 run data modify storage evercraft:companions letter.rare_msg set value "Last night I heard singing from underground. No words, just a melody that made my fur stand on end. It stopped at dawn."
execute if score #ltr_msg ec.temp matches 4 run data modify storage evercraft:companions letter.rare_msg set value "I found a journal half-buried in the mud. The last entry just says: 'The lanterns are going out one by one.'"
execute if score #ltr_msg ec.temp matches 5 run data modify storage evercraft:companions letter.rare_msg set value "There are flowers growing here that close when you look at them and open when you turn away. I tried not blinking. They waited."
execute if score #ltr_msg ec.temp matches 6 run data modify storage evercraft:companions letter.rare_msg set value "I followed a stream uphill today. It was flowing the wrong direction. The fish didn't seem to mind."
execute if score #ltr_msg ec.temp matches 7 run data modify storage evercraft:companions letter.rare_msg set value "Met an old wanderer on the path. They said they'd been walking for longer than they could remember. Then they were gone."
execute if score #ltr_msg ec.temp matches 8 run data modify storage evercraft:companions letter.rare_msg set value "The stars look different out here. I swear I can see patterns that don't match any chart. It feels like they're new."

# Display with special formatting
function evercraft:companions/expedition/letter/display_rare with storage evercraft:companions letter

# Special sound
playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 0.8
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.3 1.5
