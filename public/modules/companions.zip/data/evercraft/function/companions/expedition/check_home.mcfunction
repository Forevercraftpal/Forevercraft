# Pet Expedition — Check if pet at given slot is placed at home
# @s = player, ec.exp_send = 0-based slot index
# Sets #exp_is_home ec.temp = 1 if home, 0 otherwise

scoreboard players set #exp_is_home ec.temp 0
execute store result storage evercraft:companions temp.exp_slot int 1 run scoreboard players get @s ec.exp_send
scoreboard players operation #Search companion.id = @s companion.id
function evercraft:companions/expedition/check_home_macro with storage evercraft:companions temp
