# Pet Expedition — Complete slot 2
scoreboard players operation #exp_roll ec.temp = @s ec.exp2_tier
scoreboard players set @s ec.exp2_end 0
scoreboard players set @s ec.exp2_tier 0
scoreboard players set @s ec.exp2_ltr 0
scoreboard players remove @s ec.exp_count 1
function evercraft:companions/expedition/reward
