# Pet Expedition System — Send pet on expedition
# DEPRECATED (SP4): superseded by companions/journey/send (themed runs, rarity-scaled, 2 sub slots). Kept
# functional only so the legacy [Send on Expedition] button works until the SP5 Journey GUI ships. No new
# wiring should target this; prefer journey/send.
# @s = player, ec.exp_send = 1-based trigger (1 = slot 0, 2 = slot 1, etc.)
# Duration: 36000 gametime ticks (~30 min real-time with slow DayTime)

# Re-enable trigger for next use (must happen before resetting score)
scoreboard players enable @s ec.exp_send

# Convert 1-based trigger to 0-based slot
scoreboard players remove @s ec.exp_send 1

# Check if already at max expeditions (3)
data modify storage evercraft:notify stage.c set value [{text:"You already have 3 pets on expeditions!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.exp_count matches 3.. run function evercraft:util/notify/emit
execute if score @s ec.exp_count matches 3.. run scoreboard players set @s ec.exp_send 0
execute if score @s ec.exp_count matches 3.. run return 0

# Check if pet is already the active companion (can't send active pet)
data modify storage evercraft:notify stage.c set value [{text:"You can't send your active companion on an expedition!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.exp_send = @s companion.activeslot if entity @s[tag=companion.activepet] run function evercraft:util/notify/emit
execute if score @s ec.exp_send = @s companion.activeslot if entity @s[tag=companion.activepet] run scoreboard players set @s ec.exp_send 0
execute if score @s ec.exp_send = @s companion.activeslot if entity @s[tag=companion.activepet] run return 0

# Check if pet is placed at home (can't send home pets)
function evercraft:companions/expedition/check_home
data modify storage evercraft:notify stage.c set value [{text:"This companion is placed at home! Retrieve it first.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #exp_is_home ec.temp matches 1 run function evercraft:util/notify/emit
execute if score #exp_is_home ec.temp matches 1 run scoreboard players set @s ec.exp_send 0
execute if score #exp_is_home ec.temp matches 1 run return 0

# Calculate return time: now + 36000
execute store result score #exp_now ec.temp run time query gametime
scoreboard players operation #exp_end ec.temp = #exp_now ec.temp
scoreboard players add #exp_end ec.temp 36000

# Find an open expedition slot and fill it
execute if score @s ec.exp1_end matches 0 run scoreboard players operation @s ec.exp1_end = #exp_end ec.temp
execute if score @s ec.exp1_end = #exp_end ec.temp run scoreboard players operation @s ec.exp1_slot = @s ec.exp_send
execute if score @s ec.exp1_end = #exp_end ec.temp run scoreboard players add @s ec.exp_count 1
execute if score @s ec.exp1_end = #exp_end ec.temp run execute store result score @s ec.exp1_tier run random value 1..100
execute if score @s ec.exp1_end = #exp_end ec.temp run scoreboard players set @s ec.exp1_ltr 0
execute if score @s ec.exp1_end = #exp_end ec.temp run function evercraft:companions/expedition/announce_sent
execute if score @s ec.exp1_end = #exp_end ec.temp run scoreboard players set @s ec.exp_send 0
execute if score @s ec.exp1_end = #exp_end ec.temp run return 0

execute if score @s ec.exp2_end matches 0 run scoreboard players operation @s ec.exp2_end = #exp_end ec.temp
execute if score @s ec.exp2_end = #exp_end ec.temp run scoreboard players operation @s ec.exp2_slot = @s ec.exp_send
execute if score @s ec.exp2_end = #exp_end ec.temp run scoreboard players add @s ec.exp_count 1
execute if score @s ec.exp2_end = #exp_end ec.temp run execute store result score @s ec.exp2_tier run random value 1..100
execute if score @s ec.exp2_end = #exp_end ec.temp run scoreboard players set @s ec.exp2_ltr 0
execute if score @s ec.exp2_end = #exp_end ec.temp run function evercraft:companions/expedition/announce_sent
execute if score @s ec.exp2_end = #exp_end ec.temp run scoreboard players set @s ec.exp_send 0
execute if score @s ec.exp2_end = #exp_end ec.temp run return 0

execute if score @s ec.exp3_end matches 0 run scoreboard players operation @s ec.exp3_end = #exp_end ec.temp
execute if score @s ec.exp3_end = #exp_end ec.temp run scoreboard players operation @s ec.exp3_slot = @s ec.exp_send
execute if score @s ec.exp3_end = #exp_end ec.temp run scoreboard players add @s ec.exp_count 1
execute if score @s ec.exp3_end = #exp_end ec.temp run execute store result score @s ec.exp3_tier run random value 1..100
execute if score @s ec.exp3_end = #exp_end ec.temp run scoreboard players set @s ec.exp3_ltr 0
execute if score @s ec.exp3_end = #exp_end ec.temp run function evercraft:companions/expedition/announce_sent
execute if score @s ec.exp3_end = #exp_end ec.temp run scoreboard players set @s ec.exp_send 0
