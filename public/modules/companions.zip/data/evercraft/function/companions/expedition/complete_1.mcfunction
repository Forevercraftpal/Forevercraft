# Pet Expedition — Complete slot 1
scoreboard players operation #exp_roll ec.temp = @s ec.exp1_tier
scoreboard players set @s ec.exp1_end 0
scoreboard players set @s ec.exp1_tier 0
scoreboard players set @s ec.exp1_ltr 0
scoreboard players remove @s ec.exp_count 1
function evercraft:companions/expedition/reward
