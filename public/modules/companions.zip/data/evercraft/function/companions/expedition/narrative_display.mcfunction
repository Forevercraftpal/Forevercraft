# Expedition Narrative Display — Macro function
# $(biome_name), $(story) from storage
$data modify storage evercraft:notify stage.c set value [{text:"Your pet explored the ",color:"gray",italic:true},{text:"$(biome_name)",color:"green",italic:true},{text:" and $(story)",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
