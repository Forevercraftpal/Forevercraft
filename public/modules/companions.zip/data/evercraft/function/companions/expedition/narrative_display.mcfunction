# Expedition Narrative Display — Macro function
# $(biome_name), $(story) from storage
$tellraw @s [{text:"  Your pet explored the ",color:"gray",italic:true},{text:"$(biome_name)",color:"green",italic:true},{text:" and $(story)",color:"gray",italic:true}]
