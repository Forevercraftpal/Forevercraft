# Companion Letter — 50% chance gate for second letter
execute store result score #ltr_coin ec.temp run random value 0..1
execute if score #ltr_coin ec.temp matches 1 run function evercraft:companions/expedition/letter/deliver
