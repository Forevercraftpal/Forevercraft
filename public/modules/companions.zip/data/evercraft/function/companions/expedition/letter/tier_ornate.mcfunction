# Companion Letter — Ornate tier messages (86-95, exciting finds)
execute store result score #ltr_msg ec.temp run random value 1..5
execute if score #ltr_msg ec.temp matches 1 run data modify storage evercraft:companions letter.message set value "Found something remarkable in an old ruin. My paws are shaking!"
execute if score #ltr_msg ec.temp matches 2 run data modify storage evercraft:companions letter.message set value "I can barely contain myself. The things I've found here are incredible."
execute if score #ltr_msg ec.temp matches 3 run data modify storage evercraft:companions letter.message set value "Stumbled into a forgotten shrine. There were treasures just sitting there!"
execute if score #ltr_msg ec.temp matches 4 run data modify storage evercraft:companions letter.message set value "I think this place hasn't been touched in centuries. Jackpot!"
execute if score #ltr_msg ec.temp matches 5 run data modify storage evercraft:companions letter.message set value "Something is glowing at the bottom of this cavern. This is big."
