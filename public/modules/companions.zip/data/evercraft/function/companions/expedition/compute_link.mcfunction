# Pet Expedition — Compute real slot and show clickable link
# @s = player with menu open, {slot:N} = page-relative slot

# Compute real slot: page * 48 + slot + 1 (1-based for trigger, since 0 = not triggered)
$scoreboard players set #exp_slot ec.temp $(slot)
scoreboard players operation #exp_page ec.temp = @s companion.menupage
scoreboard players operation #exp_page ec.temp *= #48 companion.calc
scoreboard players operation #exp_slot ec.temp += #exp_page ec.temp
# +1 offset: trigger value 1 = slot 0, 2 = slot 1, etc.
scoreboard players add #exp_slot ec.temp 1

# Store to storage for macro tellraw
execute store result storage evercraft:companions temp.exp_trigger int 1 run scoreboard players get #exp_slot ec.temp

# Show the link (only if player has < 3 active expeditions)
execute if score @s ec.exp_count matches ..2 run function evercraft:companions/expedition/show_link_tellraw with storage evercraft:companions temp
