# Companion Letter — Display rare lore letter (Macro)
# $(name) = pet name, $(rare_msg) = lore text
$data modify storage evercraft:notify stage.c set value [{text:"From ",color:"light_purple"},{text:"$(name)",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"\"$(rare_msg)\"",color:"light_purple",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
