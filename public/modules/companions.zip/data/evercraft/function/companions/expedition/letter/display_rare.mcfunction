# Companion Letter — Display rare lore letter (Macro)
# $(name) = pet name, $(rare_msg) = lore text
$tellraw @s [{text:""},{"text":"[Letter] ","color":"gold","bold":true},{"text":"From ","color":"light_purple"},{"text":"$(name)","color":"yellow"}]
$tellraw @s [{text:"  \"$(rare_msg)\"","color":"light_purple","italic":true}]
