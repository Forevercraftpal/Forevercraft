# Pet Expedition — Clickable tellraw link
# $(exp_trigger) = 1-based trigger value for ec.exp_send
$tellraw @s ["",{"text":"  "},{"text":"[Send on Expedition]","color":"dark_green","bold":true,"click_event":{"action":"run_command","command":"/trigger ec.exp_send set $(exp_trigger)"},"hover_event":{"action":"show_text","value":{"text":"Send this pet on a 30-minute expedition for rewards!","color":"green"}}}]
