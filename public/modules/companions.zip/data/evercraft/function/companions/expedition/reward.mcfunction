# Pet Expedition — Roll rewards on return
# DEPRECATED (SP4): the crate-reward concept is re-homed into companions/journey/reward (same
# evercraft:crates/items/* ladder, tier-scaled). Kept LIVE so in-flight expeditions still pay out.
# @s = player, at player position

# Announce return
data modify storage evercraft:notify stage.c set value [{text:"Your pet has returned from their expedition!",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
# FX · pet returned with rewards — reuse the obtain pip (gated; light, neutral rarity).
scoreboard players set #pc_tier ec.var 2
execute at @s run function evercraft:fx/companion/obtain

# Expedition narrative (biome + story flavor text)
function evercraft:companions/expedition/narrative

# Reward tier pre-rolled at send time — #exp_roll ec.temp set by complete_N caller

# Check inventory space
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# Common reward (1-40): basic resources
execute if score #exp_roll ec.temp matches 1..40 if score #inv_full ec.var matches 0 run give @s emerald 8
execute if score #exp_roll ec.temp matches 1..40 if score #inv_full ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:8}}
execute if score #exp_roll ec.temp matches 1..40 run experience add @s 100 points
data modify storage evercraft:notify stage.c set value [{text:"Reward: ",color:"gray"},{text:"8 Emeralds + 100 XP",color:"white"}]
scoreboard players set #ndur ec.temp 40
execute if score #exp_roll ec.temp matches 1..40 run function evercraft:util/notify/emit

# Uncommon reward (41-65): more resources
execute if score #exp_roll ec.temp matches 41..65 if score #inv_full ec.var matches 0 run give @s emerald 16
execute if score #exp_roll ec.temp matches 41..65 if score #inv_full ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:16}}
execute if score #exp_roll ec.temp matches 41..65 run experience add @s 250 points
data modify storage evercraft:notify stage.c set value [{text:"Reward: ",color:"gray"},{text:"16 Emeralds + 250 XP",color:"blue"}]
scoreboard players set #ndur ec.temp 40
execute if score #exp_roll ec.temp matches 41..65 run function evercraft:util/notify/emit

# Rare reward (66-85): crate + emeralds
execute if score #exp_roll ec.temp matches 66..85 if score #inv_full ec.var matches 0 run give @s emerald 24
execute if score #exp_roll ec.temp matches 66..85 if score #inv_full ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:24}}
execute if score #exp_roll ec.temp matches 66..85 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/common
execute if score #exp_roll ec.temp matches 66..85 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/common
execute if score #exp_roll ec.temp matches 66..85 run experience add @s 500 points
data modify storage evercraft:notify stage.c set value [{text:"Reward: ",color:"gray"},{text:"24 Emeralds + Common Crate + 500 XP",color:"aqua"}]
scoreboard players set #ndur ec.temp 40
execute if score #exp_roll ec.temp matches 66..85 run function evercraft:util/notify/emit

# Ornate reward (86-95): rare crate + emeralds
execute if score #exp_roll ec.temp matches 86..95 if score #inv_full ec.var matches 0 run give @s emerald 32
execute if score #exp_roll ec.temp matches 86..95 if score #inv_full ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:32}}
execute if score #exp_roll ec.temp matches 86..95 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/uncommon
execute if score #exp_roll ec.temp matches 86..95 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/uncommon
execute if score #exp_roll ec.temp matches 86..95 run experience add @s 1000 points
data modify storage evercraft:notify stage.c set value [{text:"Reward: ",color:"gray"},{text:"32 Emeralds + Uncommon Crate + 1000 XP",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 40
execute if score #exp_roll ec.temp matches 86..95 run function evercraft:util/notify/emit

# Exquisite reward (96-100): rare crate + bonus
execute if score #exp_roll ec.temp matches 96..100 if score #inv_full ec.var matches 0 run give @s emerald_block 2
execute if score #exp_roll ec.temp matches 96..100 if score #inv_full ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald_block",count:2}}
execute if score #exp_roll ec.temp matches 96..100 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/rare
execute if score #exp_roll ec.temp matches 96..100 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/rare
execute if score #exp_roll ec.temp matches 96..100 run experience add @s 2000 points
data modify storage evercraft:notify stage.c set value [{text:"Reward: ",color:"gray"},{text:"2 Emerald Blocks + Rare Crate + 2000 XP",color:"light_purple"}]
scoreboard players set #ndur ec.temp 40
execute if score #exp_roll ec.temp matches 96..100 run function evercraft:util/notify/emit

# Inventory full warning
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Rewards dropped at your feet.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit

# Particle celebration
particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0 10
