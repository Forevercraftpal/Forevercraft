# Pet Expedition — Roll rewards on return
# @s = player, at player position

# Announce return
tellraw @s [{text:""},{"text":"[Expedition] ","color":"dark_green"},{"text":"Your pet has returned from their expedition!","color":"green","bold":true}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 1.0
playsound minecraft:entity.item.pickup master @s ~ ~ ~ 0.6 0.8

# Expedition narrative (biome + story flavor text)
function evercraft:companions/expedition/narrative

# Reward tier pre-rolled at send time — #exp_roll ec.temp set by complete_N caller

# Check inventory space
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# Common reward (1-40): basic resources
execute if score #exp_roll ec.temp matches 1..40 if score #inv_full ec.var matches 0 run give @s emerald 8
execute if score #exp_roll ec.temp matches 1..40 if score #inv_full ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:8}}
execute if score #exp_roll ec.temp matches 1..40 run experience add @s 100 points
execute if score #exp_roll ec.temp matches 1..40 run tellraw @s [{text:"  Reward: ",color:"gray"},{text:"8 Emeralds + 100 XP",color:"white"}]

# Uncommon reward (41-65): more resources
execute if score #exp_roll ec.temp matches 41..65 if score #inv_full ec.var matches 0 run give @s emerald 16
execute if score #exp_roll ec.temp matches 41..65 if score #inv_full ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:16}}
execute if score #exp_roll ec.temp matches 41..65 run experience add @s 250 points
execute if score #exp_roll ec.temp matches 41..65 run tellraw @s [{text:"  Reward: ",color:"gray"},{text:"16 Emeralds + 250 XP",color:"blue"}]

# Rare reward (66-85): crate + emeralds
execute if score #exp_roll ec.temp matches 66..85 if score #inv_full ec.var matches 0 run give @s emerald 24
execute if score #exp_roll ec.temp matches 66..85 if score #inv_full ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:24}}
execute if score #exp_roll ec.temp matches 66..85 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/common
execute if score #exp_roll ec.temp matches 66..85 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/common
execute if score #exp_roll ec.temp matches 66..85 run experience add @s 500 points
execute if score #exp_roll ec.temp matches 66..85 run tellraw @s [{text:"  Reward: ",color:"gray"},{text:"24 Emeralds + Common Crate + 500 XP",color:"aqua"}]

# Ornate reward (86-95): rare crate + emeralds
execute if score #exp_roll ec.temp matches 86..95 if score #inv_full ec.var matches 0 run give @s emerald 32
execute if score #exp_roll ec.temp matches 86..95 if score #inv_full ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald",count:32}}
execute if score #exp_roll ec.temp matches 86..95 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/uncommon
execute if score #exp_roll ec.temp matches 86..95 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/uncommon
execute if score #exp_roll ec.temp matches 86..95 run experience add @s 1000 points
execute if score #exp_roll ec.temp matches 86..95 run tellraw @s [{text:"  Reward: ",color:"gray"},{text:"32 Emeralds + Uncommon Crate + 1000 XP",color:"dark_purple"}]

# Exquisite reward (96-100): rare crate + bonus
execute if score #exp_roll ec.temp matches 96..100 if score #inv_full ec.var matches 0 run give @s emerald_block 2
execute if score #exp_roll ec.temp matches 96..100 if score #inv_full ec.var matches 1 at @s run summon item ~ ~ ~ {Item:{id:"minecraft:emerald_block",count:2}}
execute if score #exp_roll ec.temp matches 96..100 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:crates/items/rare
execute if score #exp_roll ec.temp matches 96..100 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:crates/items/rare
execute if score #exp_roll ec.temp matches 96..100 run experience add @s 2000 points
execute if score #exp_roll ec.temp matches 96..100 run tellraw @s [{text:"  Reward: ",color:"gray"},{text:"2 Emerald Blocks + Rare Crate + 2000 XP",color:"light_purple"}]

# Inventory full warning
execute if score #inv_full ec.var matches 1 run tellraw @s [{text:"[!] ",color:"red"},{text:"Inventory full! Rewards dropped at your feet.",color:"yellow"}]

# Particle celebration
particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0 20
