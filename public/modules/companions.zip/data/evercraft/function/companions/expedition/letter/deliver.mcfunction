# Companion Letter — Deliver a letter to the player
# Inputs: #ltr_tier, #ltr_slot (ec.temp)
# @s = player

# Increment letter count
scoreboard players add #ltr_count ec.temp 1

# Get pet name from marker entity (fallback if marker unreachable)
data modify storage evercraft:companions letter.name set value "Your companion"
scoreboard players operation #Search companion.id = @s companion.id
execute store result storage evercraft:companions letter.slot int 1 run scoreboard players get #ltr_slot ec.temp
function evercraft:companions/expedition/letter/get_name with storage evercraft:companions letter

# Roll biome for letter flavor
execute store result score #ltr_biome ec.temp run random value 1..12
execute if score #ltr_biome ec.temp matches 1 run data modify storage evercraft:companions letter.biome set value "the Plains"
execute if score #ltr_biome ec.temp matches 2 run data modify storage evercraft:companions letter.biome set value "a Forest"
execute if score #ltr_biome ec.temp matches 3 run data modify storage evercraft:companions letter.biome set value "the Desert"
execute if score #ltr_biome ec.temp matches 4 run data modify storage evercraft:companions letter.biome set value "a Jungle"
execute if score #ltr_biome ec.temp matches 5 run data modify storage evercraft:companions letter.biome set value "the Mountains"
execute if score #ltr_biome ec.temp matches 6 run data modify storage evercraft:companions letter.biome set value "an Ocean Shore"
execute if score #ltr_biome ec.temp matches 7 run data modify storage evercraft:companions letter.biome set value "a Swamp"
execute if score #ltr_biome ec.temp matches 8 run data modify storage evercraft:companions letter.biome set value "the Taiga"
execute if score #ltr_biome ec.temp matches 9 run data modify storage evercraft:companions letter.biome set value "the Savanna"
execute if score #ltr_biome ec.temp matches 10 run data modify storage evercraft:companions letter.biome set value "a Dark Forest"
execute if score #ltr_biome ec.temp matches 11 run data modify storage evercraft:companions letter.biome set value "the Mushroom Fields"
execute if score #ltr_biome ec.temp matches 12 run data modify storage evercraft:companions letter.biome set value "the Frozen Peaks"

# 15% chance for rare lore letter
execute store result score #ltr_rare ec.temp run random value 1..100
execute if score #ltr_rare ec.temp matches 1..15 run function evercraft:companions/expedition/letter/deliver_rare
execute if score #ltr_rare ec.temp matches 1..15 run return 0

# Normal letter — pick tier-appropriate message
execute if score #ltr_tier ec.temp matches 1..40 run function evercraft:companions/expedition/letter/tier_common
execute if score #ltr_tier ec.temp matches 41..65 run function evercraft:companions/expedition/letter/tier_uncommon
execute if score #ltr_tier ec.temp matches 66..85 run function evercraft:companions/expedition/letter/tier_rare
execute if score #ltr_tier ec.temp matches 86..95 run function evercraft:companions/expedition/letter/tier_ornate
execute if score #ltr_tier ec.temp matches 96..100 run function evercraft:companions/expedition/letter/tier_exquisite

# Display the composed letter
function evercraft:companions/expedition/letter/display with storage evercraft:companions letter
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.2
playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.8 1.0
