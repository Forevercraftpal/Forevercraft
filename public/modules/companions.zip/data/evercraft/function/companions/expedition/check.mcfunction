# Pet Expedition System — Scheduled check (60s loop)
schedule function evercraft:companions/expedition/check 60s

# Check each player for completed expeditions
execute as @a[scores={ec.exp_count=1..}] run function evercraft:companions/expedition/check_player
