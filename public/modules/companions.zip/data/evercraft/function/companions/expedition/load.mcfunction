# Pet Expedition System — Load
# 3 expedition slots per player: end time (gametime when complete) + slot index

scoreboard objectives add ec.exp_count dummy "Active Expeditions"
scoreboard objectives add ec.exp1_end dummy "Expedition 1 End"
scoreboard objectives add ec.exp2_end dummy "Expedition 2 End"
scoreboard objectives add ec.exp3_end dummy "Expedition 3 End"
scoreboard objectives add ec.exp1_slot dummy "Expedition 1 Slot"
scoreboard objectives add ec.exp2_slot dummy "Expedition 2 Slot"
scoreboard objectives add ec.exp3_slot dummy "Expedition 3 Slot"
scoreboard objectives add ec.exp_send trigger "Send on Expedition"
scoreboard objectives add ec.exp1_tier dummy "Expedition 1 Tier Roll"
scoreboard objectives add ec.exp2_tier dummy "Expedition 2 Tier Roll"
scoreboard objectives add ec.exp3_tier dummy "Expedition 3 Tier Roll"
scoreboard objectives add ec.exp1_ltr dummy "Expedition 1 Letters Sent"
scoreboard objectives add ec.exp2_ltr dummy "Expedition 2 Letters Sent"
scoreboard objectives add ec.exp3_ltr dummy "Expedition 3 Letters Sent"
scoreboard players enable @a ec.exp_send

# Start 60s check schedule
schedule function evercraft:companions/expedition/check 60s
