# Companion Letter — Display normal letter (Macro)
# $(name) = pet name, $(biome) = biome text, $(message) = tier hint text
$data modify storage evercraft:notify stage.c set value [{text:"From ",color:"green"},{text:"$(name)",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"\"Exploring $(biome)... $(message)\"",color:"green",italic:true}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit
