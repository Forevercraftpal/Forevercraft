# Companion Letter — Display normal letter (Macro)
# $(name) = pet name, $(biome) = biome text, $(message) = tier hint text
$tellraw @s [{text:""},{"text":"[Letter] ","color":"dark_green","bold":true},{"text":"From ","color":"green"},{"text":"$(name)","color":"yellow"}]
$tellraw @s [{text:"  \"Exploring $(biome)... $(message)\"","color":"green","italic":true}]
