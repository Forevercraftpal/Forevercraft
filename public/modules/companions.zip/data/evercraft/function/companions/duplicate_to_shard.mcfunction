# Duplicate Pet Detected — Determine tier and convert to shards or prompt
# Runs as @s = player, evercraft:companions has generatedItem + name in storage
# Head block is already removed at this point

# Determine tier from pet name
data modify storage evercraft:companion_combat companion_name set from storage evercraft:companions name
function evercraft:companions/combat/get_tier_stats

# Set shard count based on tier: Common=1, Uncommon=2, Rare=3, Ornate=5, Exquisite=10, Mythical=25
scoreboard players set #shard_count ec.temp 1
execute if score #pc_tier ec.var matches 2 run scoreboard players set #shard_count ec.temp 2
execute if score #pc_tier ec.var matches 3 run scoreboard players set #shard_count ec.temp 3
execute if score #pc_tier ec.var matches 4 run scoreboard players set #shard_count ec.temp 5
execute if score #pc_tier ec.var matches 5 run scoreboard players set #shard_count ec.temp 10
execute if score #pc_tier ec.var matches 6 run scoreboard players set #shard_count ec.temp 25

# Store shard count to storage for macro grant
execute store result storage evercraft:companions shard_count int 1 run scoreboard players get #shard_count ec.temp

# Tier 1-4 (Common through Ornate): auto-convert immediately
execute if score #pc_tier ec.var matches 1..4 run function evercraft:companions/grant_shards with storage evercraft:companions
data modify storage evercraft:notify stage.c set value [{text:"\u27F3 ",color:"yellow"},{text:"Duplicate companion detected! ",color:"gray"},{text:"Converted to ",color:"white"},{score:{name:"#shard_count",objective:"ec.temp"},color:"aqua"},{text:" Companion Shard(s)",color:"aqua"},{text:".",color:"white"}]
scoreboard players set #ndur ec.temp 45
execute if score #pc_tier ec.var matches 1..4 run function evercraft:util/notify/emit
execute if score #pc_tier ec.var matches 1..4 at @s run function evercraft:fx/companion/shard
# SP7: a dupe of an owned species also grants ONE free roll to open the next ability slot on that
# species' active head (non-deterministic \u2014 dupes add SLOTS not power). `name` + #pc_tier are live here.
execute if score #pc_tier ec.var matches 1..4 run function evercraft:companions/skills/dupe_slot_roll
execute if score #pc_tier ec.var matches 1..4 run return 0

# Tier 5-6 (Exquisite/Mythical): show confirmation prompt
# Edge case: if player already has a pending confirm (placed 2 Exquisite+ heads back-to-back),
# auto-convert the new one to shards instead of overwriting the pending data
scoreboard players operation #Search companion.id = @s companion.id
execute if score #pc_tier ec.var matches 5..6 in overworld if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDup run function evercraft:companions/grant_shards with storage evercraft:companions
data modify storage evercraft:notify stage.c set value [{text:"\u27F3 ",color:"yellow"},{text:"Duplicate companion detected! ",color:"gray"},{text:"Converted to ",color:"white"},{score:{name:"#shard_count",objective:"ec.temp"},color:"aqua"},{text:" Companion Shard(s)",color:"aqua"},{text:" (previous confirm still pending).",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #pc_tier ec.var matches 5..6 in overworld if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDup run function evercraft:util/notify/emit
execute if score #pc_tier ec.var matches 5..6 in overworld if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDup at @s run function evercraft:fx/companion/shard
execute if score #pc_tier ec.var matches 5..6 in overworld if data entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDup run return 0

# No pending confirm — show prompt normally
execute if score #pc_tier ec.var matches 5..6 run function evercraft:companions/duplicate_confirm
