# Player confirmed: Convert Exquisite/Mythical duplicate to Companion Shards
# Runs as @s = player, triggered by ec.dup_confirm = 2

# Reset trigger
scoreboard players set @s ec.dup_confirm 0
scoreboard players enable @s ec.dup_confirm

# Retrieve shard count from marker
scoreboard players operation #Search companion.id = @s companion.id
execute in overworld store result score #shard_count ec.temp run data get entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDupShards

# Store count to storage for macro grant
execute store result storage evercraft:companions shard_count int 1 run scoreboard players get #shard_count ec.temp

# Grant shards
function evercraft:companions/grant_shards with storage evercraft:companions

# Notify
data modify storage evercraft:notify stage.c set value [{text:"\u27F3 ",color:"yellow"},{text:"Duplicate converted to ",color:"white"},{score:{name:"#shard_count",objective:"ec.temp"},color:"aqua"},{text:" Companion Shard(s)",color:"aqua"},{text:"!",color:"white"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/companion/shard

# SP7: a confirmed Exquisite/Mythical dupe also grants ONE free roll to open the next ability slot on
# that species' active head (non-deterministic — dupes add SLOTS not power). Re-establish the species
# key + #pc_tier (not in scope on this deferred-confirm path) before rolling.
data modify storage evercraft:companions name set from entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDupName
data modify storage evercraft:companion_combat companion_name set from storage evercraft:companions name
function evercraft:companions/combat/get_tier_stats
function evercraft:companions/skills/dupe_slot_roll

# Clean up pending data from marker
execute in overworld run data remove entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDup
execute in overworld run data remove entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDupName
execute in overworld run data remove entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDupShards
