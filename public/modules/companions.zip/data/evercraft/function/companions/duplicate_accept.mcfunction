# Player confirmed: Convert Exquisite/Mythical duplicate to Companion Shards
# Runs as @s = player, triggered by ec.dup_confirm = 2

# Reset trigger
scoreboard players set @s ec.dup_confirm 0
scoreboard players enable @s ec.dup_confirm

# Retrieve shard count from marker
scoreboard players operation #Search companion.id = @s companion.id
execute in overworld store result score #shard_count ec.temp run data get entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDupShards

# Store count to storage for macro grant
execute store result storage evercraft:companions shard_count int 1 run scoreboard players get #shard_count ec.temp

# Grant shards
function evercraft:companions/grant_shards with storage evercraft:companions

# Notify
tellraw @s [{"text":"\u27F3 ","color":"yellow"},{"text":"Duplicate converted to ","color":"white"},{"score":{"name":"#shard_count","objective":"ec.temp"},"color":"aqua"},{"text":" Companion Shard(s)","color":"aqua"},{"text":"!","color":"white"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1.2

# Clean up pending data from marker
execute in overworld run data remove entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDup
execute in overworld run data remove entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDupName
execute in overworld run data remove entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDupShards
