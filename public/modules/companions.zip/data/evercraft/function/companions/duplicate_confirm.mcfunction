# Exquisite/Mythical Duplicate — Confirmation Prompt
# Runs as @s = player, #pc_tier ec.var = 5 or 6, #shard_count ec.temp = 10 or 25
# Stores pending data on marker for later retrieval

# Store pending duplicate item + name on player's companion marker
scoreboard players operation #Search companion.id = @s companion.id
execute in overworld run data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDup set from storage evercraft:companions generatedItem
execute in overworld run data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDupName set from storage evercraft:companions name
execute in overworld store result entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDupShards int 1 run scoreboard players get #shard_count ec.temp

# Enable trigger for player response
scoreboard players enable @s ec.dup_confirm

# Show confirmation message
tellraw @s ""
execute if score #pc_tier ec.var matches 5 run tellraw @s [{"text":"\u26A0 ","color":"gold"},{"text":"You already own this ","color":"white"},{"nbt":"generatedItem.components.\"minecraft:custom_name\"","storage":"evercraft:companions","interpret":true},{"text":"!","color":"white"},{"text":" (Exquisite)","color":"#00AAFF","bold":true}]
execute if score #pc_tier ec.var matches 6 run tellraw @s [{"text":"\u26A0 ","color":"gold"},{"text":"You already own this ","color":"white"},{"nbt":"generatedItem.components.\"minecraft:custom_name\"","storage":"evercraft:companions","interpret":true},{"text":"!","color":"white"},{"text":" (Mythical)","color":"#FF55FF","bold":true}]
execute if score #pc_tier ec.var matches 5 run tellraw @s [{"text":"  Convert to ","color":"gray"},{"text":"10 Companion Shards","color":"aqua"},{"text":"? Or keep for trading.","color":"gray"}]
execute if score #pc_tier ec.var matches 6 run tellraw @s [{"text":"  Convert to ","color":"gray"},{"text":"25 Companion Shards","color":"aqua"},{"text":"? Or keep for trading.","color":"gray"}]
tellraw @s [{"text":"  "},{"text":"[Convert to Shards]","color":"aqua","bold":true,"click_event":{"action":"run_command","command":"/trigger ec.dup_confirm set 2"}},{"text":"  "},{"text":"[Keep Duplicate]","color":"green","bold":true,"click_event":{"action":"run_command","command":"/trigger ec.dup_confirm set 3"}}]
