# Player chose: Keep the duplicate Exquisite/Mythical pet
# Runs as @s = player, triggered by ec.dup_confirm = 3

# Reset trigger
scoreboard players set @s ec.dup_confirm 0
scoreboard players enable @s ec.dup_confirm

# Restore pending item data to storage so store_companion can read it
scoreboard players operation #Search companion.id = @s companion.id
execute in overworld run data modify storage evercraft:companions generatedItem set from entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDup
execute in overworld run data modify storage evercraft:companions name set from entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDupName

# Store the companion normally (adds to Pets[] array)
function evercraft:companions/handler/database/store_companion

# Clean up pending data from marker
execute in overworld run data remove entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDup
execute in overworld run data remove entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDupName
execute in overworld run data remove entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.PendingDupShards
