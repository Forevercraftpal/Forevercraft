execute if data storage evercraft:companions uninstalled run return fail
# Guard: if companion constants not loaded yet, re-trigger load and skip this tick
execute unless data storage evercraft:companions constants run return run schedule function evercraft:companions/load 1t

# Death-screen gate: @a includes players on the "You Died" screen (entity loaded, Health 0.0f, not yet
# respawned). Skip them so the active-pet AI/movement doesn't teleport the pet onto the corpse, AND the
# marker-failsafe (test_for_marker) doesn't re-mint a companion marker mid-death — which in Pioneer
# races admin/strip_player_zero (it just killed the marker + zeroed companion.id) and re-creates data the
# strip erased.
# Joseph 2026-06-07 FIX (pets stopped following): gate on the LIVE entity Health (==0.0f = on the death
# screen), NOT the ec.health SCOREBOARD. ec.health is a health-CRITERION objective that only re-syncs on a
# health CHANGE, so an ALIVE player whose criterion is stuck at 0 (after admin/strip_player_zero, or before
# it first fires) was wrongly skipped here → the active pet's AI/follow never ran. The entity Health is
# always accurate, so this runs for every alive player and skips only true "You Died"-screen ones. This
# also subsumes the old inmenuv2 menu-tick fallback (player/main runs the menu tick for alive inmenuv2).
execute as @a at @s unless data entity @s {Health:0.0f} run function evercraft:companions/handler/player/main

# OPT: Timer moved to 1s self-schedule (was per-tick inline — saved 920 ops/sec)

# --------------------------------------------------------------------------------- #

# OPT: Single time query for all gametime-based checks (was 2 separate queries)
execute store result score #gt_mem ec.temp run time query gametime

# OPT: Consolidated 5s + 20s companion checks into 1 @a dispatch
scoreboard players operation #gt_rival ec.temp = #gt_mem ec.temp
scoreboard players operation #gt_rival ec.temp %= #400 companion.calc
scoreboard players operation #gt_mem ec.temp %= #100 companion.calc
execute if score #gt_mem ec.temp matches 0 as @a[tag=companion.activepet] at @s run function evercraft:companions/tick_5s_player

# === PET DUEL: Detect cross-pet clicks (player sneak-right-clicked ANOTHER player's pet) ===
# After player/main processes own-pet interactions, any remaining interaction data on
# pet interaction entities is from a NON-OWNER click → potential duel challenge
# R11: existence-gate the two per-tick @e[type=interaction] pool scans (timer:9 idiom) — was
# ungated, paid 20x/sec on every server including pet-free ones.
execute if entity @e[type=interaction, tag=companion.petinteract, limit=1] as @e[type=interaction, tag=companion.petinteract] if data entity @s interaction run function evercraft:pet_duel/detect_cross_click
execute if entity @e[type=interaction, tag=companion.petinteract, limit=1] as @e[type=interaction, tag=companion.petinteract] if data entity @s interaction run data remove entity @s interaction

# Pet Expedition: check trigger for sending pets
execute as @a[scores={ec.exp_send=1..}] at @s run function evercraft:companions/expedition/send

# Companion Journeys (SP4): check the GUI send trigger for sending a sub on a themed run. Runs at
# jrny_cnt 0 too (the 60s journey/check is jrny_cnt-gated, so the FIRST journey must start here).
execute as @a[scores={ec.journey_send=1..}] at @s run function evercraft:companions/journey/dispatch_send

# Duplicate Confirmation: process player trigger responses
execute as @a[scores={ec.dup_confirm=2}] run function evercraft:companions/duplicate_accept
execute as @a[scores={ec.dup_confirm=3}] run function evercraft:companions/duplicate_keep

# Horn Stance first-summon pick: process the clickable [Active]/[Passive] prompt (SP1).
execute as @a[scores={ec.stance_pick=1}] run function evercraft:companions/horn/set_default_stance
execute as @a[scores={ec.stance_pick=2}] run function evercraft:companions/horn/set_default_stance

# Pet Pickup: process trigger from health status [Pick Up] button
execute as @a[scores={ec.pet_pickup=1}] run function evercraft:companions/health/pick_up

# Weakened companion: smoke particles every 5s (reuse gt_mem from above)
execute if score #gt_mem ec.temp matches 0 as @a[tag=companion.weakened,tag=companion.activepet] at @s run function evercraft:companions/health/apply_weakness

# Companion Roar — 1s cadence (cooldown decrement + Mode 1 auto-house dispatch).
# Gate on gametime % 20 == 0 so this block runs once per second, not per tick.
execute store result score #gt_roar ec.temp run time query gametime
scoreboard players operation #gt_roar ec.temp %= #20 companion.calc
execute if score #gt_roar ec.temp matches 0 run function evercraft:companions/roar/tick

# Group-6: despawn Evoker "Vex Swarm" cosmetic vexes once they've lived ~4s (Age in game-ticks). Single
# global existence-gated per-entity pass on the 1s cadence — these are NoAI flair entities, not real
# minions. Age is read into a per-entity score so we can range-compare (selector NBT matches are exact).
execute if score #gt_roar ec.temp matches 0 if entity @e[type=vex,tag=companion.evoker_vex,limit=1] as @e[type=vex,tag=companion.evoker_vex] run function evercraft:companions/handler/active/abilities/trigger/evoker_vex_despawn
