# ============================================================================
# ONE-TIME MIGRATION worker (R3) — reseat a single id-0 player. (one-time migration)
# @s = the lone player whose companion.id == 0 (verified by the caller migrate_id0).
# ----------------------------------------------------------------------------
# Plan: old id (0) stays in #Search so the check_id predicate still resolves the player's
# legacy-stamped entities; we mint a fresh id into #NewId and stamp it onto every persistent
# companion entity + the player, then advance the global counter. Order matters: re-stamp the
# ENTITIES while #Search is still 0, then move the PLAYER off 0 last.
# ============================================================================

# Snapshot the legacy id (0) for the check_id predicate that finds this player's entities.
scoreboard players operation #Search companion.id = @s companion.id

# Mint a fresh id from the global counter (assign-then-increment, exactly like new_player).
scoreboard players operation #NewId companion.id = #Global companion.id
scoreboard players add #Global companion.id 1

# --- Re-stamp every persistent entity that still carries the legacy id (#Search = 0). ---
# Active trio: floating head, its hp_label passenger, the petinteract interaction.
execute in overworld run scoreboard players operation @e[type=item_display,tag=Companion,predicate=evercraft:companions/check_id] companion.id = #NewId companion.id
execute in overworld run scoreboard players operation @e[type=text_display,tag=companion.hp_label,predicate=evercraft:companions/check_id] companion.id = #NewId companion.id
execute in overworld run scoreboard players operation @e[type=interaction,tag=companion.petinteract,predicate=evercraft:companions/check_id] companion.id = #NewId companion.id
# Combat wolf (when out).
execute in overworld run scoreboard players operation @e[type=wolf,tag=CompanionWolf,predicate=evercraft:companions/check_id] companion.id = #NewId companion.id
# Home companion trio: invisible carrier chicken + HC.Head display + HC.Interact interaction.
execute in overworld run scoreboard players operation @e[type=chicken,tag=HomeCompanion,predicate=evercraft:companions/check_id] companion.id = #NewId companion.id
execute in overworld run scoreboard players operation @e[type=item_display,tag=HC.Head,predicate=evercraft:companions/check_id] companion.id = #NewId companion.id
execute in overworld run scoreboard players operation @e[type=interaction,tag=HC.Interact,predicate=evercraft:companions/check_id] companion.id = #NewId companion.id
# The database marker (Pets[]/HomePets[]) — MUST be re-stamped or the player loses their roster.
execute in overworld run scoreboard players operation @e[type=marker,tag=companion.marker,predicate=evercraft:companions/check_id] companion.id = #NewId companion.id

# --- Move the PLAYER onto the fresh id LAST (after every entity is reseated). ---
scoreboard players operation @s companion.id = #NewId companion.id

# Quiet operator confirmation (no player-facing popup — this is a silent housekeeping reseat).
tellraw @a[tag=ec.admin] [{text:"[Companion Migration] ",color:"gold"},{selector:"@s"},{text:" reseated from legacy companion.id 0 to ",color:"gray"},{score:{name:"@s",objective:"companion.id"},color:"aqua"},{text:".",color:"gray"}]
