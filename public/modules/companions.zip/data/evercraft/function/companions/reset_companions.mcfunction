# Reset all pets for the player running this command
# Usage: /function evercraft:companions/reset_companions

# Store player's ID for marker lookup
scoreboard players operation #Search companion.id = @s companion.id

# Reset perks if active pet exists
execute if entity @s[tag=companion.activepet] run function evercraft:companions/handler/active/abilities/reset_perks

# Kill pet entities — predicate teardown via the shared helper (head+hp_label+interaction+wolf).
# R1: was missing the hp_label passenger kill on both the predicate and fallback paths. #Search set above.
function evercraft:companions/health/despawn_active_entities
# Fallback: kill ANY companion entities near the player (catches predicate mismatches / stale ids)
execute at @s run kill @e[type=wolf, tag=CompanionWolf, distance=..100]
execute at @s run kill @e[type=item_display, tag=Companion, distance=..100]
execute at @s run kill @e[type=interaction, tag=companion.petinteract, distance=..100]
execute at @s run kill @e[type=text_display, tag=companion.hp_label, distance=..100]
tag @s remove companion.activepet

# Close menu if open
execute if entity @s[tag=companion.inmenuv2] run function evercraft:companions/handler/menu_v2/close

# Clear the pet array — positioned approach (no predicate)
execute in overworld positioned 0 -60 0 as @n[type=marker,tag=companion.marker,distance=..10] run data modify entity @s data.Pets set value []
# Also try the predicate approach
execute in overworld run data modify entity @e[type=marker, tag=companion.marker, predicate=evercraft:companions/check_id, limit=1] data.Pets set value []
# Nuclear fallback: clear ALL companion markers
execute in overworld as @e[type=marker, tag=companion.marker] run data modify entity @s data.Pets set value []

# Reset all companion state
scoreboard players set @s companion.count 0
scoreboard players reset @s companion.activeslot
scoreboard players set @s companion.kills 0
# SP3: the data.Pets nuke above cleared every `departed` flag; drop the per-player win-back latch/scratch.
scoreboard players set @s companion.neglect 0
scoreboard players set @s companion.wb_slot 0
scoreboard players set @s companion.wb_timer 0
tag @s remove companion.wb_pending

# Confirm
tellraw @s [{text:"[Reset] Done. companion.id = ", color:"gold"},{score:{name:"@s",objective:"companion.id"},color:"aqua"}]
