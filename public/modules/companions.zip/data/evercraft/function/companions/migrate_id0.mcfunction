# ============================================================================
# ONE-TIME MIGRATION (R3) — reseat the legacy id-0 player onto a fresh companion.id
# ----------------------------------------------------------------------------
# Run automatically from companions/load (every /reload), but GUARDED so the body
# executes at most ONCE per world: the `#id0_migrated companion.id` flag latches it.
#   - Fresh world  -> first player is born id 1 (R3 seed), this flag is set, body no-ops forever.
#   - Live world    -> the single pre-R3 id-0 player is reseated to a fresh id ONCE.
#   - Re-run / re-/reload -> flag already 1 -> immediate return (idempotent).
# This is a "one-time migration" fixture (dead-code-audit marker — preserved by policy).
#
# WHY: before R3, companions/load seeded #Global companion.id to 0, so the FIRST player to
# join got companion.id 0 and strip_player_zero re-sets 0. Every companion entity that player
# owns (marker, head, hp_label, petinteract, combat wolf, home trio) is stamped id 0, and the
# ~3,952 check_id selectors that key on it now collide with the 0-sentinel. We hand that player
# a fresh id (>=1) from the global counter and RE-STAMP all their live entities + their marker.
#
# SAFETY BOUNDARY (documented gap — see change report):
#   Companion markers are NOT owner-UUID-keyed; they are paired to a player ONLY by companion.id
#   (predicate=check_id) and all live co-located at ~0 -60 0. So if TWO OR MORE players share
#   id 0, no selector can reliably pair player->marker, and re-stamping could hand one player's
#   companions to another. We therefore migrate ONLY when EXACTLY ONE player has id 0 (the live
#   single-early-adopter case). If 2+ share id 0 we STOP, leave them untouched, and log an admin
#   warning rather than guess. On a clean Testing world there are zero id-0 owners -> pure no-op.
# ============================================================================

# --- Guard: skip once a real reseat has completed. ---
execute if score #id0_migrated companion.id matches 1 run return 0
# NOTE: we do NOT latch here. We latch ONLY after a confirmed reseat (bottom of file). If the
# lone legacy id-0 player is OFFLINE during this /reload, @a cannot see them — counting would
# yield 0. Latching on a no-op would skip them PERMANENTLY when they next log in. Leaving the
# flag unset means we simply re-check next reload (cost: one @a count, negligible). mcfunctions
# run atomically to completion, so there is no mid-run /reload to guard against.

# Count players currently sitting on the legacy id 0.
scoreboard players set #id0_count companion.id 0
execute as @a if score @s companion.id matches 0 run scoreboard players add #id0_count companion.id 1

# Ambiguous multi-player case: cannot safely pair markers — STOP and warn an operator. Do NOT guess.
execute if score #id0_count companion.id matches 2.. run tellraw @a[tag=ec.admin] [{text:"[Companion Migration] ",color:"gold"},{text:"2+ players share legacy companion.id 0 — auto-reseat SKIPPED (markers are not owner-keyed). Run ",color:"yellow"},{text:"/function evercraft:companions/reset_companions",color:"aqua"},{text:" per-player or reseat manually.",color:"yellow"}]
execute if score #id0_count companion.id matches 2.. run return 0

# Nothing to do (clean / fresh world, or the lone id-0 slot is unused).
execute if score #id0_count companion.id matches 0 run return 0

# --- Exactly one id-0 player: reseat them. ---
execute as @a[limit=1] if score @s companion.id matches 0 run function evercraft:companions/migrate_id0_one

# Latch ONLY now — exactly one id-0 player was present and has been reseated. Future reloads skip.
scoreboard players set #id0_migrated companion.id 1
