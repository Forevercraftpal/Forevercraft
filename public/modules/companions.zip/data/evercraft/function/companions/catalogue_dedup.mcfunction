# Companion Catalogue — Duplicate → Shard conversion
# Reward for advancement evercraft:companions/catalogue_dedup (inventory_changed).
# A player never needs more than one Companion Catalogue, and holders of an
# Eternal/Phoenix Codex need none at all (the codex opens the companion menu —
# see companions/handler/menu_v2/tick). Any redundant catalogue handed out by a
# crate is crystallized into Companion Shards instead.
# @s = player

# Re-arm the trigger so the NEXT catalogue is caught too.
advancement revoke @s only evercraft:companions/catalogue_dedup

# Count Companion Catalogues currently in the player's inventory (clear ... 0 reports, removes nothing).
execute store result score #shard_count ec.temp run clear @s book[custom_data~{CompanionMenuKey:true}] 0
execute if score #shard_count ec.temp matches ..0 run return 0

# How many catalogues to keep: 1 normally, 0 if the player already holds an Eternal/Phoenix Codex.
scoreboard players set #cd_keep ec.temp 1
execute if items entity @s container.* book[custom_data~{eternal_codex:true}] run scoreboard players set #cd_keep ec.temp 0
execute if items entity @s weapon.offhand book[custom_data~{eternal_codex:true}] run scoreboard players set #cd_keep ec.temp 0
execute if items entity @s container.* book[custom_data~{phoenix_codex:true}] run scoreboard players set #cd_keep ec.temp 0
execute if items entity @s weapon.offhand book[custom_data~{phoenix_codex:true}] run scoreboard players set #cd_keep ec.temp 0

# Surplus = count - keep. Nothing to do if the player only has the one they're allowed.
scoreboard players operation #shard_count ec.temp -= #cd_keep ec.temp
execute if score #shard_count ec.temp matches ..0 run return 0

# Convert the surplus catalogues into an equal number of Companion Shards.
execute store result storage evercraft:companions shard_count int 1 run scoreboard players get #shard_count ec.temp
function evercraft:companions/catalogue_dedup_clear with storage evercraft:companions
function evercraft:companions/grant_shards with storage evercraft:companions

# Feedback (mirrors the duplicate-companion conversion style).
data modify storage evercraft:notify stage.c set value [{text:"⟳ ",color:"yellow"},{text:"Extra Companion Catalogue — ",color:"gray"},{text:"crystallized into ",color:"white"},{score:{name:"#shard_count",objective:"ec.temp"},color:"aqua"},{text:" Companion Shard(s)",color:"aqua"},{text:".",color:"white"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute at @s run function evercraft:fx/companion/shard
