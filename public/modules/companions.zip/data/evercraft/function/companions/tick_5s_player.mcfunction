# Companion — Consolidated 5s per-player tick (memories + hours + passive RP + rivalry)
# OPT: 5s + 20s companion checks merged into single @a dispatch
# Run as: player with companion.activepet tag, at player position

function evercraft:companions/memories/tick_checks
function evercraft:companions/memories/tick_hours
function evercraft:companions/handler/home/passive_rp_active

# Rivalry check (only runs every 20s — when gametime % 400 == 0)
execute if score #gt_rival ec.temp matches 0 run function evercraft:companions/rivalry/check

# Companion gift check (only runs every 20s to reduce overhead)
execute if score #gt_rival ec.temp matches 0 run function evercraft:companions/gifts/tick

# SP4: sub-companion gift drip (1/8 the main rate). Same 20s cadence; internally gated to ~12h per drip
# and skipped entirely for players with no subs assigned.
execute if score #gt_rival ec.temp matches 0 run function evercraft:companions/gifts/sub_tick

# Companion coin pickup check (every 5s, with internal 3-day cooldown + random roll)
function evercraft:companions/coin_pickup

# Bond skill 11 Thick Hide — refresh the owner's Resistance I aura (7s window > 5s cadence so it never
# lapses). Gated on the companion.bond_thickhide tag set in bond/apply_skill_auras; dropped there when the
# skill is lost or the pet is dismissed (this @s already has companion.activepet).
execute if entity @s[tag=companion.bond_thickhide] run effect give @s minecraft:resistance 7 0 true
