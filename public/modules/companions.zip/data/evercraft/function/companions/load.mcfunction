data remove storage evercraft:companions uninstalled

advancement revoke @a only evercraft:companions/add_to_player
advancement revoke @a only evercraft:companions/menu_v2/spawn
# Re-arm the catalogue duplicate→shard trigger for everyone after a reload.
advancement revoke @a only evercraft:companions/catalogue_dedup
# SP1: re-arm the Claude flagship empowered-hit detector after a reload (so the next hit fires).
advancement revoke @a only evercraft:companions/horn/flagship_hit

scoreboard objectives add companion.timer dummy
scoreboard objectives add companion.id dummy

# Companion Catalogue use flag (2-step pattern: advancement sets flag, tick processes)
scoreboard objectives add ec.cc_use dummy "Catalogue Use Flag"
scoreboard objectives add companion.count dummy
# Companion Dex (Joseph 2026-06-06): distinct companion species owned (of 104), and how many owned as
# shiny. Recomputed authoritatively by companions/dex/recompute on menu open; drives the X/104 hub
# display + the Complete-Catalogue shiny bonus (wild_companions/shiny/roll).
scoreboard objectives add ec.comp_dex dummy "Species Discovered"
scoreboard objectives add ec.comp_dex_shiny dummy "Shiny Species"
scoreboard objectives add companion.menu dummy
scoreboard objectives add companion.menupage dummy
scoreboard objectives add companion.calc dummy
scoreboard objectives add companion.exp dummy
scoreboard objectives add companion.playerexp xp
scoreboard objectives add companion.previousplayerexp dummy
scoreboard objectives add companion.temp dummy
scoreboard objectives add companion.slot dummy

# Relationship system scoreboards
scoreboard objectives add companion.rp dummy
scoreboard objectives add companion.rellevel dummy
scoreboard objectives add companion.relmult dummy
scoreboard objectives add companion.feedcd dummy
scoreboard objectives add companion.interactcd dummy

# Dupe-fusion: the active pet's fuse_count cached on the OWNER at summon (mirrors companion.relmult).
# Read by the flavor-ability fuse helper (handler/active/abilities/fuse_dmg) so trigger abilities scale
# their burst by +1%/fuse without a per-event NBT round-trip. Live-updated by dupe_fuse_advance on fuse.
scoreboard objectives add companion.fuse dummy "Active pet fuse_count (session)"

# Kill counter (per active companion session)
scoreboard objectives add companion.kills dummy

# Companion Health system
scoreboard objectives add companion.hp dummy "Companion HP"
scoreboard objectives add companion.maxhp dummy "Companion Max HP"
scoreboard objectives add ec.pet_pickup trigger "Pet Pickup"
execute as @a run scoreboard players enable @s ec.pet_pickup

# Boss bar for health status display (shift-click)
bossbar add evercraft:companion_health {text:"Companion Health",color:"green"}
bossbar set evercraft:companion_health max 100
bossbar set evercraft:companion_health visible false

# Active companion slot index (used for unsummon detection and memory sync)
scoreboard objectives add companion.activeslot dummy

# Rivalry cooldown
scoreboard objectives add ec.rival_cd dummy

# Bee "Honey Shield" cooldown (Group-5 companion ability)
scoreboard objectives add ec.bee_shield_cd dummy

# Wither "Death's Door" cheat-death cooldown (Group-6 companion ability; value in ticks, 6000 = 5min)
scoreboard objectives add ec.wither_doors_cd dummy

# Home companion system scoreboards
scoreboard objectives add hc.count dummy
scoreboard objectives add hc.slot dummy
scoreboard objectives add hc.wander dummy
scoreboard objectives add hc.rp_timer dummy
scoreboard objectives add hc.active_rp dummy
scoreboard objectives add hc.petcd dummy
scoreboard objectives add hc.feedcd dummy

scoreboard players set #0 companion.calc 0
scoreboard players set #1 companion.calc 1
scoreboard players set #2 companion.calc 2
scoreboard players set #4 companion.calc 4
scoreboard players set #5 companion.calc 5
scoreboard players set #8 companion.calc 8
scoreboard players set #10 companion.calc 10
scoreboard players set #15 companion.calc 15
scoreboard players set #20 companion.calc 20
scoreboard players set #100 companion.calc 100
scoreboard players set #400 companion.calc 400
scoreboard players set #1000 companion.calc 1000
scoreboard players set #5000 companion.calc 5000
scoreboard players set #25 companion.calc 25
scoreboard players set #18 companion.calc 18
scoreboard players set #48 companion.calc 48

# Timer divisor constants (OPT: precomputed for schedule/timer.mcfunction)
scoreboard players set #3 companion.calc 3
scoreboard players set #12 companion.calc 12
scoreboard players set #14 companion.calc 14
scoreboard players set #16 companion.calc 16
scoreboard players set #22 companion.calc 22
scoreboard players set #24 companion.calc 24
scoreboard players set #26 companion.calc 26
scoreboard players set #28 companion.calc 28
scoreboard players set #30 companion.calc 30
scoreboard players set #60 companion.calc 60
scoreboard players set #90 companion.calc 90
scoreboard players set #120 companion.calc 120
scoreboard players set #150 companion.calc 150
scoreboard players set #180 companion.calc 180

# Relationship level thresholds (scaled for 5000 max)
scoreboard players set #RelLvl1 companion.calc 500
scoreboard players set #RelLvl2 companion.calc 1250
scoreboard players set #RelLvl3 companion.calc 2250
scoreboard players set #RelLvl4 companion.calc 3500
scoreboard players set #RelLvl5 companion.calc 4500

# === SP1 HORN ABILITY ENGINE (Companion Overhaul, Wave 1) ===
# Objectives (one-writer owners documented in companions/horn/*):
scoreboard objectives add companion.horncd dummy "Horn Ability Cooldown"
scoreboard objectives add companion.stance dummy "Horn Stance (0=Active 1=Passive)"
scoreboard objectives add companion.slots dummy "Horn Ability Slots (read-cache)"
scoreboard objectives add companion.skillslot dummy "Active Horn Skill Slot"
scoreboard objectives add companion.flaghits dummy "Claude Flagship empowered hits"
scoreboard objectives add companion.thornmag dummy "Horn Thorns reflect magnitude (half-hearts)"
# First-summon stance pick (clickable tellraw → /trigger, same pattern as ec.dup_confirm). The
# trigger is enabled per-player only while the prompt is live; the click sets 1 (Active) / 2 (Passive).
scoreboard objectives add ec.stance_pick trigger "Horn Stance Pick"
execute as @a run scoreboard players enable @s ec.stance_pick
# Default stance = Active (0). First-summon prompt (set_default_stance) lets the player pick;
# this `unless …matches 0..` seed only fires for players who never owned a companion.
execute as @a unless score @s companion.stance matches 0.. run scoreboard players set @s companion.stance 0
# Seed horncd to 0 (READY) for any player who has never fired — the fire gate is `matches 0`, and an
# UNSET score matches nothing, so without this seed a brand-new player's horn would never fire.
execute as @a unless score @s companion.horncd matches 0.. run scoreboard players set @s companion.horncd 0

# BURST_CAP: per-cast burst-damage clamp in HALF-HEARTS (HP×2). 100 HP = 200 half-hearts for ALL
# abilities; Claude's flagship is the lone exception at 150 HP = 300 half-hearts (Joseph DECISIONS P1).
# Read by companions/horn/scale (the reusable clamp helper). One-writer = this load fn.
scoreboard players set #BURST_CAP ec.const 200
scoreboard players set #CLAUDE_CAP ec.const 300
# LEVEL power curve: LP = 1000 + (level-1)*15 → 2.485x at lvl 100 (scaling-balance §3.3).
scoreboard players set #LP_BASE ec.const 1000
scoreboard players set #LP_STEP ec.const 15
# Horn cooldown baseline (ticks): ~30s common (tier 1) → ~15s mythical (tier 6). Tier-hybrid: the
# baseline shortens by tier, Active stance ×70%, and bond rank (read in companions/horn/fire).
scoreboard players set #HORNCD_BASE ec.const 600
scoreboard players set #HORNCD_TIERCUT ec.const 60
# Stance multipliers (÷100): Active boost ×130, Active CD ×70.
scoreboard players set #STANCE_BOOST ec.const 130
scoreboard players set #STANCE_CDCUT ec.const 70
scoreboard players set #c100 ec.const 100

# === SP2 BOND & CARE (Companion Overhaul, Wave 2) ===
# Objectives (one-writer owners documented in companions/bond/*):
#   companion.happiness  — 0..100 care meter   (writer: bond/happiness/add, decay in bond/happiness/tick)
#   companion.happydays  — 7-day continuous-happy clock (writer: bond/happiness/tick)
#   companion.happypass  — bool: 7-day species-passive unlocked (writer: bond/happiness/unlock)
#   companion.bondskills — in-session decoded set-bond-skill bitfield (writer: bond/load_skills)
scoreboard objectives add companion.happiness dummy "Companion Happiness (0-100)"
scoreboard objectives add companion.happydays dummy "Continuous-happy day clock"
scoreboard objectives add companion.happypass dummy "7-day species-passive unlocked"
scoreboard objectives add companion.bondskills dummy "Set-bond skill bitfield (session)"
# Happiness bands (read by bond/happiness/* + reminders): 100..60 Happy, 59..25 Content,
# 24..1 Restless (reminder band), 0 Forlorn (SP3 abandonment trigger — built in Wave 3).
# Pet/Feed each refill +50 (literal in process_interact/feed → bond/happiness/add {amount:50}).
scoreboard players set #HAPPY_FULL ec.const 100
scoreboard players set #HAPPY_HAPPYBAND ec.const 60
scoreboard players set #HAPPY_DECAY ec.const 8
scoreboard players set #HAPPY_STREAK ec.const 7
# Set-bond-skill roll: 50% per rank-up, cap 5 stacked skills (12-skill roster, bits 0..11).
scoreboard players set #BOND_ROLLPCT ec.const 50
scoreboard players set #BOND_SKILLCAP ec.const 5
# Gift interval per bond rank (ticks). Baseline rank 0 = 108000t (1.5h); each rank ~ -8%..-42%.
# Read by gifts/tick (main companion). One-writer = this load fn (constants, reseeded on /reload).
scoreboard players set #GiftInt0 companion.calc 108000
scoreboard players set #GiftInt1 companion.calc 99000
scoreboard players set #GiftInt2 companion.calc 90000
scoreboard players set #GiftInt3 companion.calc 81000
scoreboard players set #GiftInt4 companion.calc 72000
scoreboard players set #GiftInt5 companion.calc 63000
# bond_skills bitfield power-of-two masks (NBT-packed, documented bit-range partition §4-D):
#   bits 0..11 = the 12 set-skill flags (owner: bond/roll_set_skill) — MONOTONIC, OR-only
#   bit  15    = happypass (species-passive unlocked, owner: bond/happiness/unlock) — MONOTONIC, OR-only
# happiness (0..100, resettable) + happydays (0..7, resettable) are their OWN profile properties
# (not packed into bond_skills) so their RESET path needs no fragile bit-masking — the §4-D 2-property
# split fallback, chosen because happydays/happiness genuinely decay/reset while the bond_skills bits
# never clear. Each remains single-writer.
scoreboard players set #bit0 companion.calc 1
scoreboard players set #bit1 companion.calc 2
scoreboard players set #bit2 companion.calc 4
scoreboard players set #bit3 companion.calc 8
scoreboard players set #bit4 companion.calc 16
scoreboard players set #bit5 companion.calc 32
scoreboard players set #bit6 companion.calc 64
scoreboard players set #bit7 companion.calc 128
scoreboard players set #bit8 companion.calc 256
scoreboard players set #bit9 companion.calc 512
scoreboard players set #bit10 companion.calc 1024
scoreboard players set #bit11 companion.calc 2048
scoreboard players set #bit15 companion.calc 32768
# Set-bond-skill rider constants: Swift Paws -15% horn CD (×85/100); Lucky Gifts -25% gift int (×75/100).
scoreboard players set #85 companion.calc 85
scoreboard players set #75 companion.calc 75

# === SP3 ABANDONMENT & WIN-BACK (Companion Overhaul, Wave 3a) ===
# Objectives (one-writer owners documented in companions/abandonment/* + handler/menu_v2/winback/*):
#   companion.neglect  — RESERVED neglect scratch (DATA-MODEL §1.5). The live LEAVE trigger reads
#                        companion.happiness==0 (Forlorn) directly in abandonment/check_leave, so this
#                        objective is declared for parity/forward-compat but is not the active signal.
#                        Owner (when used) = bond/happiness/tick (SP2). Reset on strip/wipe.
#   companion.wb_slot  — pending win-back target Pets[] index (writer: winback/offer).
#   companion.wb_timer — ~30s auto-expiry on the live offer (writer: winback/offer + winback/expire_tick).
scoreboard objectives add companion.neglect dummy "Companion neglect scratch (SP3)"
scoreboard objectives add companion.wb_slot dummy "Win-back pending Pets[] slot"
scoreboard objectives add companion.wb_timer dummy "Win-back offer auto-expiry"
# LEAVE immunity is by Eternal Bond (ec.pet_bonded) — same line SP2 happiness/tick decay-skips on, so no
# threshold constant is needed for the trigger. WIN-back constants (read by winback/restore):
#   #WINBACK_RP_FLOOR — RP floor on return = RelLvl1 (500, "Friend"); restore = max(floor, lastRP) (DECISIONS P22).
#   #WB_TIMER         — offer auto-expiry in ticks (~30s = 600t).
scoreboard players set #WINBACK_RP_FLOOR companion.calc 500
scoreboard players set #WB_TIMER companion.calc 600

# === SP9 HOUSE & GUILD PLACED-PET "HEARTH COMFORT" (Companion Overhaul, Plan Two) ===
# A modest passive the OWNER receives while at home (and guild members in the guild zone) for keeping
# companions placed. It SHARES the new framework's two persistent axes — TIER (#pc_tier 1..6 from
# combat/get_tier_stats) and BOND level (companion.rellevel-equivalent 0..5, decoded from the placed
# companion's `relationship` profile property). Neither axis is dropped on place/retrieve: both already
# travel on the HC.Head/GC.Head item_display (same item data as the active companion).
#   companion.hcomfort — cached HOME comfort score 0..11 (best placed companion's tier+bondLvl).
#                        ONE-writer = companions/handler/home/abilities/comfort_score (folded into the
#                        existing apply_all roster-change recompute; read each 2s by housing/zone/apply_buffs).
#   companion.gcomfort — cached GUILD comfort score 0..11 (best guild-placed companion's tier+bondLvl).
#                        ONE-writer = guild/pets/abilities/comfort_score (folded into apply_all_zone;
#                        read each 5s by guild/zone/apply_buffs).
# Effect-based, short-refresh (5s home / 7s guild), so it lapses cleanly the instant the player leaves the
# zone or the companion is retrieved — nothing lingers (mirrors the existing zone potion-buff pattern).
scoreboard objectives add companion.hcomfort dummy "Hearth Comfort score (home, 0-11)"
scoreboard objectives add companion.gcomfort dummy "Hearth Comfort score (guild, 0-11)"
# Comfort-score bands → effect strength (read by the two apply_buffs sites). Modest by design.
#   1..5  → Regeneration I
#   6..8  → Regeneration I + Saturation I
#   9..11 → Regeneration II + Saturation I
scoreboard players set #COMFORT_MID companion.calc 6
scoreboard players set #COMFORT_HIGH companion.calc 9

# === SP7 ASCENSION (dupes→slots) + SP8 WAYFARER TRACK + CHIPS (Companion Overhaul, Wave 5b) ===
# Slot hard-cap constant, read by skills/unlock_slot's re-clamp (the single per-instance slot writer).
scoreboard players set #c12 ec.const 12
# Wayfarer Track objectives (one-writer owners documented in companions/track/*):
#   ec.wf_xp       — Wayfarer Track XP (remap of dr.points + ec.wf_bonus)  writer: companions/track/accrue
#   ec.wf_node     — highest node UNLOCKED (claimable boundary)     writer: companions/track/accrue
#   ec.wf_claimed  — DEAD (legacy bitfield); real claimed model = 250 per-node advs companions/track/claimed/nN
#   ec.wf_baseline — per-season dr.points snapshot (evergreen=0)   writer: companions/track/season_advance
#   ec.wf_season   — current season index (evergreen first = 0)    writer: companions/track/season_advance
#   ec.wf_bonus    — Wayfarer cross-source bonus XP (evergreen additive)  writers: milestone event hooks
scoreboard objectives add ec.wf_xp dummy "Wayfarer Track XP"
scoreboard objectives add ec.wf_node dummy "Wayfarer highest node unlocked"
scoreboard objectives add ec.wf_claimed dummy "Wayfarer claimed-node bitfield"
scoreboard objectives add ec.wf_baseline dummy "Wayfarer per-season dr baseline"
scoreboard objectives add ec.wf_season dummy "Wayfarer season index"
scoreboard objectives add ec.wf_bonus dummy "Wayfarer cross-source bonus XP"
# Wayfarer GUI per-player pager + per-entity click-node stamp (menu_v2/wayfarer/*).
scoreboard objectives add companion.wf_page dummy "Wayfarer GUI page (0-2)"
scoreboard objectives add companion.wf_clicknode dummy "Wayfarer cell node stamp"
# Seed the node thresholds + reward table (#wf_thr_N ec.const). One-writer = track/load.
function evercraft:companions/track/load

# R3: seed the global id counter to 1, NOT 0. id 0 is reserved as the "no companion" sentinel
# so every check_id selector (~3,952 sites) is player-isolated and an id-0 orphan can never be
# pinned alive by an id-0 player's head. new_player.mcfunction assigns-then-increments, so the
# first real player gets id 1. Only seeds on a brand-new world (the `unless …matches 1..` guard
# never re-fires once the counter has advanced).
execute unless score #Global companion.id matches 1.. run scoreboard players set #Global companion.id 1
execute as @a unless score @s companion.id matches 0.. run advancement revoke @s only evercraft:companions/new_player

# R3: one-time, flag-guarded reseat of the legacy id-0 player onto a fresh id (no-op on a clean
# world). Runs AFTER the #Global seed (counter is live) and BEFORE orphan_sweep below (so the
# sweep runs over a clean, player-isolated id space).
function evercraft:companions/migrate_id0

team add companion.immunetowarden
team modify companion.immunetowarden friendlyFire false

team add companion.oreglow
team modify companion.oreglow color aqua

execute in overworld run forceload add 0 0 0 0
execute in overworld run setblock 0 -63 0 barrel{lock:{items:"command_block"}} replace

# Ensure existing companion markers have HomePets[] array (migration for existing players)
execute as @e[type=marker, tag=companion.marker] unless data entity @s data.HomePets run data modify entity @s data.HomePets set value []

# Migrate old stick-based Companion Catalogue to new book-based version
execute as @a run function evercraft:companions/handler/menu_v2/migrate_item

# Companion Gift System
scoreboard objectives add ec.pet_gift dummy "Pet Gift Timer (gametime)"
scoreboard objectives add ec.pet_gift_day dummy "Last Crate Gift Day"

# Duplicate Pet → Shard Conversion
scoreboard objectives add ec.dup_confirm trigger "Duplicate Confirm"
execute as @a run scoreboard players enable @s ec.dup_confirm
# Clean up stale PendingDup data on all markers (after reload, clickable tellraw is gone)
execute as @e[type=marker, tag=companion.marker] if data entity @s data.PendingDup run data remove entity @s data.PendingDup
execute as @e[type=marker, tag=companion.marker] if data entity @s data.PendingDupName run data remove entity @s data.PendingDupName
execute as @e[type=marker, tag=companion.marker] if data entity @s data.PendingDupShards run data remove entity @s data.PendingDupShards

# Companion Coin Pickup (gametime of last pickup)
scoreboard objectives add ec.pet_coin_cd dummy "Pet Coin Cooldown"

# Pet Expedition System (DEPRECATED — folded into Journeys, SP4. Kept for in-flight expeditions to drain;
# the send entry-point is retired. See companions/journey/* for the unified idle system.)
function evercraft:companions/expedition/load

# Companion Journey System (SP4 — unified idle/async-reward: 1 main + 2 subs, themed runs).
function evercraft:companions/journey/load

# New Companion GUI (SP5 — home view / Care / Skills frame / Journey frame / placed heads).
function evercraft:companions/handler/menu_v2/care/load_sp5

# Orphan hp_label sweep — kills lingering "❤ 0/0" passenger labels whose parent Companion
# head is gone (e.g., from pre-2026-05-27 deaths where strip_player_zero forgot to kill
# the passenger). Idempotent — safe to run on every /reload.
function evercraft:companions/health/orphan_sweep


data modify storage evercraft:companions constants.menu set value [{id:"bookshelf", Slot:18b, count:1, components:{custom_data:{MenuItem:1b}, "minecraft:max_stack_size":1,"minecraft:lore":[{italic:0b, text:"Displays your companion's level,", color:"gray"}, {italic:0b, text:"current exp, and the exp", color:"gray"}, {italic:0b, text:"needed for the next level.", color:"gray"}, "", {italic:0b, text:"No active companion detected", bold:1b, color:"red"}], "minecraft:custom_name":{italic:0b, text:"Companion Leveling Display", color:"aqua"}}}, {count:1, Slot:19b, components:{"minecraft:custom_data":{MenuItem:1b, Visibility:1b},"minecraft:max_stack_size":1, "minecraft:custom_name":{italic:0b, text:"Companion Visibility", color:"yellow"}}, id:"ender_eye"}, {count:1, Slot:20b, components:{"minecraft:custom_data":{MenuItem:1b},"minecraft:max_stack_size":1, tooltip_display:{hide_tooltip:true}}, id:"gray_stained_glass_pane"}, {count:1, Slot:21b, components:{"minecraft:max_stack_size":1,"minecraft:lore":[{color:"gray",italic:false,text:"Click to convert active companion"}, {color:"gray",italic:false,text:"back to an item."}, "", {color:"gray",italic:false,text:"This removes the active companion"}, {color:"gray",italic:false,text:"from your companion list."}], custom_data:{MenuItem:1b} ,"minecraft:custom_name":{color:"red",italic:false,text:"Convert companion to item"}}, id:"gray_dye"}, {count:1, Slot:22b, components:{"minecraft:max_stack_size":1,"minecraft:lore":[{color:"gray",italic:false,text:"Click to close the menu"}], custom_data:{MenuItem:1b} ,"minecraft:custom_name":{color:"dark_red",italic:false,text:"Close"}}, id:"barrier"}, {count:1, Slot:23b, components:{"minecraft:max_stack_size":1,"minecraft:lore":[{color:"gray",italic:false,text:"Click to despawn your"},{color:"gray",italic:false,text:"active companion"}], custom_data:{MenuItem:1b} ,"minecraft:custom_name":{color:"dark_red",italic:false,text:"Despawn Companion"}}, id:"purple_dye"}, {count:1, Slot:24b, components:{"minecraft:custom_data":{MenuItem:1b},"minecraft:max_stack_size":1, tooltip_display:{hide_tooltip:true}}, id:"gray_stained_glass_pane"}, {count:1, Slot:25b, components:{"minecraft:custom_data":{MenuItem:1b},"minecraft:max_stack_size":1, tooltip_display:{hide_tooltip:true}}, id:"gray_stained_glass_pane"}, {count:1, Slot:26b, components:{"minecraft:custom_data":{MenuItem:1b},"minecraft:max_stack_size":1, tooltip_display:{hide_tooltip:true}}, id:"gray_stained_glass_pane"}]

data modify storage evercraft:companions constants.pages set value [{Slot: 26b, count: 1, components: {custom_data: {MenuItem: 1b, PreviousPage:1b}, "minecraft:custom_name": {italic: 0b, text: "Previous Page", color: "green"}, "minecraft:max_stack_size": 1, "minecraft:lore": [{italic: 0b, text: "To page 1 (1-18)", color: "gray"}]}, id: "arrow"},{Slot: 26b, count: 1, components: {custom_data: {MenuItem: 1b, NextPage:1b}, "minecraft:custom_name": {italic: 0b, text: "Next Page", color: "green"}, "minecraft:max_stack_size": 1, "minecraft:lore": [{italic: 0b, text: "To page 2 (19-36)", color: "gray"}]}, id: "arrow"}]