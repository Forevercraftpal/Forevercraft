# Macro: remove the surplus Companion Catalogues being converted to shards.
# Source storage: evercraft:companions { shard_count: <n> }  (same compound used by grant_shards,
# so the count cleared always equals the count of shards granted).
# @s = player
$clear @s book[custom_data~{CompanionMenuKey:true}] $(shard_count)
