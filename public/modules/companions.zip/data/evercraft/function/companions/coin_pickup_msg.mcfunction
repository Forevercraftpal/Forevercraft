# Companion Coin Pickup — Random flavor messages
execute store result score #msg ec.temp run random value 1..5

execute if score #msg ec.temp matches 1 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Your companion found something shiny on the ground!","color":"yellow"}]
execute if score #msg ec.temp matches 2 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Your companion dug up a coin!","color":"yellow"}]
execute if score #msg ec.temp matches 3 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Your companion brought you a gift!","color":"yellow"}]
execute if score #msg ec.temp matches 4 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Something glinted in the grass \u2014 your companion spotted it!","color":"yellow"}]
execute if score #msg ec.temp matches 5 run tellraw @s [{"text":"\u2726 ","color":"gold"},{"text":"Your companion nudges a coin toward you.","color":"yellow"}]
