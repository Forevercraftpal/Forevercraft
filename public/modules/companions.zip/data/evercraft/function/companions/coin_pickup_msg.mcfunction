# Companion Coin Pickup — Random flavor messages
execute store result score #msg ec.temp run random value 1..5

scoreboard players set #ndur ec.temp 45
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"Your companion found something shiny on the ground!",color:"yellow"},{text:" \u2726",color:"gold"}]
execute if score #msg ec.temp matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"Your companion dug up a coin!",color:"yellow"},{text:" \u2726",color:"gold"}]
execute if score #msg ec.temp matches 2 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"Your companion brought you a gift!",color:"yellow"},{text:" \u2726",color:"gold"}]
execute if score #msg ec.temp matches 3 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"Something glinted in the grass \u2014 your companion spotted it!",color:"yellow"},{text:" \u2726",color:"gold"}]
execute if score #msg ec.temp matches 4 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"Your companion nudges a coin toward you.",color:"yellow"},{text:" \u2726",color:"gold"}]
execute if score #msg ec.temp matches 5 run function evercraft:util/notify/emit
