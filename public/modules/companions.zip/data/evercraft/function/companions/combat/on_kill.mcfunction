# Companion Combat — Mob Killed by Player After Pet Hit
# Advancement reward — revoke and award combat XP

advancement revoke @s only evercraft:companions/combat/mob_kill

# Must have an active pet
execute unless entity @s[tag=companion.activepet] run return 0

# Set search ID
scoreboard players operation #Search companion.id = @s companion.id

# Increment kill counter
scoreboard players add @s companion.kills 1

# Award 3 combat XP for a pet-assisted kill
scoreboard players set #pc_cxp_gain ec.var 3
function evercraft:companions/combat/add_cxp

# Notify player
tellraw @s [{text:"Combat XP ",color:"gold"},{text:"+3",color:"green"},{text:" (pet-assisted kill)",color:"gray"}]

# Evolved companion on-kill abilities
execute if entity @s[tag=ce.evolved_active] run function evercraft:companion_evolution/on_kill
