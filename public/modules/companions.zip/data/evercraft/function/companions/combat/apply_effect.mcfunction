# Companion Combat — Apply Combat Effect Based on Pet Type
# Routes to specific effect function based on companion_name in storage
# 102 pets total (herobrine + unicorn removed)

# === IGNITE (fire damage) — 6 pets ===
execute if data storage evercraft:companion_combat {companion_name:"ashborn"} run function evercraft:companions/combat/effects/ignite
execute if data storage evercraft:companion_combat {companion_name:"blaze"} run function evercraft:companions/combat/effects/ignite
execute if data storage evercraft:companion_combat {companion_name:"emberheart"} run function evercraft:companions/combat/effects/ignite
execute if data storage evercraft:companion_combat {companion_name:"golden_dragon"} run function evercraft:companions/combat/effects/ignite
execute if data storage evercraft:companion_combat {companion_name:"infernus"} run function evercraft:companions/combat/effects/ignite
execute if data storage evercraft:companion_combat {companion_name:"strider"} run function evercraft:companions/combat/effects/ignite

# === FROST (slowness) — 9 pets ===
execute if data storage evercraft:companion_combat {companion_name:"abyssal"} run function evercraft:companions/combat/effects/frost
execute if data storage evercraft:companion_combat {companion_name:"arctic_fox"} run function evercraft:companions/combat/effects/frost
execute if data storage evercraft:companion_combat {companion_name:"frostweaver"} run function evercraft:companions/combat/effects/frost
execute if data storage evercraft:companion_combat {companion_name:"frozen_zombie"} run function evercraft:companions/combat/effects/frost
execute if data storage evercraft:companion_combat {companion_name:"polar_bear"} run function evercraft:companions/combat/effects/frost
execute if data storage evercraft:companion_combat {companion_name:"snow_fox_spirit"} run function evercraft:companions/combat/effects/frost
execute if data storage evercraft:companion_combat {companion_name:"snowman"} run function evercraft:companions/combat/effects/frost
execute if data storage evercraft:companion_combat {companion_name:"wooly_cow"} run function evercraft:companions/combat/effects/frost
execute if data storage evercraft:companion_combat {companion_name:"starweaver"} run function evercraft:companions/combat/effects/frost

# === POISON — 8 pets ===
execute if data storage evercraft:companion_combat {companion_name:"bee"} run function evercraft:companions/combat/effects/poison
execute if data storage evercraft:companion_combat {companion_name:"bramble"} run function evercraft:companions/combat/effects/poison
execute if data storage evercraft:companion_combat {companion_name:"frog"} run function evercraft:companions/combat/effects/poison
execute if data storage evercraft:companion_combat {companion_name:"mossy_skeleton"} run function evercraft:companions/combat/effects/poison
execute if data storage evercraft:companion_combat {companion_name:"mossy_zombie"} run function evercraft:companions/combat/effects/poison
execute if data storage evercraft:companion_combat {companion_name:"mushroom_pet"} run function evercraft:companions/combat/effects/poison
execute if data storage evercraft:companion_combat {companion_name:"shade"} run function evercraft:companions/combat/effects/poison
execute if data storage evercraft:companion_combat {companion_name:"sporeblossom"} run function evercraft:companions/combat/effects/poison

# === WITHER — 3 pets ===
execute if data storage evercraft:companion_combat {companion_name:"skeleton_horse"} run function evercraft:companions/combat/effects/wither_effect
execute if data storage evercraft:companion_combat {companion_name:"wither"} run function evercraft:companions/combat/effects/wither_effect
execute if data storage evercraft:companion_combat {companion_name:"wraith"} run function evercraft:companions/combat/effects/wither_effect

# === VOID (levitation) — 6 pets ===
execute if data storage evercraft:companion_combat {companion_name:"creaking"} run function evercraft:companions/combat/effects/void_pull
execute if data storage evercraft:companion_combat {companion_name:"ender_dragon"} run function evercraft:companions/combat/effects/void_pull
execute if data storage evercraft:companion_combat {companion_name:"enderman"} run function evercraft:companions/combat/effects/void_pull
execute if data storage evercraft:companion_combat {companion_name:"endwalker"} run function evercraft:companions/combat/effects/void_pull
execute if data storage evercraft:companion_combat {companion_name:"void_walker"} run function evercraft:companions/combat/effects/void_pull
execute if data storage evercraft:companion_combat {companion_name:"voidshade"} run function evercraft:companions/combat/effects/void_pull

# === LIGHTNING (bonus damage + flash) — 9 pets ===
execute if data storage evercraft:companion_combat {companion_name:"alien"} run function evercraft:companions/combat/effects/lightning
execute if data storage evercraft:companion_combat {companion_name:"breeze"} run function evercraft:companions/combat/effects/lightning
execute if data storage evercraft:companion_combat {companion_name:"cindershell"} run function evercraft:companions/combat/effects/lightning
execute if data storage evercraft:companion_combat {companion_name:"copper_golem"} run function evercraft:companions/combat/effects/lightning
execute if data storage evercraft:companion_combat {companion_name:"creeper"} run function evercraft:companions/combat/effects/lightning
execute if data storage evercraft:companion_combat {companion_name:"evoker"} run function evercraft:companions/combat/effects/lightning
execute if data storage evercraft:companion_combat {companion_name:"stormcaller"} run function evercraft:companions/combat/effects/lightning
execute if data storage evercraft:companion_combat {companion_name:"time_weaver"} run function evercraft:companions/combat/effects/lightning
execute if data storage evercraft:companion_combat {companion_name:"nebula_kit"} run function evercraft:companions/combat/effects/lightning

# === STUN (slowness III + weakness) — 17 pets ===
execute if data storage evercraft:companion_combat {companion_name:"armadillo"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"bulwark"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"crystalheart"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"deloris"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"giraffe"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"goat"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"hoglin"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"iron_golem"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"juggernaut"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"knight"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"leviathan"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"llama"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"monolith"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"mule"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"ravager"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"titan"} run function evercraft:companions/combat/effects/stun
execute if data storage evercraft:companion_combat {companion_name:"somnia"} run function evercraft:companions/combat/effects/stun

# === BLEED (instant damage tick) — 8 pets ===
execute if data storage evercraft:companion_combat {companion_name:"camel"} run function evercraft:companions/combat/effects/bleed
execute if data storage evercraft:companion_combat {companion_name:"panther"} run function evercraft:companions/combat/effects/bleed
execute if data storage evercraft:companion_combat {companion_name:"piglin"} run function evercraft:companions/combat/effects/bleed
execute if data storage evercraft:companion_combat {companion_name:"prowler"} run function evercraft:companions/combat/effects/bleed
execute if data storage evercraft:companion_combat {companion_name:"regal_tiger"} run function evercraft:companions/combat/effects/bleed
execute if data storage evercraft:companion_combat {companion_name:"sabertooth"} run function evercraft:companions/combat/effects/bleed
execute if data storage evercraft:companion_combat {companion_name:"wolf_pet"} run function evercraft:companions/combat/effects/bleed
execute if data storage evercraft:companion_combat {companion_name:"zoglin"} run function evercraft:companions/combat/effects/bleed

# === CHARM (heal player) — 20 pets ===
execute if data storage evercraft:companion_combat {companion_name:"allay"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"baby_potato"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"butterfly"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"claude"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"cow"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"cow_of_eden"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"grovekeeper"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"koala"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"moobloom"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"mooshroom"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"naiad"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"oracle"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"pig"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"red_panda"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"sentinel"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"sniffer"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"squid"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"tidecaller"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"dreamstag"} run function evercraft:companions/combat/effects/charm
execute if data storage evercraft:companion_combat {companion_name:"lunar_moth"} run function evercraft:companions/combat/effects/charm

# === RUSH (double hit) — 16 pets ===
execute if data storage evercraft:companion_combat {companion_name:"chick"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"cragmite"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"duck"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"fox"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"glider"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"grasshopper"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"moldwarp"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"monkey"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"ocelot"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"pixie"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"rascal_pet"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"silverfish"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"spirit_wolf"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"vex"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"zephyr"} run function evercraft:companions/combat/effects/rush
execute if data storage evercraft:companion_combat {companion_name:"twilight_hare"} run function evercraft:companions/combat/effects/rush
