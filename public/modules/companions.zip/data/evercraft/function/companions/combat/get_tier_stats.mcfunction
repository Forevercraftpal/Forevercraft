# Companion Combat — Get Tier Stats from Pet Name
# Reads companion_name from storage, sets tier base damage and scaling
# Output: #pc_base, #pc_scaling (x100), #pc_cooldown (ticks)
# Also sets #pc_tier ec.var (1-6) for effect scaling

# Default: Common (tier 1) — base 2.0 dmg, +0.04/level, 6s cooldown
scoreboard players set #pc_base ec.var 200
scoreboard players set #pc_scaling ec.var 4
scoreboard players set #pc_cooldown ec.var 120
scoreboard players set #pc_tier ec.var 1

# Uncommon (tier 2) — base 3.0, +0.06/level, 5.5s (10 pets)
execute if data storage evercraft:companion_combat {companion_name:"bulwark"} run function evercraft:companions/combat/tier_uncommon
execute if data storage evercraft:companion_combat {companion_name:"cow"} run function evercraft:companions/combat/tier_uncommon
execute if data storage evercraft:companion_combat {companion_name:"moldwarp"} run function evercraft:companions/combat/tier_uncommon
execute if data storage evercraft:companion_combat {companion_name:"mooshroom"} run function evercraft:companions/combat/tier_uncommon
execute if data storage evercraft:companion_combat {companion_name:"pig"} run function evercraft:companions/combat/tier_uncommon
execute if data storage evercraft:companion_combat {companion_name:"prowler"} run function evercraft:companions/combat/tier_uncommon
execute if data storage evercraft:companion_combat {companion_name:"shade"} run function evercraft:companions/combat/tier_uncommon
execute if data storage evercraft:companion_combat {companion_name:"silverfish"} run function evercraft:companions/combat/tier_uncommon
execute if data storage evercraft:companion_combat {companion_name:"squid"} run function evercraft:companions/combat/tier_uncommon
execute if data storage evercraft:companion_combat {companion_name:"zephyr"} run function evercraft:companions/combat/tier_uncommon

# Rare (tier 3) — base 4.0, +0.08/level, 5s (14 pets)
execute if data storage evercraft:companion_combat {companion_name:"abyssal"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"blaze"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"bramble"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"camel"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"giraffe"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"goat"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"llama"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"mossy_skeleton"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"ocelot"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"piglin"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"tidecaller"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"wolf_pet"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"wooly_cow"} run function evercraft:companions/combat/tier_rare
execute if data storage evercraft:companion_combat {companion_name:"zoglin"} run function evercraft:companions/combat/tier_rare

# Ornate (tier 4) — base 5.0, +0.10/level, 4.5s (23 pets)
execute if data storage evercraft:companion_combat {companion_name:"alien"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"allay"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"armadillo"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"cindershell"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"creeper"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"enderman"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"fox"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"frog"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"frostweaver"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"frozen_zombie"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"grasshopper"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"hoglin"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"juggernaut"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"knight"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"koala"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"monkey"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"mossy_zombie"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"mule"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"naiad"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"oracle"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"polar_bear"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"sniffer"} run function evercraft:companions/combat/tier_ornate
execute if data storage evercraft:companion_combat {companion_name:"strider"} run function evercraft:companions/combat/tier_ornate

# Exquisite (tier 5) — base 7.0, +0.12/level, 4s (18 pets)
execute if data storage evercraft:companion_combat {companion_name:"ashborn"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"bee"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"breeze"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"creaking"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"crystalheart"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"ender_dragon"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"endwalker"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"evoker"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"grovekeeper"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"infernus"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"ravager"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"sabertooth"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"snowman"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"stormcaller"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"voidshade"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"lunar_moth"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"nebula_kit"} run function evercraft:companions/combat/tier_exquisite
execute if data storage evercraft:companion_combat {companion_name:"twilight_hare"} run function evercraft:companions/combat/tier_exquisite

# Mythical (tier 6) — base 10.0, +0.15/level, 3s (26 pets)
execute if data storage evercraft:companion_combat {companion_name:"arctic_fox"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"butterfly"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"claude"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"copper_golem"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"cow_of_eden"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"deloris"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"emberheart"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"golden_dragon"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"iron_golem"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"leviathan"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"moobloom"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"monolith"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"panther"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"red_panda"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"regal_tiger"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"skeleton_horse"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"snow_fox_spirit"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"spirit_wolf"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"time_weaver"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"vex"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"void_walker"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"wither"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"wraith"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"dreamstag"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"somnia"} run function evercraft:companions/combat/tier_mythical
execute if data storage evercraft:companion_combat {companion_name:"starweaver"} run function evercraft:companions/combat/tier_mythical
