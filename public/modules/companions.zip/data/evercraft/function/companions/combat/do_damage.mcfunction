# Companion Combat — Apply Damage (Macro Function)
# Called with storage evercraft:companion_combat {damage: <float>}
$damage @e[tag=pc.target,limit=1] $(damage) minecraft:mob_attack by @s
