# Potion stack sweep (run as @s = the player; reward of advancement evercraft:potions/stack_on_pickup,
# which fires on inventory_changed with any potion / splash / lingering potion).
# Joseph 2026-06-10: ALL potions stack to 16, like the original custom potion lines
# (loot_table/potions/* shipped with minecraft:max_stack_size 16; the Chemistry/treasure/chest
# tables now carry it at source too). This sweep catches the rest — vanilla-BREWED, traded, and
# legacy pre-component potions — the moment they enter an inventory.
# The modifier (item_modifier/potions/stackify) only touches potion-family items WITHOUT
# custom_data: pack potions are componented at source, and any potion-BASE special item is
# protected by its custom_data. Idempotent: the modify re-triggers inventory_changed once, the
# second pass changes nothing, and the chain settles.
advancement revoke @s only evercraft:potions/stack_on_pickup
item modify entity @s hotbar.0 evercraft:potions/stackify
item modify entity @s hotbar.1 evercraft:potions/stackify
item modify entity @s hotbar.2 evercraft:potions/stackify
item modify entity @s hotbar.3 evercraft:potions/stackify
item modify entity @s hotbar.4 evercraft:potions/stackify
item modify entity @s hotbar.5 evercraft:potions/stackify
item modify entity @s hotbar.6 evercraft:potions/stackify
item modify entity @s hotbar.7 evercraft:potions/stackify
item modify entity @s hotbar.8 evercraft:potions/stackify
item modify entity @s inventory.0 evercraft:potions/stackify
item modify entity @s inventory.1 evercraft:potions/stackify
item modify entity @s inventory.2 evercraft:potions/stackify
item modify entity @s inventory.3 evercraft:potions/stackify
item modify entity @s inventory.4 evercraft:potions/stackify
item modify entity @s inventory.5 evercraft:potions/stackify
item modify entity @s inventory.6 evercraft:potions/stackify
item modify entity @s inventory.7 evercraft:potions/stackify
item modify entity @s inventory.8 evercraft:potions/stackify
item modify entity @s inventory.9 evercraft:potions/stackify
item modify entity @s inventory.10 evercraft:potions/stackify
item modify entity @s inventory.11 evercraft:potions/stackify
item modify entity @s inventory.12 evercraft:potions/stackify
item modify entity @s inventory.13 evercraft:potions/stackify
item modify entity @s inventory.14 evercraft:potions/stackify
item modify entity @s inventory.15 evercraft:potions/stackify
item modify entity @s inventory.16 evercraft:potions/stackify
item modify entity @s inventory.17 evercraft:potions/stackify
item modify entity @s inventory.18 evercraft:potions/stackify
item modify entity @s inventory.19 evercraft:potions/stackify
item modify entity @s inventory.20 evercraft:potions/stackify
item modify entity @s inventory.21 evercraft:potions/stackify
item modify entity @s inventory.22 evercraft:potions/stackify
item modify entity @s inventory.23 evercraft:potions/stackify
item modify entity @s inventory.24 evercraft:potions/stackify
item modify entity @s inventory.25 evercraft:potions/stackify
item modify entity @s inventory.26 evercraft:potions/stackify
item modify entity @s weapon.offhand evercraft:potions/stackify
