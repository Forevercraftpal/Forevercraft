# ============================================================
# The Chemist's Questline — Reward (pay out the completed quest)
# ============================================================
# Run as @s = the player. Reads the just-completed quest's reward fields from
# chq_cur.quest and dispatches on reward type. chq_cur still holds the OLD (just-
# completed) quest at this point (reward runs BEFORE advance bumps the pointer).
#
# Reward fields: reward (xp|coins|crate), reward_amt (int), target (crate tier).
# NO `title` reward type exists in this engine (per the wave spec — Chemistry pays
# only xp/coins/crate). xp pays category-6 Alchemy XP via the FROZEN add_xp
# contract; `internal_grant` is NEVER used. Dispatch -> reward_type/<reward>.

# Flatten the quest fields for the reward macro.
data modify storage evercraft:chq_cur o set from storage evercraft:chq_cur quest
function evercraft:alchemy/questline/reward_macro with storage evercraft:chq_cur o

# === ADDITIVE: D-Q10-REWARD artifact (Artifact-Fusion w1) ===
# On TOP of the q10 xp reward above. Fires only when the just-completed quest is
# #10 (ec.chq_quest still holds 10 here — advance bumps the pointer AFTER reward).
# Chemistry q10 -> Steeping Vial Pendant (C18, Family H Alchemist leaf). One-shot
# per the pointer-equals-10 gate. Inv-full aware via the shared helper.
execute if score @s ec.chq_quest matches 10 run data modify storage evercraft:q10r args set value {lt:"artifacts/common/steeping_vial_pendant",name:"Steeping Vial Pendant",color:"white"}
execute if score @s ec.chq_quest matches 10 run function evercraft:artifacts/give/q10_reward with storage evercraft:q10r args
