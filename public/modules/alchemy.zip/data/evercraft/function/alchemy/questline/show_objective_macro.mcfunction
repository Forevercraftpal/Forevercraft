# ============================================================
# The Chemist's Questline — Show objective (macro body)
# ============================================================
# Called `with storage evercraft:chq_cur o`, where o = the current quest object
# {id,title,desc,type,target,count,reward,reward_amt,chapter,...}.
# Mirrors the Cooking/Fisher show_objective tone (white-not-gray active line).
$tellraw @s [{text:"➤ ",color:"#C9A0DC"},{text:"$(title)",color:"white",bold:true}]
$tellraw @s [{text:"  $(desc)",color:"gray"}]
$tellraw @s [{text:"  Quest $(id)",color:"dark_gray"},{text:"  ·  Chapter $(chapter)",color:"dark_gray"}]
