# ============================================================
# The Chemist's Questline — Load (objective declarations + registry + schedule)
# ============================================================
# A strictly-linear, data-driven quest line (q1..N in order, one active quest at
# a time), structural clone of cooking/questline/load. Called from init (the pack
# load host) on /reload — see init.mcfunction "CHEMIST'S QUESTLINE" block.
#
# NAMING LOCK (Council #2 §0b / SYNTHESIS §7b): all player-facing text reads
# "Chemistry"; the CODE path stays `alchemy/` (the live system) and the objective
# family is the council-locked ec.chq_* (Chemistry Questline). NEVER use ec.alch_*
# or surface "Alchemy"/"magic" in player text.
#
# Declarations are guarded by #chq_loaded ec.var so subsequent /reloads skip the
# re-declaration spam, matching questline/load's P6 polish.
#
# After declaring objectives, this fn ALWAYS (re)loads the registry (the quest
# data storage is NOT persisted across /reload) and (re)kicks the 20t catch-up
# scheduler with `replace` (so /reload never stacks duplicate schedules).

# === ONE-TIME OBJECTIVE DECLARATIONS (skipped on subsequent /reloads) ===
execute unless score #chq_loaded ec.var matches 1 run function evercraft:alchemy/questline/declare_objectives

# === UNGUARDED: ec.chq_brewed (Finding #1 fix) — declared EVERY /reload, not under the
# #chq_loaded guard, so the new real-brew counter is created on ALREADY-RUNNING worlds
# (where declare_objectives no longer re-runs). One cosmetic "Objective already exists"
# warning after the first /reload is expected and is the correct way to introduce a new
# objective to a live world. Counts completed Fusion Funnel brews (written by
# craftforever/alchemy/minigame/resolve); read by check_type/brew_count_at.
scoreboard objectives add ec.chq_brewed dummy "Chem Brews Done"

# === REGISTRY (re)load — storage is volatile across /reload, must re-run ===
function evercraft:alchemy/questline/registry/load

# === 20t CATCH-UP / INTERLUDE SCHEDULER (self-rescheduling, existence-gated) ===
# check_progress only does work for @a[scores={ec.chq_active=1}] — no per-tick @a
# scan when nobody is on the line. It re-schedules itself; kick once here.
schedule function evercraft:alchemy/questline/check_progress 20t replace
