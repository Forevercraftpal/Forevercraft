# CHQ check helper — brew_count_at (real completed Fusion Funnel brews). Catch-up beat.
# @s = player. Reads ec.chq_brewed DIRECTLY — the honest count of completed Fusion
# Funnel brews, written by craftforever/alchemy/minigame/resolve (+1 per brew). This
# REPLACES the old read of the vanilla custom:interact_with_brewingstand stat
# (ach.brew_count), which only counted opening a vanilla brewing-stand GUI — an action
# Forevercraft brewing never performs, so the beats measured an unreachable signal.
# The reward is a constant per quest, so this can't be farmed; the forward-only
# ec.chq_quest cursor (one advance per satisfied beat) blocks retro double-credit.
#
# NOTE: ec.chq_brewed starts at 0 (it counts brews going FORWARD from this fix — a
# veteran's pre-fix brews are not retro-credited here). The alch_xp_at beats remain the
# veteran catch-up path (they read the lifetime ec.cf_axp_alch mirror), and every
# brew_count_at beat is skippable, so this is no wall for an existing player.
#
# READ-ONLY: reads ec.chq_brewed (written by the alchemy minigame resolve). Writes NO
# craftforever/alchemy/ engine objective and NO Healer objective.
scoreboard players set #chq_satisfied ec.temp 0
execute if score @s ec.chq_brewed >= #chq_count ec.temp run scoreboard players set #chq_satisfied ec.temp 1
