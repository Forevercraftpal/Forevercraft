# ============================================================
# The Chemist's Questline — Check (is the current quest satisfied?)
# ============================================================
# Reads the current quest's type/target/count/beat and decides whether the active
# quest is complete; if so, calls alchemy/questline/advance. Idempotency-guarded
# like the Cooking/Build/Fisher checks (refuses to act when the line is already
# complete). Run as @s = the player. Cheap; called from the alchemy resolve funnel
# (gate-first) + the 20t check_progress loop.
#
# C0 PACING (SCHEMA_DELTA §3): an `interlude` beat (beat:"interlude", count:0) is
# a pure-lore breather that auto-passes. We satisfy it BEFORE the per-type dispatch
# so the macro never has to route a "$(type)" of interlude (no check_type/interlude
# file needed). A defensive count:0 path also covers a mis-authored interlude.

# --- Existence gate: do nothing unless this player is on the Chemist's line. ---
execute unless score @s ec.chq_active matches 1 run return 0
# --- Already finished the whole line? Nothing left to check. ---
execute if score @s ec.chq_complete matches 1 run return 0

# Make sure chq_cur holds THIS quest (callers may have run get_quest already, but
# re-loading is cheap and keeps check self-contained / caller-order-proof).
function evercraft:alchemy/questline/get_quest

# Flatten the quest fields the macro compares against.
data modify storage evercraft:chq_cur o set from storage evercraft:chq_cur quest

# Snapshot the linear pointer BEFORE dispatch, so advance can detect a re-entrant
# same-tick double-call (idempotency guard, mirrors the Cooking/Fisher upper-bound guard).
execute store result score #chq_q_before ec.temp run scoreboard players get @s ec.chq_quest

# Default unsatisfied.
scoreboard players set #chq_satisfied ec.temp 0

# === C0 INTERLUDE GUARD (BEFORE the per-type dispatch) ===
# A pure-lore beat is instantly satisfied: deliver its lore on advance, pay its
# tiny reward once, step the cursor forward. SCHEMA_DELTA §3.
execute if data storage evercraft:chq_cur o{beat:"interlude"} run scoreboard players set #chq_satisfied ec.temp 1
# Defensive: any beat with count:0 is also satisfied (0 >= 0) — covers a non-zero
# author slip where beat was mislabeled but count is 0.
execute if data storage evercraft:chq_cur o{count:0} run scoreboard players set #chq_satisfied ec.temp 1

# === PER-TYPE DISPATCH (skipped if the interlude/count:0 guard already fired) ===
execute if score #chq_satisfied ec.temp matches 0 run function evercraft:alchemy/questline/check_macro with storage evercraft:chq_cur o

# If satisfied, advance — but only if the pointer hasn't already moved this tick.
execute if score #chq_satisfied ec.temp matches 1 if score @s ec.chq_quest = #chq_q_before ec.temp run function evercraft:alchemy/questline/advance
