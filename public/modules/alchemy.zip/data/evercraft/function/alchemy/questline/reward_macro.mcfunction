# ============================================================
# The Chemist's Questline — Reward dispatch (macro body)
# ============================================================
# Called `with storage evercraft:chq_cur o`, o = the completed quest
#   {...,reward,reward_amt,target,...}. Exposes the reward args to ec.temp /
# storage and routes to reward_type/$(reward). Run as @s = the player.
#
# Shared args the helpers consume:
#   #chq_reward_amt ec.temp = quest.reward_amt (coins amount / xp amount)
#   storage evercraft:chq_cur o.target = crate tier name (crate reward only)
$scoreboard players set #chq_reward_amt ec.temp $(reward_amt)

# Dispatch on reward type: xp | coins | crate  (NO title — wave spec).
$function evercraft:alchemy/questline/reward_type/$(reward) with storage evercraft:chq_cur o
