# CHQ check helper — healer_kit (the HEALER TIE, read-only). @s = player.
# The Chemistry capstone chapter teaches how a chemist's craft feeds the Healer kit.
# This beat is satisfied when the player owns ANY Healer-class artifact (i.e. has
# ever stepped onto the Healer path) — proving the chemist→healer identity by their
# own collection. It reads the Healer artifact-collected advancements READ-ONLY and
# writes NO Healer objective and NO craftforever/alchemy/ engine objective (the
# no-write proof — SYNTHESIS §7b: "reads Healer-class state and points at the Healer
# codex page; it writes no Healer objective").
#
# Healer-class state = "has collected a Healer artifact" (the live game stores the
# class identity as artifact collection, not a single class score — verified against
# codex/hub/classes/detail/healer + artifacts/healer/). We check the two T1 starter
# Healer artifacts (bandages/poultice) AND a couple higher tiers, so any healer at
# any depth passes; a chemist who hasn't touched the Healer path yet sees the
# `[Skip ▸]` button (the beat is skippable by default in the registry) and is never
# walled. #chq_count is exposed by check_macro but intentionally IGNORED here (this
# is a presence gate, not a threshold).
scoreboard players set #chq_satisfied ec.temp 0
execute if entity @s[advancements={evercraft:artifacts/collected/healer_bandages=true}] run scoreboard players set #chq_satisfied ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/healer_poultice=true}] run scoreboard players set #chq_satisfied ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/healer_salts=true}] run scoreboard players set #chq_satisfied ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/healer_chalice=true}] run scoreboard players set #chq_satisfied ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/healer_ambrosia=true}] run scoreboard players set #chq_satisfied ec.temp 1
execute if entity @s[advancements={evercraft:artifacts/collected/healer_tome=true}] run scoreboard players set #chq_satisfied ec.temp 1
