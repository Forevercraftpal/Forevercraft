# ============================================================
# The Chemist's Questline — 20t catch-up / interlude scheduler
# ============================================================
# Self-rescheduling, EXISTENCE-GATED 20t loop (kicked from alchemy/questline/load
# with `replace`). It does work ONLY for players on the line
# (@a[scores={ec.chq_active=1,ec.chq_complete=0}]), so with no Chemistry players it
# iterates over NOTHING — no per-tick @a scan (the datapack's perf law).
#
# Two jobs per active player (both via the existing, idempotent check chain):
#   1. CATCH-UP (R1): a `brew_count_at`/`alch_xp_at`/`healer_kit` beat whose lifetime
#      threshold the player's mirror already clears auto-satisfies on this tick and
#      pays full reward — a veteran is never walled. Those helpers read the lifetime
#      mirror directly (no per-brew hook needed for catch-up).
#   2. INTERLUDE auto-pass (C0, SCHEMA_DELTA §3): a beat:"interlude"/count:0 beat is
#      instantly satisfied by check()'s interlude guard, so it advances here on the
#      next tick — delivering its lore once, paying its tiny reward once.
#
# The forward-only ec.chq_quest cursor (one advance per satisfied beat, inside
# advance) makes this no-double-credit and no-penalty.

# === RUN THE CHECK FOR EVERY ACTIVE, NON-COMPLETE PLAYER ===
# (check() is itself existence-gated + idempotent; the outer selector keeps the
#  per-tick cost zero when nobody is on the line.)
execute as @a[scores={ec.chq_active=1,ec.chq_complete=0}] run function evercraft:alchemy/questline/check

# === RE-SYNC THE OVERVIEW PROGRESS BAR (chq_prog, one writer) ===
# Keep ec.chq_prog mirroring the present-beat brew-count delta for active players,
# so the overview's live progress bar reads true for `brewed_potion` beats. This is
# the ONLY persistent writer of chq_prog besides the reset path — strictly one-writer.
# Computed per active @s: chq_prog = ach.brew_count - ec.chq_seen (clamped at 0 via
# the seed, which is always <= ach.brew_count). Harmless for non-brewed_potion beats
# (the bar just shows the brews-since-start delta, a meaningful "you're brewing"
# indicator). No-op for non-active players via the selector.
execute as @a[scores={ec.chq_active=1,ec.chq_complete=0}] run scoreboard players operation @s ec.chq_prog = @s ach.brew_count
execute as @a[scores={ec.chq_active=1,ec.chq_complete=0}] run scoreboard players operation @s ec.chq_prog -= @s ec.chq_seen

# Re-schedule self.
schedule function evercraft:alchemy/questline/check_progress 20t replace
