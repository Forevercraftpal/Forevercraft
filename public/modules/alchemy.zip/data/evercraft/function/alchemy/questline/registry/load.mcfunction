# ============================================================
# The Chemist's Questline — Registry load (storage init + batch dispatch)
# ============================================================
# Initializes the quest registry storage to an empty list, then calls each
# load_batch_K to append its quests. The storage is volatile across /reload,
# so this MUST run every reload (called from alchemy/questline/load).
#
# Registry shape (storage evercraft:chq_registry):
#   {quests:[ {id,title,desc,type,target,count,reward,reward_amt,chapter,
#              [lore],[beat],[skippable]}, ... ]}
#
# Each load_batch_K appends via:
#   data modify storage evercraft:chq_registry quests append value {...}
# Quests are appended in id order so the 0-based list index == (ec.chq_quest - 1).

# Reset to an empty quest list.
data modify storage evercraft:chq_registry quests set value []

# Append the quest batches, in id order (id 1 first => list index 0). Batch 0 is
# the full ~14-beat starter Chemistry line: 3 chapters (alembic / reagents / healer),
# 3:1 lore:objective cadence, with the Healer-tie capstone. Later batches
# (load_batch_1+) extend the line; advance reads N (list length) dynamically, so
# appending a batch auto-extends with no engine edit.
function evercraft:alchemy/questline/registry/load_batch_0
