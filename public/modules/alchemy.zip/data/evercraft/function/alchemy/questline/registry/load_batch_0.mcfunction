# ============================================================
# The Chemist's Questline — Registry batch 0 (the starter line, q1..q14)
# ============================================================
# Appends the first 14 quests onto storage evercraft:chq_registry quests.
# Called by registry/load AFTER it sets quests=[]. MUST append in id order
# (id=1 first => list index 0), contiguous, so list-position == ec.chq_quest-1.
# (Structural clone of cooking/questline/registry/load_batch_0, paced via C0.)
#
# NAMING LOCK (Council #2 §0b): ALL player-facing strings here say "Chemistry" /
# "chemist" / "reagent" — NEVER "Alchemy" or "magic". The code path stays alch/cat-6.
#
# Quest object schema (the engine reads these exact fields):
#   {id:int, title:string, desc:string, type:string, target:string,
#    count:int, reward:string, reward_amt:int, chapter:int,
#    [lore:string], [beat:string], [skippable:int]}      <- C0 fields OPTIONAL
#
# type    -> dispatched by check_type/$(type):
#            brewed_potion | brew_count_at | alch_xp_at | healer_kit
#            (beat:"interlude"/count:0 auto-passes BEFORE dispatch — SCHEMA_DELTA §3)
# target  -> the check helpers IGNORE it (each reads a fixed public mirror), so it
#             is "" on most beats. On a `reward:"crate"` beat it names the crate
#             TIER consumed by reward_type/crate (common|uncommon|rare|ornate|
#             exquisite|mythical) — the only consumer of target in this batch.
# count   -> brewed_potion: brews-since-start threshold (delta off ec.chq_seen);
#            brew_count_at: completed-brew threshold (ec.chq_brewed — real Fusion
#              Funnel brews, counted forward from the QW-1 fix);
#            alch_xp_at: lifetime ec.cf_axp_alch threshold;
#            healer_kit: ignored (presence gate — owns a Healer artifact);
#            interlude: 0 (auto-pass).
# reward  -> xp | coins | crate   (NO title). reward_amt = amount.
#            xp pays category-6 Alchemy XP via the FROZEN add_xp contract.
# chapter -> display grouping: 1=alembic, 2=reagents, 3=healer.
#
# XP TIER TABLE (artisan-locked flat curve, mirrors the Cooking line so a Chemistry
# quest is never a fatter XP source than a brew-of-equal-tier loop):
#   40 / 90 / 180 / 320 / 480 / 700 / 950
#
# C0 CADENCE (SCHEMA_DELTA §1): every objective beat carries `lore`; interludes
# (q4 alembic-vapor breather, q9 reagents/Healer foreshadow, q13 the quiet before
# the kit) sit ~3:1 against objective beats; the headline teach beats q2 (the
# discovery of a recipe via brewing) + q11 (the Healer tie via healer_kit) are
# `skippable:0` "see-it-once" — both still auto-pass a veteran via the lifetime /
# presence read in their check helper (Decision #5).
#
# ARTIFACT INTEGRATION (SYNTHESIS §7d — Chemistry = medium→TOWARD): the capstone
# q14 leans into a healing-reagent artifact theme (the Healer kit IS an artifact
# kit), so the finale reads the chemist→healer identity, not raw potion-count.
# ------------------------------------------------------------

# --- Chapter 1: The Alembic ------------------------------------------------

# q1 — gentle intro: brew at the Fusion Funnel. Pure on-ramp. lore + default
#   [Skip ▸]. Uses alch_xp_at (a small lifetime Chemistry-XP threshold) so a Fusion
#   Funnel brew RELIABLY advances it — the Funnel resolve is the only craftforever
#   path that raises ec.cf_axp_alch. (Post-QW-1 the brew_count_at beats below also
#   count real Funnel brews — via ec.chq_brewed — not the old vanilla brewing-stand
#   `ach.brew_count` stat, which the Funnel never triggered.)
data modify storage evercraft:chq_registry quests append value {id:1,title:"The First Vapor",desc:"Brew a potion at the Fusion Funnel to earn your first Chemistry XP.",type:"alch_xp_at",target:"",count:5,reward:"xp",reward_amt:40,chapter:1,lore:"The Fusion Funnel is the Chemist's whole laboratory: drop the makings in and it brews. Your first vapor earns Chemistry XP — the Artisan ladder counts it alongside the forge and the hearth."}

# q2 — *** SEE-IT-ONCE teach beat (skippable:0) ***: brewing IS the discovery
#   mechanic. NO [Skip ▸], and (post-QW-1) no veteran auto-pass either: brew_count_at
#   now reads ec.chq_brewed, which counts forward from 0, so everyone brews 6 real
#   Funnel potions here. That is the intended "see it once" (the count is small); the
#   alch_xp_at beats (q1/q3/q5) carry the veteran Chemistry-XP catch-up instead.
data modify storage evercraft:chq_registry quests append value {id:2,title:"What the Glass Remembers",desc:"Brew 6 potions in all — let the alembic learn your hand.",type:"brew_count_at",target:"common",count:6,reward:"crate",reward_amt:1,chapter:1,lore:"The alembic learns your hand: every brew pays Chemistry XP, and discovered formulas surface in reward crates the world over. Brew wide, not just deep.",skippable:0}

# q3 — brew a few more to settle into the rhythm. lore + default [Skip ▸]. Also
#   alch_xp_at (reliably Fusion-Funnel-fed) so the on-ramp never stalls for a player
#   who brews only via the Funnel (not a vanilla brewing stand).
data modify storage evercraft:chq_registry quests append value {id:3,title:"Hands That Know the Boil",desc:"Earn 100 lifetime Chemistry XP at the Fusion Funnel.",type:"alch_xp_at",target:"",count:100,reward:"xp",reward_amt:90,chapter:1,lore:"One hundred lifetime XP is the apprentice's mark. Rank gates nothing here — it OPENS things: trials, deeper formulas, the Crafter tier-two doors."}

# q4 — *** INTERLUDE (count:0, beat:interlude) ***: a pure-lore breather that
#   auto-passes on the next 20t check, delivers its lore once, pays coins:1 once.
#   A quiet meditation on the alembic. Proves the C0 interlude path end-to-end.
data modify storage evercraft:chq_registry quests append value {id:4,title:"The Patience of Vapor",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:1,beat:"interlude",lore:"Potions are the adventurer's second heartbeat. A Chemist who walks the dungeons drinks their own work — and sells the surplus."}

# --- Chapter 2: Reagents ---------------------------------------------------

# q5 — climb the Chemistry XP. lore + default [Skip ▸]. alch_xp_at reads
#   ec.cf_axp_alch directly (lifetime catch-up — a veteran auto-passes at full XP).
data modify storage evercraft:chq_registry quests append value {id:5,title:"A Fuller Shelf",desc:"Earn 200 lifetime Chemistry XP.",type:"alch_xp_at",target:"",count:200,reward:"xp",reward_amt:180,chapter:2,lore:"A reagent shelf is a kind of memory made solid. The more you keep within reach, the longer your craft can speak without faltering."}

# q6 — brew more, deeper. lore + default [Skip ▸]. Reward Chemistry XP (tier 4).
data modify storage evercraft:chq_registry quests append value {id:6,title:"The Curious Chemist",desc:"Brew 24 potions in all.",type:"brew_count_at",target:"",count:24,reward:"xp",reward_amt:320,chapter:2,lore:"Curiosity is the chemist's finest reagent. Reach for the mixture you have never dared — that is where the true craft hides, in the elixir you cannot yet name."}

# q7 — a brew-count milestone to mark the chapter. lore + default [Skip ▸].
data modify storage evercraft:chq_registry quests append value {id:7,title:"A Shelf Well Stocked",desc:"Brew 40 potions in all.",type:"brew_count_at",target:"",count:40,reward:"xp",reward_amt:480,chapter:2,lore:"Count not the bottles but the hurts they will mend. A shelf well stocked is the quietest kind of mercy, waiting for the day a friend needs it."}

# q8 — keep brewing; reward a crate (reagent cache). lore + default [Skip ▸].
data modify storage evercraft:chq_registry quests append value {id:8,title:"The Mob's Reluctant Gift",desc:"Brew 30 potions in all — many reagents are won, not bought.",type:"brew_count_at",target:"uncommon",count:30,reward:"crate",reward_amt:1,chapter:2,lore:"Some reagents grow in a garden; others must be taken from things that did not wish to give them. Honor the cost. Waste nothing the hunt has bought you."}

# q9 — *** INTERLUDE (count:0) ***: foreshadow the Healer tie.
data modify storage evercraft:chq_registry quests append value {id:9,title:"For Whom the Elixir Is Brewed",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:2,beat:"interlude",lore:"Ask yourself, as the elixir cools: who is this for? The finest chemists were never collectors — they were Healers in waiting, brewing against a wound not yet taken. Keep that face in mind. The next chapter is theirs."}

# --- Chapter 3: The Healer -------------------------------------------------

# q10 — climb the Chemistry artisan XP higher. lore + default [Skip ▸].
data modify storage evercraft:chq_registry quests append value {id:10,title:"The Artisan's Rise",desc:"Earn 500 lifetime Chemistry XP.",type:"alch_xp_at",target:"",count:500,reward:"xp",reward_amt:480,chapter:3,lore:"Skill is the slow gift the craft gives back. You have fed it your hours; now it steadies your hand for the work that matters most — the mending of others."}

# q11 — *** SEE-IT-ONCE teach beat (skippable:0) — THE HEALER TIE ***: satisfied
#   when the player owns ANY Healer-class artifact (healer_kit reads the Healer
#   artifact-collected advancements READ-ONLY — writes no Healer objective). NO
#   [Skip ▸] for a newcomer; a player already on the Healer path auto-passes. The
#   lore POINTS AT the Healer codex page (Classes -> Healer) without forcing a class.
data modify storage evercraft:chq_registry quests append value {id:11,title:"The Chemist Who Mends",desc:"Hold a Healer artifact — let your reagents become a remedy. (Open the Codex: Classes -> Healer to see the kit.)",type:"healer_kit",target:"",count:1,reward:"xp",reward_amt:700,chapter:3,lore:"A potion is potential; a Healer is the hand that spends it. Take up even one piece of the Healer's kit, and your craft stops being a curiosity and becomes a covenant: to stand between your friends and their wounds.",skippable:0}

# q12 — a large lifetime XP capstone-runner. lore + default [Skip ▸].
data modify storage evercraft:chq_registry quests append value {id:12,title:"Name Among Healers",desc:"Earn 1200 lifetime Chemistry XP.",type:"alch_xp_at",target:"",count:1200,reward:"xp",reward_amt:700,chapter:3,lore:"There comes a day the wounded speak your name before the bandage is even tied. You did not seek it. It found you at the brewing stand, where mercy is always being quietly prepared."}

# q13 — *** INTERLUDE (count:0) ***: a quiet breather before the finale.
data modify storage evercraft:chq_registry quests append value {id:13,title:"The Last Quiet Before the Cure",desc:"",type:"interlude",target:"",count:0,reward:"coins",reward_amt:1,chapter:3,beat:"interlude",lore:"Before the great cure there is always a still hour — the bottles labeled, the stand banked low, the chemist alone with all they have learned to mend. Sit in it a moment. The world will need you soon enough."}

# q14 — FINALE (artifact-themed, Healer-kit capstone): a wide brew milestone
#   framed as forging a healing-reagent artifact. lore + default [Skip ▸]. XP tier 7.
#   q14 is a soft finale, not a hard cap: advance reads N (list length) dynamically,
#   so appending load_batch_1 later auto-extends the line — q14's finish() only
#   fires while N == 14.
data modify storage evercraft:chq_registry quests append value {id:14,title:"The Grand Reagent",desc:"Brew 80 potions in all. Distill your craft into a healing-reagent worthy of any Healer's kit.",type:"brew_count_at",target:"",count:80,reward:"xp",reward_amt:950,chapter:3,lore:"The grand reagent is not a stronger potion — it is the whole of your craft poured into a single, steady remedy. You are a Grand Chemist now, and somewhere a Healer's kit is the surer for it. Forevercraft heals because you learned to brew."}

# ------------------------------------------------------------
# HAND-OFF TO load_batch_1 (future Chemistry chapters):
#   - This batch ends at id=14. The next batch's FIRST quest MUST be id=15 (list
#     index 14), appended immediately after q14, contiguously.
#   - registry/load calls load_batch_0; add the load_batch_1 call there when it
#     lands. Do NOT renumber this batch.
# ------------------------------------------------------------
