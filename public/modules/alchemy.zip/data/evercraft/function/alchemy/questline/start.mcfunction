# ============================================================
# The Chemist's Questline — Start (begin the line at quest 1)
# ============================================================
# Run as @s = the player who just brewed their first potion (via the first_brew
# advancement reward fn, which guards on ec.chq_active == 0) OR clicked the temp
# admin entry. Sets the linear pointer to quest 1, loads it, shows the intro +
# first objective. WRITER of the initial pointer state.

# === ACTIVATE + RESET LINEAR STATE ===
scoreboard players set @s ec.chq_active 1
# Auto-track this line for the [Skip ▸] button (Wiring #52): Chemistry = slot 6 (do_skip
# value-map). Latest-activated line wins; finish clears it if still pointed here.
scoreboard players set @s ec.gq_track 6
scoreboard players set @s ec.chq_quest 1
scoreboard players set @s ec.chq_prog 0
scoreboard players set @s ec.chq_done 0
scoreboard players set @s ec.chq_complete 0
# Seed the brew-count cursor at the player's current LIVE brew count (ec.chq_brewed,
# completed Fusion Funnel brews) so potions brewed BEFORE the line began never
# retro-credit the present `brewed_potion` beat (forward-only). check_progress mirrors
# ec.chq_prog off this cursor (ec.chq_brewed - ec.chq_seen); the
# `alch_xp_at`/`brew_count_at`/`healer_kit` catch-up TYPES read their lifetime mirror
# DIRECTLY (so a veteran still auto-passes at full reward). Repointed off the dead
# vanilla ach.brew_count stat to live ec.chq_brewed (WA64-D1, 2026-06-22).
scoreboard players operation @s ec.chq_seen = @s ec.chq_brewed

# Load quest 1 into chq_cur for the objective display.
function evercraft:alchemy/questline/get_quest

# === INTRO BANNER (mirrors the Cook's start tone, Chemistry-themed) ===
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"The Chemist's Questline",color:"#9B59B6",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The first vapor curls from your alembic. A long road of reagents and remedies lies ahead, chemist — walk it, and learn to mend all of Forevercraft.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.4 1.4
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.brewing_stand.brew master @s ~ ~ ~ 0.7 1.0

# Subtle title flash, then show the first objective.
title @s times 5 40 10
title @s subtitle {text:"Your first task awaits",color:"gray",italic:true}
function evercraft:alchemy/questline/show_objective
# Pacing (q1-lore fill 2026-06-10, mirror build_quests/start): deliver quest 1's lore line
# (muted in Quick Mode) + [Skip ▸] button — advances get this via on_advance_notify; the start
# path was the one chat-silent entry.
data modify storage evercraft:qp_cur o set from storage evercraft:chq_cur quest
function evercraft:quest_pacing/render_lore
