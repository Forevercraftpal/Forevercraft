# ============================================================
# The Chemist's Questline — Advance (complete current quest -> next)
# ============================================================
# Run as @s = the player. Called by alchemy/questline/check when the active quest
# is satisfied, OR by quest_pacing/do_skip (the [Skip ▸] button, full reward).
# WRITER of the linear pointer (ec.chq_quest), ec.chq_prog reset, ec.chq_done,
# ec.chq_complete.
#
# Order: show_completed -> reward -> bump pointer (clamped) -> reset prog ->
#        +1 done -> load next quest -> show_objective. Final quest -> a one-shot
#        "line complete!" tellraw, pointer clamped at N.

# --- Idempotency / out-of-range guards (mirror the Cooking/Fisher upper-bound guard) ---
execute unless score @s ec.chq_active matches 1 run return 0
execute if score @s ec.chq_complete matches 1 run return 0

# Registry length = N (the last valid quest index). Dynamic so the engine never
# hardcodes the quest count — it grows automatically as batches are added.
execute store result score #chq_n ec.temp run data get storage evercraft:chq_registry quests
# Defensive: if the registry failed to load (length 0), do nothing.
execute if score #chq_n ec.temp matches ..0 run return 0
# If the pointer is somehow already past N, clamp + finish (don't run past the end).
execute if score @s ec.chq_quest > #chq_n ec.temp run function evercraft:alchemy/questline/finish
execute if score @s ec.chq_quest > #chq_n ec.temp run return 0

# === 1) SHOW WHAT WAS JUST COMPLETED (chq_cur still holds the old quest) ===
function evercraft:alchemy/questline/show_completed

# === 2) PAY OUT THE REWARD for the completed quest ===
function evercraft:alchemy/questline/reward

# === 2b) ADDITIVE: grant progress toward the CHEMISTRY advantage tree (Joseph 2026-06-01) ===
# On TOP of the existing reward. Feeds the normal level-up grind gate (adv.stat_brew);
# does NOT raw-set adv.chemistry. Read while ec.chq_quest still holds the just-completed
# index (the bump below happens after). See tree_credit for sizing rationale.
function evercraft:alchemy/questline/tree_credit

# === 3) ADVANCE THE LINEAR POINTER + COUNTERS ===
scoreboard players add @s ec.chq_quest 1
scoreboard players set @s ec.chq_prog 0
scoreboard players add @s ec.chq_done 1

# === 4) FINAL-QUEST HANDLING ===
# If the new pointer exceeds N, the player just finished the LAST quest. Detect
# the overflow FIRST (into a flag), then clamp the pointer back to N (so a future
# check can't index out of range) and run the one-shot completion fanfare.
scoreboard players set #chq_overflow ec.temp 0
execute if score @s ec.chq_quest > #chq_n ec.temp run scoreboard players set #chq_overflow ec.temp 1
execute if score #chq_overflow ec.temp matches 1 run scoreboard players operation @s ec.chq_quest = #chq_n ec.temp
execute if score #chq_overflow ec.temp matches 1 run function evercraft:alchemy/questline/finish

# Not finished: load the next quest into chq_cur and show its objective (paced).
execute if score #chq_overflow ec.temp matches 0 run function evercraft:alchemy/questline/get_quest
execute if score #chq_overflow ec.temp matches 0 run function evercraft:alchemy/questline/on_advance_notify
