# ============================================================
# The Chemist's Questline — get_quest macro body
# ============================================================
# Called with storage evercraft:chq_cur containing {idx:<0-based index>}.
# Copies registry quest[idx] into evercraft:chq_cur quest.
$data modify storage evercraft:chq_cur quest set from storage evercraft:chq_registry quests[$(idx)]
