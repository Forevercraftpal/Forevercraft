# CHQ reward — coins. @s = player. Amount in #chq_reward_amt ec.temp.
# Adds Forever Coins (ec.coins) and tells the player. (No macro args needed;
# invoked `with storage ... o` but only reads the temp.)
scoreboard players operation @s ec.coins += #chq_reward_amt ec.temp
# BAKE the amount as a literal $(reward_amt) — NOT a live {score:#chq_reward_amt} ref. util/notify/emit
# QUEUES the frame and resolves any score component at DISPLAY time; in a multi-advance cascade (skip
# spam / consecutive auto-pass) #chq_reward_amt is overwritten to the LAST quest's amount before the
# queued frame renders, so every frame showed the wrong number (the build_quests/reward_type bug class).
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Reward: ",color:"yellow"},{text:"$(reward_amt)",color:"gold"},{text:" Forever Coins",color:"gold"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.0
