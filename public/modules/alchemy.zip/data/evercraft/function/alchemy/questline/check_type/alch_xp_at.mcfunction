# CHQ check helper — alch_xp_at (lifetime Alchemy artisan XP). Catch-up beat.
# @s = player. Reads ec.cf_axp_alch (the category-6 Alchemy XP total) DIRECTLY, so
# a veteran whose Alchemy XP already clears the count auto-satisfies on the next
# 20t check_progress tick at full reward (R1). Constant per-quest reward => can't
# be farmed; forward-only ec.chq_quest cursor blocks retro double-credit.
#
# READ-ONLY: reads ec.cf_axp_alch (craftforever-owned, written ONLY by the frozen
# add_xp contract). Writes NO craftforever/alchemy/ engine objective and NO Healer
# objective. NOTE: this line's OWN xp rewards (paid via add_xp cat-6) also raise
# ec.cf_axp_alch, so an alch_xp_at beat can be partly fed by the line's earlier
# rewards — intended (the line teaches by paying). Player-facing name is "Chemistry".
scoreboard players set #chq_satisfied ec.temp 0
execute if score @s ec.cf_axp_alch >= #chq_count ec.temp run scoreboard players set #chq_satisfied ec.temp 1
