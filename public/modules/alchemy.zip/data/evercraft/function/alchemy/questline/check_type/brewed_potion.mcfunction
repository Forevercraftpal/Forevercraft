# CHQ check helper — brewed_potion (potions brewed SINCE the line began). @s = player.
# Present-action beat: reads the FORWARD-only delta (ec.chq_brewed - ec.chq_seen)
# so potions brewed before this beat was active never retro-credit it. Satisfied
# when the delta reaches quest.count (#chq_count ec.temp).
#
# UNREACHABLE / PARKED scaffolding (WA64-BREWED-POTION-UNREACHABLE): no live quest in
# load_batch_0 declares type:"brewed_potion" (the live present-action beats are all
# brew_count_at), so check_macro never routes here. Kept + correctly cited so the
# dead-code audit won't re-flag it; if wired into a future load_batch_1 it is already
# repointed at the live signal.
#
# READ-ONLY: reads ec.chq_brewed (live completed Fusion Funnel brews, +1 in
# craftforever/alchemy/minigame/resolve) + ec.chq_seen (this line's OWN cursor, seeded
# at start). Repointed off the dead vanilla ach.brew_count stat to ec.chq_brewed so the
# whole Chemist line is free of the never-incremented stat (WA64-D1, 2026-06-22).
# Writes NO craftforever/alchemy/ engine objective and NO Healer objective.
#
# Note: a true veteran is NOT auto-passed by brewed_potion (the forward cursor is
# intentional for present-action beats) — but the line never WALLS on it, because
# every brewed_potion beat is `skippable` (default), so a player who would rather not
# brew fresh potions can [Skip ▸] at full reward. The catch-up TYPES (brew_count_at
# / alch_xp_at / healer_kit) are the veteran auto-pass path.
scoreboard players set #chq_satisfied ec.temp 0
scoreboard players operation #chq_delta ec.temp = @s ec.chq_brewed
scoreboard players operation #chq_delta ec.temp -= @s ec.chq_seen
execute if score #chq_delta ec.temp >= #chq_count ec.temp run scoreboard players set #chq_satisfied ec.temp 1
