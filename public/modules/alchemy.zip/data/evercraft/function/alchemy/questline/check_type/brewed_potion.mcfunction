# CHQ check helper — brewed_potion (potions brewed SINCE the line began). @s = player.
# Present-action beat: reads the FORWARD-only delta (ach.brew_count - ec.chq_seen)
# so potions brewed before this beat was active never retro-credit it. Satisfied
# when the delta reaches quest.count (#chq_count ec.temp).
#
# READ-ONLY: reads ach.brew_count (achievements-owned, custom:interact_with_brewing-
# stand) + ec.chq_seen (this line's OWN cursor, seeded at start). Writes NO
# craftforever/alchemy/ engine objective and NO Healer objective.
#
# Note: a true veteran is NOT auto-passed by brewed_potion (the forward cursor is
# intentional for present-action beats) — but the line never WALLS on it, because
# every brewed_potion beat is `skippable` (default), so a player who would rather not
# brew fresh potions can [Skip ▸] at full reward. The catch-up TYPES (brew_count_at
# / alch_xp_at / healer_kit) are the veteran auto-pass path.
scoreboard players set #chq_satisfied ec.temp 0
scoreboard players operation #chq_delta ec.temp = @s ach.brew_count
scoreboard players operation #chq_delta ec.temp -= @s ec.chq_seen
execute if score #chq_delta ec.temp >= #chq_count ec.temp run scoreboard players set #chq_satisfied ec.temp 1
