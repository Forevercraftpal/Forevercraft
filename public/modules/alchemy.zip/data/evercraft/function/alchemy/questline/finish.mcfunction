# ============================================================
# The Chemist's Questline — Finish (one-shot completion fanfare)
# ============================================================
# Run as @s = the player who just completed the final quest. Sets the
# ec.chq_complete sentinel so this fires exactly once, then prints the
# "line complete!" celebration. WRITER of ec.chq_complete (with advance).

# Guard: only ever fire once.
execute if score @s ec.chq_complete matches 1 run return 0
scoreboard players set @s ec.chq_complete 1

# Auto-track repoint (Wiring #52): clear the [Skip ▸] tracker if it was pointed at THIS
# line (Chemistry = slot 6) — a completed line must never accept a skip.
execute if score @s ec.gq_track matches 6 run scoreboard players set @s ec.gq_track 0

data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"The Chemist's Questline — Complete!",color:"#9B59B6",bold:true},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"Every reagent known, every remedy mastered. You are a Grand Chemist of Forevercraft — and a Healer's truest ally, for no kit mends without your craft.",color:"#C9A0DC",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

title @s times 10 60 20
title @s title {text:"Grand Chemist",color:"#9B59B6"}
title @s subtitle {text:"The Chemist's Questline is complete",color:"#C9A0DC"}

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.2

# === ADDITIVE: difficulty-scaled CHEMISTRY-tree prestige capstone (Joseph 2026-06-01) ===
# On TOP of the celebration above. Runs once (inside this ec.chq_complete one-shot guard).
# Drives prestige on adv.chemistry via the existing advantage/prestige/do_prestige path:
# Newcomer = 2 / Adventurer = 1 / Pioneer or unset = 1 (PHASE-3 council F4). See tree_capstone.
function evercraft:alchemy/questline/tree_capstone

# === ADDITIVE: exit handoff (Questline Restructure W4, 2026-06-10) ===
# A finished Path never goes dark: name the repeatable continuation (Trade Trials),
# bridge with 1 Trial Pass, and nudge the Grand Chronicle if both branches qualify.
# Runs inside this finish's one-shot complete-sentinel guard.
function evercraft:grand_quests/exit_handoff_craft

# Clear a stale tracked-Path pin if THIS line was pinned (QR-P5, 2026-06-10).
function evercraft:grand_quests/untrack_on_finish {slot:6}
