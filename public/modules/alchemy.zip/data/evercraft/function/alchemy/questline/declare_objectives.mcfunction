# ============================================================
# The Chemist's Questline — One-time scoreboard objective declarations.
# (Structural clone of cooking/questline/declare_objectives, Council #2 Wave C4 —
#  the Chemistry book line, player-facing name "Chemistry", tied to the Healer
#  class.) Split from alchemy/questline/load so the per-/reload "Objective already
#  exists" warnings only fire once. Gated by `#chq_loaded ec.var matches 1` — set
#  at the bottom of this file.
# ============================================================
# A paced, always-skippable Chemistry quest line: a sibling Fisher's clone that only
# READS public alchemy + Healer state (ec.chq_brewed live brew count, ec.cf_axp_alch,
# the Healer artifact-collected advancements). It WRITES none of craftforever/alchemy/'s engine
# objectives, and NO Healer objective (the no-write proof). It is pacing-aware from
# the start (lore/beat/skippable) — see check.mcfunction (interlude guard),
# on_advance_notify + overview (render_lore), and the registry rows that carry `lore`.
#
# NAMING LOCK: code stays `alch`/cat-6; all player-facing strings say "Chemistry".
# NOTE: ec.fg_* is partly OCCUPIED and ec.alch_* / ec.ck_* belong to live engines —
# this line uses the council-locked ec.chq_* family ONLY.

# === CORE LINEAR-POINTER SCOREBOARDS (mirror ec.cq_*; one writer each) ===
# ec.chq_active — 0/1, has this player started the Chemist's line?
#   WRITER: alchemy/questline/start (sets 1).
scoreboard objectives add ec.chq_active dummy "Chem Questline Active"
# ec.chq_quest — current quest index, 1..N. The ONLY linear pointer.
#   WRITER: alchemy/questline/start (sets 1) + alchemy/questline/advance (+1, clamped at N).
scoreboard objectives add ec.chq_quest dummy "Chem Quest Index"
# ec.chq_prog — progress within the current quest, surfaced ONLY in the overview
#   progress bar. The Chemistry check types are all READ-DERIVED (they compute their
#   satisfied condition from a public mirror + the ec.chq_seen cursor into ec.temp,
#   never persisting a per-brew tally), so the single persistent writer of chq_prog
#   is the reset path — keeping it strictly one-writer.
#   WRITER (reset to 0): alchemy/questline/start + alchemy/questline/advance.
#   WRITER (live mirror for the bar): alchemy/questline/check_progress re-syncs it
#     to the present-beat delta (one writer, on the 20t loop).
scoreboard objectives add ec.chq_prog dummy "Chem Quest Progress"
# ec.chq_done — lifetime completed quest count (overview + the ec.gq_track value).
#   WRITER: alchemy/questline/advance (+1) + alchemy/questline/start (sets 0 on first start).
scoreboard objectives add ec.chq_done dummy "Chem Quests Done"
# (NO ec.chq_title — per the wave spec the Chemistry line rewards only xp/coins/crate.
#  ALL chemistry-prestige identity comes from elsewhere; no reward_type/title file
#  exists in this engine.)

# === COMPLETION SENTINEL ===
# ec.chq_complete — 0/1, set once when the player finishes the final quest so the
#   "line complete!" tellraw fires exactly once. WRITER: alchemy/questline/advance
#   (via finish) + alchemy/questline/start (sets 0 on first start).
scoreboard objectives add ec.chq_complete dummy "Chem Questline Complete"

# === LIFETIME-THRESHOLD CATCH-UP CURSOR (forward-only, no-penalty) ===
# ec.chq_seen — snapshot of ec.chq_brewed (live completed Fusion Funnel brews) taken
#   at start. The present-action `brewed_potion` beat + the panel progress counter read
#   (ec.chq_brewed - this) as the count of potions brewed SINCE the line began, so
#   pre-activation brews never retro-credit the present beat (forward cursor). The
#   `alch_xp_at`/`brew_count_at`/`healer_kit` catch-up TYPES read their lifetime mirror
#   DIRECTLY, so a veteran auto-passes at full reward. Repointed off the dead vanilla
#   ach.brew_count stat to ec.chq_brewed (WA64-D1, 2026-06-22).
#   The ec.chq_seen objective writes ONLY here-via-start; check_progress READS it.
#   WRITER: alchemy/questline/start (seeds it).
scoreboard objectives add ec.chq_seen dummy "CHQ Brew-Count Cursor"

# === REAL COMPLETED-BREW COUNTER (Finding #1 fix — replaces vanilla interact stat) ===
# ec.chq_brewed — lifetime count of completed Fusion Funnel brews, the honest "potions
#   brewed" signal read by check_type/brew_count_at (replacing the vanilla
#   custom:interact_with_brewingstand stat ach.brew_count, which only counted opening a
#   vanilla brewing-stand GUI — an action Forevercraft brewing never performs).
#   WRITER: craftforever/alchemy/minigame/resolve (+1 per completed brew, unconditionally).
#   ALSO declared UNGUARDED in alchemy/questline/load so it exists on already-running worlds.
scoreboard objectives add ec.chq_brewed dummy "Chem Brews Done"

# Mark declarations done so re-/reload skips this file.
scoreboard players set #chq_loaded ec.var 1
