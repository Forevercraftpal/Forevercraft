# Run as operator (testing). Temp entry to hand yourself the Chemist's Codex + start
# the Chemist's Questline before C1's Crafter Tier-2 menu row is the canonical entry.
# Usage: /execute as <player> run function evercraft:alchemy/questline/admin/give_book_temp
# (debug) — gives the book (dup-guarded) and starts the line if not already active.
function evercraft:alchemy/questline/book/give
execute unless score @s ec.chq_active matches 1 run function evercraft:alchemy/questline/start
