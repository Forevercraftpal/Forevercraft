# ============================================================
# The Chemist's Questline — Show current objective
# ============================================================
# Reads the current quest from chq_cur.quest (already loaded by get_quest) and
# prints its title + description as the active objective. Data-driven via macro
# (the quest text lives in the registry, not in per-quest files).
# Run as @s = the player.

# Surface the quest fields the macro needs at the top level of chq_cur.
data modify storage evercraft:chq_cur o set from storage evercraft:chq_cur quest
function evercraft:alchemy/questline/show_objective_macro with storage evercraft:chq_cur o
