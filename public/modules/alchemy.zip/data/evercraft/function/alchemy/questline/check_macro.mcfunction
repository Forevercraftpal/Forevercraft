# ============================================================
# The Chemist's Questline — Check (macro body, dispatch on quest.type)
# ============================================================
# Called `with storage evercraft:chq_cur o`, o = current quest
#   {id,title,desc,type,target,count,reward,reward_amt,chapter,...}.
# Sets #chq_satisfied ec.temp to 1 iff the active quest's completion condition is
# met. Run as @s = the player.
#
# A macro can't branch on an int comparison inline, so we expose the threshold to
# ec.temp and route the per-TYPE decision to a tiny helper file:
#   - #chq_count ec.temp     = quest.count
# The helper at check_type/$(type) reads its OWN public mirror (ec.chq_brewed live
# brew count, minus the ec.chq_seen cursor / ec.cf_axp_alch / the Healer artifact-
# collected advancement) and sets #chq_satisfied ec.temp. All helpers are READ-ONLY: they
# never write a craftforever/alchemy/ engine objective NOR any Healer objective
# (the no-write proof).

# Expose the threshold for the helpers to compare against.
$scoreboard players set #chq_count ec.temp $(count)

# Per-type decision (sets #chq_satisfied ec.temp). $(type) is one of:
#   brewed_potion | brew_count_at | alch_xp_at | healer_kit
$function evercraft:alchemy/questline/check_type/$(type)
