# The Chemist's Codex — Reset cooldown (runs ~1s after a right-click use).
# Revokes the using_item advancement so the book can be used again. Clone of
# cooking/questline/book/reset_cooldown.
execute as @a[tag=ec.chembook_cd] run advancement revoke @s only evercraft:chemistry_book/on_use
tag @a[tag=ec.chembook_cd] remove ec.chembook_cd
