# ============================================================
# The Chemist's Questline — first_brew advancement reward (self-arming safety net)
# ============================================================
# Fired when a player has a legacy Chemist's Tome book in inventory (advancement
# evercraft:chemistry_book/first_brew). @s = that player. Mirrors
# cooking/questline/on_first_meal_adv: a self-arming, dup-guarded START net.
#
# In the normal flow the line is ALREADY active by the time this fires (the
# alchemy resolve gate-first line ran on_first_brew -> book/give (codex unlock,
# book retired 2026-06-11) -> start BEFORE the inventory_changed advancement
# evaluates). So this is almost always a no-op past activation — it exists as the
# resilience net for the edge case where a legacy book exists but the line never
# started (e.g. the book was admin-given, or pre-existed this engine). Hands NO item
# (book/give catalyzes into the Codex; this path only starts the line).

# Revoke so the criterion re-arms (cheap; mirrors on_first_meal_adv).
advancement revoke @s only evercraft:chemistry_book/first_brew

# Start the line only if it isn't already active (ec.chq_active still 0).
execute unless score @s ec.chq_active matches 1 run function evercraft:alchemy/questline/start
