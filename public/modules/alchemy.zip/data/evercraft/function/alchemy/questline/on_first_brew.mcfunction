# ============================================================
# The Chemist's Questline — First-brew trigger (auto-give book + start)
# ============================================================
# Run as @s = the player, from the ONE gate-first line spliced into
# craftforever/alchemy/minigame/resolve (`if score @s ec.chq_active matches 0 run
# ...`). resolve is the single funnel every completed fusion-funnel brew passes
# through (it pays the cat-6 add_xp), so it is the correct, robust "first brew"
# detector — the Chemistry station is entirely GUI/minigame-driven. Mirrors
# cooking/questline/on_first_meal (first meal -> start), but the trigger is the
# first BREW rather than first meal.
#
# DUP-GUARDED by the resolve gate (ec.chq_active matches 0) AND again here, so a
# re-entrant call past activation is a no-op. Gives the Chemist's Codex (book/give
# is itself inventory-dup-guarded) then starts the line at quest 1.

# Defensive re-guard (resolve already gated on ec.chq_active matches 0).
execute if score @s ec.chq_active matches 1 run return 0

# Hand the player their Chemist's Codex (book/give dup-guards on inventory contents).
function evercraft:alchemy/questline/book/give

# Begin the line at quest 1 (start seeds the ec.chq_seen cursor + shows the intro).
function evercraft:alchemy/questline/start
