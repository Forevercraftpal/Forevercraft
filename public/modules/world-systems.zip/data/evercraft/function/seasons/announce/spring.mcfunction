# Season Announcement — Spring
data modify storage evercraft:notify stage.c set value [{text:"Spring has arrived.",color:"green",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"New life blooms across the land.",color:"dark_green"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @a times 10 60 20
title @a subtitle {"text":"New life blooms.","color":"dark_green"}
title @a title {"text":"Spring","color":"green"}
playsound minecraft:block.note_block.chime master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.0
playsound minecraft:block.note_block.chime master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.2
