# Season Announcement — Autumn
data modify storage evercraft:notify stage.c set value [{text:"Autumn has arrived.",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The air grows crisp and the harvest calls.",color:"yellow"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @a times 10 60 20
title @a subtitle {"text":"The harvest calls.","color":"yellow"}
title @a title {"text":"Autumn","color":"gold"}
playsound minecraft:block.note_block.chime master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.8
playsound minecraft:block.note_block.chime master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.0
