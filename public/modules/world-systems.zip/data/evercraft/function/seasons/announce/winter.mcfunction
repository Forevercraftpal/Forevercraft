# Season Announcement — Winter
data modify storage evercraft:notify stage.c set value [{text:"Winter has arrived.",color:"blue",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The frost settles and the hearth beckons.",color:"aqua"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @a times 10 60 20
title @a subtitle {"text":"The frost settles.","color":"aqua"}
title @a title {"text":"Winter","color":"blue"}
playsound minecraft:block.note_block.chime master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 0.6
playsound minecraft:block.note_block.chime master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 0.8
