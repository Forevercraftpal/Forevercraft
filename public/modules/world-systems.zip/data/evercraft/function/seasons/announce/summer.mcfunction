# Season Announcement — Summer
data modify storage evercraft:notify stage.c set value [{text:"Summer has arrived.",color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The sun blazes and adventure awaits.",color:"gold"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @a times 10 60 20
title @a subtitle {"text":"Adventure awaits.","color":"gold"}
title @a title {"text":"Summer","color":"yellow"}
playsound minecraft:block.note_block.chime master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.2
playsound minecraft:block.note_block.chime master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.4
