# Seasonal System — Season transition detected
# Announce the new season to all players

# Only announce to players during real transitions (not on server load)
execute unless score #season_loading ec.var matches 1 if score #season_id ec.var matches 0 run function evercraft:seasons/announce/autumn
execute unless score #season_loading ec.var matches 1 if score #season_id ec.var matches 1 run function evercraft:seasons/announce/winter
execute unless score #season_loading ec.var matches 1 if score #season_id ec.var matches 2 run function evercraft:seasons/announce/spring
execute unless score #season_loading ec.var matches 1 if score #season_id ec.var matches 3 run function evercraft:seasons/announce/summer

# Snow melt is no longer triggered here — it runs every non-winter season from
# the effects tick (gated on season_id/season_day), so leftover snow keeps
# fading out across spring/summer/early-autumn instead of stopping after a window.

# === SEASONAL CLOCK RATE ===
# Autumn/Spring: uniform 1/3 speed all day
execute if score #season_id ec.var matches 0 run time of minecraft:overworld rate 0.333333
execute if score #season_id ec.var matches 2 run time of minecraft:overworld rate 0.333333
# Winter: day goes 2x fast (0.666), night stays slow (0.333) — set initial based on time of day
execute if score #season_id ec.var matches 1 if score #visual_time ec.var matches ..12999 run time of minecraft:overworld rate 0.666666
execute if score #season_id ec.var matches 1 if score #visual_time ec.var matches 13000.. run time of minecraft:overworld rate 0.333333
# Summer: day stays slow (0.333), night goes 2x fast (0.666) — set initial based on time of day
execute if score #season_id ec.var matches 3 if score #visual_time ec.var matches ..12999 run time of minecraft:overworld rate 0.333333
execute if score #season_id ec.var matches 3 if score #visual_time ec.var matches 13000.. run time of minecraft:overworld rate 0.666666

# Signal resource pack swap (skipped during server load to prevent restart loop)
execute unless score #season_loading ec.var matches 1 run scoreboard players set #season_swap_pending ec.var 1
data modify storage evercraft:notify stage.c set value [{text:"The world is transforming... server will restart momentarily.",color:"dark_aqua",italic:true}]
scoreboard players set #ndur ec.temp 50
execute unless score #season_loading ec.var matches 1 as @a run function evercraft:util/notify/emit
