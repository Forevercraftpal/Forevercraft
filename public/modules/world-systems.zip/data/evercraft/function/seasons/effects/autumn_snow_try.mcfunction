# Autumn Dusting — try to place/thicken a THIN snow layer at current XZ
# Mirrors winter_snow_try's placement guards (motion_blocking heightmap skips
# small plants so we don't pile snow on them), but caps the dusting at 2 layers.

# Biome-smart (Joseph 2026-06-01): skip hot/dry biomes via the #evercraft:no_snow tag.
# Thicken an existing thin dusting one step: layer 1 -> 2 only (never deeper)
execute positioned over motion_blocking unless biome ~ ~ ~ #evercraft:no_snow if block ~ ~-1 ~ snow[layers=1] run setblock ~ ~-1 ~ snow[layers=2]

# Place the first layer only where the cell is truly air over solid ground
execute positioned over motion_blocking unless biome ~ ~ ~ #evercraft:no_snow if block ~ ~ ~ air unless block ~ ~-1 ~ snow unless block ~ ~-1 ~ air unless block ~ ~-1 ~ water unless block ~ ~-1 ~ lava run setblock ~ ~ ~ snow[layers=1]
