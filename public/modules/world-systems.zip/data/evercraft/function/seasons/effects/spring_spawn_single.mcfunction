# Spring Spawn — Single Player Check
# Run as player, at player position
# Skip if too many animals nearby

# Count nearby animals — skip if >25
execute store result score @s ec.temp run execute if entity @e[type=#evercraft:passive_mobs,distance=..48]
execute if score @s ec.temp matches 26.. run return 0

# Pick random animal type (1-5) and summon 20-30 blocks away
execute store result score #spring_type ec.temp run random value 1..5
execute store result score #spring_ox ec.temp run random value -30..30
execute store result score #spring_oz ec.temp run random value -30..30

# Summon at the offset ON THE GROUND (Joseph 2026-06-01): dropped the old ~5 air offset that
# made animals rain from the sky. Guard `unless block ~ ~-1 ~ air` so we only spawn where there's
# solid ground right at the player's Y — over a cliff/dip the spot is air below and we skip this
# cycle (no floating/sky spawns). Tagged ec.season_spawn so seasons/effects/tick self-despawns them.
execute if score #spring_type ec.temp matches 1 positioned ~20 ~ ~0 unless block ~ ~-1 ~ minecraft:air run summon sheep ~ ~ ~ {Tags:["ec.season_spawn"]}
execute if score #spring_type ec.temp matches 2 positioned ~-15 ~ ~20 unless block ~ ~-1 ~ minecraft:air run summon cow ~ ~ ~ {Tags:["ec.season_spawn"]}
execute if score #spring_type ec.temp matches 3 positioned ~0 ~ ~-25 unless block ~ ~-1 ~ minecraft:air run summon pig ~ ~ ~ {Tags:["ec.season_spawn"]}
execute if score #spring_type ec.temp matches 4 positioned ~25 ~ ~-10 unless block ~ ~-1 ~ minecraft:air run summon chicken ~ ~ ~ {Tags:["ec.season_spawn"]}
execute if score #spring_type ec.temp matches 5 positioned ~-20 ~ ~15 unless block ~ ~-1 ~ minecraft:air run summon rabbit ~ ~ ~ {Tags:["ec.season_spawn"]}
