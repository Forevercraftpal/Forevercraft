# Winter Effects — 1s tick
# Snowfall particles in all biomes + icy blue ambient dust + snow accumulation

# Gentle snowfall (white_ash drifts down slowly) — sky-exposed players only (no snowfall in caves/indoors)
execute as @a at @s if predicate evercraft:seasons/open_sky run particle white_ash ~ ~6 ~ 12 4 12 0.02 4

# Icy blue ambient dust
execute as @a at @s if predicate evercraft:seasons/open_sky run particle dust{color:[0.6,0.8,1.0],scale:0.5} ~ ~2 ~ 8 3 8 0.01 1

# === Snow Accumulation (every 81s) ===
# 24-point footprint reaching ~36 blocks (winter_snow_place); point count ×3 +
# cadence ×3 vs the old 8-point/27s version keeps server stress unchanged.
scoreboard players add #winter_snow_cd ec.var 1
execute if score #winter_snow_cd ec.var matches 81.. run function evercraft:seasons/effects/winter_snow
execute if score #winter_snow_cd ec.var matches 81.. run scoreboard players set #winter_snow_cd ec.var 0
