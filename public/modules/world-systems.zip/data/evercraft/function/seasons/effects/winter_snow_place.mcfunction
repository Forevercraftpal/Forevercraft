# Winter Snow — Place/stack snow at positions near player
# Run as player, at player position
# 24-point footprint reaching ~36 blocks (inner + mid + outer rings).
# This is the CANONICAL footprint — snow_melt_area and autumn_snow_place are
# kept IDENTICAL to it so melt/dusting cover exactly where snow is placed.
# Fires every 81s (see effects/winter) — point count ×3 + cadence ×3 vs the
# old 8-point/27s version keeps per-second work (server stress) unchanged.

# Inner ring (~7-16 blocks)
execute positioned ~7 ~0 ~3 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~-4 ~0 ~8 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~10 ~0 ~-6 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~-9 ~0 ~-2 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~2 ~0 ~-10 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~-6 ~0 ~5 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~14 ~0 ~8 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~-12 ~0 ~-11 run function evercraft:seasons/effects/winter_snow_try

# Mid ring (~24-27 blocks)
execute positioned ~22 ~0 ~10 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~-20 ~0 ~14 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~24 ~0 ~-8 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~-16 ~0 ~-20 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~6 ~0 ~26 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~-26 ~0 ~2 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~15 ~0 ~-22 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~-10 ~0 ~-25 run function evercraft:seasons/effects/winter_snow_try

# Outer ring (~33-36 blocks)
execute positioned ~30 ~0 ~14 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~-28 ~0 ~18 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~33 ~0 ~-10 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~-22 ~0 ~-26 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~8 ~0 ~34 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~-34 ~0 ~6 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~20 ~0 ~-30 run function evercraft:seasons/effects/winter_snow_try
execute positioned ~-14 ~0 ~-33 run function evercraft:seasons/effects/winter_snow_try
