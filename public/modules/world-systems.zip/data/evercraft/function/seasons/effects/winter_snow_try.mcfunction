# Winter Snow — Try to place/stack snow at current XZ (outdoor only)
# motion_blocking heightmap skips small plants (short_grass, tall_grass, ferns,
# flowers) so the position lands inside the plant cell — and the `if block air`
# check then fails, leaving the plant uncovered instead of piling snow on it.

# Biome-smart (Joseph 2026-06-01): no snow in hot/dry biomes (desert, jungles, savannas, badlands).
# Gate placement AND stacking on the #evercraft:no_snow biome tag so those biomes stay clear.
# If snow already exists at surface, stack it (increase layers)
execute positioned over motion_blocking unless biome ~ ~ ~ #evercraft:no_snow if block ~ ~-1 ~ snow positioned ~ ~-1 ~ run function evercraft:seasons/effects/winter_snow_stack

# Place first snow layer only where the cell is truly air (plants are skipped)
execute positioned over motion_blocking unless biome ~ ~ ~ #evercraft:no_snow if block ~ ~ ~ air unless block ~ ~-1 ~ snow unless block ~ ~-1 ~ air unless block ~ ~-1 ~ water unless block ~ ~-1 ~ lava run setblock ~ ~ ~ snow[layers=1]
