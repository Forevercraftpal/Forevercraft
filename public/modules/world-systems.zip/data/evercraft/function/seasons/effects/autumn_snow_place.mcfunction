# Autumn Dusting — place thin snow at positions near player
# Run as player, at player position
# Same 24-point footprint as winter_snow_place (kept in sync, ~36 blocks) so the
# fade-in dusting covers the same ground winter will deepen. Stays "light" via
# the 2-layer cap + slower cadence in autumn_snow_try / effects/autumn, not a
# smaller radius. Fires every 135s (see effects/autumn) — point count ×3 +
# cadence ×3 vs the old 8-point/45s version keeps server stress unchanged.

# Inner ring (~7-16 blocks)
execute positioned ~7 ~0 ~3 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~-4 ~0 ~8 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~10 ~0 ~-6 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~-9 ~0 ~-2 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~2 ~0 ~-10 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~-6 ~0 ~5 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~14 ~0 ~8 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~-12 ~0 ~-11 run function evercraft:seasons/effects/autumn_snow_try

# Mid ring (~24-27 blocks)
execute positioned ~22 ~0 ~10 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~-20 ~0 ~14 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~24 ~0 ~-8 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~-16 ~0 ~-20 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~6 ~0 ~26 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~-26 ~0 ~2 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~15 ~0 ~-22 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~-10 ~0 ~-25 run function evercraft:seasons/effects/autumn_snow_try

# Outer ring (~33-36 blocks)
execute positioned ~30 ~0 ~14 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~-28 ~0 ~18 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~33 ~0 ~-10 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~-22 ~0 ~-26 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~8 ~0 ~34 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~-34 ~0 ~6 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~20 ~0 ~-30 run function evercraft:seasons/effects/autumn_snow_try
execute positioned ~-14 ~0 ~-33 run function evercraft:seasons/effects/autumn_snow_try
