# Snow Melt — clear winter snow in a volume around the player.
# Run as player, at player position.
# Joseph 2026-06-01: was 24 FIXED single-layer points every 6s (a stationary player only ever
# cleared the same 24 spots, 1 layer at a time — snow piled up faster than it melted). Now one
# fill-replace clears ALL snow layers (any depth) in range each pass; it follows the player.
#
# Biome/season rule (Joseph 2026-06-01): SUMMER (season_id 3) thaws everything, even naturally-snowy
# biomes. Every other non-winter season melts the seasonal snow EXCEPT where the player stands in a
# naturally-snowy biome (#evercraft:snowy) — those keep their snow year-round.
#
# Perf retrofit H2 (2026-06-14): slab shrunk 20->10 radius / Y +-5->+-3 (~6x less volume), cadence
# widened to 6s (effects/tick), AND a per-player adaptive skip: a pass that melts nothing backs that
# player off for ~24s via ec.snowmelt_skip. Most players, most of the post-winter year, have no snow
# near them and now cost ~nothing; a pass that melts something keeps them hot (skip stays 0).
execute if score @s ec.snowmelt_skip matches 1.. run scoreboard players remove @s ec.snowmelt_skip 1
execute if score @s ec.snowmelt_skip matches 1.. run return 0
scoreboard players set #sm_hit ec.temp 0
execute if score #season_id ec.var matches 3 store result score #sm_hit ec.temp run fill ~-10 ~-3 ~-10 ~10 ~3 ~10 air replace snow
execute unless score #season_id ec.var matches 3 unless biome ~ ~ ~ #evercraft:snowy store result score #sm_hit ec.temp run fill ~-10 ~-3 ~-10 ~10 ~3 ~10 air replace snow
# Nothing melted -> no snow near this player; skip the next 4 passes (~24s) before scanning again.
execute if score #sm_hit ec.temp matches 0 run scoreboard players set @s ec.snowmelt_skip 4
