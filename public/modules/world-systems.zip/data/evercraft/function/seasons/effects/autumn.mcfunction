# Autumn Effects — 1s tick
# Leaf particles drifting down + warm ambient embers

# Falling leaves (cherry_leaves drift down naturally) — sky-exposed players only (no leaf-fall in caves/indoors)
execute as @a at @s if predicate evercraft:seasons/open_sky run particle cherry_leaves ~ ~4 ~ 8 3 8 0.01 2

# Warm ambient embers (very sparse, cozy feel)
execute as @a at @s if predicate evercraft:seasons/open_sky run particle small_flame ~ ~1 ~ 10 2 10 0.001 1

# === Late-autumn snow fade-in (days 12-15) ===
# A thin dusting begins building toward winter, capped at 2 layers — winter
# then deepens it. Melt is suppressed during this window (see effects/tick) so
# it can build. Fires every 135s: 24-point footprint (~36 blocks) ×3 + cadence
# ×3 vs the old 8-point/45s version keeps server stress unchanged.
execute if score #season_day ec.var matches 12.. run scoreboard players add #autumn_snow_cd ec.var 1
execute if score #season_day ec.var matches 12.. if score #autumn_snow_cd ec.var matches 135.. run function evercraft:seasons/effects/autumn_snow_place
execute if score #season_day ec.var matches 12.. if score #autumn_snow_cd ec.var matches 135.. run scoreboard players set #autumn_snow_cd ec.var 0
