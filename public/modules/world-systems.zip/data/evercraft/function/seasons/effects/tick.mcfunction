# Seasonal Effects — Main Tick (1s schedule)
# Ambient particles and periodic mechanics per season

# Early exit if no players
execute unless entity @a run return run schedule function evercraft:seasons/effects/tick 1s

# Dispatch to current season's effects
execute if score #season_id ec.var matches 0 run function evercraft:seasons/effects/autumn
execute if score #season_id ec.var matches 1 run function evercraft:seasons/effects/winter
execute if score #season_id ec.var matches 2 run function evercraft:seasons/effects/spring
execute if score #season_id ec.var matches 3 run function evercraft:seasons/effects/summer

# === Snow Melt (every non-winter season, until snow is gone) ===
# Runs continuously whenever it isn't winter, EXCEPT the late-autumn fade-in
# window (autumn days 12-15) where a fresh dusting is building toward winter.
# Cadence: every 3s (Joseph 2026-06-01 — was 6s / 24 sparse 1-layer points, far too slow).
# snow_melt_area now does ONE fill-replace clearing all snow within 20 blocks of each player
# per pass, so the post-winter footprint melts quickly and follows players as they move.
scoreboard players set #snow_can_melt ec.var 1
execute if score #season_id ec.var matches 1 run scoreboard players set #snow_can_melt ec.var 0
execute if score #season_id ec.var matches 0 if score #season_day ec.var matches 12.. run scoreboard players set #snow_can_melt ec.var 0
execute if score #snow_can_melt ec.var matches 1 run scoreboard players add #snow_melt_cd ec.var 1
execute if score #snow_can_melt ec.var matches 1 if score #snow_melt_cd ec.var matches 6.. run function evercraft:seasons/effects/snow_melt
execute if score #snow_can_melt ec.var matches 1 if score #snow_melt_cd ec.var matches 6.. run scoreboard players set #snow_melt_cd ec.var 0

# === SEASON-SPAWN CLEANUP (Joseph 2026-06-01 — "ambient & self-cleaning") ===
# Spring-spawned animals carry ec.season_spawn. Despawn any with NO player within 64 blocks so the
# world population stays flat instead of filling up as players roam. 10s cadence + existence-gated.
# Runs every season (not just spring) so spawns also clear after spring ends. Bred offspring are
# untagged -> permanent, so players can still keep a herd from them.
scoreboard players add #season_cleanup_cd ec.var 1
execute if score #season_cleanup_cd ec.var matches 10.. run scoreboard players set #season_cleanup_cd ec.var 0
execute if score #season_cleanup_cd ec.var matches 0 if entity @e[tag=ec.season_spawn,limit=1] as @e[tag=ec.season_spawn] at @s unless entity @p[distance=..64] run kill @s

# Reschedule
schedule function evercraft:seasons/effects/tick 1s
