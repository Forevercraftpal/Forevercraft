# Autumn Crop Bonus — 50% chance for extra crop drop
# Run as the player, at their position. $(crop) = wheat, carrots, potatoes, beetroots, nether_wart
# Called from crop_harvest/on_break during autumn

execute store result score @s ec.temp run random value 1..2
$execute if score @s ec.temp matches 1 run give @s $(crop) 1
data modify storage evercraft:notify stage.c set value [{text:"Autumn's bounty! Extra crop harvested.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.temp matches 1 run function evercraft:util/notify/emit
