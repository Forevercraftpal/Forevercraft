# The Dreaming — STOP
# One-time event — no cooldown needed (never repeats)

# Clear world event state
scoreboard players set #we_active ec.var 0
scoreboard players set #we_event_id ec.var 0

# Clear tier lock flag
scoreboard players set #we_dreaming_lock ec.var 0

# Clear Convergence of Dreams (set in start.mcfunction — Wiring #39)
scoreboard players set #gacha_convergence ec.var 0

# Remove modifier from all players
execute as @a run attribute @s luck modifier remove ec_we_dreaming
execute as @a run attribute @s luck modifier remove ec_we_omen_bonus

# Announcement
data modify storage evercraft:notify stage.c set value [{text:"The Dreaming fades... but the memory lingers.",color:"light_purple",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The world has been forever touched by dreams.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Sound
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.5 1.0
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 1.5

# Title display
title @a times 10 40 20
title @a title {text:" "}
title @a subtitle {text:"The Dreaming Has Faded",color:"light_purple"}
