# The Dreaming — START (1 hour, one-time milestone)
# Triggered when ANY player first reaches DR 30
# Executed as the triggering player

# Set one-time flag (prevents ever triggering again)
scoreboard players set #dream_30_ever ec.var 1

# Set world event state
scoreboard players set #we_active ec.var 1
scoreboard players set #we_event_id ec.var 2
scoreboard players set #we_timer ec.var 3600
scoreboard players set #we_fx ec.var 0

# Set tier lock flag (checked by crate systems — guaranteed Rare+)
scoreboard players set #we_dreaming_lock ec.var 1

# Convergence of Dreams — half-price wishes + boosted dreamdust on reveal, live for the duration
# of The Dreaming (Wiring #39 wire-up: this flag was previously set NOWHERE, so the whole
# Convergence feature was dead). Cleared in the matching stop.mcfunction. Init'd to 0 in
# gacha/load, so it's safe across /reload.
scoreboard players set #gacha_convergence ec.var 1

# Apply Dream Rate modifier (+10.0 global — massive temporary boost)
execute as @a run attribute @s luck modifier remove ec_we_dreaming
execute as @a run attribute @s luck modifier add ec_we_dreaming 10.0 add_value

# Omens + World Events: Bad Omen doubles event DR boost
tag @a[nbt={active_effects:[{id:"minecraft:bad_omen"}]}] add ec.we_omen
execute as @a[tag=ec.we_omen] run attribute @s luck modifier add ec_we_omen_bonus 2.0 add_value
execute as @a[tag=ec.we_omen] run effect clear @s minecraft:bad_omen
data modify storage evercraft:notify stage.c set value [{text:"Your Bad Omen amplifies the event! ",color:"red"},{text:"(+2.0 bonus DR)",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=ec.we_omen] run function evercraft:util/notify/emit
tag @a remove ec.we_omen

# Server-wide announcement with triggering player's name
# Actor-named line renders directly (selector:@s must resolve in actor context, not recipient's)
execute as @s run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"gold",bold:true},{text:" has awakened The Dreaming!",color:"light_purple",italic:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @s run execute as @a run scoreboard players set #nttl ec.temp 600
execute as @s run execute as @a run function evercraft:util/notify/emit_keep
data modify storage evercraft:notify stage.c set value [{text:"✦ THE DREAMING ✦",color:"light_purple",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Reality bends to the will of dreams...",color:"light_purple",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"light_purple"},{text:"ALL players: Dream Rate +10.0",color:"#FF88FF"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"light_purple"},{text:"All crate drops guaranteed Rare+",color:"#FF88FF"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"light_purple"},{text:"Lore sparkle spawn rate tripled",color:"#FF88FF"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 1 hour",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Ethereal sounds
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.end_portal.spawn master @s ~ ~ ~ 0.4 1.5
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.allay.ambient_with_item master @s ~ ~ ~ 1.0 0.5
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1.0 0.3
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 0.8

# Title for all players
title @a times 20 100 40
title @a title [{text:"The Dreaming",color:"light_purple"}]
title @a subtitle [{text:"Reality bends to the will of dreams...",color:"#FF88FF",italic:true}]

# Track for achievements
scoreboard players set @a ach.we_dreaming 1

# Override tick to 1s for active event
schedule function evercraft:world_events/tick 1s
