# Rift Echo — Spawn The Ender Architect Boss
# Executed as a random player, at their position.
# (Was warden — replaced because warden's dig-down + per-tick anger damage was
# buggy in 26.1. Dropped RIFT.Mob tag because dimensional_rift/stop.mcfunction's
# `kill @e[tag=RIFT.Mob]` was clobbering the boss cross-event.)

# Summon temp marker for position finding
summon marker ~ ~ ~ {Tags:["RIFT.boss_temp"]}

# Spread to random surface position (30-80 blocks from player)
spreadplayers ~ ~ 30 80 false @e[type=marker,tag=RIFT.boss_temp,distance=..5,limit=1,sort=nearest]

# Summon The Ender Architect (blaze) at the marker position.
# RIFT.Boss only (no RIFT.Mob) so dimensional_rift's stop doesn't kill it.
execute at @e[type=marker,tag=RIFT.boss_temp,limit=1] run summon blaze ~ ~ ~ {Tags:["RIFT.Boss","wb.boss","wb.ender_architect"],PersistenceRequired:1b,CustomName:{text:"The Ender Architect",color:"light_purple",bold:true},CustomNameVisible:1b,attributes:[{id:"max_health",base:550.0d},{id:"armor",base:8.0d},{id:"movement_speed",base:0.23d},{id:"attack_damage",base:9.0d},{id:"follow_range",base:64.0d}]}

# Heal to full (max_health attribute change doesn't auto-heal)
execute as @e[tag=RIFT.Boss,limit=1] run effect give @s instant_health 1 100 true

# Glowing for visibility through walls (the rift drama wants this)
execute as @e[tag=RIFT.Boss,limit=1] run effect give @s glowing infinite 0 true

# Spawn 4 endermite minions around the boss (signature Ender Architect adds)
execute at @e[tag=RIFT.Boss,limit=1] run summon endermite ~2 ~ ~ {Tags:["RIFT.Mob","wb.minion"],PersistenceRequired:1b,Lifetime:0}
execute at @e[tag=RIFT.Boss,limit=1] run summon endermite ~-2 ~ ~ {Tags:["RIFT.Mob","wb.minion"],PersistenceRequired:1b,Lifetime:0}
execute at @e[tag=RIFT.Boss,limit=1] run summon endermite ~ ~ ~2 {Tags:["RIFT.Mob","wb.minion"],PersistenceRequired:1b,Lifetime:0}
execute at @e[tag=RIFT.Boss,limit=1] run summon endermite ~ ~ ~-2 {Tags:["RIFT.Mob","wb.minion"],PersistenceRequired:1b,Lifetime:0}

# Announce boss coordinates
execute as @e[tag=RIFT.Boss,limit=1] store result score #boss_x ec.temp run data get entity @s Pos[0]
execute as @e[tag=RIFT.Boss,limit=1] store result score #boss_z ec.temp run data get entity @s Pos[2]
data modify storage evercraft:notify stage.c set value [{text:"The Ender Architect emerges at ",color:"light_purple"},{text:"X: ",color:"gray"},{score:{name:"#boss_x",objective:"ec.temp"},color:"gold"},{text:" Z: ",color:"gray"},{score:{name:"#boss_z",objective:"ec.temp"},color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit

# Impact effects
execute at @e[type=marker,tag=RIFT.boss_temp,limit=1] run particle minecraft:reverse_portal ~ ~2 ~ 5 3 5 1.0 25
execute at @e[type=marker,tag=RIFT.boss_temp,limit=1] run particle minecraft:portal ~ ~2 ~ 4 2 4 0.5 20
execute at @e[type=marker,tag=RIFT.boss_temp,limit=1] run playsound minecraft:entity.blaze.ambient master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 0.6
execute at @e[type=marker,tag=RIFT.boss_temp,limit=1] run playsound minecraft:entity.enderman.scream master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 0.9 0.7

# Kill temp marker
kill @e[type=marker,tag=RIFT.boss_temp]
