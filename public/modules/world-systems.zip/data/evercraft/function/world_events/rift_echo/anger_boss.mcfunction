# DEPRECATED — Rift Echo boss is no longer a warden. This file is a no-op so any
# in-flight `schedule function evercraft:world_events/rift_echo/anger_boss` calls
# from before the swap don't error on resolve. Safe to delete after one server cycle.
