# Fishing Derby — START (1-day event)
# Competitive fishing scoring, prizes for top angler

# Set calendar state
scoreboard players set #cal_active ec.var 1
scoreboard players set #cal_event_id ec.var 4
scoreboard players set #cal_event_days ec.var 1
function evercraft:briefing/log_event {msg:"Fishing Derby started!"}

# Reset all derby scores
scoreboard players set @a cal.derby_score 0

# Apply fishing luck modifier (+0.5 DR)
execute as @a run attribute @s luck modifier remove ec_cal_derby
execute as @a run attribute @s luck modifier add ec_cal_derby 0.5 add_value

# Server-wide announcement
data modify storage evercraft:notify stage.c set value [{text:"FISHING DERBY",color:"blue",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Anglers, the competition begins!",color:"aqua",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"blue"},{text:"Catch as many fish as you can",color:"white"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"blue"},{text:"Dream Rate +0.5 while fishing",color:"green"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"blue"},{text:"Top angler wins an artifact!",color:"gold"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"blue"},{text:"1.5x Fishing Crate chance",color:"green"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 1 day",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Sound
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.fishing_bobber.splash master @s ~ ~ ~ 0.8 1.0
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.5

# Title
title @a times 10 60 20
title @a title {text:" "}
title @a subtitle [{text:"Fishing Derby",color:"blue"}]
