# Meteor Shower — STOP

# Clear calendar state
scoreboard players set #cal_active ec.var 0
scoreboard players set #cal_event_id ec.var 0
scoreboard players set #cal_rest_days ec.var 6

# Remove modifier
execute as @a run attribute @s luck modifier remove ec_cal_meteor

# Clean up remaining meteor ore blocks — ore was placed into surface air, so
# restore to air. Gated on the block STILL being a meteor ore so any spot a
# player mined + rebuilt is left untouched (no grief).
execute as @e[type=marker,tag=METEOR.Ore] at @s if block ~ ~ ~ #evercraft:meteor_ore run setblock ~ ~ ~ air
kill @e[type=marker,tag=METEOR.Ore]

# Announcement
data modify storage evercraft:notify stage.c set value [{text:"The meteor shower fades with the dawn...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Any uncollected ore crumbles to dust.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Sound
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.5 1.0
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.5

# Title display
title @a times 10 40 20
title @a title {text:" "}
title @a subtitle {text:"Meteor Shower Ended",color:"gray"}
