# Harvest Festival — STOP

# Clear calendar state
scoreboard players set #cal_active ec.var 0
scoreboard players set #cal_event_id ec.var 0
scoreboard players set #cal_rest_days ec.var 6

# Remove Dream Rate modifier
execute as @a run attribute @s luck modifier remove ec_cal_harvest

# Deactivate harvest crate bonus
scoreboard players set @a ec.hf_active 0

# Restore normal crop growth
gamerule minecraft:random_tick_speed 3

# Announcement
data modify storage evercraft:notify stage.c set value [{text:"The Harvest Festival has ended.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The fields return to their normal rhythm.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Sound
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.5 1.0

# Title display
title @a times 10 40 20
title @a title {text:" "}
title @a subtitle {text:"Harvest Festival Ended",color:"gray"}
