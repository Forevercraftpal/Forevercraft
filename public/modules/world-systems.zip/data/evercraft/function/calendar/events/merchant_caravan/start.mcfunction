# Merchant Caravan — START (2-day event)
# Special traveling merchant with exclusive goods

# Set calendar state
scoreboard players set #cal_active ec.var 1
scoreboard players set #cal_event_id ec.var 3
scoreboard players set #cal_event_days ec.var 2
function evercraft:briefing/log_event {msg:"Merchant Caravan arrived!"}

# Summon merchant near a random player
execute as @r at @s run function evercraft:calendar/events/merchant_caravan/spawn_merchant

# Server-wide announcement
data modify storage evercraft:notify stage.c set value [{text:"MERCHANT CARAVAN",color:"aqua",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"A traveling merchant has arrived!",color:"aqua",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"aqua"},{text:"Exclusive goods for sale",color:"white"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"+ ",color:"aqua"},{text:"Find the merchant nearby",color:"white"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 2 days",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Sound
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wandering_trader.ambient master @s ~ ~ ~ 0.8 1.0
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.2

# Title
title @a times 10 60 20
title @a title {text:" "}
title @a subtitle [{text:"Merchant Caravan",color:"aqua"}]
