# Fishing Derby — STOP

# Clear calendar state
scoreboard players set #cal_active ec.var 0
scoreboard players set #cal_event_id ec.var 0
scoreboard players set #cal_rest_days ec.var 6

# Remove modifier
execute as @a run attribute @s luck modifier remove ec_cal_derby

# Announce results
data modify storage evercraft:notify stage.c set value [{text:"FISHING DERBY RESULTS",color:"blue",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit

# Find winner and announce
function evercraft:calendar/events/fishing_derby/leaderboard

# Sound
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.5 1.2

# Title display
title @a times 10 40 20
title @a title {text:" "}
title @a subtitle {text:"Fishing Derby Ended",color:"gray"}

# Clear all scores (including offline players) to prevent stale data in next derby
scoreboard players reset * cal.derby_score
