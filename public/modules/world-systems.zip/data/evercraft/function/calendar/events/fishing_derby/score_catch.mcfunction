# Fishing Derby — Score a Catch
# Called from fishing/ref/on_catch.mcfunction when derby is active
# Run as the player who caught the fish

scoreboard players add @s cal.derby_score 1

# Visual feedback
data modify storage evercraft:notify stage.c set value [{text:"Catch! Score: ",color:"aqua"},{score:{name:"@s",objective:"cal.derby_score"},color:"white",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.3 1.8
