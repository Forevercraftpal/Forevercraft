# Fishing Derby — Leaderboard
# Announce the winner(s) and give prize

# Find the highest score
scoreboard players set #cal_top_score ec.var 0
execute as @a if score @s cal.derby_score > #cal_top_score ec.var run scoreboard players operation #cal_top_score ec.var = @s cal.derby_score

# No catches = no winner
execute if score #cal_top_score ec.var matches 0 run data modify storage evercraft:notify stage.c set value [{text:"No fish were caught today!",color:"gray",italic:true}]
execute if score #cal_top_score ec.var matches 0 run scoreboard players set #ndur ec.temp 45
execute if score #cal_top_score ec.var matches 0 run execute as @a run function evercraft:util/notify/emit
execute if score #cal_top_score ec.var matches 0 run return 0

# Announce winner(s) — any player matching top score (names actor → direct render)
execute as @a if score @s cal.derby_score = #cal_top_score ec.var run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"Winner: ",color:"gold"},{text:"",color:"gold",bold:true},{text:" with ",color:"white"},{score:{name:"@s",objective:"cal.derby_score"},color:"gold",bold:true},{text:" catches!",color:"white"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a if score @s cal.derby_score = #cal_top_score ec.var run execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a if score @s cal.derby_score = #cal_top_score ec.var run execute as @a run function evercraft:util/notify/emit_keep

# Give prize to winner(s) — a rare artifact
execute as @a if score @s cal.derby_score = #cal_top_score ec.var store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute as @a if score @s cal.derby_score = #cal_top_score ec.var at @s if score #inv_full ec.var matches 0 run loot give @s loot evercraft:artifacts/rare/main
execute as @a if score @s cal.derby_score = #cal_top_score ec.var at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:artifacts/rare/main
data modify storage evercraft:notify stage.c set value [{text:"You received a rare artifact as your prize!",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute as @a if score @s cal.derby_score = #cal_top_score ec.var run function evercraft:util/notify/emit

# Announce everyone else's scores (names actor → direct render)
execute as @a unless score @s cal.derby_score = #cal_top_score ec.var if score @s cal.derby_score matches 1.. run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"gray"},{text:": ",color:"gray"},{score:{name:"@s",objective:"cal.derby_score"},color:"white"},{text:" catches",color:"gray"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a unless score @s cal.derby_score = #cal_top_score ec.var if score @s cal.derby_score matches 1.. run execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a unless score @s cal.derby_score = #cal_top_score ec.var if score @s cal.derby_score matches 1.. run execute as @a run function evercraft:util/notify/emit_keep
