# Calendar — Pick Next Event
# Random selection with anti-repeat buffer (can't repeat last 2 events)
# Uses random value 1..8, validates against #cal_last1/#cal_last2
# 4 random attempts, then deterministic fallback
#
# UNIFIED EVENT DIRECTOR integration (2026-06-05):
#  - Calendar events are TRACK B (ambient). Spacing: if another Track-B (ambient)
#    event already fired today, defer this pick (extend rest 1 day) so two ambient
#    events can't stack. Competitions (Track A) do NOT block the calendar — a noon
#    competition and a calendar event may share a day.
#  - Fishing Derby (id 4) is competition-flavored but calendar-scheduled, so it
#    rides Track B with the rest of the calendar (owner default 2026-06-05).
#  - Skyrift Derby (id 8) is now eligibility-gated AT SELECTION: a pick of 8 is
#    only valid if a player currently has elytra equipped (#evd_skyrift_ok). This
#    replaces the old countdown/swap hack — Skyrift now fires cleanly when chosen.
#  - On a successful pick, stamp Track B's spacing registers (cal_on_commit).

# === Director Track-B spacing gate: defer if an ambient event already fired ===
function evercraft:event_director/cal_spacing_gate
execute if score #evd_cal_block ec.var matches 1 run scoreboard players set #cal_rest_days ec.var 1
execute if score #evd_cal_block ec.var matches 1 run return 0

# === CROSS-TRACK CAP GATE (2026-06-06) — at most 2 event bossbars/day ========================
# A calendar event is a Track-B ambient event with its own bossbar; it counts toward the global
# 2-bar cap (#evt_today_n, reset each dawn in luck_buffs/dawn_dispatch). HARD CAP: if 2 events
# already committed today, defer the pick (extend rest 1 day) and bail — never a 3rd bar.
execute if score #evt_today_n ec.var matches 2.. run scoreboard players set #cal_rest_days ec.var 1
execute if score #evt_today_n ec.var matches 2.. run return 0
# SUPER-RARE 2nd event: if exactly 1 event already committed today, this calendar pick fires only
# on a ~1/10 roll; otherwise defer (extend rest 1 day) so two-at-once stays rare. 0 committed ->
# fall straight through (first event of the day).
execute if score #evt_today_n ec.var matches 1 store result score #evt_2nd ec.var run random value 1..10
execute if score #evt_today_n ec.var matches 1 if score #evt_2nd ec.var matches 2..10 run scoreboard players set #cal_rest_days ec.var 1
execute if score #evt_today_n ec.var matches 1 if score #evt_2nd ec.var matches 2..10 run return 0

# === Director eligibility: can Skyrift (id 8) be selected right now? ===
function evercraft:event_director/cal_can_skyrift

scoreboard players set #cal_pick_ok cal.temp 0

# --- Attempt 1 ---
execute if score #cal_pick_ok cal.temp matches 0 store result score #cal_pick cal.temp run random value 1..8
execute if score #cal_pick_ok cal.temp matches 0 unless score #cal_pick cal.temp = #cal_last1 ec.var unless score #cal_pick cal.temp = #cal_last2 ec.var run function evercraft:calendar/pick_validate

# --- Attempt 2 ---
execute if score #cal_pick_ok cal.temp matches 0 store result score #cal_pick cal.temp run random value 1..8
execute if score #cal_pick_ok cal.temp matches 0 unless score #cal_pick cal.temp = #cal_last1 ec.var unless score #cal_pick cal.temp = #cal_last2 ec.var run function evercraft:calendar/pick_validate

# --- Attempt 3 ---
execute if score #cal_pick_ok cal.temp matches 0 store result score #cal_pick cal.temp run random value 1..8
execute if score #cal_pick_ok cal.temp matches 0 unless score #cal_pick cal.temp = #cal_last1 ec.var unless score #cal_pick cal.temp = #cal_last2 ec.var run function evercraft:calendar/pick_validate

# --- Attempt 4 ---
execute if score #cal_pick_ok cal.temp matches 0 store result score #cal_pick cal.temp run random value 1..8
execute if score #cal_pick_ok cal.temp matches 0 unless score #cal_pick cal.temp = #cal_last1 ec.var unless score #cal_pick cal.temp = #cal_last2 ec.var run function evercraft:calendar/pick_validate

# --- Deterministic fallback if all random rolls failed ---
execute if score #cal_pick_ok cal.temp matches 0 run function evercraft:calendar/pick_fallback

# === Update anti-repeat buffer ===
scoreboard players operation #cal_last2 ec.var = #cal_last1 ec.var
scoreboard players operation #cal_last1 ec.var = #cal_pick cal.temp

# === Director: stamp shared spacing registers (a gated event fired today) ===
function evercraft:event_director/cal_on_commit

# === Cross-track cap: a calendar event committed -> count it toward today's 2-bar cap. ===
scoreboard players add #evt_today_n ec.var 1

# === Route to event start (via omen warning system) ===
# Immediate-start events: set omen timer (60s = chat warning, then 30s particles, then start)
execute if score #cal_pick cal.temp matches 1 run scoreboard players set #cal_omen_id ec.var 1
execute if score #cal_pick cal.temp matches 3 run scoreboard players set #cal_omen_id ec.var 3
execute if score #cal_pick cal.temp matches 4 run scoreboard players set #cal_omen_id ec.var 4
execute if score #cal_pick cal.temp matches 6 run scoreboard players set #cal_omen_id ec.var 6
execute if score #cal_pick cal.temp matches 7 run scoreboard players set #cal_omen_id ec.var 7
execute if score #cal_pick cal.temp matches 8 run scoreboard players set #cal_omen_id ec.var 8
# If omen was set (immediate events), start the 60s timer + chat warning
execute if score #cal_omen_id ec.var matches 1.. run scoreboard players set #cal_omen_timer ec.var 60
execute if score #cal_omen_id ec.var matches 1.. run function evercraft:omens/calendar/chat_warning

# Night-gated events: set pending (omen plays at pre-dusk, starts at dusk)
execute if score #cal_pick cal.temp matches 2 run scoreboard players set #cal_pending ec.var 2
execute if score #cal_pick cal.temp matches 5 run scoreboard players set #cal_pending ec.var 5
# Reset night warned flag so omen fires for this pending event
execute if score #cal_pick cal.temp matches 2 run scoreboard players set #cal_night_warned ec.var 0
execute if score #cal_pick cal.temp matches 5 run scoreboard players set #cal_night_warned ec.var 0
