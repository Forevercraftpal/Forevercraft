# Calendar — Validate a candidate pick (#cal_pick) past the anti-repeat filter.
# Called only after the caller has already confirmed #cal_pick is NOT in
# #cal_last1/#cal_last2. Here we apply the remaining eligibility rule:
#   - Skyrift Derby (id 8) requires a player to currently have elytra equipped
#     (#evd_skyrift_ok == 1, set by event_director/cal_can_skyrift). If nobody
#     is wing-ready, reject the pick so the loop re-rolls a different event.
# Sets #cal_pick_ok cal.temp = 1 when the pick is accepted.

# Skyrift roll but no one is wing-ready -> reject (leave #cal_pick_ok at 0).
execute if score #cal_pick cal.temp matches 8 unless score #evd_skyrift_ok ec.var matches 1 run return 0

# Otherwise the pick is valid.
scoreboard players set #cal_pick_ok cal.temp 1
