# Furia — Force Spawn (Creator Toolkit)
# @s = op player, positioned at @s
# Triggers furia check with debug boost to guarantee spawn

scoreboard players set #debug_boost ec.debug 1
function evercraft:mobs/furia/check
scoreboard players set #debug_boost ec.debug 0
