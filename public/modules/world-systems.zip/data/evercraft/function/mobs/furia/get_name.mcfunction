# Fetch Furia name from database (indices 126-250)
# Reads first_name and last_name from evercraft:database into evercraft:furia/temp
# Reads from evercraft:database names.patrons.* at indices 126..250 (shares patron DB; no separate names.furia.* schema exists).
$data modify storage evercraft:furia/temp first_name set from storage evercraft:database names.patrons.first.$(first_name)
$data modify storage evercraft:furia/temp last_name set from storage evercraft:database names.patrons.last.$(last_name)
