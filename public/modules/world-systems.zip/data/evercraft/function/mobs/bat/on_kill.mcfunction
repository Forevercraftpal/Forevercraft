# Bat Kill — 40% chance of Poison I for 5 seconds ("bat bit back")
# + 5% chance to drop Crystalized Dream Droppings
# Triggered by advancement: evercraft:mobs/bat/on_kill

# Revoke so it can trigger again
advancement revoke @s only evercraft:mobs/bat/on_kill

# 40% chance: roll 1-100, if 1-40 then poison
execute store result score #rand ec.var run random value 1..100
execute if score #rand ec.var matches 1..40 run effect give @s minecraft:poison 5 0 false
data modify storage evercraft:notify stage.c set value [{text:"The bat bit you as it died!",color:"dark_green"}]
scoreboard players set #ndur ec.temp 45
execute if score #rand ec.var matches 1..40 run function evercraft:util/notify/emit_keyed {key:4}

# 5% chance to drop Crystalized Dream Droppings
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if predicate {"condition":"minecraft:random_chance","chance":0.05} if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/crystalized_dream_droppings
execute if predicate {"condition":"minecraft:random_chance","chance":0.05} at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/crystalized_dream_droppings
