# Zombie Villager Cured — grant trade discounts to ALL nearby players
# Triggered when any player cures a zombie villager
# Run as the curing player

# Revoke advancement so it can trigger again
advancement revoke @s only evercraft:mobs/zombie_cure

# Announce to all players — actor-named broadcast (§5b direct render in actor context)
execute as @s run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"green"},{text:" has cured a zombie villager! All nearby players receive temporary trade discounts.",color:"green"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 45
execute as @s run execute as @a run scoreboard players set #nttl ec.temp 300
execute as @s run execute as @a run function evercraft:util/notify/emit

# Give Hero of the Village I (60 seconds = 1200 ticks) to all players within 64 blocks
effect give @a[distance=..64] minecraft:hero_of_the_village 60 0 true

# Play a celebratory sound for all nearby players
playsound minecraft:entity.player.levelup master @a[distance=..64,scores={ec.fx_snd=1..}] ~ ~ ~ 0.8 1.0

# Particles at the curing player's location
execute at @s run particle minecraft:happy_villager ~ ~1 ~ 1 1 1 0 10
