# Night = time-of-day 13000..23000. Reuses #visual_time ec.var — the pack's maintained 0-24000
# time-of-day (updated every 1s by luck_buffs/tick), the same DayTime the removed time_check
# predicate evercraft:mobs/time/night_time read (its 26.1 schema was unparseable).
$execute if data storage eden:settings bestiary.villager_settings{villagecenter_healing:"daytime"} as @e[type=#$(validmobs)] at @s unless score #visual_time ec.var matches 13000..23000 if entity @e[type=armor_stand,tag=bestiary.village.name,distance=..$(village_heal_distance)] run effect give @s regeneration 5 0 true
$execute if data storage eden:settings bestiary.villager_settings{villagecenter_healing:"nighttime"} as @e[type=#$(validmobs)] at @s if score #visual_time ec.var matches 13000..23000 if entity @e[type=armor_stand,tag=bestiary.village.name,distance=..$(village_heal_distance)] run effect give @s regeneration 5 0 true
$execute if data storage eden:settings bestiary.villager_settings{villagecenter_healing:"always"} as @e[type=#$(validmobs)] at @s if entity @e[type=armor_stand,tag=bestiary.village.name,distance=..$(village_heal_distance)] run effect give @s regeneration 5 0 true
