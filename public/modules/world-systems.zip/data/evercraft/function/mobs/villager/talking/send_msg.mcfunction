# (Wave 2, 2026-06-10: villager chatter rides the queue — $(message) baked at stage time; keyed
# debounce would be wrong here (each line is distinct), short TTL keeps it from showing stale.)
$data modify storage evercraft:notify stage.c set value [{bold:false,color:"dark_gray",italic:false,text:"- "},{bold:false,color:"white",italic:false,text:"$(message)"},{bold:false,color:"dark_gray",italic:false,text:" -"}]
scoreboard players set #ndur ec.temp 45
execute if data storage eden:settings bestiary.villager_settings{talking:"actionbar"} run scoreboard players set #nttl ec.temp 200
execute if data storage eden:settings bestiary.villager_settings{talking:"actionbar"} run function evercraft:util/notify/emit
$execute if data storage eden:settings bestiary.villager_settings{talking:"chat"} run tellraw @s [{bold:false,color:"white",italic:false,text:"▊ "},{bold:false,color:"white",italic:false,text:"Villager: $(message)"}]
