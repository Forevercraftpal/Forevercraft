# Spider Tier Re-derive (Audit #10 Option C — no shared ec.gear_target tag)
# Run as: mythical_spider_tN, at spider
# Untag this spider's tier if no nearby (..64) player still carries artifact-tier gear.
# Re-running mythical_scaling/apply at next mobs/init scan will re-promote if eligible.

# Use ec.spider_gear_ok per-spider scratch — set if ANY player in 64b has any tier item
scoreboard players set #has_gear ec.temp 0

execute if entity @a[distance=..64,sort=nearest,limit=1,predicate=evercraft:mobs/has_mythical_gear] run scoreboard players set #has_gear ec.temp 1

# If no nearby player has any qualifying gear, drop all tier tags from this spider
execute if score #has_gear ec.temp matches 0 run tag @s remove mythical_spider_t1
execute if score #has_gear ec.temp matches 0 run tag @s remove mythical_spider_t2
execute if score #has_gear ec.temp matches 0 run tag @s remove mythical_spider_t3
