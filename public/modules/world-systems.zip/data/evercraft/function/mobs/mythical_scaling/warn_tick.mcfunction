# Gear-rarity difficulty warning — self-scheduling 1s loop (Joseph 2026-06-02).
# Bootstrapped from mobs/load. Existence-gated: only players who have NOT yet been warned at the
# mythical tier (ec.gear_warn <= 2) and are NOT in Newcomer mode (ec.difficulty 1 — the scaling is
# skipped for Newcomers) run the per-player gear scan. Once a player is mythical-warned (gear_warn=3)
# they are excluded forever, so the cost sheds as players progress.

# Initialise ec.gear_warn=0 for any player missing it, so the `..2` selector also catches new players.
scoreboard players add @a ec.gear_warn 0

execute as @a[scores={ec.gear_warn=..2}] unless score @s ec.difficulty matches 1 run function evercraft:mobs/mythical_scaling/warn_player

schedule function evercraft:mobs/mythical_scaling/warn_tick 20t replace
