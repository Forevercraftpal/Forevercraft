# Mythical Spider Tick
# Run every 20t (1s) via schedule
# Abilities scale with tier: t1 (ornate/exquisite), t2 (mythical 1-3), t3 (mythical 4+)

schedule function evercraft:mobs/mythical_scaling/spider_tick 20t replace

# Skip if no mythical spiders exist
execute unless entity @e[tag=mythical_spider_t1,limit=1] unless entity @e[tag=mythical_spider_t2,limit=1] unless entity @e[tag=mythical_spider_t3,limit=1] run return 0

# --- Re-tier spiders near players whose gear changed ---
# Re-evaluate tier for loaded spiders near players with artifact gear.
# Audit #10 (2026-05-28): Option C migration — `ec.gear_target` is now fn-local scratch
# inside mythical_scaling/apply (cleared on every return path). Re-derive per-spider
# by inline-checking for any artifact-tier item on the nearest 64b player.
# Perf retrofit M6 (2026-06-14): gear rarely changes second-to-second, so the per-spider gear scan
# only needs to run ~every 5s — the damage/effect logic below STAYS at 1s. #myth_retier_cd (ec.var).
scoreboard players add #myth_retier_cd ec.var 1
execute if score #myth_retier_cd ec.var matches 5.. run scoreboard players set #myth_retier_cd ec.var 0
execute if score #myth_retier_cd ec.var matches 0 as @e[type=#evercraft:mobs/mythical_scaling/spiders,tag=mythical_spider_t1] at @s run function evercraft:mobs/mythical_scaling/spider_tick_retier
execute if score #myth_retier_cd ec.var matches 0 as @e[type=#evercraft:mobs/mythical_scaling/spiders,tag=mythical_spider_t2] at @s run function evercraft:mobs/mythical_scaling/spider_tick_retier
execute if score #myth_retier_cd ec.var matches 0 as @e[type=#evercraft:mobs/mythical_scaling/spiders,tag=mythical_spider_t3] at @s run function evercraft:mobs/mythical_scaling/spider_tick_retier

# OPT: Tag-once pattern — 1 NBT read instead of 6 (same pattern as spirit/progression/track_tick)
tag @a[nbt={HurtTime:10s}] add ec.spider_hurt

# === TIER 1 (Ornate/Exquisite): Poison I 3s, 10% Wither I 3s, 5% web ===
execute as @a[tag=ec.spider_hurt] at @s if entity @e[type=#evercraft:mobs/mythical_scaling/spiders,tag=mythical_spider_t1,distance=..3] run effect give @s poison 3 0
execute as @a[tag=ec.spider_hurt] at @s if entity @e[type=#evercraft:mobs/mythical_scaling/spiders,tag=mythical_spider_t1,distance=..3] if predicate {"condition":"minecraft:random_chance","chance":0.1} run effect give @s wither 3 0
execute as @e[type=#evercraft:mobs/mythical_scaling/spiders,tag=mythical_spider_t1] at @s if entity @a[distance=..8] if predicate {"condition":"minecraft:random_chance","chance":0.05} run function evercraft:mobs/mythical_scaling/spider_web

# === TIER 2 (Mythical 1-3): Poison II 5s, 20% Wither I 4s, 10% web ===
execute as @a[tag=ec.spider_hurt] at @s if entity @e[type=#evercraft:mobs/mythical_scaling/spiders,tag=mythical_spider_t2,distance=..3] run effect give @s poison 5 1
execute as @a[tag=ec.spider_hurt] at @s if entity @e[type=#evercraft:mobs/mythical_scaling/spiders,tag=mythical_spider_t2,distance=..3] if predicate {"condition":"minecraft:random_chance","chance":0.2} run effect give @s wither 4 0
execute as @e[type=#evercraft:mobs/mythical_scaling/spiders,tag=mythical_spider_t2] at @s if entity @a[distance=..8] if predicate {"condition":"minecraft:random_chance","chance":0.1} run function evercraft:mobs/mythical_scaling/spider_web

# === TIER 3 (Mythical 4+): Poison III 7s, 30% Wither II 5s, 15% web ===
execute as @a[tag=ec.spider_hurt] at @s if entity @e[type=#evercraft:mobs/mythical_scaling/spiders,tag=mythical_spider_t3,distance=..3] run effect give @s poison 7 2
execute as @a[tag=ec.spider_hurt] at @s if entity @e[type=#evercraft:mobs/mythical_scaling/spiders,tag=mythical_spider_t3,distance=..3] if predicate {"condition":"minecraft:random_chance","chance":0.3} run effect give @s wither 5 1
execute as @e[type=#evercraft:mobs/mythical_scaling/spiders,tag=mythical_spider_t3] at @s if entity @a[distance=..8] if predicate {"condition":"minecraft:random_chance","chance":0.15} run function evercraft:mobs/mythical_scaling/spider_web

tag @a[tag=ec.spider_hurt] remove ec.spider_hurt
