# Gear-rarity difficulty warning — fire ONCE per tier the player first crosses (Joseph 2026-06-02).
# Run as @s = a player with ec.gear_warn <= 2 who is NOT in Newcomer mode (gated by warn_tick — the
# mythical/dr scaling is skipped for Newcomers, so the warning would mislead them).
#
# ec.gear_warn is a MONOTONIC high-water mark of the highest gear tier the player has been WARNED at:
#   0 = none   1 = ornate   2 = exquisite   3 = mythical
# Detection mirrors mobs/mythical_scaling/apply exactly (custom_data tier across
# armor.* / weapon.offhand / hotbar.* / inventory.*). Higher tier overwrites lower.
# NOTE: the Wishing Star / Salvation Stone carry no `tier:` custom_data, so they never trip this —
# only real ornate/exquisite/mythical ARTIFACT gear does, matching what the difficulty system reads.

scoreboard players set #cur_tier ec.temp 0
execute if items entity @s armor.* *[custom_data~{tier:"ornate"}] run scoreboard players set #cur_tier ec.temp 1
execute if items entity @s weapon.offhand *[custom_data~{tier:"ornate"}] run scoreboard players set #cur_tier ec.temp 1
execute if items entity @s hotbar.* *[custom_data~{tier:"ornate"}] run scoreboard players set #cur_tier ec.temp 1
execute if items entity @s inventory.* *[custom_data~{tier:"ornate"}] run scoreboard players set #cur_tier ec.temp 1
execute if items entity @s armor.* *[custom_data~{tier:"exquisite"}] run scoreboard players set #cur_tier ec.temp 2
execute if items entity @s weapon.offhand *[custom_data~{tier:"exquisite"}] run scoreboard players set #cur_tier ec.temp 2
execute if items entity @s hotbar.* *[custom_data~{tier:"exquisite"}] run scoreboard players set #cur_tier ec.temp 2
execute if items entity @s inventory.* *[custom_data~{tier:"exquisite"}] run scoreboard players set #cur_tier ec.temp 2
execute if items entity @s armor.* *[custom_data~{tier:"mythical"}] run scoreboard players set #cur_tier ec.temp 3
execute if items entity @s weapon.offhand *[custom_data~{tier:"mythical"}] run scoreboard players set #cur_tier ec.temp 3
execute if items entity @s hotbar.* *[custom_data~{tier:"mythical"}] run scoreboard players set #cur_tier ec.temp 3
execute if items entity @s inventory.* *[custom_data~{tier:"mythical"}] run scoreboard players set #cur_tier ec.temp 3

# Only warn when the player has reached a NEW tier above their high-water mark (monotonic — never re-warns,
# never back-warns lower tiers after a jump straight to a higher one).
execute unless score #cur_tier ec.temp > @s ec.gear_warn run return 0

# Advance the high-water mark to the current tier (each tier thus warns exactly once).
scoreboard players operation @s ec.gear_warn = #cur_tier ec.temp

# --- Tier 1: Ornate ---
execute if score #cur_tier ec.temp matches 1 run title @s times 10 70 20
execute if score #cur_tier ec.temp matches 1 run title @s title {text:"⚠ The World Takes Notice",color:"yellow",bold:true}
execute if score #cur_tier ec.temp matches 1 run title @s subtitle {text:"Your ornate gear draws stronger foes",color:"gold"}
execute if score #cur_tier ec.temp matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.bell.resonate master @s ~ ~ ~ 1.0 0.7
execute if score #cur_tier ec.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"⚠ ",color:"yellow"},{text:"Your ",color:"gray"},{text:"ornate",color:"#A855F7"},{text:" gear is drawing stronger foes nearby — power has a price. (Codex ▸ Help)",color:"gray"}]

# --- Tier 2: Exquisite ---
execute if score #cur_tier ec.temp matches 2 run title @s times 10 70 20
execute if score #cur_tier ec.temp matches 2 run title @s title {text:"⚠ Danger Rises",color:"gold",bold:true}
execute if score #cur_tier ec.temp matches 2 run title @s subtitle {text:"Exquisite power makes nearby enemies fiercer",color:"gold"}
execute if score #cur_tier ec.temp matches 2 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.elder_guardian.curse master @s ~ ~ ~ 0.8 1.0
execute if score #cur_tier ec.temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"⚠ ",color:"gold"},{text:"Your ",color:"gray"},{text:"exquisite",color:"#22D3EE"},{text:" gear hardens the foes around you — tread carefully. (Codex ▸ Help)",color:"gray"}]

# --- Tier 3: Mythical ---
execute if score #cur_tier ec.temp matches 3 run title @s times 10 80 20
execute if score #cur_tier ec.temp matches 3 run title @s title {text:"⚠ The World Grows Hostile",color:"red",bold:true}
execute if score #cur_tier ec.temp matches 3 run title @s subtitle {text:"Mythical power — nearby foes become EXTREMELY tough",color:"gold"}
execute if score #cur_tier ec.temp matches 3 if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 1.0 1.0
execute if score #cur_tier ec.temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"☠ ",color:"red"},{text:"You bear a ",color:"gray"},{text:"mythical",color:"gold",bold:true},{text:" item — nearby mobs turn EXTREMELY tough (Strength, Resistance, deadly abilities). (Codex ▸ Help)",color:"gray"}]

scoreboard players set #ndur ec.temp 60
function evercraft:util/notify/emit
