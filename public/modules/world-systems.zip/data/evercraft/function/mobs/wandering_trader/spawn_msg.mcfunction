execute if data storage eden:settings bestiary.wandering_trader_settings{spawnmsg:"chat"} run tellraw @a[distance=..64] [{bold:false,color:"#75A7FF",italic:false,text:"▊ "},{bold:false,color:"#75A7FF",italic:false,text:"A Wandering Trader spawned nearby."}]
data modify storage evercraft:notify stage.c set value [{bold:false,color:"dark_gray",italic:false,text:"- "},{bold:false,color:"#75A7FF",italic:false,text:"Wandering Trader Spawned Nearby"},{bold:false,color:"dark_gray",italic:false,text:" -"}]
scoreboard players set #ndur ec.temp 45
execute if data storage eden:settings bestiary.wandering_trader_settings{spawnmsg:"actionbar"} run execute as @a[distance=..64] run scoreboard players set #nttl ec.temp 300
execute if data storage eden:settings bestiary.wandering_trader_settings{spawnmsg:"actionbar"} run execute as @a[distance=..64] run function evercraft:util/notify/emit

execute as @a[distance=..64] at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.chicken.egg neutral @s ~ ~ ~ .5 2
