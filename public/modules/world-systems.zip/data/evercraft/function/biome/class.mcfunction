# Biome -> coarse 6-class category. Writes #biome_class ec.var (1-6). The ONE canonical
# biome-class key, shared by quests + crates + fishing (Maintenance guardrail: no per-system
# biome vocabularies). Promoted from quests/pool/biome_class (which is now a back-compat alias).
# Run as @s with ec.biome_id current (call biome/detect first).
#
# Classes: 1 farmland | 2 forest | 3 aquatic | 4 arid | 5 depths | 6 otherworld
# (Default 1 farmland if unknown.)
# FIX vs the legacy quests/pool body: the old `18..24 -> 6` row misclassified biome_id 24
# (wind = Overworld windswept). Split here: 18..23 (nether+end) -> 6 otherworld; 24 -> 5 depths.

scoreboard players set #biome_class ec.var 1

# Farmland — plains / flower_forest / savanna
execute if score @s ec.biome_id matches 0 run scoreboard players set #biome_class ec.var 1
execute if score @s ec.biome_id matches 2 run scoreboard players set #biome_class ec.var 1
execute if score @s ec.biome_id matches 8 run scoreboard players set #biome_class ec.var 1
# Forest — forest / dark_forest / taiga / jungle
execute if score @s ec.biome_id matches 1 run scoreboard players set #biome_class ec.var 2
execute if score @s ec.biome_id matches 3 run scoreboard players set #biome_class ec.var 2
execute if score @s ec.biome_id matches 4 run scoreboard players set #biome_class ec.var 2
execute if score @s ec.biome_id matches 6 run scoreboard players set #biome_class ec.var 2
# Aquatic — ocean / river / swamp / mushroom
execute if score @s ec.biome_id matches 9 run scoreboard players set #biome_class ec.var 3
execute if score @s ec.biome_id matches 10 run scoreboard players set #biome_class ec.var 3
execute if score @s ec.biome_id matches 11 run scoreboard players set #biome_class ec.var 3
execute if score @s ec.biome_id matches 12 run scoreboard players set #biome_class ec.var 3
# Arid — desert / badlands
execute if score @s ec.biome_id matches 7 run scoreboard players set #biome_class ec.var 4
execute if score @s ec.biome_id matches 14 run scoreboard players set #biome_class ec.var 4
# Depths — mountain / ice / lush_caves / dripstone / deep_dark / wind(windswept)
execute if score @s ec.biome_id matches 5 run scoreboard players set #biome_class ec.var 5
execute if score @s ec.biome_id matches 13 run scoreboard players set #biome_class ec.var 5
execute if score @s ec.biome_id matches 15 run scoreboard players set #biome_class ec.var 5
execute if score @s ec.biome_id matches 16 run scoreboard players set #biome_class ec.var 5
execute if score @s ec.biome_id matches 17 run scoreboard players set #biome_class ec.var 5
execute if score @s ec.biome_id matches 24 run scoreboard players set #biome_class ec.var 5
# Otherworld — nether (18-22) + end (23)
execute if score @s ec.biome_id matches 18..23 run scoreboard players set #biome_class ec.var 6
