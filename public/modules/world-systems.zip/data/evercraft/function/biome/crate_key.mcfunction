# Biome -> Biome-Crate Key map (curated 25->15 fold). Writes #biome_crate_key ec.var (1-15, 0=unknown).
# Run as @s with ec.biome_id current (call biome/detect first). Structural clone of quests/pool/biome_class.
#
# DUAL-INDEX LAW: affinity is per-RAW-biome (ec.baf<id>, 0-24); the crate ITEM is per-KEY (1-15).
# The biome_id->key fold happens HERE, ONCE, at crate-grant time — NEVER on the affinity write path.
# (Ocean 9+10 -> key 8 masks this in Wave-1; later keys break subtly if the fold is skipped.)
#
# Fold (council-ratified 2026-06-04):
#   k1 Verdant{0,2,8} k2 Woodland{1,3,4} k3 Jungle{6} k4 Desert{7} k5 Badlands{14}
#   k6 Frozen{13} k7 Peaks{5,24} k8 Ocean{9,10} k9 Swamp{11} k10 Mushroom{12}
#   k11 LushCaves{15} k12 Dripstone{16} k13 DeepDark{17} k14 Nether{18,19,20,21,22} k15 End{23}

scoreboard players set #biome_crate_key ec.var 0

# k1 Verdant — plains / flower_forest / savanna
execute if score @s ec.biome_id matches 0 run scoreboard players set #biome_crate_key ec.var 1
execute if score @s ec.biome_id matches 2 run scoreboard players set #biome_crate_key ec.var 1
execute if score @s ec.biome_id matches 8 run scoreboard players set #biome_crate_key ec.var 1
# k2 Woodland — forest / dark_forest / taiga
execute if score @s ec.biome_id matches 1 run scoreboard players set #biome_crate_key ec.var 2
execute if score @s ec.biome_id matches 3 run scoreboard players set #biome_crate_key ec.var 2
execute if score @s ec.biome_id matches 4 run scoreboard players set #biome_crate_key ec.var 2
# k3 Jungle
execute if score @s ec.biome_id matches 6 run scoreboard players set #biome_crate_key ec.var 3
# k4 Desert
execute if score @s ec.biome_id matches 7 run scoreboard players set #biome_crate_key ec.var 4
# k5 Badlands
execute if score @s ec.biome_id matches 14 run scoreboard players set #biome_crate_key ec.var 5
# k6 Frozen — ice / snowy
execute if score @s ec.biome_id matches 13 run scoreboard players set #biome_crate_key ec.var 6
# k7 Peaks — mountain / wind(windswept)
execute if score @s ec.biome_id matches 5 run scoreboard players set #biome_crate_key ec.var 7
execute if score @s ec.biome_id matches 24 run scoreboard players set #biome_crate_key ec.var 7
# k8 Ocean — ocean / river
execute if score @s ec.biome_id matches 9 run scoreboard players set #biome_crate_key ec.var 8
execute if score @s ec.biome_id matches 10 run scoreboard players set #biome_crate_key ec.var 8
# k9 Swamp
execute if score @s ec.biome_id matches 11 run scoreboard players set #biome_crate_key ec.var 9
# k10 Mushroom
execute if score @s ec.biome_id matches 12 run scoreboard players set #biome_crate_key ec.var 10
# k11 Lush Caves
execute if score @s ec.biome_id matches 15 run scoreboard players set #biome_crate_key ec.var 11
# k12 Dripstone Caves
execute if score @s ec.biome_id matches 16 run scoreboard players set #biome_crate_key ec.var 12
# k13 Deep Dark
execute if score @s ec.biome_id matches 17 run scoreboard players set #biome_crate_key ec.var 13
# k14 Nether — wastes / crimson / warped / basalt / soul_sand
execute if score @s ec.biome_id matches 18 run scoreboard players set #biome_crate_key ec.var 14
execute if score @s ec.biome_id matches 19 run scoreboard players set #biome_crate_key ec.var 14
execute if score @s ec.biome_id matches 20 run scoreboard players set #biome_crate_key ec.var 14
execute if score @s ec.biome_id matches 21 run scoreboard players set #biome_crate_key ec.var 14
execute if score @s ec.biome_id matches 22 run scoreboard players set #biome_crate_key ec.var 14
# k15 The End
execute if score @s ec.biome_id matches 23 run scoreboard players set #biome_crate_key ec.var 15
