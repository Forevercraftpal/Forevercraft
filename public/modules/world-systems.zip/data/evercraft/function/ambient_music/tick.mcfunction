# Ambient Music — Detection Tick (2s)
# Checks if any player is near a campfire or in a bed

# Check for players sitting at campfires (within 3 blocks of campfire)
execute as @a[tag=ec.joined] at @s if block ~ ~-1 ~ #minecraft:campfires run function evercraft:ambient_music/start_check
execute as @a[tag=ec.joined] at @s if block ~1 ~ ~ #minecraft:campfires run function evercraft:ambient_music/start_check
execute as @a[tag=ec.joined] at @s if block ~-1 ~ ~ #minecraft:campfires run function evercraft:ambient_music/start_check
execute as @a[tag=ec.joined] at @s if block ~ ~ ~1 #minecraft:campfires run function evercraft:ambient_music/start_check
execute as @a[tag=ec.joined] at @s if block ~ ~ ~-1 #minecraft:campfires run function evercraft:ambient_music/start_check

# Check for players in bed (sleeping)
execute as @a[tag=ec.joined,nbt={Sleeping:1b}] run function evercraft:ambient_music/start_check

# Stop music for players who moved away
execute as @a[tag=am.playing] at @s unless block ~ ~-1 ~ #minecraft:campfires unless block ~1 ~ ~ #minecraft:campfires unless block ~-1 ~ ~ #minecraft:campfires unless block ~ ~ ~1 #minecraft:campfires unless block ~ ~ ~-1 #minecraft:campfires unless entity @s[nbt={Sleeping:1b}] run function evercraft:ambient_music/stop

# Reschedule
schedule function evercraft:ambient_music/tick 40t replace
