# Ambient Music — Mood 7 melody: MYSTERIOUS
# Key: whole-tone on C (C D E F# G#/Ab A#/Bb). Instrument: chime. Vol 0.2.
# Phrase: floating, ambiguous whole-tone steps with no leading-tone pull, drifts back to C.
# @s = player, at @s. Branch on am.bar = phrase position 0..31.
# Pitches: C0 0.707 D0 0.794 E0 0.891 F#1 1.0 Ab1 1.122 Bb1 1.26
# (No bass drone — the whole-tone scale has no stable root; a drone would anchor it.)

execute if score @s am.bar matches 0 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 0.707
execute if score @s am.bar matches 2 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 0.794
execute if score @s am.bar matches 4 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 0.891
execute if score @s am.bar matches 6 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 1.0
execute if score @s am.bar matches 8 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 1.122
execute if score @s am.bar matches 10 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 1.0
execute if score @s am.bar matches 12 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 0.891
execute if score @s am.bar matches 16 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 0.794
execute if score @s am.bar matches 18 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 0.891
execute if score @s am.bar matches 20 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 1.0
execute if score @s am.bar matches 22 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 1.26
execute if score @s am.bar matches 24 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 1.122
execute if score @s am.bar matches 26 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 1.0
execute if score @s am.bar matches 27 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 0.891
execute if score @s am.bar matches 29 run playsound minecraft:block.note_block.chime music @s ~ ~ ~ 0.2 0.707
