# Ambient Music — Mood 4 melody: LONELY
# Key: E natural minor (E F# G A B C D). Instrument: guitar. Vol 0.3.
# Phrase: very sparse, single notes drifting in wide space, resolves quietly to E.
# @s = player, at @s. Branch on am.bar = phrase position 0..31.
# Pitches: E0 0.891 F#1 1.0 G0 1.059 A0 1.189 B0 1.335 D0 0.794

# Soft bass root drone on the downbeat for body
execute if score @s am.bar matches 0 run playsound minecraft:block.note_block.bass music @s ~ ~ ~ 0.2 0.891

execute if score @s am.bar matches 0 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.28 0.891
execute if score @s am.bar matches 4 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.28 1.335
execute if score @s am.bar matches 8 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.28 1.189
execute if score @s am.bar matches 11 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.28 1.059
execute if score @s am.bar matches 16 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.28 1.0
execute if score @s am.bar matches 20 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.28 0.891
execute if score @s am.bar matches 24 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.28 0.794
execute if score @s am.bar matches 28 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.28 0.891
