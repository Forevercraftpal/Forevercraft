# Ambient Music — Mood 3 melody: SAD
# Key: A natural minor (A B C D E F G). Instrument: guitar. Vol 0.3.
# Phrase: two descending minor lines that sigh down and settle on A.
# @s = player, at @s. Branch on am.bar = phrase position 0..31.
# Pitches: A0 0.595 B0 0.667 C0 0.707 D0 0.794 E0 0.891 F0 0.944 G0 1.059
#          C1 1.414 D1 1.587 E1 1.782

# Soft bass root drone on the downbeat for body
execute if score @s am.bar matches 0 run playsound minecraft:block.note_block.bass music @s ~ ~ ~ 0.2 0.595
execute if score @s am.bar matches 16 run playsound minecraft:block.note_block.bass music @s ~ ~ ~ 0.18 0.595

execute if score @s am.bar matches 0 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 1.782
execute if score @s am.bar matches 2 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 1.587
execute if score @s am.bar matches 4 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 1.414
execute if score @s am.bar matches 5 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 1.335
execute if score @s am.bar matches 6 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 1.189
execute if score @s am.bar matches 8 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 1.059
execute if score @s am.bar matches 10 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 1.189
execute if score @s am.bar matches 12 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 0.891
execute if score @s am.bar matches 16 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 0.944
execute if score @s am.bar matches 18 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 0.891
execute if score @s am.bar matches 20 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 0.794
execute if score @s am.bar matches 21 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 0.707
execute if score @s am.bar matches 22 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 0.667
execute if score @s am.bar matches 24 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 0.595
execute if score @s am.bar matches 27 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 0.667
execute if score @s am.bar matches 28 run playsound minecraft:block.note_block.guitar music @s ~ ~ ~ 0.3 0.595
