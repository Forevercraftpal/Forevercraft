# Ambient Music — Mood 6 melody: NOSTALGIC
# Key: F major (F G A Bb C D E). Instrument: harp. Vol 0.3.
# Phrase: warm, gentle rise and fall, wistful, comes home to F.
# @s = player, at @s. Branch on am.bar = phrase position 0..31.
# Pitches: F0 0.944 G0 1.059 A0 1.189 C1 1.414 D0 0.794 C0 0.707

# Soft bass root drone on the downbeat for body
execute if score @s am.bar matches 0 run playsound minecraft:block.note_block.bass music @s ~ ~ ~ 0.2 0.944
execute if score @s am.bar matches 16 run playsound minecraft:block.note_block.bass music @s ~ ~ ~ 0.18 0.944

execute if score @s am.bar matches 0 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 0.944
execute if score @s am.bar matches 2 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 1.059
execute if score @s am.bar matches 3 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 1.189
execute if score @s am.bar matches 5 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 1.414
execute if score @s am.bar matches 7 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 1.189
execute if score @s am.bar matches 8 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 1.059
execute if score @s am.bar matches 10 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 0.944
execute if score @s am.bar matches 12 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 1.189
execute if score @s am.bar matches 16 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 1.414
execute if score @s am.bar matches 18 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 0.794
execute if score @s am.bar matches 20 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 0.707
execute if score @s am.bar matches 21 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 1.189
execute if score @s am.bar matches 22 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 1.059
execute if score @s am.bar matches 24 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 1.189
execute if score @s am.bar matches 26 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 1.059
execute if score @s am.bar matches 27 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 0.944
execute if score @s am.bar matches 29 run playsound minecraft:block.note_block.harp music @s ~ ~ ~ 0.3 0.944
