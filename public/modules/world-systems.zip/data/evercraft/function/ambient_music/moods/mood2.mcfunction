# Ambient Music — Mood 2 melody: ADVENTUROUS
# Key: C major. Instrument: bell. Vol 0.2.
# Phrase: bright C-major triad arpeggio motifs with confident leaps, lands home on C.
# @s = player, at @s. Branch on am.bar = phrase position 0..31.
# Pitches: C0 0.707 D0 0.794 E0 0.891 G0 1.059 C1 1.414

# Soft bass root drone on the downbeat for body
execute if score @s am.bar matches 0 run playsound minecraft:block.note_block.bass music @s ~ ~ ~ 0.2 0.707
execute if score @s am.bar matches 16 run playsound minecraft:block.note_block.bass music @s ~ ~ ~ 0.18 0.707

execute if score @s am.bar matches 0 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 0.707
execute if score @s am.bar matches 2 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 0.891
execute if score @s am.bar matches 4 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 1.059
execute if score @s am.bar matches 6 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 1.414
execute if score @s am.bar matches 8 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 1.059
execute if score @s am.bar matches 10 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 0.891
execute if score @s am.bar matches 12 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 1.059
execute if score @s am.bar matches 16 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 1.414
execute if score @s am.bar matches 18 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 1.059
execute if score @s am.bar matches 19 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 0.891
execute if score @s am.bar matches 20 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 0.794
execute if score @s am.bar matches 22 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 0.891
execute if score @s am.bar matches 24 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 1.059
execute if score @s am.bar matches 26 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 0.891
execute if score @s am.bar matches 27 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 0.707
execute if score @s am.bar matches 29 run playsound minecraft:block.note_block.bell music @s ~ ~ ~ 0.2 0.707
