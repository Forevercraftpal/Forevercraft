# Ambient Music — Start Check
# @s = player near a campfire or in a bed. Starts the composed melody only if
# nothing is already playing.

# Already playing our melody? Don't restart.
execute if entity @s[tag=am.playing] run return 0

# --- No-song gate (Joseph) ---
# Don't start if a jukebox is actively playing a record nearby. In 26.1 a jukebox
# block exposes the boolean blockstate has_record=true while a disc is in/playing,
# so we can detect a *playing* jukebox cleanly (not just any jukebox). We scan the
# player's own level fully (3x3) plus the cardinal cells one above and one below
# (19 cells) — enough to catch a jukebox the player is standing on/at; bail if any
# is a playing jukebox.
execute if block ~ ~ ~ minecraft:jukebox[has_record=true] run return 0
execute if block ~1 ~ ~ minecraft:jukebox[has_record=true] run return 0
execute if block ~-1 ~ ~ minecraft:jukebox[has_record=true] run return 0
execute if block ~ ~ ~1 minecraft:jukebox[has_record=true] run return 0
execute if block ~ ~ ~-1 minecraft:jukebox[has_record=true] run return 0
execute if block ~1 ~ ~1 minecraft:jukebox[has_record=true] run return 0
execute if block ~1 ~ ~-1 minecraft:jukebox[has_record=true] run return 0
execute if block ~-1 ~ ~1 minecraft:jukebox[has_record=true] run return 0
execute if block ~-1 ~ ~-1 minecraft:jukebox[has_record=true] run return 0
execute if block ~ ~1 ~ minecraft:jukebox[has_record=true] run return 0
execute if block ~1 ~1 ~ minecraft:jukebox[has_record=true] run return 0
execute if block ~-1 ~1 ~ minecraft:jukebox[has_record=true] run return 0
execute if block ~ ~1 ~1 minecraft:jukebox[has_record=true] run return 0
execute if block ~ ~1 ~-1 minecraft:jukebox[has_record=true] run return 0
execute if block ~ ~-1 ~ minecraft:jukebox[has_record=true] run return 0
execute if block ~1 ~-1 ~ minecraft:jukebox[has_record=true] run return 0
execute if block ~-1 ~-1 ~ minecraft:jukebox[has_record=true] run return 0
execute if block ~ ~-1 ~1 minecraft:jukebox[has_record=true] run return 0
execute if block ~ ~-1 ~-1 minecraft:jukebox[has_record=true] run return 0

# Select random mood
execute store result score @s am.mood run random value 1..7

# Start playing
tag @s add am.playing
# note_idx starts at -1 so the first generate_note increment lands on phrase
# position 0 (the tonic downbeat with the bass drone).
scoreboard players set @s am.note_idx -1
scoreboard players set @s am.bar 0
scoreboard players set @s am.cd 0

# Replace any vanilla background music with the custom melody (clean hand-off).
# The melody plays in the `music` category so it respects the Music volume slider
# and is mixed as music; stopsound clears whatever vanilla track is fading in/out.
stopsound @s music

# Instrument is now baked into each mood's composed phrase (moods/mood<N>):
# harp(1,6), bell(2,5), guitar(3,4), chime(7).

# Set tempo (ticks between notes)
scoreboard players set @s am.tempo 8

# Schedule note playback
schedule function evercraft:ambient_music/play_note 8t append
