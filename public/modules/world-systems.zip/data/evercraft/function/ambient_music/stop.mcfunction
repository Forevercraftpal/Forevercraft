# Ambient Music — Stop Playing
# @s = player stopping music

tag @s remove am.playing
scoreboard players set @s am.note_idx 0
scoreboard players set @s am.bar 0
