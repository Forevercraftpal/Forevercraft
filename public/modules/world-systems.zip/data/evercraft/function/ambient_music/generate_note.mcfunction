# Ambient Music — Generate Note
# Plays the next note of a hand-composed, loopable melodic phrase.
# Each mood has its own 32-step phrase under moods/; the phrase position is
# am.note_idx % 32, stored in am.bar, and the mood file branches on it.
# @s = player, at @s. Stops are handled by tick (move-away) — the phrase loops.

# Advance the melody one step
scoreboard players add @s am.note_idx 1

# Phrase position = note_idx % 32  (0..31). Loops the phrase cleanly forever.
scoreboard players operation @s am.bar = @s am.note_idx
scoreboard players operation @s am.bar %= #am32 ec.temp

# Dispatch to this player's composed mood phrase
execute if score @s am.mood matches 1 run function evercraft:ambient_music/moods/mood1
execute if score @s am.mood matches 2 run function evercraft:ambient_music/moods/mood2
execute if score @s am.mood matches 3 run function evercraft:ambient_music/moods/mood3
execute if score @s am.mood matches 4 run function evercraft:ambient_music/moods/mood4
execute if score @s am.mood matches 5 run function evercraft:ambient_music/moods/mood5
execute if score @s am.mood matches 6 run function evercraft:ambient_music/moods/mood6
execute if score @s am.mood matches 7 run function evercraft:ambient_music/moods/mood7
