# Ambient Music — Play Note
# Generates procedural melodies using pentatonic scale
# Runs for each player with am.playing tag

execute as @a[tag=am.playing] at @s run function evercraft:ambient_music/generate_note

# Reschedule if anyone is still playing
execute if entity @a[tag=am.playing] run schedule function evercraft:ambient_music/play_note 8t append
