# Ambient Music System — Load
# Plan 4: Campfire & bed procedural note block music

# === SCOREBOARDS ===
scoreboard objectives add am.active dummy
scoreboard objectives add am.mood dummy
# 1=medieval, 2=adventurous, 3=sad, 4=lonely, 5=happy, 6=nostalgic, 7=mysterious
scoreboard objectives add am.note_idx dummy
scoreboard objectives add am.tempo dummy
scoreboard objectives add am.bar dummy
scoreboard objectives add am.instrument dummy
scoreboard objectives add am.key dummy
scoreboard objectives add am.cd dummy

# Phrase length constant for the melody loop (am.note_idx %= 32 -> phrase position)
scoreboard players set #am32 ec.temp 32

# Schedule detection tick (every 2 seconds)
schedule function evercraft:ambient_music/tick 40t replace
