# Night Terrors — 10-second warning before spawn
# Run as player at player

# Warning effects
data modify storage evercraft:notify stage.c set value [{text:"The dreamless sky stirs... something watches you.",color:"dark_red",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ambient.cave player @s ~ ~ ~ 0.8 0.5
particle dust{color:[0.3,0.0,0.0],scale:2.0} ~ ~1 ~ 4 2 4 0.1 20

# Set warning timer (10 seconds) and start active tick
tag @s add ec.nt_warned
scoreboard players set @s ec.nt_warn_cd 10

# Start the active tick loop (handles warning countdown + ability ticking)
schedule function evercraft:night_terrors/active_tick 1s replace
