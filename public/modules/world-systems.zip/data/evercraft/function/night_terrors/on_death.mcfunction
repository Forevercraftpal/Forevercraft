# Night Terrors — Terror has been defeated
# Run as player who had the active terror

# Clear active state
scoreboard players set @s ec.nt_active 0

# Set 30-minute cooldown (30 decrements at 1 per minute)
scoreboard players set @s ec.nt_cd 30

# Kill any remaining minions
kill @e[type=stray,tag=ec.nt_minion,distance=..100]

# Read DR for loot tier
execute store result score @s ec.temp run attribute @s luck get 10

# Drop loot based on DR tier
# Sub-DR-30 fallback (host's DR dropped between spawn + kill): 1 Nightmare Shard token
# AU12-PRESERVE.3 (Joseph 2026-05-30): closes the silent-zero edge case.
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score @s ec.temp matches ..299 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches ..299 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/nightmare_shard
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"dark_gray"},{text:"A token from the nightmare...",color:"gray",italic:true},{text:" ✦",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.temp matches ..299 run function evercraft:util/notify/emit

# DR 30-34: Ornate crate + 1 Nightmare Shard
execute if score @s ec.temp matches 300..349 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/tier_ornate
execute if score @s ec.temp matches 300..349 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/tier_ornate
execute if score @s ec.temp matches 300..349 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 300..349 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/nightmare_shard

# DR 35-39: Exquisite crate + 2 Nightmare Shards
execute if score @s ec.temp matches 350..399 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/tier_exquisite
execute if score @s ec.temp matches 350..399 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/tier_exquisite
execute if score @s ec.temp matches 350..399 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 350..399 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 350..399 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 350..399 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/nightmare_shard

# DR 40-44: Exquisite + 25% Mythical + 3 Nightmare Shards
execute if score @s ec.temp matches 400..449 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/tier_exquisite
execute if score @s ec.temp matches 400..449 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/tier_exquisite
execute if score @s ec.temp matches 400..449 store result score #nt_myth_roll ec.var run random value 1..4
execute if score @s ec.temp matches 400..449 if score #nt_myth_roll ec.var matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/tier_mythical
execute if score @s ec.temp matches 400..449 if score #nt_myth_roll ec.var matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/tier_mythical
execute if score @s ec.temp matches 400..449 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 400..449 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 400..449 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 400..449 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 400..449 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 400..449 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/nightmare_shard

# DR 45-50: Mythical + 5 Nightmare Shards
execute if score @s ec.temp matches 450.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/tier_mythical
execute if score @s ec.temp matches 450.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/tier_mythical
execute if score @s ec.temp matches 450.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 450.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 450.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 450.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 450.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 450.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 450.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 450.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 450.. if score #inv_full ec.var matches 0 run loot give @s loot evercraft:night_terrors/nightmare_shard
execute if score @s ec.temp matches 450.. at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:night_terrors/nightmare_shard

# World Milestones — mythical artifact found (DR 40-44 with lucky roll, or DR 45+)
execute if score @s ec.temp matches 400..449 if score #nt_myth_roll ec.var matches 1 run function evercraft:milestones/increment/mythical_found
execute if score @s ec.temp matches 450.. run function evercraft:milestones/increment/mythical_found

# Companion memory: Mythical Discovery (night terror mythical drop)
execute if score @s ec.temp matches 400..449 if score #nt_myth_roll ec.var matches 1 if entity @s[tag=companion.activepet] run function evercraft:companions/memories/on_mythical_artifact
execute if score @s ec.temp matches 450.. if entity @s[tag=companion.activepet] run function evercraft:companions/memories/on_mythical_artifact

# XP reward
experience add @s 200 points

# Announcement
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"gold"},{text:" has conquered a Night Terror!",color:"dark_red"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1.0 1.0
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
title @s subtitle {text:"The nightmare fades...",color:"gold"}
title @s title {text:"",color:"gold"}

# Achievement tracking
scoreboard players add @s ec.nt_kills 1
