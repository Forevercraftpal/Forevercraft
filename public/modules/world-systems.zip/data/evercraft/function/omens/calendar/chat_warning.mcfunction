# Calendar Omen — Chat Warning (fires once when omen begins)
# Dispatches by #cal_omen_id

data modify storage evercraft:notify stage.c set value [{text:"\u2728 ",color:"gold"},{text:"The fields stir with golden energy... a harvest is near.",color:"#D4A574",italic:true},{text:" \u2728",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute if score #cal_omen_id ec.var matches 1 as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u263D ",color:"dark_red"},{text:"A crimson haze creeps across the horizon...",color:"#D4A574",italic:true}]
scoreboard players set #ndur ec.temp 50
execute if score #cal_omen_id ec.var matches 2 as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2728 ",color:"gold"},{text:"Distant bells echo on the wind... a trader approaches.",color:"#D4A574",italic:true},{text:" \u2728",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute if score #cal_omen_id ec.var matches 3 as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2728 ",color:"aqua"},{text:"The waters ripple with unusual energy...",color:"#D4A574",italic:true},{text:" \u2728",color:"aqua"}]
scoreboard players set #ndur ec.temp 50
execute if score #cal_omen_id ec.var matches 4 as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2728 ",color:"white"},{text:"The stars flicker restlessly overhead...",color:"#D4A574",italic:true},{text:" \u2728",color:"white"}]
scoreboard players set #ndur ec.temp 50
execute if score #cal_omen_id ec.var matches 5 as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2728 ",color:"dark_purple"},{text:"Reality fractures at the edges of your vision...",color:"#D4A574",italic:true},{text:" \u2728",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 50
execute if score #cal_omen_id ec.var matches 6 as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2728 ",color:"green"},{text:"A warm wind carries whispers of fortune...",color:"#D4A574",italic:true},{text:" \u2728",color:"green"}]
scoreboard players set #ndur ec.temp 50
execute if score #cal_omen_id ec.var matches 7 as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2728 ",color:"light_purple"},{text:"The Skyrift Derby approaches! Saddle up or spread your wings!",color:"#D4A574",italic:true},{text:" \u2728",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
execute if score #cal_omen_id ec.var matches 8 as @a run function evercraft:util/notify/emit

# Subtle sound cue
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 0.8
