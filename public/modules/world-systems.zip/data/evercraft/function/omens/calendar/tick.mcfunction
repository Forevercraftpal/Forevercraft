# Calendar Omen — Timer Tick (called from calendar/tick every 1s when omen active)

# Decrement timer
scoreboard players remove #cal_omen_timer ec.var 1

# === Phase 1: Particles (30s..1s remaining) ===
execute if score #cal_omen_timer ec.var matches 1..30 run function evercraft:omens/calendar/particles

# === Skyrift Derby — live countdown actionbar so players know to grab an elytra ===
execute if score #cal_omen_id ec.var matches 8 if score #cal_omen_timer ec.var matches 1.. run title @a[tag=!ab_q] actionbar [{text:"⚡ Skyrift Derby in ",color:"light_purple"},{score:{name:"#cal_omen_timer",objective:"ec.var"},color:"yellow",bold:true},{text:"s — equip elytra to participate!",color:"light_purple"}]

# === Phase 2: Timer expired — start actual event ===
execute if score #cal_omen_timer ec.var matches ..0 run function evercraft:omens/calendar/start_event
