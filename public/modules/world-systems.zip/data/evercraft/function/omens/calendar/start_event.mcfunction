# Calendar Omen — Timer Expired, Start Actual Event
# Route to the real event start based on omen ID

execute if score #cal_omen_id ec.var matches 1 run function evercraft:calendar/events/harvest_festival/start
execute if score #cal_omen_id ec.var matches 2 run function evercraft:calendar/events/blood_moon/start
execute if score #cal_omen_id ec.var matches 3 run function evercraft:calendar/events/merchant_caravan/start
execute if score #cal_omen_id ec.var matches 4 run function evercraft:calendar/events/fishing_derby/start
execute if score #cal_omen_id ec.var matches 5 run function evercraft:calendar/events/meteor_shower/start
execute if score #cal_omen_id ec.var matches 6 run function evercraft:calendar/events/dimensional_rift/start
execute if score #cal_omen_id ec.var matches 7 run function evercraft:calendar/events/prosperity_tide/start
# Skyrift (id 8) is selected ONLY when a player already has elytra equipped
# (gated at selection by event_director/cal_can_skyrift), so it starts cleanly
# here — no countdown/swap hack. (Was: mount_training/skyrift/precheck_or_swap.)
execute if score #cal_omen_id ec.var matches 8 run function evercraft:mount_training/skyrift/start

# Clear omen state
scoreboard players set #cal_omen_id ec.var 0
scoreboard players set #cal_omen_timer ec.var 0
