# World Event Omen — Begin Warning Sequence
# Called when conditions are met; starts 60s countdown before event
# #we_omen_id is already set by check_conditions

scoreboard players set #we_omen_timer ec.var 60

# UNIFIED EVENT DIRECTOR (Track B = ambient): a world event is now firing today.
# Stamp Track B's spacing registers so another ambient/calendar event can't stack
# the same day. Does NOT touch Track A — a noon competition may still run today.
scoreboard players operation #evd_last_we ec.var = #visual_day ec.var
scoreboard players set #evd_since_we ec.var 0
# Track B order-independent no-stack marker (today = an ambient event fired).
scoreboard players operation #evd_fired_we ec.var = #visual_day ec.var

# Cross-track cap (2026-06-06): a world event committed -> count it toward today's 2-bar cap
# (#evt_today_n, reset each dawn in luck_buffs/dawn_dispatch).
scoreboard players add #evt_today_n ec.var 1

function evercraft:omens/world_events/chat_warning
