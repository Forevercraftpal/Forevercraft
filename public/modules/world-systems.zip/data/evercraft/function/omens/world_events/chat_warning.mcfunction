# World Event Omen — Chat Warning (fires once when omen begins)
# Dispatches by #we_omen_id

data modify storage evercraft:notify stage.c set value [{text:"\u2728 ",color:"white"},{text:"The constellation's alignment draws near... look to the sky.",color:"#D4A574",italic:true},{text:" \u2728",color:"white"}]
scoreboard players set #ndur ec.temp 50
execute if score #we_omen_id ec.var matches 1 as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2728 ",color:"dark_gray"},{text:"The earth groans beneath your feet...",color:"#D4A574",italic:true},{text:" \u2728",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 50
execute if score #we_omen_id ec.var matches 3 as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2728 ",color:"green"},{text:"Dawn's first light carries an otherworldly shimmer...",color:"#D4A574",italic:true},{text:" \u2728",color:"green"}]
scoreboard players set #ndur ec.temp 50
execute if score #we_omen_id ec.var matches 4 as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"\u2728 ",color:"dark_purple"},{text:"The boundary between worlds grows thin...",color:"#D4A574",italic:true},{text:" \u2728",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 50
execute if score #we_omen_id ec.var matches 5 as @a run function evercraft:util/notify/emit

# Subtle sound cue
execute as @a at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 0.8
