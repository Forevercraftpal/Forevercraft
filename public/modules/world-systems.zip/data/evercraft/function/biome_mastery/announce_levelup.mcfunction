# Macro: Announce biome mastery level-up with biome name
$data modify storage evercraft:notify stage.c set value [{text:"$(biome_name)",color:"green",bold:true},{text:" — Level Up!",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
