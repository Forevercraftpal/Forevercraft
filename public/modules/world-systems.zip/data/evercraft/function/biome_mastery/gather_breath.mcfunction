# === BIOME MASTERY — GATHER BREATH: stacking underwater-breathing (Wave E2) ===========
# Run as @s. Called from biome_mastery/player_tick right AFTER apply_perk (every 5s per
# player). This is the SINGLE WRITER of the gathering water-breathing buff (perf P0-3 /
# compliance C1 / crossplay C3): ONE computed `effect give` of the summed duration, folded
# into the existing 5s tick — NO new ticking surface, NO per-tick in-water poll. The 5s
# re-grant of a >=7s effect never lapses while submerged: that re-grant IS the refresh.
#
# Sources (each a Crafting-Class unlocked at the river/ocean unlock level, ec.caffl_*; the
# 30.. literal is #gth_uw_unlock — the SAME threshold E1 gates underwater node-spawning on,
# so breathing unlocks exactly when underwater nodes do):
#   Stone Strike (ss)  >= 30 -> +7s
#   Growseer    (gs)  >= 30 -> +7s
#   Siren Call  (sc)  >= 30 -> +14s
#   Ocean-Master (4th source, crossplay C3): current biome = Ocean (9) at bm_level 5 -> +7s
# Max SS+GS+SC = 28; + Ocean-Master in an ocean = 35. (If ec.caffl_* unlock literal changes,
# keep it in sync with #gth_uw_unlock in gather/load — same note as the check_spawn gates.)

# --- 1) Compute the stacked duration into #wb_dur ec.temp (start 0). ---
scoreboard players set #wb_dur ec.temp 0
execute if score @s ec.caffl_ss matches 30.. run scoreboard players add #wb_dur ec.temp 7
execute if score @s ec.caffl_gs matches 30.. run scoreboard players add #wb_dur ec.temp 7
execute if score @s ec.caffl_sc matches 30.. run scoreboard players add #wb_dur ec.temp 14
# Ocean-Master 4th source (folded in from the deleted apply_perk:42 Ocean give — single writer).
# ec.biome_id + ec.bm_level are this player's CURRENT biome/level (set by biome/detect +
# check_levelup earlier in player_tick), so this only fires while actually standing in an ocean.
execute if score @s ec.biome_id matches 9 if score @s ec.bm_level matches 5 run scoreboard players add #wb_dur ec.temp 7

# --- 2) One-time unlock toast (lore L6) — fires the FIRST time a class crosses the unlock, ---
# even on land (it's an unlock announcement). Flag-gated so it fires exactly once.
execute if score #wb_dur ec.temp matches 1.. if score @s ec.gth_deep_seen matches 0 run function evercraft:biome_mastery/gather_breath_unlock

# --- 3) Apply the buff: ONE give of the summed duration, ONLY in water. ---
# Hand the duration to the macro via storage, then apply iff wb>=1 AND in_water (perf P0-3:
# the only condition; no per-tick poll — this whole fn runs on the 5s tick).
execute store result storage evercraft:bm_temp wb int 1 run scoreboard players get #wb_dur ec.temp
execute if score #wb_dur ec.temp matches 1.. if predicate evercraft:in_water run function evercraft:biome_mastery/gather_breath_apply with storage evercraft:bm_temp

# --- 4) Per-entry actionbar (lore L6), EDGE-DETECTED so it never spams every 5s. ---
# Only tease unlocked players (#wb_dur >= 1). On the first wet tick after a dry one we show
# "Deep Breath — Ns underwater" once, then latch ec.gth_was_wet so subsequent wet ticks are
# silent; leaving water clears the latch so the next dive re-announces.
execute if predicate evercraft:in_water if score #wb_dur ec.temp matches 1.. if score @s ec.gth_was_wet matches 0 run function evercraft:biome_mastery/gather_breath_actionbar
execute if predicate evercraft:in_water if score #wb_dur ec.temp matches 1.. run scoreboard players set @s ec.gth_was_wet 1
execute unless predicate evercraft:in_water run scoreboard players set @s ec.gth_was_wet 0
