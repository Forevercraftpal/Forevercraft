# Biome Mastery — Announce the perk unlocked at Level 5
# @s = player, ec.biome_id = mastered biome

data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"+10% Movement Speed in Plains",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 0 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"+15% Attack Speed in Forests",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Passive Regeneration in Flower Forests",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 2 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Night Vision in Dark Forests",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 3 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"+2 Armor in Taiga",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 4 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Slow Falling in Mountains",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 5 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"+25% Forage Yield in Jungle",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 6 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"No Hunger Drain in Deserts",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 7 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"+10% Movement Speed in Savanna",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 8 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Water Breathing in Oceans",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 9 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Dolphin's Grace in Rivers",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 10 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Resistance I in Swamps",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 11 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Saturation + Regen in Mushroom Islands",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 12 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Fire Resistance in Ice Biomes",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 13 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"+0.5 Dream Rate in Badlands",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 14 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Passive Regeneration in Lush Caves",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 15 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Haste I in Dripstone Caves",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 16 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Night Vision in the Deep Dark",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 17 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Fire Resistance in Nether Wastes",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 18 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Strength I in Crimson Forest",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 19 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Speed + Jump Boost in Warped Forest",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 20 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Fire Res + Resistance in Basalt Deltas",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 21 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Speed II in Soul Valley",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 22 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Slow Falling in The End",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 23 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"★ ",color:"gold"},{text:"Perk: ",color:"#FFD54F"},{text:"Speed + Jump Boost in Windswept Hills",color:"white"},{text:" ★",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.biome_id matches 24 run function evercraft:util/notify/emit
