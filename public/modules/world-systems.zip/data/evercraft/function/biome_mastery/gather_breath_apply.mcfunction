# === BIOME MASTERY — GATHER BREATH: APPLY (Wave E2 macro) ============================
# Run as @s, with storage evercraft:bm_temp {wb:<seconds>}. Issues the ONE computed
# water-breathing give (compliance C1 / R1: never 3 stacked calls — a single give of the
# summed duration is the correct 26.1 keep-stronger shape). amplifier 0, hide-particles true.
# Caller (gather_breath) only invokes this when wb>=1 AND the player is in water.
$effect give @s water_breathing $(wb) 0 true
