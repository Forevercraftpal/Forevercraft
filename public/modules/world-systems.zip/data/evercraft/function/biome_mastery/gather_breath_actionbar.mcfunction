# === BIOME MASTERY — GATHER BREATH: per-dive actionbar (Wave E2, lore L6) =============
# Run as @s on the first wet tick of a dive (edge-detected by the caller via ec.gth_was_wet,
# so it shows ONCE per dive, not every 5s). actionbar only, never chat (lore L6 / perf "b").
# Reads the stacked duration straight off the #wb_dur ec.temp fakeplayer the caller computed.
data modify storage evercraft:notify stage.c set value [{text:"≈ ",color:"aqua"},{text:"Deep Breath",color:"aqua"},{text:" — ",color:"gray"},{score:{name:"#wb_dur",objective:"ec.temp"},color:"aqua"},{text:"s underwater",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
