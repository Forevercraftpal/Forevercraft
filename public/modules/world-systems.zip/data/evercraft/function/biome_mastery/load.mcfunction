# Biome Mastery System — Init
# Per-biome time tracking scoreboards (seconds spent)
scoreboard objectives add ec.bm0 dummy "BM Plains"
scoreboard objectives add ec.bm1 dummy "BM Forest"
scoreboard objectives add ec.bm2 dummy "BM Flower Forest"
scoreboard objectives add ec.bm3 dummy "BM Dark Forest"
scoreboard objectives add ec.bm4 dummy "BM Taiga"
scoreboard objectives add ec.bm5 dummy "BM Mountain"
scoreboard objectives add ec.bm6 dummy "BM Jungle"
scoreboard objectives add ec.bm7 dummy "BM Desert"
scoreboard objectives add ec.bm8 dummy "BM Savanna"
scoreboard objectives add ec.bm9 dummy "BM Ocean"
scoreboard objectives add ec.bm10 dummy "BM River"
scoreboard objectives add ec.bm11 dummy "BM Swamp"
scoreboard objectives add ec.bm12 dummy "BM Mushroom"
scoreboard objectives add ec.bm13 dummy "BM Ice"
scoreboard objectives add ec.bm14 dummy "BM Badlands"
scoreboard objectives add ec.bm15 dummy "BM Lush Caves"
scoreboard objectives add ec.bm16 dummy "BM Dripstone"
scoreboard objectives add ec.bm17 dummy "BM Deep Dark"
scoreboard objectives add ec.bm18 dummy "BM Nether Wastes"
scoreboard objectives add ec.bm19 dummy "BM Crimson Forest"
scoreboard objectives add ec.bm20 dummy "BM Warped Forest"
scoreboard objectives add ec.bm21 dummy "BM Basalt Deltas"
scoreboard objectives add ec.bm22 dummy "BM Soul Valley"
scoreboard objectives add ec.bm23 dummy "BM The End"
scoreboard objectives add ec.bm24 dummy "BM Windswept"

# Biome Crates — persistent per-biome AFFINITY (harvest-only counter; time is read from ec.bm<id>).
# Sole writer = biome_crates/affinity/add. Declared in the same block as ec.bm so the family
# is minted up-front (declaring all 25 now is free, avoids a later load edit). See affinity/add.
scoreboard objectives add ec.baf0 dummy "Aff Plains"
scoreboard objectives add ec.baf1 dummy "Aff Forest"
scoreboard objectives add ec.baf2 dummy "Aff Flower Forest"
scoreboard objectives add ec.baf3 dummy "Aff Dark Forest"
scoreboard objectives add ec.baf4 dummy "Aff Taiga"
scoreboard objectives add ec.baf5 dummy "Aff Mountain"
scoreboard objectives add ec.baf6 dummy "Aff Jungle"
scoreboard objectives add ec.baf7 dummy "Aff Desert"
scoreboard objectives add ec.baf8 dummy "Aff Savanna"
scoreboard objectives add ec.baf9 dummy "Aff Ocean"
scoreboard objectives add ec.baf10 dummy "Aff River"
scoreboard objectives add ec.baf11 dummy "Aff Swamp"
scoreboard objectives add ec.baf12 dummy "Aff Mushroom"
scoreboard objectives add ec.baf13 dummy "Aff Ice"
scoreboard objectives add ec.baf14 dummy "Aff Badlands"
scoreboard objectives add ec.baf15 dummy "Aff Lush Caves"
scoreboard objectives add ec.baf16 dummy "Aff Dripstone"
scoreboard objectives add ec.baf17 dummy "Aff Deep Dark"
scoreboard objectives add ec.baf18 dummy "Aff Nether Wastes"
scoreboard objectives add ec.baf19 dummy "Aff Crimson Forest"
scoreboard objectives add ec.baf20 dummy "Aff Warped Forest"
scoreboard objectives add ec.baf21 dummy "Aff Basalt Deltas"
scoreboard objectives add ec.baf22 dummy "Aff Soul Valley"
scoreboard objectives add ec.baf23 dummy "Aff The End"
scoreboard objectives add ec.baf24 dummy "Aff Windswept"
scoreboard objectives add ec.baf_cd dummy "Biome Crate Drop CD (5s units)"

# Working scoreboards
scoreboard objectives add ec.bm_time dummy "Biome Time (current)"
scoreboard objectives add ec.bm_level dummy "Biome Mastery Level"
scoreboard objectives add ec.bm_prev dummy "Previous Biome ID"
scoreboard objectives add ec.biome_mastery trigger "Biome Mastery"
scoreboard players enable @a ec.biome_mastery

# Wave E2 — stacking underwater-breathing flags (single writer = biome_mastery/gather_breath):
#   ec.gth_deep_seen : 1 once the "The Deep Welcomes You" unlock toast has fired (fire-once).
#   ec.gth_was_wet   : edge-detect latch — 1 while the player is submerged (set on the first
#                      wet tick, cleared on leaving water) so the per-dive actionbar shows once
#                      per dive, not every 5s.
scoreboard objectives add ec.gth_deep_seen dummy "Gather Deep-Unlock Toast Seen (0/1)"
scoreboard objectives add ec.gth_was_wet dummy "Gather Underwater Edge Latch (0/1)"

# Constants
scoreboard players set #3600 ec.const 3600

# Initialize previous biome to -1 for all players (forces initial detection)
execute as @a run scoreboard players set @s ec.bm_prev -1

# Start self-scheduling tick
schedule function evercraft:biome_mastery/tick 1s
