# === BIOME MASTERY — HOME TURF: GATHER FAMILIARITY FACTOR (Wave C2) ====================
# Run as @s. Outputs the "Home Turf" familiarity factor (×100) from the player's CURRENT
# biome mastery (ec.bm_level, 0-5, maintained every 5s by biome_mastery/player_tick) into
# @s ec.gth_familiar. The CURVE lives HERE because Biome Mastery owns the bm_level curve
# (crossplay C2 — "the multiplier itself is a Biome-Mastery concept; gather/ only applies
# it"). gather/grant_xp CALLS this, then folds ec.gth_familiar into ec.gth_areamult.
#
#   familiar = 100 + ec.bm_level * 5     (L0 -> 100 ... L5 -> 125, i.e. ×1.00 ... ×1.25)
#
# THE CLAMP IS THE CURVE: because familiar <= 125, the combined areaMult × familiar can never
# exceed areaMult × 1.25 (the area's own ceiling +25%). That single ceiling on the familiarity
# factor IS the hard clamp EPIC §8 / crossplay C2 require — no extra clamp logic anywhere. The
# Dreamy ×2 (Wave D) stays a SEPARATE multiplicative factor applied AFTER, so it is unaffected.
#
# Pure grant-time read of an already-cached score — ZERO new tick/schedule cost (crossplay C2).
# RACE B3: @s-scoped output (ec.gth_familiar); no #...ec.temp parked across a call.

scoreboard players operation @s ec.gth_familiar = @s ec.bm_level
scoreboard players operation @s ec.gth_familiar *= #gth_familiar_per ec.var
scoreboard players operation @s ec.gth_familiar += #gth_c100 ec.var
