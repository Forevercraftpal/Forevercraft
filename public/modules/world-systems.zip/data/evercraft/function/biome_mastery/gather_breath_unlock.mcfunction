# === BIOME MASTERY — GATHER BREATH: one-time unlock toast (Wave E2, lore L6) ==========
# Run as @s the first time the stacked water-breathing duration (#wb_dur) crosses >=1.
# Celebratory "The Deep Welcomes You" announce (lore L6 SNBT verbatim) + sound. Sets the
# ec.gth_deep_seen latch so it never fires again. Fires even on land (an unlock announcement).
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"aqua"},{text:"The Deep Welcomes You",color:"aqua",bold:true},{text:" — you can now work beneath the waves. The water yields its breath to you for a while.",color:"gray"},{text:" ✦",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.1
scoreboard players set @s ec.gth_deep_seen 1
