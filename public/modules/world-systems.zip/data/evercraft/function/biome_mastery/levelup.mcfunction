# Biome Mastery — Level Up announcement and reward application
# @s = player, ec.bm_level = new level, ec.biome_id = current biome

# Get biome name for display (writes to evercraft:briefing biome_name)
function evercraft:briefing/get_biome_name

# Announce with biome name
function evercraft:biome_mastery/announce_levelup with storage evercraft:briefing

# Level-specific reward details
data modify storage evercraft:notify stage.c set value [{text:"Visitor",color:"white"},{text:" — You're getting familiar with this biome!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.bm_level matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Familiar",color:"aqua"},{text:" — +0.1 Dream Rate in this biome!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.bm_level matches 2 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Resident",color:"#4FC3F7"},{text:" — Patron aggro reduced here!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.bm_level matches 3 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Warden",color:"#AB47BC"},{text:" — +0.35 Dream Rate in this biome!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.bm_level matches 4 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Master",color:"gold",bold:true},{text:" — +0.5 Dream Rate! Biome title & perk unlocked!",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute if score @s ec.bm_level matches 5 run function evercraft:util/notify/emit
# Wave C2 (Home Turf) — one-time celebratory level-up toast (lore L3, LOCKED name "Home Turf",
# never "affinity"). Names the perk so the player learns gathering here is now easier. The
# per-harvest familiarity XP-mult + the success-roll shave fire SILENTLY thereafter (see note
# below) — this level-up line is the ONLY Home-Turf chat the player ever sees.
data modify storage evercraft:notify stage.c set value [{text:"✦ Home Turf",color:"gold",bold:true},{text:" — you know this land. Gathering here comes easier now.",color:"gray"},{text:" ✦",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.bm_level matches 5 run function evercraft:util/notify/emit
# NOTE (deliberate deviation from lore L3's per-harvest "[Home Turf]" example): NO per-harvest
# tell. The familiarity mult fires on EVERY harvest in ANY biome the player has spent time in
# (bm_level >= 1), so a per-harvest line would spam the comfort loop relentlessly. The player
# sees the effect in their XP/codex; this level-up toast is the announce. Per-harvest = SILENT.

# Sound effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1.2
execute if score @s ec.bm_level matches 5 if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1

# Apply dream rate modifier
function evercraft:biome_mastery/apply_dr

# Apply title at level 5 (announced to all players)
execute if score @s ec.bm_level matches 5 run function evercraft:biome_mastery/apply_title

# Announce and apply biome perk at level 5
execute if score @s ec.bm_level matches 5 run function evercraft:biome_mastery/announce_perk
execute if score @s ec.bm_level matches 5 run function evercraft:biome_mastery/apply_perk
