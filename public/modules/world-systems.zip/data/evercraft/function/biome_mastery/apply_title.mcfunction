# Biome Mastery — Apply biome-specific title at Level 5 (Master)
# @s = player, ec.biome_id = mastered biome
# Announced to all players on the server (§5b: actor-naming broadcast → direct render)
execute if score @s ec.biome_id matches 0 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Meadow Keeper",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 0 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 0 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 1 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Forestborn",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 1 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 1 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 2 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Bloomkeeper",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 2 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 2 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 3 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Shadowstrider",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 3 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 3 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 4 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Frostpine Warden",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 4 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 4 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 5 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Peakwalker",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 5 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 5 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 6 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Canopy Runner",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 6 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 6 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 7 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Dune Sovereign",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 7 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 7 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 8 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Sunwatcher",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 8 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 8 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 9 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Tidecaller",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 9 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 9 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 10 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Riverguard",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 10 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 10 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 11 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Bogstrider",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 11 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 11 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 12 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Sporekeeper",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 12 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 12 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 13 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Frostbound",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 13 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 13 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 14 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Mesa Walker",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 14 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 14 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 15 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Verdant Dweller",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 15 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 15 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 16 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Stalactite Sage",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 16 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 16 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 17 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Void Warden",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 17 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 17 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 18 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Ashborn",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 18 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 18 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 19 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Crimson Stalker",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 19 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 19 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 20 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Warped Walker",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 20 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 20 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 21 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Deltastrider",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 21 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 21 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 22 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Soulbound",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 22 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 22 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 23 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Ender Warden",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 23 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 23 run execute as @a run function evercraft:util/notify/emit_keep
execute if score @s ec.biome_id matches 24 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Stormchaser",color:"gold",bold:true}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.biome_id matches 24 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.biome_id matches 24 run execute as @a run function evercraft:util/notify/emit_keep
