# === PRISTINE BRUSH — GIVE N BACK (macro) ===
# Run as @s = the player. MACRO arg (storage evercraft:pb_temp): $(count) = how many pristine brushes
# to return to the inventory (the remainder of a split stack). Mirrors the recipe result's components
# EXACTLY so the given brushes stack with the rest: max_stack_size 16, NO durability (!max_damage),
# the pristine_brush tag, item name + lore. Component-removal (!minecraft:max_damage) in a give item
# arg is the same syntax the pack uses elsewhere (e.g. !minecraft:custom_name).
$give @s minecraft:brush[minecraft:max_stack_size=16,!minecraft:max_damage,minecraft:custom_data={pristine_brush:true},minecraft:item_name={text:"Pristine Brush",color:"#C2B280",italic:false},minecraft:lore=[{text:"Stacks while pristine — becomes a",color:"gray",italic:true},{text:"single working brush once you use it.",color:"gray",italic:true}]] $(count)
