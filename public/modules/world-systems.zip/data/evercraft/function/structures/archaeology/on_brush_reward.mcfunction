# === ARCHAEOLOGY -> TERRA WARP XP + 7% CHEST-NODE SPAWN (PLAN §9 / SPEC §10) ===
# Run as @s = the brushing player, positioned at the former suspicious-block location, from
# structures/archaeology/check_marker on brush COMPLETION. This is the Terra Warp <-> archaeology
# integration: brushing a sus block awards Terra Warp (Craft-Affinity class 4) XP and, on a flat 7%
# roll, additionally spawns a chest node near the player.
#
# ADDITIVE — this in NO way replaces or alters the existing archaeology structure barrel (spawn_crate,
# brush_chance-gated). The barrel and this reward are independent: both can fire on the same brush.
# Terra Warp XP fires on EVERY completed brush; the chest node is its own separate 7% roll (Joseph,
# 2026-06-03). Mirrors craft_affinity/on_till's register-setup idiom (caff_class + #delta + internal_grant).

# --- (a) Terra Warp (class 4) XP grant. #delta 15-30 per completed brush (a meaningful but uncapped-
#         per-event reward). #caff_node 1 routes it through the 50k/day NODE cap in internal_grant so
#         brush-grinding respects the same ceiling as gather nodes (Gatherer's Path). ---
scoreboard players set @s ec.caff_class 4
execute store result score #delta ec.temp run random value 15..30
scoreboard players set #caff_node ec.temp 1
function evercraft:craft_affinity/internal_grant

# Lifetime milestone counter: +1 on EVERY completed brush (this fn already fires once per
# completed brush from check_marker, run as @s = the brushing player).
scoreboard players add @s ec.arch_finds 1

# --- (b) FLAT 7% chance to spawn a chest node near the player (independent of the barrel roll). The
#         node is a plain (no-key) ctype unless the player happens to carry a key — chest_nodes/place
#         defaults keytype 0 (plain) when no caller stamps cn_temp.keytype, which is correct here: the
#         archaeology node is a bonus surprise, not key-biased. ---
execute if predicate evercraft:treasure/archaeology/brush_node_chance run function evercraft:chest_nodes/place

# --- (c) Pristine Brush conversion (Joseph 2026-06-05): if the player completed this brush while
#         holding a stackable Pristine Brush, split one off the stack + turn the held one into a normal
#         durability brush (the rest stay pristine in the inventory). See convert_pristine_brush. ---
execute if items entity @s weapon.mainhand minecraft:brush[minecraft:custom_data~{pristine_brush:true}] run function evercraft:structures/archaeology/convert_pristine_brush
