# === PRISTINE BRUSH — CONVERT ON USE (Joseph 2026-06-05) ===
# Run as @s = the brushing player, from on_brush_reward, ONLY when the mainhand holds a Pristine Brush
# (stackable, no durability). A Pristine Brush stacks (16) so it packs compactly into a bundle; the
# moment you brush a block with it, ONE splits off the stack and becomes a NORMAL vanilla durability
# brush in your hand (which then wears + breaks like always), while the rest of the stack stays pristine
# in your inventory. So: carry a compact stack of spares, each becomes a single working brush as used.
#
# (The block that triggered this was brushed AS a pristine brush — i.e. the first stroke of each fresh
# brush is "free" of wear; thereafter it's an ordinary durability brush.)

# How many pristine brushes are in the held stack right now.
execute store result score #pb_count ec.temp run data get entity @s SelectedItem.count

# Replace the held slot with a SINGLE fresh vanilla durability brush (default max_damage, max_stack 1 —
# it now wears down + can't stack, exactly the "once damaged it won't stack" behaviour).
item replace entity @s weapon.mainhand with minecraft:brush 1

# Hand the REMAINDER of the stack (count - 1) back to the inventory, still pristine + stackable.
scoreboard players operation #pb_give ec.temp = #pb_count ec.temp
scoreboard players remove #pb_give ec.temp 1
execute if score #pb_give ec.temp matches 1.. store result storage evercraft:pb_temp count int 1 run scoreboard players get #pb_give ec.temp
execute if score #pb_give ec.temp matches 1.. run function evercraft:structures/archaeology/give_pristine with storage evercraft:pb_temp
