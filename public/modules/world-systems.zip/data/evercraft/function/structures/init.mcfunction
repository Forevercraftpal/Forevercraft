# Chest Filler System - Initialize
# Per-player loot system - each player gets their own unique loot from structure chests
# Tiers: Common, Uncommon, Rare, Ornate, Exquisite

# Scoreboards for position tracking
scoreboard objectives add cf.pos_x dummy
scoreboard objectives add cf.pos_y dummy
scoreboard objectives add cf.pos_z dummy
scoreboard objectives add cf.tier dummy
scoreboard objectives add cf.struct_id dummy
scoreboard objectives add cf.temp dummy
scoreboard objectives add cf.bonus_roll dummy
# First-crate grace: 1 once a player has spent their free above-ground first crate (Joseph 2026-06-04).
# Reset to 0 on Pioneer death (admin/strip_player_zero) so each rebirth gets a fresh free crate.
scoreboard objectives add ec.first_crate_used dummy "First Crate Used"
# Discovery-cap counter — crates ACTUALLY spawned (incremented only in storage/mark_looted, post-spawn).
# DEDICATED so check_crate_cap no longer reads adv.stat_struct, which is overloaded as the Explorer
# tree's exploration stat (grant_tree_credit bumps it from lore/raids/dungeons/quests) — that made the
# "limit of discovery" climb from non-crate activity and lock players out. (Joseph 2026-06-05.)
scoreboard objectives add ec.struct_crates dummy "Structure Crates Opened"

# Timer for container cleanup
scoreboard objectives add cf.container_life dummy

# Track if chest has LootTable NBT (generated structure chest)
scoreboard objectives add cf.has_loottable dummy

# Mark as initialized
scoreboard players set chest_filler cf.init 1
