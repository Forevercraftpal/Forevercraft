# Mark this position as looted for the current player
# Spawn an invisible marker at the chest position storing the player's UUID
# Includes refresh_timer (total duration) and looted_at (game time when looted) for time-based refresh
# Run as the player (position stored in cf.pos_x/y/z)

# Create marker at chest position with default 50 in-game day duration (3,600,000 ticks @ 72000/day)
summon marker ~ ~ ~ {Tags:["cf.looted_marker","cf.new_marker","smithed.entity"],data:{refresh_timer:3600000,looted_at:0L}}
execute store result entity @e[type=marker,tag=cf.new_marker,limit=1] Pos[0] double 1 run scoreboard players get @s cf.pos_x
execute store result entity @e[type=marker,tag=cf.new_marker,limit=1] Pos[1] double 1 run scoreboard players get @s cf.pos_y
execute store result entity @e[type=marker,tag=cf.new_marker,limit=1] Pos[2] double 1 run scoreboard players get @s cf.pos_z

# Store player UUID and structure ID in marker for refresh system
# Copy from @s (the looting player) — NOT @p which would resolve relative to the marker's position
data modify entity @e[type=marker,tag=cf.new_marker,limit=1] data.player_uuid set from entity @s UUID
execute store result entity @e[type=marker,tag=cf.new_marker,limit=1] data.struct_id int 1 run scoreboard players get @s cf.struct_id

# Store current game time so we can compute elapsed time later (works even in unloaded chunks)
execute store result entity @e[type=marker,tag=cf.new_marker,limit=1] data.looted_at long 1 run time query gametime

# Apply Explorer reduction: level * 2% off the refresh timer (max 50% at level 25)
execute if score @s adv.explorer matches 1.. run function evercraft:advantage/explorer/reduce_cooldown

tag @e[type=marker,tag=cf.new_marker] remove cf.new_marker

# First-find bonus (check BEFORE track_struct_type sets the flag)
function evercraft:structures/storage/first_find_check

# Track unique structure types for Wanderer's Dream Map
function evercraft:structures/storage/track_struct_type

# Increment advantage stat counter for Explorer tree.
# NOT for refreshed re-loots: those skip the crate cap (check_looted_then_spawn
# sets #cf_is_refresh=1) and the location was already counted on first loot —
# re-counting would push the total past the Dream-Rate cap and let players farm
# Explorer progress by re-looting one refreshing chest.
execute unless score #cf_is_refresh cf.temp matches 1 run scoreboard players add @s adv.stat_struct 1
# Dedicated discovery-cap counter (Joseph 2026-06-05): crates ACTUALLY spawned, crate-only.
# check_crate_cap reads THIS (not adv.stat_struct, which the Explorer tree's grant_tree_credit also
# inflates) so the "limit of discovery" can never climb from non-crate activity. Same post-spawn,
# same non-refresh gate as the Explorer stat above. Crates still count toward Explorer XP via stat_struct.
execute unless score #cf_is_refresh cf.temp matches 1 run scoreboard players add @s ec.struct_crates 1

# Spirit progression: Ocean Structures explored (Ellegaard Trident objective). Per-INSTANCE
# count — each newly-looted ocean structure container (Ocean Monument=8, Shipwreck=11,
# Ocean Ruin=12) tallies once. Rides the same non-refresh gate as the Explorer stat above, so
# re-looting a refreshed chest never re-counts. (True per-instance, not per-type: the objective
# needs up to 20, but only 3 ocean structure TYPES exist — per-type dedup would cap at 3.)
execute unless score #cf_is_refresh cf.temp matches 1 if score @s cf.struct_id matches 8 run scoreboard players add @s ec.sp_ocean_explore 1
execute unless score #cf_is_refresh cf.temp matches 1 if score @s cf.struct_id matches 11 run scoreboard players add @s ec.sp_ocean_explore 1
execute unless score #cf_is_refresh cf.temp matches 1 if score @s cf.struct_id matches 12 run scoreboard players add @s ec.sp_ocean_explore 1
