# Run as a cf.looted_marker. Kills self if it belongs to the resetting player.
# Caller (structures/storage/reset_player) has already loaded the player's UUID
# into #player_uuid0..3 cf.temp.
execute store result score #marker_uuid0 cf.temp run data get entity @s data.player_uuid[0]
execute store result score #marker_uuid1 cf.temp run data get entity @s data.player_uuid[1]
execute store result score #marker_uuid2 cf.temp run data get entity @s data.player_uuid[2]
execute store result score #marker_uuid3 cf.temp run data get entity @s data.player_uuid[3]
execute if score #marker_uuid0 cf.temp = #player_uuid0 cf.temp if score #marker_uuid1 cf.temp = #player_uuid1 cf.temp if score #marker_uuid2 cf.temp = #player_uuid2 cf.temp if score #marker_uuid3 cf.temp = #player_uuid3 cf.temp run kill @s
