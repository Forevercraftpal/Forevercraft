# Structure First-Find Bonus (macro)
# Called with {name:"Structure Name",color:"tier_color",xp:"amount"}

# Action-bar notification
$data modify storage evercraft:notify stage.c set value [{text:"🏛 ",color:"$(color)"},{text:"FIRST DISCOVERY: ",color:"$(color)",bold:true},{text:"$(name)",color:"$(color)"},{text:" — +$(xp) XP bonus!",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit

# Grant XP
$experience add @s $(xp) points

# Sounds
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.2
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_cluster.break master @s ~ ~ ~ 0.6 0.8

# Achievement tracking
scoreboard players add @s ach.structures_found 1
# Wayfarer Track: cross-source bonus XP (milestone credit on top of dr.points)
scoreboard players add @s ec.wf_bonus 20
