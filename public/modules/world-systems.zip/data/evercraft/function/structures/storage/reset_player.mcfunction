# Usage: /execute as <player> run function evercraft:structures/storage/reset_player
# Reset ONE player's structure-crate "chest list" — wipes only the looted markers
# that belong to @s (other players' markers at the same chests are untouched), and
# zeroes their Explorer crate counter. Refresh markers are preserved, mirroring
# structures/storage/reset_all (so any already-ready crates stay openable).
# @s = the player whose list is being wiped.

# Load @s UUID into scores for per-marker comparison.
execute store result score #player_uuid0 cf.temp run data get entity @s UUID[0]
execute store result score #player_uuid1 cf.temp run data get entity @s UUID[1]
execute store result score #player_uuid2 cf.temp run data get entity @s UUID[2]
execute store result score #player_uuid3 cf.temp run data get entity @s UUID[3]

# Kill the looted markers stamped with this player's UUID.
execute as @e[type=marker,tag=cf.looted_marker] run function evercraft:structures/storage/reset_player_marker

# Reset this player's structure crate stat counter (Explorer tree).
scoreboard players set @s adv.stat_struct 0
# Reset the dedicated discovery-cap counter too (the one check_crate_cap actually reads since 2026-06-05).
scoreboard players set @s ec.struct_crates 0
