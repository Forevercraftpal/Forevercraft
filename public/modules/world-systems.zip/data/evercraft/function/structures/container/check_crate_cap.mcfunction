# Check if player has reached their structure crate limit based on Dream Rate
# Limit = (dr_level + floor(dr_level / 5) * 5) * 2
# DR 1→2, DR 5→20, DR 10→40, DR 15→60, DR 50+→unlimited

# Get integer DR level (floor of luck attribute)
execute store result score #dr_level cf.temp run attribute @s luck get 1

# DR 50+ = unlimited crates (no cap)
execute if score #dr_level cf.temp matches 50.. run return 0

# Calculate bonus: floor(dr_level / 5) * 5
scoreboard players set #5 cf.temp 5
scoreboard players operation #crate_limit cf.temp = #dr_level cf.temp
scoreboard players operation #crate_limit cf.temp /= #5 cf.temp
scoreboard players operation #crate_limit cf.temp *= #5 cf.temp

# Total limit = (base + bonus) * 2
scoreboard players operation #crate_limit cf.temp += #dr_level cf.temp
scoreboard players set #2 cf.temp 2
scoreboard players operation #crate_limit cf.temp *= #2 cf.temp

# If player has opened >= limit, set placed flag to block all position attempts.
# Reads ec.struct_crates (crates ACTUALLY spawned, crate-only) — NOT adv.stat_struct, which is the
# Explorer tree's exploration stat that grant_tree_credit inflates from lore/raids/dungeons/quests.
# (Joseph 2026-06-05: the cap was climbing from non-crate activity / "counting but not spawning".)
execute if score @s ec.struct_crates >= #crate_limit cf.temp run scoreboard players set #cf_placed cf.temp 1
data modify storage evercraft:notify stage.c set value [{text:"Your mind has reached its limit of discovery... ",color:"gray",italic:true},{text:"(",color:"red"},{score:{name:"@s",objective:"ec.struct_crates"},color:"red"},{text:"/",color:"red"},{score:{name:"#crate_limit",objective:"cf.temp"},color:"red"},{text:" opened)",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #cf_placed cf.temp matches 1 run function evercraft:util/notify/emit
execute if score #cf_placed cf.temp matches 1 at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 0.5 0.5
