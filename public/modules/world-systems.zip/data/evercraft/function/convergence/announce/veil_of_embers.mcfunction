# Harmonic Convergence: Veil of Embers
# Autumn + Waning Gibbous + Abyssal Tremor + DR >= 20.0

data modify storage evercraft:notify stage.c set value [{text:"✦ HARMONIC CONVERGENCE ✦",color:"#FF6633",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"— Veil of Embers —",color:"#FF9966"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Autumnal fire meets the fury of the deep...",color:"#CC6633",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The earth trembles with hidden power.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"#FF6633"},{text:"All gathering yields doubled",color:"aqua"},{text:" ✧",color:"#FF6633"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"#FF6633"},{text:"Boss drops enhanced",color:"aqua"},{text:" ✧",color:"#FF6633"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"#FF6633"},{text:"Convergence lore now discoverable",color:"light_purple"},{text:" ✧",color:"#FF6633"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"#FF6633"},{text:"Dream Rate +2.0",color:"green"},{text:" ✧",color:"#FF6633"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 10 minutes",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Deep rumbling + fire ambiance
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.end_portal.spawn master @s ~ ~ ~ 0.4 0.8
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.2 1.5
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.lava.ambient master @s ~ ~ ~ 0.6 0.8

# Title
title @a times 10 100 30
title @a title [{text:"✦ Veil of Embers ✦",color:"#FF6633"}]
title @a subtitle [{text:"Harmonic Convergence",color:"#FF9966",italic:true}]
