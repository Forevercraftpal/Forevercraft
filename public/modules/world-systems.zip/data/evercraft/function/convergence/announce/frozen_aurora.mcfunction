# Harmonic Convergence: Frozen Aurora
# Winter + New Moon + Aurora Bloom + DR >= 15.0

data modify storage evercraft:notify stage.c set value [{text:"✦ HARMONIC CONVERGENCE ✦",color:"#99FFCC",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"— Frozen Aurora —",color:"#CCFFEE"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Northern lights pierce the darkest winter night...",color:"#88DDAA",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The aurora dances where no moon dares shine.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"#99FFCC"},{text:"All gathering yields doubled",color:"aqua"},{text:" ✧",color:"#99FFCC"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"#99FFCC"},{text:"Boss drops enhanced",color:"aqua"},{text:" ✧",color:"#99FFCC"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"#99FFCC"},{text:"Convergence lore now discoverable",color:"light_purple"},{text:" ✧",color:"#99FFCC"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"#99FFCC"},{text:"Dream Rate +2.0",color:"green"},{text:" ✧",color:"#99FFCC"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 10 minutes",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Icy crystalline sounds
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.end_portal.spawn master @s ~ ~ ~ 0.4 2.0
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1.0 1.8
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.glass.break master @s ~ ~ ~ 0.3 2.0

# Title
title @a times 10 100 30
title @a title [{text:"✦ Frozen Aurora ✦",color:"#99FFCC"}]
title @a subtitle [{text:"Harmonic Convergence",color:"#CCFFEE",italic:true}]
