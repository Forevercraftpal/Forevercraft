# Harmonic Convergence: Celestial Tide
# Summer + Full Moon + Starfall + DR >= 15.0

data modify storage evercraft:notify stage.c set value [{text:"✦ HARMONIC CONVERGENCE ✦",color:"#66CCFF",bold:true}]
scoreboard players set #ndur ec.temp 50
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"— Celestial Tide —",color:"#AADDFF"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The stars align over summer seas...",color:"#88CCEE",italic:true}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The heavens pour their light upon the world.",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"#66CCFF"},{text:"All gathering yields doubled",color:"aqua"},{text:" ✧",color:"#66CCFF"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"#66CCFF"},{text:"Boss drops enhanced",color:"aqua"},{text:" ✧",color:"#66CCFF"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"#66CCFF"},{text:"Convergence lore now discoverable",color:"light_purple"},{text:" ✧",color:"#66CCFF"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"#66CCFF"},{text:"Dream Rate +2.0",color:"green"},{text:" ✧",color:"#66CCFF"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Duration: 10 minutes",color:"gray"}]
scoreboard players set #ndur ec.temp 40
execute as @a run function evercraft:util/notify/emit

# Celestial sound cascade
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.end_portal.spawn master @s ~ ~ ~ 0.4 2.0
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1.0 0.5
execute as @a[scores={ec.fx_snd=1..}] at @s run playsound minecraft:entity.allay.ambient_with_item master @s ~ ~ ~ 0.8 1.2

# Title
title @a times 10 100 30
title @a title [{text:"✦ Celestial Tide ✦",color:"#66CCFF"}]
title @a subtitle [{text:"Harmonic Convergence",color:"#AADDFF",italic:true}]
