# Harmonic Convergence — Sync modifier + notify for joining player
# @s = joining player
attribute @s luck modifier remove evercraft:convergence
attribute @s luck modifier add evercraft:convergence 2.0 add_value
data modify storage evercraft:notify stage.c set value [{text:"A Harmonic Convergence is active! Gathering yields doubled, boss drops enhanced.",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.end_portal.spawn master @s ~ ~ ~ 0.3 1.5
