# Dream Rate Breakdown — Artifact Passive Modifiers
# Shows which artifact luck modifiers are active on the player

scoreboard players set #dr_any ec.temp 0

# --- Pebble of Dreams ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:pebble_of_dreams_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Pebble of Dreams",color:"green"},{text:"        +1.0",color:"gold"}]

# --- Aquamarine Ring ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:aquamarine_ring_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Aquamarine Ring",color:"blue"},{text:"             +1.0",color:"gold"}]

# --- Ruin Watch ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:ruin_watch_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Ruin Watch",color:"blue"},{text:"               +1.0",color:"gold"}]

# --- Miner's Lantern ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:miners_lantern_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Miner's Lantern",color:"yellow"},{text:"         +1.0",color:"gold"}]

# --- Merchant's Coin ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:merchants_coin_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Merchant's Coin",color:"yellow"},{text:"         +1.0",color:"gold"}]

# --- Angler's Pearl ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:anglers_pearl_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Angler's Pearl",color:"yellow"},{text:"          +1.0",color:"gold"}]

# --- Enchanted Monocle ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:enchanted_monocle_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Enchanted Monocle",color:"yellow"},{text:"       +1.0",color:"gold"}]

# --- Ring of Undying ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:ring_of_undying_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Ring of Undying",color:"aqua"},{text:"          +1.0",color:"gold"}]

# --- Claude's Eye ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:claudes_eye_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Claude's Eye",color:"aqua"},{text:"             +1.0",color:"gold"}]

# --- Sculk Heart ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:sculk_heart_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Sculk Heart",color:"aqua"},{text:"              +2.0",color:"gold"}]

# --- Trial Ring ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:trial_ring_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Trial Ring",color:"yellow"},{text:"               +2.0",color:"gold"}]

# --- Codex of Everything ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:codex_of_everything_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Codex of Everything",color:"light_purple"},{text:"     +3.0",color:"gold"}]

# --- Beacon of Ancients ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:beacon_of_ancients_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Beacon of Ancients",color:"light_purple"},{text:"      +3.0",color:"gold"}]

# --- Netherite Nexus ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:netherite_nexus_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Netherite Nexus",color:"light_purple"},{text:"          +4.0",color:"gold"}]

# --- Claude's Gift ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:claudes_gift_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Claude's Gift",color:"light_purple"},{text:"            +5.0",color:"gold"}]

# --- Wishing Shard (Family B new leaf — art-B) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:wishing_shard_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Wishing Shard",color:"green"},{text:"            +1.0",color:"gold"}]

# --- Dreamspun Crown of Ages (Family B new leaf — art-B; mythical DR head) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:dreamspun_crown_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Dreamspun Crown",color:"gold"},{text:"        +12.0",color:"gold"}]

# --- Geologist's Loupe (Family B new leaf — art-B; conditional DR, shows only while mining) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:geologist_loupe_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Geologist's Loupe",color:"green"},{text:"      +2.0",color:"gold"}]

# --- Conditional Cache-Eye (Family B new leaf — art-B; conditional DR, shows only while working) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:cache_eye_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Conditional Cache-Eye",color:"aqua"},{text:"  +2.0",color:"gold"}]

# --- Worldforge Ember (Family B new leaf — art-B; conditional DR, shows only after crafting) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:worldforge_ember_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Worldforge Ember",color:"gold"},{text:"        +3.0",color:"gold"}]

# --- Cornucopia Tide (Family J GRAND — cap-J; consolidated conditional DR, ONE line, while fishing or
#     in water). The grand folds the Riverpearl + Deepcurrent conditional DR into evercraft:cornucopia_
#     tide_luck (+5.0), condition-gated in player_tick (the Geologist's Loupe breakdown template — shows
#     only while the modifier is live). The loose Riverpearl/Deepcurrent lines below self-hide because
#     the player_tick m4 suppress-at-source removes their loose ids when the grand is held. ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:cornucopia_tide_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Cornucopia Tide",color:"#FFC04D"},{text:"        +5.0",color:"gold"}]

# --- Tidewright's Net (Family J fishing sub-cap — cap-J; consolidated conditional DR, ONE line, while
#     fishing or in water). evercraft:tidewright_luck (+5.0), condition-gated in player_tick. ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:tidewright_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Tidewright's Net",color:"#4FB6C8"},{text:"        +5.0",color:"gold"}]

# --- Riverpearl Charm (Family J — art-J; conditional DR, shows only while fishing) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:riverpearl_charm_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Riverpearl Charm",color:"aqua"},{text:"       +2.0",color:"gold"}]

# --- Deepcurrent Reliquary (Family J — art-J; conditional DR, shows only while in water) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:deepcurrent_reliquary_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Deepcurrent Reliquary",color:"aqua"},{text:"  +3.0",color:"gold"}]

# --- Demiurge's Spirit Artifact (Family K GRAND — art-K pre-wire; conditional DR, shows only while mining) ---
# The lattice's "DR consolidated: conditional +3.0 while mining (one line)" for Family K. Lives on the
# Demiurge's Spirit Artifact id (the future cap-K item), NOT on any loose K leaf (no K leaf carries DR). Shows
# only while the mining-activity window (ec.cf_actwin) is open, since the modifier is condition-gated in
# player_tick (the Geologist's Loupe breakdown template). Harmless until cap-K builds the capstone item.
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:demiurges_capstone_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Demiurge's Spirit Artifact",color:"dark_purple"},{text:"   +3.0",color:"gold"}]

# --- Resonant Locket (Family L — art-L; conditional DR, shows only while a craft-node is within 24b) ---
# L's ONLY luck modifier (B10). The conditional +1.0 node-proximity DR reports here under B's craft-luck
# line per the lattice; the modifier is gated on a nearby ec.cf_node_data marker in player_tick, so this
# line shows only while a craft-node is near. Harmless when no node is near (the modifier value is 0).
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:resonant_locket_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Resonant Locket",color:"dark_purple"},{text:"       +1.0",color:"gold"}]

# --- Ascendant Line / Heart of the Mountain (Family L tree — cap-L; CONSOLIDATED conditional node-DR) ---
# The B10 Resonant Locket node-proximity DR consolidates into ONE ascendant_locket_luck modifier on the
# Ascendant Line sub-cap + the grand Heart of the Mountain (re-granted in tinkering/heart/*_apply,
# condition-gated on a nearby ec.cf_node_data marker). When either node is held + a craft-node is within
# 24 b, this ONE line reports under B's craft-luck line per the lattice; the loose Resonant Locket line
# above prints nothing then (its loose modifier was m4-suppressed). Shows only while a node is near
# (modifier value 0 otherwise). The grand supersedes the sub-cap (same id, one modifier -> one line).
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:ascendant_locket_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Ascendant Line",color:"dark_purple"},{text:"        +1.0",color:"gold"}]

# ============================================================
# === Dreamer's Reliquary tree — CONSOLIDATED capstone lines (one line each, cap-B) ===
# ============================================================
# When a Reliquary-tree capstone is held, its apply (tinkering/reliquary/*_apply) has folded the
# member *_luck into ONE consolidated modifier — so exactly one of these reports per held node, and
# the member leaf lines above print nothing (their modifiers were stripped). The grand Reliquary
# supersedes its sub-nodes (its apply strips the sub-binding ids when held), so only ONE line shows
# even if a player re-acquired a sub-binding. (D1 full-power, UNCAPPED; the global DR ceiling rose
# to 100 in w5.) Order: grand first (it supersedes), then the sub-nodes, then the starter.

# --- Dreamer's Reliquary (Spirit Artifact, +24.0) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:dreamers_reliquary_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Dreamer's Reliquary",color:"#B695E0"},{text:"     +24.0",color:"gold"}]

# --- Astral Core (mythical sub-binding, +25.0) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:astral_core_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Astral Core",color:"light_purple"},{text:"             +25.0",color:"gold"}]

# --- Dream Lens (exquisite sub-binding, +7.0) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:dream_lens_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Dream Lens",color:"aqua"},{text:"               +7.0",color:"gold"}]

# --- Fortune Coffer (ornate sub-binding, up to +5.0; toggles can shrink it) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:fortune_coffer_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Fortune Coffer",color:"yellow"},{text:"           +5.0",color:"gold"}]

# --- Craft-Luck Sigil (conditional sub-binding, +7.0 — shows only while working) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:craft_luck_sigil_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Craft-Dream Sigil",color:"gold"},{text:"         +7.0",color:"gold"}]

# --- Lucky Charm (common starter sub-binding, +2.0) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:lucky_charm_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Dreamer's Charm",color:"green"},{text:"         +2.0",color:"gold"}]

# ============================================================
# === Dragonheart tree — CONSOLIDATED capstone lines (one line each, cap-M / Family M) ===
# ============================================================
# When a Dragonheart-tree node is held, its apply (tinkering/dragonheart/*_apply) has folded the member DR
# into ONE consolidated modifier — so exactly one of these reports per held node. MIXED-DR family (like
# Family A/B): each sub-cap carries partial DR; the grand carries the FULL union +21.0 (D1 full-power,
# UNCAPPED, no nerf fence). The grand Dragonheart supersedes its four sub-caps (its apply strips the sub-cap
# ids when held), and the final-form Wyrmscale Aegis supersedes the grand (its apply strips dragonheart_luck),
# so only ONE Dragonheart line shows even if a player re-acquired a lower node. Order: final-form first (it
# supersedes), then the grand, then the four sub-caps. The Family-M LEAVES carry NO loose *_luck (DR is
# realized only on fusion), so there are no loose leaf lines above to self-hide.

# --- Wyrmscale Aegis (final-form, +21.0 — the same union as the grand) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:wyrmscale_aegis_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Wyrmscale Aegis",color:"#7FE3FF"},{text:"         +21.0",color:"gold"}]

# --- Dragonheart (Spirit Artifact, +21.0 — the FULL union) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:dragonheart_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Dragonheart",color:"#9B59D0"},{text:"             +21.0",color:"gold"}]

# --- Wyrmheart Core (mythical sub-binding, +6.5) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:wyrmheart_core_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Wyrmheart Core",color:"#9B59D0"},{text:"          +6.5",color:"gold"}]

# --- Wyrmclaw Grips (exquisite sub-binding, +5.0) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:wyrmclaw_grips_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Wyrmclaw Grips",color:"#C0392B"},{text:"          +5.0",color:"gold"}]

# --- Wyrmwing Pinions (exquisite sub-binding, +5.0) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:wyrmwing_pinions_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Wyrmwing Pinions",color:"#5DADE2"},{text:"        +5.0",color:"gold"}]

# --- Wyrmscale Mantle (exquisite sub-binding, +4.5) ---
execute store success score #has ec.temp run attribute @s luck modifier value get evercraft:wyrmscale_mantle_luck 10
execute if score #has ec.temp matches 1 if score #dr_any ec.temp matches 0 run tellraw @s [{text:"  ◆ ",color:"dark_purple"},{text:"Artifacts:",color:"gray"}]
execute if score #has ec.temp matches 1 run scoreboard players set #dr_any ec.temp 1
execute if score #has ec.temp matches 1 run tellraw @s [{text:"    Wyrmscale Mantle",color:"#7D6FB0"},{text:"        +4.5",color:"gold"}]
