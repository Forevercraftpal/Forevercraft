# On Join — Compute dream rate, show unified briefing, initialize player systems
# @s = player, at @s context

# === Clear stale action-bar notification backlog (FIRST — before anything emits) ===
# The render queue is per-player in persistent world storage and the pump only runs for ONLINE
# players, so a backlog that didn't finish draining before logout freezes and replays on rejoin
# (most visible as a world-boss fight spamming every phase + the boss type). Drop it on join so
# only fresh, post-join notifications show. Slot/init scores persist; we only wipe the contents.
tag @s remove ab_q
scoreboard players set @s ec.abhold 0
scoreboard players set @s ec.abld 0
scoreboard players set @s ec.abfade 0
execute if score @s ec.abinit matches 1 store result storage evercraft:notify args.slot int 1 run scoreboard players get @s ec.abslot
execute if score @s ec.abinit matches 1 run function evercraft:util/notify/queue/clear_self with storage evercraft:notify args

# === Compute dream rate (scores used by briefing/show) ===
# Get total dream rate (scale 10 for decimal display)
execute store result score @s ec.temp run attribute @s luck get 10

# Calculate whole and decimal parts
# OPT: Removed redundant `set #10 ec.const 10` — already initialized in init.mcfunction
scoreboard players operation @s ec.var = @s ec.temp
scoreboard players operation @s ec.var /= #10 ec.const
scoreboard players operation #dec ec.temp = @s ec.temp
scoreboard players operation #dec ec.temp %= #10 ec.const

# Fix negative decimals: ensure decimal part is always positive for display
# e.g., -5 % 10 = -5 in Minecraft, but we want to show -0.5 not -0.-5
# OPT: Use ec.const instead of ec.var (avoids overwriting shared temp namespace; #-1 ec.const already set in init)
execute if score #dec ec.temp matches ..-1 run scoreboard players operation #dec ec.temp *= #-1 ec.const

# === Daily Login Gift ===
function evercraft:world/daily_gift

# WP6 generosity (2026-05-29): initialize the daily free-wish accumulator + the
# collection-milestone flag so `matches`-gated reads (fountain menu, achievement
# check) resolve deterministically for pre-existing players. `add 0` is a no-op if
# already set; it only seeds an unset score to 0.
scoreboard players add @s ec.free_pulls 0
scoreboard players add @s ec.coll_common 0

# Ability-FX channels default to Full (2). Self-compare seeds ONLY an unset score, so a
# player who deliberately chose Off/Reduced/Cracked in Settings keeps it across rejoin.
execute unless score @s ec.fx_vis = @s ec.fx_vis run scoreboard players set @s ec.fx_vis 2
execute unless score @s ec.fx_snd = @s ec.fx_snd run scoreboard players set @s ec.fx_snd 2

# === Calculate Craft Rate before briefing ===
function evercraft:craftforever/craft_rate/calculate

# === Show unified join briefing ===
function evercraft:briefing/show

playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 0.3 1.5

# === Re-show any unclaimed EARNED prestige offers (banked by a questline capstone) so they're
# never lost if the player missed the completion message. No-op unless a bank exists (2026-06-02). ===
function evercraft:advantage/prestige/show_claim_offers

# === Initialize player systems ===
function evercraft:advantage/init_player
function evercraft:advantage/effects/reapply_all

# Initialize RPG health bar (claim/reassign boss bar slot)
function evercraft:health_bar/join

# === ENABLE ALL TRIGGER SCOREBOARDS (OPT — moved from per-tick enable @a) ===
# Core triggers
scoreboard players enable @s ach.progress
scoreboard players enable @s ec.dreams
scoreboard players enable @s ec.dr_history
scoreboard players enable @s ec.craft_check
scoreboard players enable @s ec.moon
scoreboard players enable @s ec.loot_timer
scoreboard players enable @s ec.stats
scoreboard players enable @s ec.healthbar
# ec.codex trigger removed 2026-05-26 (v1 text-UI archive — see _council/2026-05-26-dead-code-codex/)
scoreboard players enable @s ec.codex_combine
scoreboard players enable @s ec.ncore
scoreboard players enable @s ec.codex_tp
scoreboard players enable @s ec.quest
scoreboard players enable @s ec.lore_add
scoreboard players enable @s ec.lore_map
scoreboard players enable @s ec.wake
scoreboard players enable @s ec.quest_track
scoreboard players enable @s ec.notify_lvl
scoreboard players add @s ec.nchan 0
scoreboard players enable @s ec.bm_quicksell
scoreboard players enable @s ec.biome_mastery
scoreboard players enable @s ec.profile
scoreboard players enable @s ec.recap
scoreboard players enable @s ec.journey_log
scoreboard players enable @s ec.duel
scoreboard players enable @s ec.pd
scoreboard players enable @s ec.h2h
scoreboard players enable @s ec.party
# wb.catalog enable REMOVED 2026-05-30 (AU12-PRESERVE.2 / no-user-triggers law).
# Catalog now reached via codex → Bestiary section → ◆ Boss Catalog ◆ button.
scoreboard players enable @s ec.tomb_accept
scoreboard players enable @s ec.tomb_deny
scoreboard players enable @s tx.dep_conf
scoreboard players enable @s ec.ge_event_tp
scoreboard players enable @s ec.diff_trigger
scoreboard players enable @s ec.sr_prompt
scoreboard players enable @s ec.newcomer_pick
scoreboard players enable @s ec.bulk_clm
scoreboard players enable @s bs.claim
scoreboard players enable @s ec.sp_meta
scoreboard players enable @s ec.sp_prog
scoreboard players enable @s ec.sp_trade
scoreboard players enable @s ec.bd_confirm
scoreboard players enable @s ec.auto_clm

# Story Mode triggers
scoreboard players enable @s sm.pick
scoreboard players enable @s sm.path_pick
scoreboard players enable @s sm.tip_show

# Friends list — collapse any leftover duplicate entries from earlier bug + resync ec.fr_count
function evercraft:friends/dedupe_self

# Apply expedition buff if active
execute if score #expedition_activity ec.var matches 1.. if score @s ec.guild_id matches 1.. run function evercraft:guild/expedition/apply_buff
# Trim: ensure player is on vex_allies team (moved from per-tick trim/tick — OPT)
execute if entity @s[team=] run team join vex_allies @s
# Trim triggers
scoreboard players enable @s update_trim_ability
scoreboard players enable @s wild_wolves
scoreboard players enable @s panda_genes
scoreboard players enable @s find_way
scoreboard players enable @s get_bundle
scoreboard players enable @s water_dash
scoreboard players enable @s summon_guardian

# Competition mid-join baseline snapshot (delta-tracked types)
# Mining (type 2) — RARITY-WEIGHTED rework (Wave 3a): snapshot the Stonestrike WEIGHTED ore
# total (#caff_mine_w from sum_mining_weighted), matching competition/start + track/mining.
execute if score #comp_active ec.var matches 2 run function evercraft:craft_affinity/sum_mining_weighted
execute if score #comp_active ec.var matches 2 run scoreboard players operation @s ec.comp_baseline = #caff_mine_w ec.temp
execute if score #comp_active ec.var matches 4 run scoreboard players operation @s ec.comp_baseline = @s ach.prospects_done
execute if score #comp_active ec.var matches 5 run scoreboard players operation @s ec.comp_baseline = @s ach.forages_done
# Node comps (Wave 3a, types 7..11): snapshot the joining player's node harvest count so a
# mid-join player scores only harvests from join onward (mirrors competition/start).
execute if score #comp_active ec.var matches 7..11 run function evercraft:competition/track/node_count
execute if score #comp_active ec.var matches 7..11 run scoreboard players operation @s ec.comp_baseline = #cnode_cur ec.temp
execute if score #comp_active ec.var matches 1..11 run bossbar set evercraft:competition players @a
execute if score #comp_active ec.var matches 1..11 run schedule function evercraft:bossbar/autodismiss/clear/competition 15s replace

# Co-op node event mid-join baseline (Wave 3b): snapshot the joining player's node count
# so they contribute only from join onward (mirrors coop_events/begin), and show them the
# collective bossbar. coev node_count writes #coev_cur for the active node #coev_node.
execute if score #coev_active ec.var matches 1 run function evercraft:coop_events/node_count
execute if score #coev_active ec.var matches 1 run scoreboard players operation @s ec.coev_base = #coev_cur ec.temp
execute if score #coev_active ec.var matches 1 run scoreboard players set @s ec.coev_ctrb 0
execute if score #coev_active ec.var matches 1 run bossbar set evercraft:coop_node players @a
execute if score #coev_active ec.var matches 1 run schedule function evercraft:bossbar/autodismiss/clear/coop_node 15s replace

# Node Festival mid-join (Wave 3c): snapshot today's featured-node baseline so a joiner can
# still earn the day's participation, and show them the festival banner. nfest node_count
# writes #nfest_cur for the featured node #nfest_node. (Does NOT reset ec.nfest_days — a player
# who participated earlier in the festival keeps their day count across a relog.)
execute if score #nfest_active ec.var matches 1 run function evercraft:node_festival/node_count
execute if score #nfest_active ec.var matches 1 run scoreboard players operation @s ec.nfest_base = #nfest_cur ec.temp
execute if score #nfest_active ec.var matches 1 run bossbar set evercraft:node_festival players @a
execute if score #nfest_active ec.var matches 1 run schedule function evercraft:bossbar/autodismiss/clear/node_festival 15s replace

# Reset dungeon daily floor counter if player missed a dawn while offline
execute unless score @s ec.last_day = #visual_day ec.var run scoreboard players set @s ec.dg_floors_today 0

# Wiring Audit B (2026-05-29) W10: reconnect reconcile (Joseph Q5 conditional macro-reconcile).
# If a player has pt.dg_active=1 / pt.ic_active=1 but their party's dungeon/castle ended while
# offline (per-party #X_floor.<pid> = 0), clear the stale per-player flag. Reversible default if
# Option A causes incidents — fall back to always-clear-on-join (AU-B-FOLLOWUP.4 reversal).
execute if score @s pt.dg_active matches 1 run function evercraft:_shared/derive_pid_from_party
execute if score @s pt.dg_active matches 1 run function evercraft:dreams/_reconcile_dg with storage evercraft:_shared cart
execute if score @s pt.ic_active matches 1 run function evercraft:_shared/derive_pid_from_party
execute if score @s pt.ic_active matches 1 run function evercraft:dreams/_reconcile_ic with storage evercraft:_shared cart

# Initialize Chrono Shard state
scoreboard players add @s ec.cs_active 0

# Initialize party scores (no score ≠ 0, so invite scan won't find them without this)
scoreboard players add @s ec.party_id 0
scoreboard players add @s ec.party_role 0

# Wiring Audit #16 W2.6: rejoin team color if returning to existing party
# Guards against all-offline color-pool reclamation race (party/load:51-57 frees the color
# if no online member holds it during /reload — relogger needs to re-bind to their team).
execute if score @s ec.party_id matches 1.. if score @s ec.pty_clr matches 1.. run function evercraft:party/color/rejoin

# Initialize difficulty score (no score ≠ 0)
scoreboard players add @s ec.difficulty 0

# Initialize codex tier (no score ≠ 0, needed for combine button visibility)
scoreboard players add @s ec.codex_tier 0

# OPT: Initialize night terrors scores (moved from 60s check that scanned all @a)
scoreboard players add @s ec.nt_active 0
scoreboard players add @s ec.nt_cd 0

# Initialize companion evolution + pet duel scores
scoreboard players add @s ec.ce_evolved 0
scoreboard players add @s ec.ce_evolved2 0
scoreboard players add @s ec.pd_active 0
scoreboard players add @s ec.pd_cd 0
scoreboard players add @s ec.pd_wins 0
scoreboard players add @s ec.pd_losses 0
scoreboard players add @s ec.pd_draws 0
scoreboard players add @s ec.pd_streak 0
scoreboard players add @s ec.pd_best_streak 0

# Guild Events: check for pending weekly rewards
function evercraft:guild/events/weekly/check_pending

# Guild Diplomacy: join mid-event if applicable
function evercraft:guild/diplomacy/event/on_join

# Enable diplomacy trigger
scoreboard players enable @s ec.gd_diplo

# === Friend System ===
# Enable friend triggers
scoreboard players enable @s ec.fr_invite
scoreboard players enable @s ec.fr_gift
scoreboard players enable @s ec.fr_marry
scoreboard players enable @s ec.fr_remove

# Initialize friend count (no score ≠ 0)
scoreboard players add @s ec.fr_count 0
scoreboard players add @s ec.fr_married 0

# Wiring Audit #32 W3 (race F3): reconcile ec.fr_married + ec.fr_count against u<self> storage.
# Fixes the offline-spouse stuck-state (divorced while offline → logs back in flagged married=1,
# permanently blocked from proposing) and same-tick mutual-accept count drift. Runs before the
# buff/check-queue hooks so they read reconciled flags.
function evercraft:friends/reconcile_on_join

# Catch up missed daily resets for gift streak evaluation
function evercraft:friends/gift/login_streak_catchup

# Deliver queued gifts from offline friends
function evercraft:friends/gift/check_queue

# Apply best friend / marriage proximity buffs
execute at @s run function evercraft:friends/buff/apply

# Track unique player for realm milestones (first-ever join only)
# Also show newcomer hint about crafting any iron tool to unlock the Codex
execute unless score @s ec.rm_joined matches 1 run tellraw @s ""
execute unless score @s ec.rm_joined matches 1 run tellraw @s [{text:"  ",color:"gray"},{text:"Craft any iron tool",color:"aqua",bold:true},{text:" to unlock ",color:"gray"},{text:"The Forevercraft Codex",color:"gold",bold:true},{text:" and begin your adventure!",color:"gray"}]
execute unless score @s ec.rm_joined matches 1 run tellraw @s ""
execute unless score @s ec.rm_joined matches 1 run scoreboard players add #rm_total_players ec.var 1
execute unless score @s ec.rm_joined matches 1 run scoreboard players set @s ec.rm_joined 1

# Reapply milestone DR bonus (in case milestones completed while offline)
execute if score #rm_dr_bonus ec.var matches 1.. run attribute @s luck modifier remove evercraft:milestone_dr_bonus
execute if score #rm_dr_bonus ec.var matches 1.. store result storage evercraft:milestones temp.dr_total double 0.1 run scoreboard players get #rm_dr_bonus ec.var
execute if score #rm_dr_bonus ec.var matches 1.. run function evercraft:milestones/complete/apply_dr_modifier with storage evercraft:milestones temp

# Reapply story DR bonus (Conv V +0.5 DR + branch-complete +0.25 DR per branch) (Audit #2 2026-05-28 F1)
# Re-applies the evercraft:story_dr_bonus luck modifier so it survives /reload + relog.
execute if score @s ec.dr_story matches 1.. run function evercraft:story/rewards/dr_story_apply

# Clear session-scoped tags
tag @s remove ec.guild_arrow_warned

# Lore "Ancient Insight" toast — reset the once-per-session flag + seed the lifetime counter so the
# all-crafts XP toast (lore/gather_path_boost) shows at most once per login, max 15 times ever.
scoreboard players set @s ec.lore_ins_seen 0
scoreboard players add @s ec.lore_ins_cnt 0

# Clear stale boss engagement tags (player may have been offline during boss cleanup/despawn)
tag @s remove wb.participant
tag @s remove wb.last_hit
tag @s remove wb.summoner
tag @s remove wb.natural_spawn
advancement revoke @s only evercraft:bosses/damage/dealt
scoreboard players set @s wb.range_warn 0

# === CONSOLIDATED FIRST-JOIN FLOW ===
# New players (no mode AND no difficulty): Story → Difficulty → Tutorial → Chronicle (chained)
execute unless score @s sm.mode matches 1..3 unless score @s ec.difficulty matches 1..3 run function evercraft:story/mode/choose
# Returning players who have difficulty but no story choice (edge case / migration)
execute if score @s ec.difficulty matches 1..3 unless score @s sm.mode matches 1..3 run function evercraft:story/mode/choose
# Story mode validation for active story players
execute if score @s sm.mode matches 1..2 run function evercraft:story/failsafe/validate_on_join

# === Harmonic Convergence: Sync modifier + notify if active ===
# OPT: 4 duplicate score checks → 1 gated function call
execute if score #conv_active ec.var matches 1 run function evercraft:convergence/sync_player

# OPT: Tag satchel owners for gated satchel tick (self-discovering — checks inventory once on join)
execute unless entity @s[tag=ec.satchel_owner] if items entity @s container.* *[custom_data~{satchel:true}] run tag @s add ec.satchel_owner
execute unless entity @s[tag=ec.satchel_owner] if items entity @s container.* *[custom_data~{hero_satchel:true}] run tag @s add ec.satchel_owner

# Migrate old stick-based Companion Catalogue to book-based version
function evercraft:companions/handler/menu_v2/migrate_item

# === SESSION SNAPSHOT (Plan 5) ===
# Capture baseline stats for session recap delta computation
function evercraft:stats/recap/snapshot

# === ENABLE PLAN 5 TRIGGERS ===
scoreboard players enable @s ec.profile
scoreboard players enable @s ec.recap
scoreboard players enable @s ec.journey_log

# === DREAM PEAK — one-time leak-correction migration (Wiring #40) ===
# dreams/peak/recompute_all only touches ONLINE players (as @a), so an OFFLINE player keeps the
# old leaky-denylist-inflated dr_peak until they happen to be online during an operator run. This
# self-corrects every player exactly ONCE, on their next join, then never again. Gated by the
# per-player ec.dr_peak_migr flag (mirrors the companions/migrate_id0 one-time-flag idiom, but
# per-player rather than global). recompute itself re-derives Dream Rank; peak/update below then
# resumes normal upward ratcheting.
execute unless score @s ec.dr_peak_migr matches 1 run function evercraft:dreams/peak/recompute
scoreboard players set @s ec.dr_peak_migr 1

# === DREAM RANK — Update peak DR and recalculate on join (Plan 2) ===
function evercraft:dreams/peak/update
function evercraft:dream_rank/calculate

# === HOUSING — Ghost-home reconcile on login (AU31-Q2) ===
# Drain the deferred-reset queue for this player (a non-player / offline-owner
# / admin break orphaned one of their homes while they were away) + tier-0
# self-heal (strip a leaked hs.in_zone / housing_dr left by an old ghost).
function evercraft:housing/login/reconcile

# === TUTORIAL — Retired 2026-05-28 (Council #15) ===
# Tutorial UI archived; Story Chapter 1 ("First Light") now teaches the iron-pick + DR/CR beats.
# Flow: Story → Difficulty → Chronicle. difficulty/choose:29 force-sets ec.tutorial_done=1
# so ch2/check:8's gate still resolves. See data/.archive/2026-05-28-dead-tutorial/TOMBSTONE.md.

# === MILESTONE SENTINEL PRIME (2026-06-03) — one-time silent backfill ===
# Grants the notif/<family>/<id>_<stage> sentinels for thresholds this player ALREADY crossed,
# WITHOUT announcing, so the 60s passive scanners stop re-announcing pre-migration progress as
# new "milestone complete" toasts. Self-gated on the per-player notif/primed advancement → runs
# exactly once per player; idempotent across /reload + relog. Never touches claim/* (claimability
# unaffected). New players (counters at 0) prime nothing. Must run before ec.joined is set so the
# next passive scan sees a fully-primed sentinel set.
# One-time cr-baseline migration BEFORE the prime so prime sees the corrected (de-polluted) counters.
function evercraft:advantage/migrate_cr_baseline
function evercraft:milestones/prime

# Joseph 2026-06-13 (#91): login-time respawn safety. Logging in next to an
# active world boss could result in an instant one-shot before the player's
# client even renders. Same hook as the post-respawn safety in tick.mcfunction:
# pushes any wb.boss/wb.minion within 32b out to 60+b and grants 5s Resistance V.
execute at @s run function evercraft:bosses/respawn_safety

# Mark as joined
tag @s add ec.joined
