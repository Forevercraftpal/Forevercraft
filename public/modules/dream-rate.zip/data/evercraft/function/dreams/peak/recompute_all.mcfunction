# Dream Rate Peak — Recompute ALL players (one-time admin migration)
# Run as: operator. Usage: /function evercraft:dreams/peak/recompute_all
# Clears leaked dr_peak inflation for every online player and re-derives their
# Dream Rank. Safe to run more than once (idempotent — recompute is an overwrite
# to the current stable DR, not an accumulate).

execute as @a run function evercraft:dreams/peak/recompute
tellraw @a [{text:"[Evercraft] ",color:"dark_gray"},{text:"Dream Rate peaks recomputed — Dream Rank corrected.",color:"gray"}]
