# Dream Rate Peak — Recompute (one-time correction)
# OVERWRITES ec.dr_peak with the player's CURRENT corrected stable DR, dropping
# any inflation the old leaky denylist baked into the high-water mark, then
# recalculates Dream Rank so the corrected value takes effect immediately.
# A downward rank change is silent (dream_rank/calculate only notifies on an
# increase). Normal play resumes ratcheting via peak/update afterward.
#
# This LOSES legit peak history (a player who has since unequipped DR gear will
# re-floor to their current loadout). That is the intended trade for clearing
# the leak. Run once, then let peak/update take over again.
# @s = player. Run via dreams/peak/recompute_all (operator) for all players.

# Compute current stable DR into @s ec.temp (shared with peak/update)
function evercraft:dreams/peak/_compute_stable

# Overwrite the peak (not max) — this is the whole point of the recompute
scoreboard players operation @s ec.dr_peak = @s ec.temp

# Re-derive Dream Rank now so the corrected peak is reflected without waiting
# for the 5s tick (and so any over-rank silently drops this instant)
function evercraft:dream_rank/calculate
