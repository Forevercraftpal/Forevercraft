# Dream Rate Peak — Update Stable DR
# Computes stable DR (excluding temporary sources) and ratchets ec.dr_peak UP.
# @s = player

# Compute current stable DR into @s ec.temp (shared with peak/recompute)
function evercraft:dreams/peak/_compute_stable

# === UPDATE PEAK ===
# Initialize if never set (add 0 is a no-op if already has score)
scoreboard players add @s ec.dr_peak 0

# Only update if current stable DR exceeds previous peak (never decreases here)
execute if score @s ec.temp > @s ec.dr_peak run scoreboard players operation @s ec.dr_peak = @s ec.temp

# Milestone rarity sync + one-time unlock celebrations (consumes the stable DR
# left in @s ec.temp by _compute_stable above — keep this call directly after it)
function evercraft:milestones/unlock/check
