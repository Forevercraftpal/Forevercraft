# Dream Rate Peak — Compute Stable DR (shared)
# Leaves the player's CURRENT stable Dream Rate (total luck minus every
# temporary modifier) in @s ec.temp (x10 scale). Does NOT touch ec.dr_peak —
# callers decide whether to ratchet (peak/update) or overwrite (peak/recompute).
# @s = player
#
# NOTE: the subtractions below are a DENYLIST of *temporary* luck modifiers. Any
# NEW temporary luck buff added elsewhere MUST be added here too, or it will
# permanently inflate ec.dr_peak (which only ratchets up in update) and silently
# rank players up. See dream_rank/calculate (dr_peak/10 feeds dr.points).

# Start with total DR (x10 scale)
execute store result score @s ec.temp run attribute @s luck get 10

# === SUBTRACT TEMPORARY SOURCES ===

# --- Effects ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_luck_potion_bonus 10
scoreboard players operation @s ec.temp -= #tmp ec.temp

# --- Environment ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_rain_fishing_luck 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_fullmoon_fishing_luck 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_morning_fishing_luck 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_noon_harvest_luck 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_night_mob_luck 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_newmoon_mob_luck 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_harvest_moon_luck 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get evercraft:housing_dr 10
scoreboard players operation @s ec.temp -= #tmp ec.temp

# --- Events ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_event_dream_surge 10
scoreboard players operation @s ec.temp -= #tmp ec.temp

# --- Calendar ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_cal_harvest 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_cal_prosperity 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_cal_derby 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_cal_rift 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_cal_blood 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_cal_meteor 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_cal_skyrift 10
scoreboard players operation @s ec.temp -= #tmp ec.temp

# --- World Events ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_we_starfall 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_we_dreaming 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_we_abyssal 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_we_aurora 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_we_aurora_biome 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_we_rift_echo 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_we_omen_bonus 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get evercraft:convergence 10
scoreboard players operation @s ec.temp -= #tmp ec.temp

# --- Party ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get evercraft:party_luck 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get evercraft:tidal_network 10
scoreboard players operation @s ec.temp -= #tmp ec.temp

# --- Social proximity (temporary — fires just by being near friends/spouse) ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get evercraft:best_friend_buff 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get evercraft:marriage_buff 10
scoreboard players operation @s ec.temp -= #tmp ec.temp

# --- Guild expedition (temporary buff while an expedition is active) ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get guild:expedition_buff 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get guild:expedition_fountain 10
scoreboard players operation @s ec.temp -= #tmp ec.temp

# --- Competition (temporary fishing-event luck) ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_comp_fishing 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_h2h_fishing 10
scoreboard players operation @s ec.temp -= #tmp ec.temp

# --- Set bonus (temporary — Hero chestplate grants DR only at night) ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get evercraft:hero_night_dr 10
scoreboard players operation @s ec.temp -= #tmp ec.temp

# --- Cooking buffs (temporary — timed feast luck, expire via cooking/buff/remove_*) ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get evercraft:well_fed 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get evercraft:fortune_meal 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get evercraft:spirit_meal 10
scoreboard players operation @s ec.temp -= #tmp ec.temp

# --- Held-item luck (temporary — re-evaluated live while holding the item) ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_enchant_dream_luck 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
execute store result score #tmp ec.temp run attribute @s luck modifier value get ec_rf_gilded 10
scoreboard players operation @s ec.temp -= #tmp ec.temp

# --- Inscription gilded PROXIMITY aura (temporary — positional; fades the moment you
#     leave a Gold Greed totem's 12-block radius). Only wild/guild gilded totems apply
#     this id now; the HOME gilded network uses evercraft:inscr_home_gg, which is
#     deliberately NOT subtracted here so it counts toward the owner's Dream Rank. ---
execute store result score #tmp ec.temp run attribute @s luck modifier value get evercraft:inscr_gold_greed 10
scoreboard players operation @s ec.temp -= #tmp ec.temp
