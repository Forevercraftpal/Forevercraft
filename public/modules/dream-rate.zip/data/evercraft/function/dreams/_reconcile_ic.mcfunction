# Wiring Audit B (2026-05-29) W10: Castle reconnect reconcile (per-party MACRO).
# Joseph Q5 / AU-B-FOLLOWUP.9: symmetric to _reconcile_dg.
# Called with storage cart for $(pid) when @s pt.ic_active matches 1.
# If THIS party's castle is no longer active (#ic_floor.<pid> = 0), clear @s pt.ic_active.

$execute unless score #ic_floor.$(pid) ec.var matches 1.. run scoreboard players set @s pt.ic_active 0
