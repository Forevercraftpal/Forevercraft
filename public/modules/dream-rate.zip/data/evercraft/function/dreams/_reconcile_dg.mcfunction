# Wiring Audit B (2026-05-29) W10: Dungeon reconnect reconcile (per-party MACRO).
# Joseph Q5 / AU-B-FOLLOWUP.9: conditional reconcile (Option A) on dreams/on_join.
# Called with storage cart for $(pid) when @s pt.dg_active matches 1.
# If THIS party's dungeon is no longer active (#dg_floor.<pid> = 0), clear @s pt.dg_active.

$execute unless score #dg_floor.$(pid) ec.var matches 1.. run scoreboard players set @s pt.dg_active 0
