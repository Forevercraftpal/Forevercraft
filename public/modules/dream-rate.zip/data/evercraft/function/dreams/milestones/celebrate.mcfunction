# Dream Rate Milestone Celebration (macro)
# Called with {title:"Name",dr:"X.0",color:"color"}

# Title
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
$title @s subtitle [{text:"Dream Rate reached ",color:"gray"},{text:"$(dr)",color:"$(color)",bold:true}]
$title @s title [{text:"✦ $(title) ✦",color:"$(color)",bold:true}]

# Sounds
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 0.8
playsound minecraft:block.amethyst_block.resonate master @s ~ ~ ~ 1 1.5
playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.5 1.8

# Firework celebration
summon firework_rocket ~ ~1 ~ {LifeTime:0,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"star",colors:[I;16777045],fade_colors:[I;11141290],has_trail:true,has_twinkle:true}],flight_duration:1}}}}

# Realm announcement
# §5b actor-named broadcast — render directly in actor's context so {selector:"@s"} resolves once.
# The static "DREAM MILESTONE" banner forerunner is dropped; the detail line carries the full info.
# (Wave 2, 2026-06-10: DR milestone brag — whoami-baked, protected, 30s TTL.)
function evercraft:util/notify/whoami
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"$(color)"},{text:""},{text:" has become a ",color:"gray"},{text:"$(title)",color:"$(color)",bold:true},{text:"! (DR $(dr))",color:"gray"},{text:" ✦",color:"$(color)"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
