# Dream Rank System — Load
# Plan 2: Master progression rank ? → G → F → E → D → C → B → A → S → SS → SSS
# Aggregates progress across all systems into a single rank

# === SCOREBOARDS ===
# ec.dream_rank already created in stats/load (0-7 rank tiers)
scoreboard objectives add dr.points dummy
scoreboard objectives add dr.calc dummy

# === RANK THRESHOLDS (on ec.const) ===
# Points needed per rank tier: ? → G → F → E → D → C → B → A → S → SS → SSS
# RETUNE 2026-06-10 (max-out math, _council/2026-06-10-codex-vault-dream-rank/):
# bounded sources ≈2k + Codex Vault ≈4.8k + hardcore-lifetime grind ≈18-25k ⇒ the old
# SSS 100,000 was ~4-5× beyond ANY reachable total ("an eternity" was literal). New
# ceiling: SS 8,000 (dedicated year+), SSS 20,000 (verified completionist-of-everything).
# Wayfarer Track node band 170-250 rescaled to match (companions/track/load).
scoreboard players set #rank_G ec.const 10
scoreboard players set #rank_F ec.const 30
scoreboard players set #rank_E ec.const 75
scoreboard players set #rank_D ec.const 150
scoreboard players set #rank_C ec.const 350
scoreboard players set #rank_B ec.const 600
scoreboard players set #rank_A ec.const 1000
scoreboard players set #rank_S ec.const 2500
scoreboard players set #rank_SS ec.const 8000
scoreboard players set #rank_SSS ec.const 20000

# === CONSTANTS (ensure all divisors used in calculate.mcfunction exist) ===
scoreboard players set #25 ec.const 25
scoreboard players set #50 ec.const 50
scoreboard players set #100 ec.const 100
scoreboard players set #500 ec.const 500
scoreboard players set #5000 ec.const 5000

# Schedule periodic recalculation (every 5 seconds)
schedule function evercraft:dream_rank/tick 5s replace
