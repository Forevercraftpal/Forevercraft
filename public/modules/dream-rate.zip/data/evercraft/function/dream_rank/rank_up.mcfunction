# Dream Rank — Rank Up Notification
# @s = player who just ranked up
# Ranks: 0=unranked, 1=G, 2=F, 3=E, 4=D, 5=C, 6=B, 7=A, 8=S, 9=SS, 10=SSS

# Sound
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0

# Multi-home: refresh unlocked home-slot count (slots 2/3/4/5 open at rank
# E/C/A/S = dream_rank 3/5/7/8). unlock_check is the sole writer of hs.slots
# and self-notifies on an increase. Fires once per rank gain (this function).
function evercraft:housing/slot/unlock_check

# === G ===
execute if score @s ec.dream_rank matches 1 run data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"dark_gray"},{text:"DREAM RANK UP!",bold:true,color:"gold"},{text:" \u2726\u2726\u2726",color:"dark_gray"}]
execute if score @s ec.dream_rank matches 1 run scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 1 run function evercraft:util/notify/emit_keep
execute if score @s ec.dream_rank matches 1 run data modify storage evercraft:notify stage.c set value [{text:"You have achieved Rank ",color:"gray"},{text:"G",color:"dark_gray",bold:true}]
execute if score @s ec.dream_rank matches 1 run scoreboard players set #ndur ec.temp 40
execute if score @s ec.dream_rank matches 1 run function evercraft:util/notify/emit

# === F ===
execute if score @s ec.dream_rank matches 2 run data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"gray"},{text:"DREAM RANK UP!",bold:true,color:"gold"},{text:" \u2726\u2726\u2726",color:"gray"}]
execute if score @s ec.dream_rank matches 2 run scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 2 run function evercraft:util/notify/emit_keep
execute if score @s ec.dream_rank matches 2 run data modify storage evercraft:notify stage.c set value [{text:"You have achieved Rank ",color:"gray"},{text:"F",color:"gray",bold:true}]
execute if score @s ec.dream_rank matches 2 run scoreboard players set #ndur ec.temp 40
execute if score @s ec.dream_rank matches 2 run function evercraft:util/notify/emit

# === E ===
execute if score @s ec.dream_rank matches 3 run data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"dark_green"},{text:"DREAM RANK UP!",bold:true,color:"gold"},{text:" \u2726\u2726\u2726",color:"dark_green"}]
execute if score @s ec.dream_rank matches 3 run scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 3 run function evercraft:util/notify/emit_keep
execute if score @s ec.dream_rank matches 3 run data modify storage evercraft:notify stage.c set value [{text:"You have achieved Rank ",color:"gray"},{text:"E",color:"dark_green",bold:true}]
execute if score @s ec.dream_rank matches 3 run scoreboard players set #ndur ec.temp 40
execute if score @s ec.dream_rank matches 3 run function evercraft:util/notify/emit

# === D ===
execute if score @s ec.dream_rank matches 4 run data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"white"},{text:"DREAM RANK UP!",bold:true,color:"gold"},{text:" \u2726\u2726\u2726",color:"white"}]
execute if score @s ec.dream_rank matches 4 run scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 4 run function evercraft:util/notify/emit_keep
execute if score @s ec.dream_rank matches 4 run data modify storage evercraft:notify stage.c set value [{text:"You have achieved Rank ",color:"gray"},{text:"D",color:"white",bold:true}]
execute if score @s ec.dream_rank matches 4 run scoreboard players set #ndur ec.temp 40
execute if score @s ec.dream_rank matches 4 run function evercraft:util/notify/emit

# === C ===
execute if score @s ec.dream_rank matches 5 run data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"green"},{text:"DREAM RANK UP!",bold:true,color:"gold"},{text:" \u2726\u2726\u2726",color:"green"}]
execute if score @s ec.dream_rank matches 5 run scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 5 run function evercraft:util/notify/emit_keep
execute if score @s ec.dream_rank matches 5 run data modify storage evercraft:notify stage.c set value [{text:"You have achieved Rank ",color:"gray"},{text:"C",color:"green",bold:true}]
execute if score @s ec.dream_rank matches 5 run scoreboard players set #ndur ec.temp 40
execute if score @s ec.dream_rank matches 5 run function evercraft:util/notify/emit

# === B ===
execute if score @s ec.dream_rank matches 6 run data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"aqua"},{text:"DREAM RANK UP!",bold:true,color:"gold"},{text:" \u2726\u2726\u2726",color:"aqua"}]
execute if score @s ec.dream_rank matches 6 run scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 6 run function evercraft:util/notify/emit_keep
execute if score @s ec.dream_rank matches 6 run data modify storage evercraft:notify stage.c set value [{text:"You have achieved Rank ",color:"gray"},{text:"B",color:"aqua",bold:true}]
execute if score @s ec.dream_rank matches 6 run scoreboard players set #ndur ec.temp 40
execute if score @s ec.dream_rank matches 6 run function evercraft:util/notify/emit

# === A ===
execute if score @s ec.dream_rank matches 7 run data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"gold"},{text:"DREAM RANK UP!",bold:true,color:"#FFD700"},{text:" \u2726\u2726\u2726",color:"gold"}]
execute if score @s ec.dream_rank matches 7 run scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 7 run function evercraft:util/notify/emit_keep
execute if score @s ec.dream_rank matches 7 run data modify storage evercraft:notify stage.c set value [{text:"You have achieved Rank ",color:"gray"},{text:"A",color:"gold",bold:true}]
execute if score @s ec.dream_rank matches 7 run scoreboard players set #ndur ec.temp 40
execute if score @s ec.dream_rank matches 7 run function evercraft:util/notify/emit

# === S (server broadcast) ===
execute if score @s ec.dream_rank matches 8 run data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"red"},{text:"DREAM RANK UP!",bold:true,color:"#FF0000"},{text:" \u2726\u2726\u2726",color:"red"}]
execute if score @s ec.dream_rank matches 8 run scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 8 run function evercraft:util/notify/emit_keep
execute if score @s ec.dream_rank matches 8 run data modify storage evercraft:notify stage.c set value [{text:"You have achieved Rank ",color:"gray"},{text:"S",color:"red",bold:true}]
execute if score @s ec.dream_rank matches 8 run scoreboard players set #ndur ec.temp 40
execute if score @s ec.dream_rank matches 8 run function evercraft:util/notify/emit
# \u00a75b: names the actor via {selector:@s}, direct render to all
execute if score @s ec.dream_rank matches 8 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"",color:"white",bold:true},{text:" has reached Dream Rank ",color:"gray"},{text:"S",color:"red",bold:true},{text:"! \u2726",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 8 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.dream_rank matches 8 run execute as @a run function evercraft:util/notify/emit_keep

# === SS (server broadcast) ===
execute if score @s ec.dream_rank matches 9 run data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"light_purple"},{text:"DREAM RANK UP!",bold:true,color:"#FF00FF"},{text:" \u2726\u2726\u2726",color:"light_purple"}]
execute if score @s ec.dream_rank matches 9 run scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 9 run function evercraft:util/notify/emit_keep
execute if score @s ec.dream_rank matches 9 run data modify storage evercraft:notify stage.c set value [{text:"You have achieved Rank ",color:"gray"},{text:"SS",color:"light_purple",bold:true}]
execute if score @s ec.dream_rank matches 9 run scoreboard players set #ndur ec.temp 40
execute if score @s ec.dream_rank matches 9 run function evercraft:util/notify/emit
# \u00a75b: names the actor via {selector:@s}, direct render to all
execute if score @s ec.dream_rank matches 9 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"gold"},{text:"",color:"white",bold:true},{text:" has reached Dream Rank ",color:"gray"},{text:"SS",color:"light_purple",bold:true},{text:"! \u2726",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 9 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.dream_rank matches 9 run execute as @a run function evercraft:util/notify/emit_keep

# === SSS (server broadcast + special) ===
execute if score @s ec.dream_rank matches 10 run data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"#FFD700"},{text:"DREAM RANK ASCENSION!",bold:true,color:"#FFD700"},{text:" \u2726\u2726\u2726",color:"#FFD700"}]
execute if score @s ec.dream_rank matches 10 run scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 10 run function evercraft:util/notify/emit_keep
execute if score @s ec.dream_rank matches 10 run data modify storage evercraft:notify stage.c set value [{text:"You have achieved the ultimate rank: ",color:"gray"},{text:"SSS",color:"#FFD700",bold:true}]
execute if score @s ec.dream_rank matches 10 run scoreboard players set #ndur ec.temp 40
execute if score @s ec.dream_rank matches 10 run function evercraft:util/notify/emit
execute if score @s ec.dream_rank matches 10 run data modify storage evercraft:notify stage.c set value [{text:"The Legend of Evercraft",color:"gold",italic:true}]
execute if score @s ec.dream_rank matches 10 run scoreboard players set #ndur ec.temp 40
execute if score @s ec.dream_rank matches 10 run function evercraft:util/notify/emit
# \u00a75b: names the actor via {selector:@s}, direct render to all (already symmetrically flanked)
execute if score @s ec.dream_rank matches 10 run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"\u2726\u2726\u2726 ",color:"gold"},{text:"",color:"white",bold:true},{text:" has ascended to Dream Rank ",color:"gray"},{text:"SSS",color:"#FFD700",bold:true},{text:"!!! \u2726\u2726\u2726",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if score @s ec.dream_rank matches 10 run execute as @a run scoreboard players set #nttl ec.temp 600
execute if score @s ec.dream_rank matches 10 run execute as @a run function evercraft:util/notify/emit_keep

# Story Mode: dream rank progression hook
execute if score @s sm.mode matches 1..2 run function evercraft:story/quest/check_progress

# Journey log entry
data modify storage evercraft:journey temp.event set value "Achieved a new Dream Rank"
function evercraft:stats/journey/record

# Guild Cards: dream rank now exceeds the claimed Adventurer card rank (sets ec.ag_eligible + one nudge)
function evercraft:guild_cards/check_adventurer

# The Awakening (Chronicles Wave C5, S9): ONE additive gated line — on a dream-rank
# gain, fire the one-time soft "[Begin the Adventure Chronicle →]" offer for an
# Adventurer/Both player who hasn't started the line and hasn't been offered yet.
# offer_prompt re-guards the chron_view lens (1 Adventurer / 3 Both, never 2 Crafter),
# latches ec.ac_offer (its sole writer), and routes the alert-class chime through
# notify key "ac_offer". The Adventurer Tier-2 row is the always-available fallback.
execute if score @s ec.ac_offer matches 0 if score @s ec.ac_active matches 0 run function evercraft:adventure/questline/offer_prompt
