# Dream Rank — Calculate
# Aggregates ALL progression sources into dr.points, then maps to rank tier
# Rates are intentionally low — SSS (20,000 pts, retune 2026-06-10) = a verified
# completionist-of-everything; derived from max-out math, reachable but a true long haul
# @s = player

# Reset point accumulator
scoreboard players set @s dr.points 0

# ═══════════════════════════════════════
# === COMBAT & DUNGEONS ===
# ═══════════════════════════════════════

# Mobs slain: 1 point per 50 kills
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s adv.stat_mobs
scoreboard players operation @s dr.calc /= #50 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Boss kills: 3 points each
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.boss_kills
scoreboard players operation @s dr.calc *= #3 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Raid clears: 5 points each
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.raids_done
scoreboard players operation @s dr.calc *= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Dungeons completed: 2 points each
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.dungeons_done
scoreboard players operation @s dr.calc *= #2 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Castle best floor: 1 point per floor. Was wired to the dead ec.castle_best
# (never written anywhere → always 0); repointed to ic.record, the real Infinite
# Castle high-water mark (max-op, gated on actual floor completion). 2026-06-04.
scoreboard players operation @s dr.points += @s ic.record

# Bounties completed: 1 point each
scoreboard players operation @s dr.points += @s ec.bounty_done

# Dodge count: 1 point per 100 dodges
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.dodge_count
scoreboard players operation @s dr.calc /= #100 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Combos triggered: 1 point per 50
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.combos_triggered
scoreboard players operation @s dr.calc /= #50 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Wiring Audit #16 W2.1: Rally Cry combo +2 temporary DR while timer ticks
# party/combos/rally_cry_apply:6 sets ec.pc_rally_dr=6000; tick_cooldowns:11 decrements
execute if score @s ec.pc_rally_dr matches 1.. run scoreboard players add @s dr.points 2

# Iluminación de Ne candle aura (Joseph 2026-06-15): +1 DR per candle on placed light furnishings within
# 64 blocks (one piece per kind). decor/candle/recompute re-sums ec.ilum_dr every 1s (0 when out of range).
execute if score @s ec.ilum_dr matches 1.. run scoreboard players operation @s dr.points += @s ec.ilum_dr

# Surge triggers: 1 point per 20
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.surge_triggers
scoreboard players operation @s dr.calc /= #20 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Patron kills: 1 point per 25
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.patron_kills
scoreboard players operation @s dr.calc /= #25 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Night terror kills: 1 point per 10
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.nt_kills
scoreboard players operation @s dr.calc /= #10 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Heist wins: 1 point per 5
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.heist_wins
scoreboard players operation @s dr.calc /= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Encounters done: 1 point per 10
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.encounters_done
scoreboard players operation @s dr.calc /= #10 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Spirit raid bosses killed: 10 points each (13 unique bosses, each 0/1)
scoreboard players set @s dr.calc 0
execute if score @s ec.sp_bk1 matches 1.. run scoreboard players add @s dr.calc 10
execute if score @s ec.sp_bk2 matches 1.. run scoreboard players add @s dr.calc 10
execute if score @s ec.sp_bk3 matches 1.. run scoreboard players add @s dr.calc 10
execute if score @s ec.sp_bk4 matches 1.. run scoreboard players add @s dr.calc 10
execute if score @s ec.sp_bk5 matches 1.. run scoreboard players add @s dr.calc 10
execute if score @s ec.sp_bk6 matches 1.. run scoreboard players add @s dr.calc 10
execute if score @s ec.sp_bk7 matches 1.. run scoreboard players add @s dr.calc 10
execute if score @s ec.sp_bk8 matches 1.. run scoreboard players add @s dr.calc 10
execute if score @s ec.sp_bk9 matches 1.. run scoreboard players add @s dr.calc 10
execute if score @s ec.sp_bk10 matches 1.. run scoreboard players add @s dr.calc 10
execute if score @s ec.sp_bk11 matches 1.. run scoreboard players add @s dr.calc 10
execute if score @s ec.sp_bk12 matches 1.. run scoreboard players add @s dr.calc 10
execute if score @s ec.sp_bk13 matches 1.. run scoreboard players add @s dr.calc 10
scoreboard players operation @s dr.points += @s dr.calc

# ═══════════════════════════════════════
# === PROGRESSION & ADVANCEMENT ===
# ═══════════════════════════════════════

# Dream Rate peak: 1 point per 5.0 DR (peak x10, so /50). Weight reduced from
# /10 → /50 (2026-06-04) so equipped gear-luck no longer dominates Dream Rank;
# it's now a modest contributor on par with the other ~49 inputs.
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.dr_peak
scoreboard players operation @s dr.calc /= #50 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Advantage tree levels: 1 point per level
scoreboard players operation @s dr.points += @s ach.total_levels

# Achievements: 1 point per 10
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.total
scoreboard players operation @s dr.calc /= #10 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Quests done: 1 point each
scoreboard players operation @s dr.points += @s ach.quests_done

# Artifacts found: 1 point per 5
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.artifacts_ever
scoreboard players operation @s dr.calc /= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Codex Vault — enshrined artifacts (Codex Vault, 2026-06-10): LIVE tier-weighted points
# (1/2/4/6/10/15 c→m), sole writer codex_vault deposit/withdraw. Full 620-vault ≈ 4,792.
# Withdrawing an artifact drops its points here at the next recalc — recompute model,
# inherently farm-proof. This is also the codex→Wayfarer's-Track feed (wf_xp = dr.points×10).
scoreboard players operation @s dr.points += @s ec.cdxv_pts

# Armor sets equipped: 2 points each
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.sets_equipped
scoreboard players operation @s dr.calc *= #2 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Spirit tier: 5 points per tier
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.sp_tier
scoreboard players operation @s dr.calc *= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Spirit tool tier: 3 points per tier
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.st_tier
scoreboard players operation @s dr.calc *= #3 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Prestige total (sum all 6 categories): 3 points per prestige
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc += @s ach.prestige_combat
scoreboard players operation @s dr.calc += @s ach.prestige_gathering
scoreboard players operation @s dr.calc += @s ach.prestige_companions
scoreboard players operation @s dr.calc += @s ach.prestige_exploration
scoreboard players operation @s dr.calc += @s ach.prestige_collection
scoreboard players operation @s dr.calc += @s ach.prestige_growth
scoreboard players operation @s dr.calc *= #3 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# ═══════════════════════════════════════
# === GATHERING & CRAFTING ===
# ═══════════════════════════════════════

# Blocks mined: 1 point per 500
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.blocks_mined
scoreboard players operation @s dr.calc /= #500 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Crops harvested: 1 point per 100
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.crops_harvested
scoreboard players operation @s dr.calc /= #100 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Fish caught: 1 point per 25
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.fish_caught
scoreboard players operation @s dr.calc /= #25 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Fishing treasures: 1 point per 5
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.fish_treasure
scoreboard players operation @s dr.calc /= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Meals cooked: 1 point per 20
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.meals_cooked
scoreboard players operation @s dr.calc /= #20 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Enchantments: 1 point per 25
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.enchant_count
scoreboard players operation @s dr.calc /= #25 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Brews: 1 point per 25
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.brew_count
scoreboard players operation @s dr.calc /= #25 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Recipes learned: 1 point per 5 (repointed 2026-06-13: ach.recipes_learned was a DEAD counter →
# ec.recipes_learned_total, the live cooking/forging/alchemy recipe-discovery counter).
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.recipes_learned_total
scoreboard players operation @s dr.calc /= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Craftforever rank: 3 points per rank
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.cf_rank
scoreboard players operation @s dr.calc *= #3 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Nodes mined: 1 point per 20. FIX 2026-06-10: was reading ec.cf_node_mined, which is a
# TRANSIENT BIOME-ID routing key (nodes/start_mine stores data.biome_id into it — same
# bug class as profile-card F6, AU#22). Real cumulative counter is ec.cf_nodes_done
# (prospect/complete_mine:26 + forage/complete_gather:29 writers).
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.cf_nodes_done
scoreboard players operation @s dr.calc /= #20 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Forges completed: 1 point per 10
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.cf_total_forges
scoreboard players operation @s dr.calc /= #10 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Trade trial completions: 1 point per 5
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.tt_completed
scoreboard players operation @s dr.calc /= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Trade trial hard mode wins: 1 point per 3
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.tt_hard_wins
scoreboard players operation @s dr.calc /= #3 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Grand forge completions: 5 points each
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.gf_done
scoreboard players operation @s dr.calc *= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Transmutes done: 1 point per 10
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.transmutes_done
scoreboard players operation @s dr.calc /= #10 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# ═══════════════════════════════════════
# === EXPLORATION & DISCOVERY ===
# ═══════════════════════════════════════

# Biomes visited: 1 point each
scoreboard players operation @s dr.points += @s ach.biomes_visited

# Structures found: 1 point each
scoreboard players operation @s dr.points += @s ach.structures_found

# Lore found: 1 point per 3
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.lore_found
scoreboard players operation @s dr.calc /= #3 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Lore sets completed: 3 points each
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.lore_sets_done
scoreboard players operation @s dr.calc *= #3 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Journal entries: 1 point per 5
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.dj_count
scoreboard players operation @s dr.calc /= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Biome mastery levels: 2 points per level
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.bm_level
scoreboard players operation @s dr.calc *= #2 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Unique structures found: 1 point each
scoreboard players operation @s dr.points += @s ec.struct_unique

# Forages done: 1 point per 50
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.forages_done
scoreboard players operation @s dr.calc /= #50 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Prospects done: 1 point per 50
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.prospects_done
scoreboard players operation @s dr.calc /= #50 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# ═══════════════════════════════════════
# === COMPANIONS & SOCIAL ===
# ═══════════════════════════════════════

# Companions owned: 1 point each
scoreboard players operation @s dr.points += @s ach.comp_owned

# Companion evolutions: 3 points each
# ec.ce_evolved + ec.ce_evolved2 are BITFIELDS, not counts (Audit #15 F4/NF1) —
# popcount both before weighting, mirroring codex/hub/profile/refresh_snapshot.
function evercraft:craftforever/codex/hub/popcount {field:"ce_evolved"}
scoreboard players operation @s dr.calc = #cf_pc_count ec.temp
function evercraft:craftforever/codex/hub/popcount {field:"ce_evolved2"}
scoreboard players operation @s dr.calc += #cf_pc_count ec.temp
scoreboard players operation @s dr.calc *= #3 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Companion feeds: 1 point per 50
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.comp_feeds
scoreboard players operation @s dr.calc /= #50 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Trades done: 1 point per 50
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.trades_done
scoreboard players operation @s dr.calc /= #50 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Villages quested: 1 point each
scoreboard players operation @s dr.points += @s ach.villages_quested

# Friends made: 1 point each
scoreboard players operation @s dr.points += @s ec.fr_count

# Guild contribution: 1 point per 100
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.gexp_contrib
scoreboard players operation @s dr.calc /= #100 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Guild rank: 2 points per rank
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.guild_rank
scoreboard players operation @s dr.calc *= #2 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Buddy tier: 3 points per tier
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.bd_tier
scoreboard players operation @s dr.calc *= #3 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Buddy points: 1 point per 500
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.bd_points
scoreboard players operation @s dr.calc /= #500 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Pet duel wins: 1 point per 10
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.pd_wins
scoreboard players operation @s dr.calc /= #10 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Mount training tier: 3 points per tier
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.mt_tier
scoreboard players operation @s dr.calc *= #3 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Campfire stories heard: 1 point per 10
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.cf_listened
scoreboard players operation @s dr.calc /= #10 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Campfire stories recorded: 1 point per 5
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.cf_recorded
scoreboard players operation @s dr.calc /= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# ═══════════════════════════════════════
# === ECONOMY & HOUSING ===
# ═══════════════════════════════════════

# Crates opened: 1 point per 25
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.crates_opened
scoreboard players operation @s dr.calc /= #25 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Chests opened: 1 point per 100
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.chests_opened
scoreboard players operation @s dr.calc /= #100 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Multi-home: sum tier + decor across ALL occupied homes (not just active).
# dr_sum writes #hs_dr_tier / #hs_dr_decor on hs.temp. (Joseph: DR rewards
# every home a player keeps. Mirror still serves the active-only readers.)
function evercraft:housing/slot/dr_sum

# Housing tier: 5 points per tier (summed across every occupied home)
scoreboard players operation @s dr.calc = #hs_dr_tier hs.temp
scoreboard players operation @s dr.calc *= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Laborers: 2 points each
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.lb_count
scoreboard players operation @s dr.calc *= #2 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Expeditions: 1 point per 10
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.lb_expeditions
scoreboard players operation @s dr.calc /= #10 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Housing decoration score: 1 point per 25 (summed across every occupied home)
scoreboard players operation @s dr.calc = #hs_dr_decor hs.temp
scoreboard players operation @s dr.calc /= #25 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# ═══════════════════════════════════════
# === PLAYTIME & ENDURANCE ===
# ═══════════════════════════════════════

# Play time: 1 point per 25 hours. Weight cut to 1/25 (2026-06-04) because
# play_time advances every tick a player is online — AFK included — making this
# the cleanest "rank up while idle" vector. /72000 = hours, then /25.
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.adj_play
scoreboard players operation @s dr.calc /= #72000 ec.const
scoreboard players operation @s dr.calc /= #25 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Distance walked: 1 point per 10km (1000000 cm)
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ach.adj_walk
scoreboard players operation @s dr.calc /= #100000 ec.const
scoreboard players operation @s dr.calc /= #10 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# ═══════════════════════════════════════
# === WAVE 4 ADDITIONS (2026-06-13) — feed the Wayfarer Pass from systems that didn't contribute ===
# ═══════════════════════════════════════
# QUESTLINE PROGRESS — METERED (Joseph: "xp from quests only every 5/10 quests, only enough for the
# next reward level"). 1 point per 5 quests completed PER LINE → the Pass fills gently from questlines
# (≈ one node per few quests early-game, negligible late), never floods. dr.points x10 = wf_xp.
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.fq_done
scoreboard players operation @s dr.calc /= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.bq_done
scoreboard players operation @s dr.calc /= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.fgq_done
scoreboard players operation @s dr.calc /= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.tnk_done
scoreboard players operation @s dr.calc /= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.chq_done
scoreboard players operation @s dr.calc /= #5 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Competition wins: 2 points each (the competitive/co-op event layer was uncounted).
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.comp_wins
scoreboard players operation @s dr.calc *= #2 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Archaeology / suspicious-block finds: 1 point per 10 (repeatable excavation loop, kept modest).
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.arch_finds
scoreboard players operation @s dr.calc /= #10 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Gear mastery — pieces awakened: 3 points each (weapon + armor; a deep, previously-silent loop).
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.wm_maxed
scoreboard players operation @s dr.calc *= #3 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# Bestiary entries mastered: 2 points each (max 63 = up to 126; was realm-only before).
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.bst_mastered
scoreboard players operation @s dr.calc *= #2 ec.const
scoreboard players operation @s dr.points += @s dr.calc

# ═══════════════════════════════════════
# === MAP POINTS TO RANK ===
# ═══════════════════════════════════════
# Store previous rank for rank-up detection
scoreboard players set @s dr.calc 0
scoreboard players operation @s dr.calc = @s ec.dream_rank

# Calculate new rank (0=unranked, 1=G, 2=F, 3=E, 4=D, 5=C, 6=B, 7=A, 8=S, 9=SS, 10=SSS)
scoreboard players set @s ec.dream_rank 0
execute if score @s dr.points >= #rank_G ec.const run scoreboard players set @s ec.dream_rank 1
execute if score @s dr.points >= #rank_F ec.const run scoreboard players set @s ec.dream_rank 2
execute if score @s dr.points >= #rank_E ec.const run scoreboard players set @s ec.dream_rank 3
execute if score @s dr.points >= #rank_D ec.const run scoreboard players set @s ec.dream_rank 4
execute if score @s dr.points >= #rank_C ec.const run scoreboard players set @s ec.dream_rank 5
execute if score @s dr.points >= #rank_B ec.const run scoreboard players set @s ec.dream_rank 6
execute if score @s dr.points >= #rank_A ec.const run scoreboard players set @s ec.dream_rank 7
execute if score @s dr.points >= #rank_S ec.const run scoreboard players set @s ec.dream_rank 8
execute if score @s dr.points >= #rank_SS ec.const run scoreboard players set @s ec.dream_rank 9
execute if score @s dr.points >= #rank_SSS ec.const run scoreboard players set @s ec.dream_rank 10

# === RANK-UP NOTIFICATION ===
# Only announce if new rank is strictly HIGHER than old rank (never on decrease)
execute if score @s ec.dream_rank > @s dr.calc run function evercraft:dream_rank/rank_up
