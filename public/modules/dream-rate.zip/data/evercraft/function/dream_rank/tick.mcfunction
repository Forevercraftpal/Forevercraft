# Dream Rank — Tick (5s schedule)
# Recalculates dream rank for all online players

# Skip if no players online
execute unless entity @a run return run schedule function evercraft:dream_rank/tick 5s replace

# Update stable DR peak before recalculating rank
execute as @a[tag=ec.joined] run function evercraft:dreams/peak/update
execute as @a[tag=ec.joined] run function evercraft:dream_rank/calculate

# SP8 Wayfarer Track: remap the freshly-computed dr.points into Track XP (sole writer of ec.wf_xp/wf_node).
# Chained here where dr.points is fresh + in scope, on the same existence-gated 5s cadence.
execute as @a[tag=ec.joined] run function evercraft:companions/track/accrue

# Reschedule
schedule function evercraft:dream_rank/tick 5s replace
