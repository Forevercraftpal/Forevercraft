# Dawn Dispatch — All dawn-triggered events consolidated into one function
# Called once when #visual_day changes (every 72000 real ticks)
# OPT: Saves 6 redundant score comparisons per second in luck_buffs/tick
# (was 7 separate "execute unless score ... = ..." checks; now 1 check + 1 function call)

# === DAWN RESET (dream rate buffs, harvest moon cleanup) ===
# Extra condition: only fire if moon_events already notified (prevents false triggers on load)
execute if score #ec_moon_notified ec.var matches 1 run function evercraft:luck_buffs/dawn_reset

# === SEASONAL CLOCK RATE ADJUSTMENT ===
# Winter (season 1): dawn = fast day rate (0.666666)
execute if score #season_id ec.var matches 1 run time of minecraft:overworld rate 0.666666
# Summer (season 3): dawn = slow day rate (0.333333)
execute if score #season_id ec.var matches 3 run time of minecraft:overworld rate 0.333333

# === CROSS-TRACK EVENT CAP (2026-06-06) — reset the per-day "events committed today" counter ===
# HARD CAP: at most 2 event bossbars active at once (the festival counts as 1). #evt_today_n is
# the single cross-track tally: festival pin (+1), forced sub-event (+1), and every NORMAL fire
# (comp / co-op / calendar / world event) increments it on commit; each track's cap-gate reads it
# BEFORE committing. Reset to 0 here, at the TOP of the dawn (before festival/comp/coop run). The
# festival is multi-day; it re-adds itself below (in node_festival/dawn) on every festival day.
# Fakeplayer on the existing ec.var objective — no new objective.
scoreboard players set #evt_today_n ec.var 0

# === SEASONAL NODE FESTIVAL (Wave 3c capstone) — MUST run before the Track A/B decisions ===
# Owns the festival day rollover (start / advance featured node / end + capstone). Running
# FIRST sets #nfest_active + #nfest_node for TODAY so the festival PINS inside the two dawn
# decisions below fire on every festival day (incl. day 1). Inert (one score check) when no
# festival is running. See node_festival/dawn.
#
# Festival self-count + pin-one (2026-06-06): on a festival day node_festival/dawn picks ONE
# sub-event (#nfest_pin 1=comp / 2=co-op) and adds the festival bar itself to #evt_today_n, so a
# festival day = festival(1) + one pinned sub-event(1) = exactly 2 bars, never 3-4.
function evercraft:node_festival/dawn

# === UNIFIED EVENT DIRECTOR (gated dawn decision) ===
# Replaces the old competition/schedule 40%-roll. The Director builds the
# eligible+unlocked competition pool, applies per-type 3-day lockout + a 0..2
# day cadence, picks one survivor, and ONLY THEN arms the noon competition.
# Empty pool -> silent (no notification). See event_director/dawn_decision.
function evercraft:event_director/dawn_decision

# === CO-OP NODE EVENTS (Track B ambient — Wave 3b) ===
# Runs AFTER the Track-A competition decision. Co-op events are Track B: this consults the
# SHARED Track-B spacing (so it can't stack with a calendar / world event / another co-op
# event) but NOT Track A — a noon competition may share the day. Its own cadence keeps these
# rare. Empty pool / blocked / cadence-miss -> silent. See coop_events/dawn_decision.
function evercraft:coop_events/dawn_decision

# === DAILY CHALLENGE ROLL (dungeon + modifier + trial) ===
function evercraft:dungeon/daily_challenge/roll
function evercraft:craftforever/trials/daily_roll_global
execute as @a run function evercraft:dungeon/daily_challenge/personal_roll

# === DAY COUNTER (RPG day/era title splash) ===
function evercraft:day_counter/dawn_display

# === FRIEND DAILY RESET (reset daily heart flags) ===
function evercraft:friends/daily_reset

# === REALM NEWS: dawn reset (copy today counters to yesterday, zero today) ===
function evercraft:news/dawn_reset
