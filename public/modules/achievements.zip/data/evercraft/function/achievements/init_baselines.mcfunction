# ============================================================
# ACHIEVEMENTS — Auto-Initialize Baselines
# Called once per player when ach.base_set != 1
# Captures current vanilla stat values as baselines so achievements
# count from 0 instead of using raw lifetime totals.
# Without this, raw vanilla stats (millions of ticks/cm) pass through
# baseline subtraction as-is and fire all threshold achievements at once.
# ============================================================

# === Achievement stat baselines (vanilla auto-populated scoreboards) ===
scoreboard players operation @s ach.base_play = @s ach.play_ticks
scoreboard players operation @s ach.base_walk = @s ach.walk_cm
scoreboard players operation @s ach.base_jump = @s ach.jumps
scoreboard players operation @s ach.base_sprint = @s ach.sprint_cm
scoreboard players operation @s ach.base_trade = @s ach.trades_done
scoreboard players operation @s ach.base_sleep = @s ach.sleeps
scoreboard players operation @s ach.base_chest = @s ach.chests_opened
scoreboard players operation @s ach.base_swim = @s ach.swim_cm
scoreboard players operation @s ach.base_fall = @s ach.fall_cm
scoreboard players operation @s ach.base_flint = @s ach.flint_used
scoreboard players operation @s ach.base_map = @s ach.maps_crafted
scoreboard players operation @s ach.base_brew = @s ach.brew_count
scoreboard players operation @s ach.base_ench = @s ach.enchant_count

# === Advantage stat baselines (vanilla-synced via sync_stats) ===
scoreboard players operation @s adv.base_walk = @s adv.walk_cm
scoreboard players operation @s adv.base_crouch = @s adv.crouch_cm
scoreboard players operation @s adv.base_fish = @s adv.fish_ct
scoreboard players operation @s adv.base_mobs = @s adv.mob_kills
# Compute clean mining total (ec.total may have treasure #progression bonus)
function evercraft:advantage/mining/sum_blocks
scoreboard players operation @s adv.base_mine = #mine_rt adv.temp
# Smelting baseline: sum all furnace types
scoreboard players operation @s adv.base_smelt = @s adv.furnace_ct
scoreboard players operation @s adv.base_smelt += @s adv.blast_ct
scoreboard players operation @s adv.base_smelt += @s adv.smoker_ct

# === Mark baselines as initialized ===
scoreboard players set @s ach.base_set 1

data modify storage evercraft:notify stage.c set value [{text:"Stat baselines initialized — milestones now track from this point forward.",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
