# Cross-system & secret chain achievement checks
# (Category-specific achievements removed — now handled by Eternal Codex milestones)

# Parties formed
execute as @a[scores={ach.parties_formed=3..}] unless entity @s[advancements={evercraft:alternate/secrets/new/party_animal=true}] run advancement grant @s only evercraft:alternate/secrets/new/party_animal

# === CROSS-SYSTEM CHAIN ACHIEVEMENTS (hidden, multi-condition) ===

# Renaissance Player: 5+ trees, 50+ artifacts, 10+ quests, 1+ bonded companion
execute as @a[scores={ach.trees_unlocked=5..,ec.artifacts_ever=50..,ach.quests_done=10..,ach.comp_bonded=1..}] unless entity @s[advancements={evercraft:alternate/secrets/new/renaissance_player=true}] run advancement grant @s only evercraft:alternate/secrets/new/renaissance_player

# Dream Architect: DR milestone 4+ (DR 20), 100+ artifacts, 10+ unique structures
execute as @a[scores={ec.dr_peak_ms=4..,ec.artifacts_ever=100..,ec.struct_unique=10..}] unless entity @s[advancements={evercraft:alternate/secrets/new/dream_architect=true}] run advancement grant @s only evercraft:alternate/secrets/new/dream_architect

# Beast Master Chef: 1+ eternal bond companion, 20+ meals cooked
execute as @a[scores={ec.companion_hours=1..,ach.meals_cooked=20..}] unless entity @s[advancements={evercraft:alternate/secrets/new/beast_master_chef=true}] run advancement grant @s only evercraft:alternate/secrets/new/beast_master_chef

# Battle Scholar: 20+ patron kills, 45+ total advantage levels
execute as @a[scores={ach.patron_kills=20..,ach.total_levels=45..}] unless entity @s[advancements={evercraft:alternate/secrets/new/battle_scholar=true}] run advancement grant @s only evercraft:alternate/secrets/new/battle_scholar

# Fortune's Favorite: 100+ crates opened, DR milestone 3+ (DR 15)
execute as @a[scores={ach.crates_opened=100..,ec.dr_peak_ms=3..}] unless entity @s[advancements={evercraft:alternate/secrets/new/fortunes_favorite=true}] run advancement grant @s only evercraft:alternate/secrets/new/fortunes_favorite

# Master of All: 50+ quests, 100+ trades, 5+ unique structures, 10+ meals
execute as @a[scores={ach.quests_done=50..,ach.adj_trade=100..,ec.struct_unique=5..,ach.meals_cooked=10..}] unless entity @s[advancements={evercraft:alternate/secrets/new/master_of_all=true}] run advancement grant @s only evercraft:alternate/secrets/new/master_of_all

# World Boss Conqueror: defeat every unique World Boss (all 11 bestiary kill counters >= 1)
# Reads the 11 bs.k_* world-boss kill counters (one writer each: bestiary/track/on_kill via bosses/rewards/on_kill_N).
# Reward fn: evercraft:quests/advancement_rewards/grant_world_boss_conqueror (Hero's Satchel + Mythical Crate + 1000 XP).
execute as @a[scores={bs.k_hollking=1..,bs.k_verdwrdn=1..,bs.k_stormfrg=1..,bs.k_tidecllr=1..,bs.k_erthshkr=1..,bs.k_nightmre=1..,bs.k_inftitan=1..,bs.k_soulwrdn=1..,bs.k_crimbhmt=1..,bs.k_voidsovr=1..,bs.k_endrarch=1..}] unless entity @s[advancements={evercraft:alternate/combat/bosses/world_boss_conqueror=true}] run advancement grant @s only evercraft:alternate/combat/bosses/world_boss_conqueror

# === SALVATION STONE GRANT CHECKS ===
# 6 sticky one-shot milestones each grant the canonical "rarest item in Forevercraft" (death-save).
# Each gate is one-time via ec.salv_* flag (declared in tomb/load:6-11), so re-firing this on the 5s tick is cheap.
# Conditions: First Ender Dragon Kill, All 10 Constellations, DR 50 reached, Castle Floor 100, All 14 Spirit Metamorphoses, First Maxed Beacon.
# Grant fn evercraft:items/salvation_grant gives the stone + dramatic announce; consume advancement at items/consume_salvation re-grants on use.
execute as @a run function evercraft:items/salvation_check
