# ============================================================
# ALTERNATE ADVANCEMENTS — Milestone Checker (5s schedule)
# Checks scoreboard thresholds and grants achievements
# ============================================================

# Self-schedule every 5 seconds
schedule function evercraft:achievements/tick 100t

# Only run if players online
execute unless entity @a run return 0

# Revoke raid victory advancement when Hero of the Village effect wears off
# OPT: Predicate check replaces NBT active_effects deep scan (faster entity property match)
execute as @a[advancements={evercraft:village/raid_victory=true}] unless predicate evercraft:has_hero_of_village run advancement revoke @s only evercraft:village/raid_victory

# --- Global init cooldown (gives vanilla stat objectives time to repopulate after
#     fix_corrupted_stats or standalone revoke_all). Decrements once per 5s cycle. ---
execute if score #ach_init_cd ec.var matches 1.. run scoreboard players remove #ach_init_cd ec.var 1
execute if score #ach_init_cd ec.var matches 1.. run return 0

# --- Sleep change detection + stat sync + derived counters ---
# OPT: Batched into per-player function (11 @a scans → 1)
execute as @a at @s run function evercraft:achievements/sync/player_stats

# --- Auto-initialize baselines for players who haven't had them set ---
# Without baselines, raw vanilla stat totals (millions of ticks/cm) pass through
# and fire all threshold-based achievements at once.
# Detect uninitialized players BEFORE init (init sets base_set=1, can't check after)
scoreboard players set #ach_init ec.var 0
execute as @a unless score @s ach.base_set matches 1 run scoreboard players set #ach_init ec.var 1
execute as @a unless score @s ach.base_set matches 1 run function evercraft:achievements/init_baselines
# Skip checks for 2 extra cycles after init — vanilla stat objectives may not have
# repopulated yet (e.g., after fix_corrupted_stats or /reload). The cooldown gives
# Minecraft time to sync stat values before baselines are used for comparisons.
execute if score #ach_init ec.var matches 1 run scoreboard players set #ach_init_cd ec.var 2
execute if score #ach_init ec.var matches 1 run return 0

# --- Copy vanilla stats to adjusted scores, then subtract baselines ---
# OPT: Batched into per-player function (26 @a scans → 1)
execute as @a run function evercraft:achievements/sync/player_adjust

# Check secrets + cross-system (only surviving achievement categories)
function evercraft:achievements/check/secrets
function evercraft:achievements/check/cross_system

# OPT: ach.progress trigger enable moved to on_join (was @a scan every 5s)
# Note: check_progress debug function was removed — trigger handler is no-op

# Handle prestige token usage (carrot_on_a_stick with prestige_token tag)
execute as @a[scores={ec.prestige_use=1..}] run function evercraft:achievements/prestige/tick
