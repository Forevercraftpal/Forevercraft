# Achievement Stat Sync — Per-player (runs as @s = player, at @s)
# OPT: Consolidates 11 @a scans into 1 function call

# Sleep change detection (must run BEFORE baseline subtraction, needs raw ach.sleeps)
execute unless score @s ach.sleeps = @s ach.prev_sleeps run scoreboard players set @s ach.no_sleep_days 0
scoreboard players operation @s ach.prev_sleeps = @s ach.sleeps

# Sync milestone counters from advantage stats, MINUS the credit portion (adv.cr_*). The tree stats
# adv.stat_* include flat tree-credit from grant_tree_credit (lore pickup / dungeon / raid), which is
# NOT a real mine/fish/harvest/place/eat. Subtracting adv.cr_* makes these milestone counters reflect
# ONLY real actions, so picking up lore no longer "completes" the crops/mining/etc milestones.
# (Joseph 2026-06-08 — root cause of the long-standing false-milestone-on-lore-pickup bug.)
scoreboard players operation @s ach.blocks_mined = @s adv.stat_mine
scoreboard players operation @s ach.blocks_mined -= @s adv.cr_mine
scoreboard players operation @s ach.fish_caught = @s adv.stat_fish
scoreboard players operation @s ach.fish_caught -= @s adv.cr_fish
scoreboard players operation @s ach.crops_harvested = @s adv.stat_harvest
scoreboard players operation @s ach.crops_harvested -= @s adv.cr_harvest
scoreboard players operation @s ach.blocks_placed = @s adv.stat_place
scoreboard players operation @s ach.blocks_placed -= @s adv.cr_place
scoreboard players operation @s ach.food_eaten = @s adv.stat_food
scoreboard players operation @s ach.food_eaten -= @s adv.cr_food
scoreboard players operation @s ach.fish_treasure = @s ach.crates_fishing

# Compute derived counters from live game state
function evercraft:achievements/sync/count_trees
function evercraft:achievements/sync/count_biomes
function evercraft:achievements/sync/count_sets
