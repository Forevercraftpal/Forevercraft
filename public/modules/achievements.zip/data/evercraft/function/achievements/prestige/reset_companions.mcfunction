# ============================================================
# PRESTIGE — Reset Companions & Quests Tree
# Categories: pets, quests
# ============================================================

# Consume the token
clear @s carrot_on_a_stick[custom_data~{prestige_token:true,prestige_tab:"companions"}] 1

# Decrement total (139 companion advancements minus root)
scoreboard players remove @s ach.total 138

# Increment prestige counter
scoreboard players add @s ach.prestige_companions 1

# Grant prestige reward
function evercraft:achievements/prestige/prestige_reward

# Announcement
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"PRESTIGE! ",color:"yellow",bold:true},{text:"Companions & Quests ",color:"yellow"},{text:"tree reset!",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Prestige Level: ",color:"white"},{score:{name:"@s",objective:"ach.prestige_companions"},color:"yellow",bold:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Advancements will re-earn over the next few seconds...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Effects
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 0.5
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.7 2.0
execute if score @s ec.fx_vis matches 1.. run particle totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.3 25
