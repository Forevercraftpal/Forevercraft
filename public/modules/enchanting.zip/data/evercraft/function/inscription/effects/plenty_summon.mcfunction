# Lantern of Plenty (Quicksilver 2nd effect) — clone summon (macro body)
# Called from plenty_roll with {Item:<the dropped item's Item compound>}.
# Run at the drop position. Summons a duplicate item; PickupDelay gives it a beat on the
# ground (so it does not instantly merge back) and the clone is pre-marked ec.plenty_seen
# so it can never itself be re-duplicated next cycle.
$summon item ~ ~0.25 ~ {Item:$(Item),PickupDelay:10s,Tags:["ec.plenty_seen"]}
