# Inscription Stone — Renewal (Tidecall Glyph)
# Regeneration — a restoring tide, not vampirism (W5 internal rename: Life Steal → Renewal).
# W2 zone-tier + W3 hybrid stacking + W7 party rules via the shared pipeline.
# Base: Regeneration I (amp 0), radius 12. Stacking → up to Regeneration III, radius up to 18.
# (1st effect — Renewal/Regeneration — LOCKED, untouched below.)
scoreboard players set #inscr_base_amp ec.temp 0
scoreboard players set #inscr_base_radius ec.temp 12
data modify storage evercraft:inscription stack.tag set value "ec.inscr_life_steal"
function evercraft:inscription/effects/stacks
data modify storage evercraft:inscription apply.effect set value "regeneration"
function evercraft:inscription/effects/apply_potion

# === Mender's Rest (Tidecall 2nd effect) ===
# Slowly repair the worn gear of players in the zone — a restoring tide for tools too.
# Throttled by the 5s effects_tick cadence + the small +4%-durability mend_small modifier;
# we only touch ONE damaged slot per recipient per cycle (mainhand first, else chest) so
# this is never an every-slot iteration. apply_potion just ran classify, so the in-range
# recipients already carry ec.inscr_full / ec.inscr_weak — reuse those tags (no 2nd scan).
# `if items ... *[minecraft:damage~{}]` gates each `item modify` so undamaged/empty slots
# and non-tool items are skipped entirely (the modifier never fires on full-durability gear).
execute as @a[tag=ec.inscr_full] if items entity @s weapon.mainhand *[minecraft:damage~{}] run item modify entity @s weapon.mainhand evercraft:inscription/mend_small
execute as @a[tag=ec.inscr_full] unless items entity @s weapon.mainhand *[minecraft:damage~{}] if items entity @s armor.chest *[minecraft:damage~{}] run item modify entity @s armor.chest evercraft:inscription/mend_small
execute as @a[tag=ec.inscr_weak] if items entity @s weapon.mainhand *[minecraft:damage~{}] run item modify entity @s weapon.mainhand evercraft:inscription/mend_small
execute as @a[tag=ec.inscr_weak] unless items entity @s weapon.mainhand *[minecraft:damage~{}] if items entity @s armor.chest *[minecraft:damage~{}] run item modify entity @s armor.chest evercraft:inscription/mend_small
