# ============================================================
# Inscription Stones — Thousandths → Decimal String Formatter
# Input:  #inscr_fmt_milli ec.temp = value in thousandths (>=0)
# Output: storage evercraft:inscription attr.value = "<int>.<3-digit frac>" string
#   e.g. 700  -> "0.700"   (force +0.7 at 7 stacks)
#        2000 -> "2.000"   (guardian +2)
#        50   -> "0.050"   (gold_greed weak half-stack)
#        350  -> "0.350"
# add_value / add_multiplied_base both accept this decimal form.
# ============================================================

# Integer part = milli / 1000
scoreboard players operation #inscr_fmt_int ec.temp = #inscr_fmt_milli ec.temp
scoreboard players operation #inscr_fmt_int ec.temp /= #1000 ec.const

# Fractional part (thousandths) = milli % 1000
scoreboard players operation #inscr_fmt_frac ec.temp = #inscr_fmt_milli ec.temp
scoreboard players operation #inscr_fmt_frac ec.temp %= #1000 ec.const

# Build "<int>." then append a zero-padded 3-digit fraction.
execute store result storage evercraft:inscription fmt.i int 1 run scoreboard players get #inscr_fmt_int ec.temp
execute store result storage evercraft:inscription fmt.f int 1 run scoreboard players get #inscr_fmt_frac ec.temp

# Zero-pad the fraction to 3 digits (100..999 -> as is, 10..99 -> "0", 0..9 -> "00").
data modify storage evercraft:inscription fmt.pad set value ""
execute if score #inscr_fmt_frac ec.temp matches ..99 run data modify storage evercraft:inscription fmt.pad set value "0"
execute if score #inscr_fmt_frac ec.temp matches ..9 run data modify storage evercraft:inscription fmt.pad set value "00"

function evercraft:inscription/effects/fmt_milli_macro with storage evercraft:inscription fmt
