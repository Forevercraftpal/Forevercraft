# Inscription Stone — Haste (Quicksilver Glyph)
# W2 zone-tier + W3 hybrid stacking + W7 party rules via the shared pipeline.
# Base: Haste I (amp 0), radius 12. Stacking → up to Haste III, radius up to 18.
# (1st effect — Haste — LOCKED, untouched below.)
scoreboard players set #inscr_base_amp ec.temp 0
scoreboard players set #inscr_base_radius ec.temp 12
data modify storage evercraft:inscription stack.tag set value "ec.inscr_haste"
function evercraft:inscription/effects/stacks
data modify storage evercraft:inscription apply.effect set value "haste"
function evercraft:inscription/effects/apply_potion

# === Lantern of Plenty (Quicksilver 2nd effect) ===
# Small chance to DUPLICATE a fresh harvest drop in the zone. Deliberately gated LOW
# (3%) and restricted to HARVEST items only — crops (#evercraft:plantable_crops) and
# mining drops (#evercraft:ore_drops) — because this feeds the economy (D1 luck concern).
# Each loose item is tag-marked ec.plenty_seen the moment it is considered so a lingering
# drop is rolled AT MOST ONCE, never re-duplicated cycle after cycle.
# Existence-gate: bail unless a FRESH (untagged) item is in the 12-block zone at all —
# most cycles have none, so the per-item harvest test below almost never runs.
execute unless entity @e[type=item,tag=!ec.plenty_seen,distance=..12,limit=1] run return 0
# For each fresh item: mark it seen (one-shot), and if it is a harvest drop, roll 3% to
# clone it. limit=4 caps the per-cycle work even on a flood of drops; later drops are
# simply marked seen next cycle. plenty_roll does the roll + clone as the item entity.
execute as @e[type=item,tag=!ec.plenty_seen,distance=..12,limit=4,sort=nearest] run function evercraft:inscription/effects/plenty_mark
