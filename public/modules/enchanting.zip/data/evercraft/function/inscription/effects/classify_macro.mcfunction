# ============================================================
# Inscription Stones — Recipient Classifier (macro body)
# Called from classify.mcfunction with {r:<radius>}.
# Run as: marker (stone), at marker.
# $(r) = effective radius in blocks.
# ============================================================

# Clear prior tags on the players we are about to (re)classify.
# Snapshot last cycle's FULL state into ec.inscr_was_full for hysteresis.
$tag @a[distance=..$(r),tag=ec.inscr_full] add ec.inscr_was_full
$tag @a[distance=..$(r)] remove ec.inscr_full
$tag @a[distance=..$(r)] remove ec.inscr_weak

# FULL tier: player is in their home zone, their guild zone, or is a party member.
# (Party travels with the player per the locked party-anywhere rule.)
$execute as @a[distance=..$(r),tag=!ec.pvp_hostile] if score @s hs.in_zone matches 1 run tag @s add ec.inscr_full
$execute as @a[distance=..$(r),tag=!ec.pvp_hostile,tag=!ec.inscr_full] if score @s ec.guild_in_zone matches 1 run tag @s add ec.inscr_full
$execute as @a[distance=..$(r),tag=!ec.pvp_hostile,tag=!ec.inscr_full] if score @s ec.party_id matches 1.. run tag @s add ec.inscr_full

# Hysteresis: a player who was FULL last cycle and is NOT hostile keeps FULL for
# one grace cycle even if they just slipped out of the zone (4-block edge band).
$execute as @a[distance=..$(r),tag=!ec.pvp_hostile,tag=!ec.inscr_full,tag=ec.inscr_was_full] run tag @s add ec.inscr_full

# WEAK tier: anyone in range who is non-hostile and did NOT qualify for FULL.
$execute as @a[distance=..$(r),tag=!ec.pvp_hostile,tag=!ec.inscr_full] run tag @s add ec.inscr_weak

# Refresh the was_full snapshot to THIS cycle's FULL set for next time.
$tag @a[distance=..$(r)] remove ec.inscr_was_full
$tag @a[distance=..$(r),tag=ec.inscr_full] add ec.inscr_was_full
