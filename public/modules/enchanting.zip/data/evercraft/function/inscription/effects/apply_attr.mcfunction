# ============================================================
# Inscription Stones — Attribute Applier (W1.2 stacking + W2 zone-tier + W7 party)
# Run as: marker (stone), at marker.
# Caller must FIRST have run stacks.mcfunction, classified recipients (via the
# effect's own classify call), and set:
#   storage evercraft:inscription attr.id     = "evercraft:inscr_<type>"  (modifier id)
#   storage evercraft:inscription attr.name   = "<minecraft:attribute>"   (e.g. attack_damage)
#   storage evercraft:inscription attr.op     = "add_value" | "add_multiplied_base"
#   #inscr_attr_milli ec.temp = base modifier value PER STACK, in thousandths
#                               (e.g. force +0.1/stack = 100; guardian +2/stack = 2000)
# Magnitude scales with effective_stacks. WEAK tier gets HALF magnitude (W2 wild rule).
#
# Convergence-safe: every same-type stone computes the same #inscr_stacks and writes
# the SAME modifier id with the SAME value per recipient, so N stones = N× base
# (the modifier value is base*stacks), not 1× as the old shared-id code produced.
# ============================================================

# Stage the stack-widened radius for the remove/add macros.
execute store result storage evercraft:inscription attr.r int 1 run scoreboard players get #inscr_radius ec.temp

# Full magnitude (thousandths) = per-stack value * effective_stacks
scoreboard players operation #inscr_val_full ec.temp = #inscr_attr_milli ec.temp
scoreboard players operation #inscr_val_full ec.temp *= #inscr_stacks ec.temp

# Weak magnitude (thousandths) = full / 2 (halve attribute % in the wild — W2)
scoreboard players operation #inscr_val_weak ec.temp = #inscr_val_full ec.temp
scoreboard players operation #inscr_val_weak ec.temp /= #2 ec.const

# Always remove the prior modifier first (idempotent per recipient), then re-add.
function evercraft:inscription/effects/apply_attr_remove with storage evercraft:inscription attr

# Format the thousandths into a decimal string and apply to FULL recipients.
scoreboard players operation #inscr_fmt_milli ec.temp = #inscr_val_full ec.temp
function evercraft:inscription/effects/fmt_milli
data modify storage evercraft:inscription attr.tier set value "ec.inscr_full"
function evercraft:inscription/effects/apply_attr_add with storage evercraft:inscription attr

# Format + apply to WEAK recipients (half magnitude).
scoreboard players operation #inscr_fmt_milli ec.temp = #inscr_val_weak ec.temp
function evercraft:inscription/effects/fmt_milli
data modify storage evercraft:inscription attr.tier set value "ec.inscr_weak"
function evercraft:inscription/effects/apply_attr_add with storage evercraft:inscription attr
