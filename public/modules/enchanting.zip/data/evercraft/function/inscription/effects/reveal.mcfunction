# Inscription Stone — Reveal (Prism Glyph)
# Glowing on hostile mobs. W3 hybrid stacking widens the radius (amp is cosmetic for
# Glowing, so the amp cap is harmless). Base radius 16, up to 22 at full stacks.
# (1st effect — Reveal/Glowing — LOCKED, untouched below.)
scoreboard players set #inscr_base_amp ec.temp 0
scoreboard players set #inscr_base_radius ec.temp 16
data modify storage evercraft:inscription stack.tag set value "ec.inscr_reveal"
function evercraft:inscription/effects/stacks
data modify storage evercraft:inscription apply.effect set value "glowing"
function evercraft:inscription/effects/apply_mob

# === Wardlight (Prism 2nd effect) ===
# Hostile mobs cannot persist in the zone — vanilla has no "no-spawn" command, so we
# periodically CLEAR freshly-appeared hostiles in the totem radius. This is the most
# expensive passive in the system, so it is HARD existence-gated in TWO ways:
#   (1) ONLY when a non-spectator player is actually within the totem radius (no point
#       clearing mobs nobody is near; also keeps the scan chunk-loaded + relevant).
#   (2) ONLY hostiles lacking the ec.ward_seen tag are touched — so an established mob
#       that wandered in last cycle (already tagged + cleared) is never re-scanned for
#       work; the kill itself removes it, and the tag is the "newly-appeared" gate.
# #inscr_radius ec.temp is already set by the stacks call above (16..22).
execute store result storage evercraft:inscription ward.r int 1 run scoreboard players get #inscr_radius ec.temp
function evercraft:inscription/effects/ward_macro with storage evercraft:inscription ward
