# ============================================================
# Inscription Stones — Wardlight (Prism 2nd effect, macro body)
# Called from reveal.mcfunction with {r:<radius>}. Run as: marker (stone), at marker.
# Anti-spawn: clear freshly-appeared hostiles in the zone. HARD existence-gated:
#   - only runs the hostile scan when a real (non-spectator) player is in radius,
#   - only touches hostiles WITHOUT the ec.ward_seen tag (the "just appeared" gate).
# A single kill removes the mob; the tag prevents a mob lingering one cycle (e.g. a
# boss or tag-immune entity) from being re-evaluated as work every tick.
# ============================================================

# Existence gate: bail unless a non-spectator player is within the totem radius.
$execute unless entity @a[gamemode=!spectator,distance=..$(r)] run return 0

# Tag every freshly-appeared hostile in range (single pass per mob), then clear it.
# Warden is excluded (it is an event boss, not ambient hostile — never instant-cleared).
$tag @e[type=#evercraft:hostile_mobs,type=!minecraft:warden,tag=!ec.ward_seen,distance=..$(r)] add ec.ward_seen
$execute at @s if entity @e[type=#evercraft:hostile_mobs,type=!minecraft:warden,tag=ec.ward_seen,distance=..$(r),limit=1] run particle minecraft:end_rod ~ ~1 ~ 0.4 0.4 0.4 0.02 6
$kill @e[type=#evercraft:hostile_mobs,type=!minecraft:warden,tag=ec.ward_seen,distance=..$(r)]
