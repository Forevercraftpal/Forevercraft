# Inscription Stone — Gold Greed (Gilded Glyph)
# +0.25 Dream Rate (luck) PER STACK (W1.2 stacking rewrite — was 1x for 7 stones).
# Magnitude = +0.25 * effective_stacks (up to +1.75 at 7), via luck attribute modifier.
# WEAK tier (wild / non-party) gets HALF (W2). Radius widens with stacks (W3).
# NOTE: D1 keeps totem luck-stacking intact; only the Gilded WEAPON luck was cut
# (+1.5 -> +0.5, see glyphforge/effects/apply) and the Rally exclusion is Agent A2.
scoreboard players set #inscr_base_amp ec.temp 0
scoreboard players set #inscr_base_radius ec.temp 12
data modify storage evercraft:inscription stack.tag set value "ec.inscr_gold_greed"
function evercraft:inscription/effects/stacks

# Classify recipients at the (stack-widened) radius for W2/W7 tiering.
function evercraft:inscription/effects/classify

# +0.25 luck per stack (add_value) → 250 thousandths/stack.
# (1st effect — Gold Greed luck / Dream Rate — LOCKED magnitude, untouched below.)
# HOME exception: a home-pool gilded totem routes its Dream Rate through the persistent,
# zone-wide home network (housing/zone/apply_buffs → evercraft:inscr_home_gg) so it covers
# the whole home and counts toward Dream Rank — so SKIP this 12-block proximity aura for
# home stones to avoid double-counting. Wild/guild gilded totems keep the proximity aura
# (evercraft:inscr_gold_greed, now denylisted from stable DR). The Gleaner below still runs.
scoreboard players set #inscr_attr_milli ec.temp 250
data modify storage evercraft:inscription attr.id set value "evercraft:inscr_gold_greed"
data modify storage evercraft:inscription attr.name set value "luck"
data modify storage evercraft:inscription attr.op set value "add_value"
execute unless entity @s[tag=ec.inscr_home_stone] run function evercraft:inscription/effects/apply_attr

# === Gleaner (Gilded 2nd effect) ===
# Pull nearby dropped items toward the totem — the same "gather after a beat on the
# ground" mechanic as the prestige Ore Magnet (advantage/prestige/abilities/ore_magnet_tick),
# but gathering to the STONE rather than a player, and on the 5s effects_tick rather than 1s.
# Existence-gate: bail immediately unless a dropped item is actually within the 8-block
# gather radius (no work on an empty zone). The single early `if entity ... limit=1` is the
# whole gate; the tp below is skipped when nothing is in range.
execute unless entity @e[type=item,distance=..8,limit=1] run return 0
# Gather: TP loose items to the totem block-top (cap 24, nearest-first so big piles don't
# stall the scan). Items already at the stone are within ..1 and excluded.
particle minecraft:enchant ~ ~1 ~ 0.4 0.4 0.4 0.6 4
tp @e[type=item,distance=1..8,limit=24,sort=nearest] ~ ~0.6 ~
