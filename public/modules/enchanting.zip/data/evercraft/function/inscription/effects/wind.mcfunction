# Inscription Stone — Wind (Zephyr Glyph)
# Speed I + Jump Boost I. W2 zone-tier + W3 hybrid stacking + W7 party rules.
# Base amp 0, radius 12. Stacking → up to amp III, radius up to 18.
scoreboard players set #inscr_base_amp ec.temp 0
scoreboard players set #inscr_base_radius ec.temp 12
data modify storage evercraft:inscription stack.tag set value "ec.inscr_wind"
function evercraft:inscription/effects/stacks
# Both effects share the same stacks/radius/amp computed above.
data modify storage evercraft:inscription apply.effect set value "speed"
function evercraft:inscription/effects/apply_potion
data modify storage evercraft:inscription apply.effect set value "jump_boost"
function evercraft:inscription/effects/apply_potion
