# ============================================================
# Inscription Stones — Effective Stack Count (W3 hybrid amp+radius)
# Run as: marker (stone), at marker. Caller sets:
#   #inscr_base_amp    ec.temp = base amplifier (0 for amp-I effects)
#   #inscr_base_radius ec.temp = base radius in blocks (12 or 16)
# and passes the same-type marker tag via the storage 'stack' compound:
#   storage evercraft:inscription stack.tag = "ec.inscr_<type>"
# Produces:
#   #inscr_stacks ec.temp     = effective same-type stones in range, 1..7 (LOCKED cap)
#   #inscr_amp    ec.temp     = base_amp + (stacks-1), capped at base_amp+2
#   #inscr_radius ec.temp     = base_radius + (stacks-1), capped at base_radius+6
# ============================================================

# Count same-type stones within 48 blocks (the resonance range), capped at 7.
scoreboard players set #inscr_stacks ec.temp 0
function evercraft:inscription/effects/stacks_macro with storage evercraft:inscription stack

# Clamp to the LOCKED 1..7 range (a stone always counts itself = min 1).
execute if score #inscr_stacks ec.temp matches ..0 run scoreboard players set #inscr_stacks ec.temp 1
execute if score #inscr_stacks ec.temp matches 8.. run scoreboard players set #inscr_stacks ec.temp 7

# bonus = effective_stacks - 1  (0 at a single stone, up to 6 at 7 stones)
scoreboard players operation #inscr_bonus ec.temp = #inscr_stacks ec.temp
scoreboard players remove #inscr_bonus ec.temp 1

# Amplifier = base_amp + bonus, capped at base_amp + 2
scoreboard players operation #inscr_amp ec.temp = #inscr_base_amp ec.temp
scoreboard players operation #inscr_amp ec.temp += #inscr_bonus ec.temp
scoreboard players operation #inscr_amp_cap ec.temp = #inscr_base_amp ec.temp
scoreboard players add #inscr_amp_cap ec.temp 2
execute if score #inscr_amp ec.temp > #inscr_amp_cap ec.temp run scoreboard players operation #inscr_amp ec.temp = #inscr_amp_cap ec.temp

# Radius = base_radius + bonus (1 block per stack), capped at base_radius + 6
scoreboard players operation #inscr_radius ec.temp = #inscr_base_radius ec.temp
scoreboard players operation #inscr_radius ec.temp += #inscr_bonus ec.temp
scoreboard players operation #inscr_radius_cap ec.temp = #inscr_base_radius ec.temp
scoreboard players add #inscr_radius_cap ec.temp 6
execute if score #inscr_radius ec.temp > #inscr_radius_cap ec.temp run scoreboard players operation #inscr_radius ec.temp = #inscr_radius_cap ec.temp

# Followup wave: ADD the milestone radius bonus stamped on this stone (ec.inscr_rad_bonus,
# 0/+1/+3) AFTER the stacking cap — a separate additive axis from same-type stacking, so a
# fully-milestoned zone reaches base+6 (stacks) +3 (milestone). Run as the marker, so @s is
# the stone; the bonus was set from the placer's per-zone ec.rad_bn_<z> in summon_marker.
execute if score @s ec.inscr_rad_bonus matches 1.. run scoreboard players operation #inscr_radius ec.temp += @s ec.inscr_rad_bonus
