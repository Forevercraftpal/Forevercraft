# Inscription Stone — Wild Forces (Arcanum Glyph)
# Random positive effect to nearby players each tick cycle
# Picks 1 of 6 effects based on random score
# Radius 12 (matches all other player-target totems; was 48 — W1.1 bug fix)
# Zone/party tiering applied per-recipient via the shared classifier:
#   tag ec.inscr_full  = full strength (home/guild zone OR party member)
#   tag ec.inscr_weak  = weaker baseline (non-party, non-hostile)
#   hostile players (ec.pvp_hostile) are excluded by the classifier selector.

# Classify recipients in range (sets ec.inscr_full / ec.inscr_weak per player)
scoreboard players set #inscr_radius ec.temp 12
function evercraft:inscription/effects/classify

# Roll 1-6
execute store result score #wm_roll ec.temp run random value 1..6

# Full-strength recipients (amp 0)
execute if score #wm_roll ec.temp matches 1 run effect give @a[distance=..12,tag=ec.inscr_full] speed 7 0 true
execute if score #wm_roll ec.temp matches 2 run effect give @a[distance=..12,tag=ec.inscr_full] strength 7 0 true
execute if score #wm_roll ec.temp matches 3 run effect give @a[distance=..12,tag=ec.inscr_full] regeneration 7 0 true
execute if score #wm_roll ec.temp matches 4 run effect give @a[distance=..12,tag=ec.inscr_full] jump_boost 7 0 true
execute if score #wm_roll ec.temp matches 5 run effect give @a[distance=..12,tag=ec.inscr_full] resistance 7 0 true
execute if score #wm_roll ec.temp matches 6 run effect give @a[distance=..12,tag=ec.inscr_full] haste 7 0 true

# Weak recipients: Wild Forces base is amp 0, so dropping amp by 1 floors to amp 0
# (still relevant — they get the rolled effect at amp 0, same as full for this totem)
execute if score #wm_roll ec.temp matches 1 run effect give @a[distance=..12,tag=ec.inscr_weak] speed 7 0 true
execute if score #wm_roll ec.temp matches 2 run effect give @a[distance=..12,tag=ec.inscr_weak] strength 7 0 true
execute if score #wm_roll ec.temp matches 3 run effect give @a[distance=..12,tag=ec.inscr_weak] regeneration 7 0 true
execute if score #wm_roll ec.temp matches 4 run effect give @a[distance=..12,tag=ec.inscr_weak] jump_boost 7 0 true
execute if score #wm_roll ec.temp matches 5 run effect give @a[distance=..12,tag=ec.inscr_weak] resistance 7 0 true
execute if score #wm_roll ec.temp matches 6 run effect give @a[distance=..12,tag=ec.inscr_weak] haste 7 0 true
