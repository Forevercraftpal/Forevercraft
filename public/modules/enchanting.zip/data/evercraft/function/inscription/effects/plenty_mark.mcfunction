# Lantern of Plenty (Quicksilver 2nd effect) — per-item gate
# Run as: a fresh (untagged) item entity in the totem zone, at the marker.
# Marks the item seen (one-shot dup gate), then if it is a HARVEST drop (crop or ore)
# rolls the low duplication chance.
tag @s add ec.plenty_seen

# Harvest-only restriction (economy guard): crops + mining drops, nothing else.
execute if items entity @s contents #evercraft:plantable_crops run function evercraft:inscription/effects/plenty_roll
execute unless items entity @s contents #evercraft:plantable_crops if items entity @s contents #evercraft:ore_drops run function evercraft:inscription/effects/plenty_roll
