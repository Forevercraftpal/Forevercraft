# ============================================================
# Inscription Stones — Hostile-Mob Applier (W3 stacking on debuff totems)
# Run as: marker (stone), at marker.
# Caller must FIRST have run stacks.mcfunction (sets #inscr_radius / #inscr_amp)
# and set storage evercraft:inscription apply.effect = "<minecraft:effect>".
# No zone/party tiering (targets are hostile mobs, not players); stacking still
# raises amplifier + radius per W3.
# ============================================================

execute store result storage evercraft:inscription apply.r int 1 run scoreboard players get #inscr_radius ec.temp
execute store result storage evercraft:inscription apply.amp_full int 1 run scoreboard players get #inscr_amp ec.temp
function evercraft:inscription/effects/apply_mob_macro with storage evercraft:inscription apply
