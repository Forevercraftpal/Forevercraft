# Lantern of Plenty (Quicksilver 2nd effect) — roll + clone
# Run as: a harvest-drop item entity (already marked ec.plenty_seen), at the marker.
# Low 3% chance to duplicate the stack: copy this item's Item component to storage and
# summon an identical item at the drop, so the clone carries the exact id/count/components.
execute store result score #plenty_roll ec.temp run random value 1..100
execute if score #plenty_roll ec.temp matches 4.. run return 0

# Success (≤3): clone the dropped stack. Stage the Item compound, then macro-summon a copy
# at the item's own position (run at @s so ~ ~ ~ is the drop).
data modify storage evercraft:inscription plenty.Item set from entity @s Item
execute at @s positioned ~ ~ ~ run function evercraft:inscription/effects/plenty_summon with storage evercraft:inscription plenty
execute at @s run particle minecraft:happy_villager ~ ~0.3 ~ 0.2 0.2 0.2 0.05 6
execute at @s run playsound minecraft:entity.item.pickup master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.4 1.6
