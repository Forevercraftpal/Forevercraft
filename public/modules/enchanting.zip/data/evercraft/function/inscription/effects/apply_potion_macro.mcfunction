# ============================================================
# Inscription Stones — Potion Applier (macro body)
# Called from apply_potion.mcfunction with {effect:..,r:..,amp_full:..,amp_weak:..}.
# Run as: marker (stone), at marker.
# 7s duration covers the 5s tick + buffer (matches the original totem pattern).
# Recipients already tagged ec.inscr_full / ec.inscr_weak by classify.
# ============================================================

$effect give @a[distance=..$(r),tag=ec.inscr_full] $(effect) 7 $(amp_full) true
$effect give @a[distance=..$(r),tag=ec.inscr_weak] $(effect) 7 $(amp_weak) true
