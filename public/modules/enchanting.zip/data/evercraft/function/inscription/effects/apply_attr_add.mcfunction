# ============================================================
# Inscription Stones — Attribute Add (macro body)
# Called with {id:.., name:.., op:.., value:.., tier:.., r:..}.
# Run as: marker (stone), at marker. Adds the modifier to recipients of one tier
# (ec.inscr_full or ec.inscr_weak) within the stack-widened radius.
# value is the decimal magnitude string from fmt_milli (base * stacks, halved for weak).
# ============================================================

$execute as @a[distance=..$(r),tag=$(tier)] run attribute @s $(name) modifier add $(id) $(value) $(op)
