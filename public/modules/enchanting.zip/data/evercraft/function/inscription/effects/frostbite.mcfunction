# Inscription Stone — Frostbite (Tempest Glyph)
# Slowness + Weakness to hostile mobs. W3 hybrid stacking (amp + radius).
# Base: amp 1 (Slowness II / Weakness II), radius 16.
# Stacking → up to amp III (level IV), radius up to 22. No zone/party tiering (mob targets).
scoreboard players set #inscr_base_amp ec.temp 1
scoreboard players set #inscr_base_radius ec.temp 16
data modify storage evercraft:inscription stack.tag set value "ec.inscr_frostbite"
function evercraft:inscription/effects/stacks
data modify storage evercraft:inscription apply.effect set value "slowness"
function evercraft:inscription/effects/apply_mob
data modify storage evercraft:inscription apply.effect set value "weakness"
function evercraft:inscription/effects/apply_mob
