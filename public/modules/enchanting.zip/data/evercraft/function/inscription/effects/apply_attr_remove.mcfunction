# ============================================================
# Inscription Stones — Attribute Remove (macro body)
# Called with {id:"evercraft:inscr_<type>", name:"<attribute>", r:<radius>}.
# Run as: marker (stone), at marker. Strips the modifier from every recipient in
# range (full + weak) so the value is re-set cleanly each cycle (idempotent).
# r comes from storage apply.r (the stack-widened radius).
# ============================================================

$execute as @a[distance=..$(r)] run attribute @s $(name) modifier remove $(id)
