# ============================================================
# Inscription Stones — Potion Applier (W2/W3/W7 unified)
# Run as: marker (stone), at marker.
# Caller must FIRST have run stacks.mcfunction (sets #inscr_radius / #inscr_amp)
# and set storage evercraft:inscription apply.effect = "<minecraft:effect>".
# Then classify recipients at the (stacked) radius and apply per tier:
#   FULL recipients  → amp = #inscr_amp
#   WEAK recipients  → amp = max(#inscr_amp - 1, 0)   (wild/non-party drop-by-1)
# ============================================================

# Classify recipients at the effective (stack-widened) radius.
function evercraft:inscription/effects/classify

# Weak amplifier = full amp - 1, floored at 0.
scoreboard players operation #inscr_amp_weak ec.temp = #inscr_amp ec.temp
scoreboard players remove #inscr_amp_weak ec.temp 1
execute if score #inscr_amp_weak ec.temp matches ..0 run scoreboard players set #inscr_amp_weak ec.temp 0

# Stage values for the macro applier.
execute store result storage evercraft:inscription apply.r int 1 run scoreboard players get #inscr_radius ec.temp
execute store result storage evercraft:inscription apply.amp_full int 1 run scoreboard players get #inscr_amp ec.temp
execute store result storage evercraft:inscription apply.amp_weak int 1 run scoreboard players get #inscr_amp_weak ec.temp

function evercraft:inscription/effects/apply_potion_macro with storage evercraft:inscription apply
