# Inscription Stone — Absorption (Hearthstone Glyph)
# W2 zone-tier + W3 hybrid stacking + W7 party rules via the shared pipeline.
# Base: Absorption I (amp 0), radius 12. Stacking → up to Absorption III, radius up to 18.
scoreboard players set #inscr_base_amp ec.temp 0
scoreboard players set #inscr_base_radius ec.temp 12
data modify storage evercraft:inscription stack.tag set value "ec.inscr_absorption"
function evercraft:inscription/effects/stacks
data modify storage evercraft:inscription apply.effect set value "absorption"
function evercraft:inscription/effects/apply_potion
