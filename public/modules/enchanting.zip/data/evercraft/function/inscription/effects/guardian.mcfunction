# Inscription Stone — Guardian (Briar Glyph)
# +2 Armor PER STACK (W1.2 stacking rewrite — was 1x for 7 stones).
# Magnitude = +2 * effective_stacks (up to +14 at 7), via attribute modifier.
# WEAK tier (wild / non-party) gets HALF (W2). Radius widens with stacks (W3).
scoreboard players set #inscr_base_amp ec.temp 0
scoreboard players set #inscr_base_radius ec.temp 12
data modify storage evercraft:inscription stack.tag set value "ec.inscr_guardian"
function evercraft:inscription/effects/stacks

# Classify recipients at the (stack-widened) radius for W2/W7 tiering.
function evercraft:inscription/effects/classify

# +2 armor per stack (add_value) → 2000 thousandths/stack.
scoreboard players set #inscr_attr_milli ec.temp 2000
data modify storage evercraft:inscription attr.id set value "evercraft:inscr_guardian"
data modify storage evercraft:inscription attr.name set value "armor"
data modify storage evercraft:inscription attr.op set value "add_value"
function evercraft:inscription/effects/apply_attr
