# ============================================================
# Inscription Stones — Recipient Classifier (W2 zone-tier + W7 party)
# Run as: marker (stone), at marker. Caller sets #inscr_radius ec.temp first.
# Tags every player within #inscr_radius blocks of the stone:
#   ec.inscr_full  — FULL strength  (in home zone OR guild zone OR a party member)
#   ec.inscr_weak  — WEAKER baseline (non-party, non-hostile, outside any zone)
# Hostile players (tag ec.pvp_hostile) get NEITHER tag → excluded from all auras.
#
# Hysteresis (W2, 4-block band): a recipient who was FULL last cycle stays FULL
# for one extra cycle (ec.inscr_was_full) so a player pacing a zone edge does not
# flicker full<->weak between the 2s zone tick and the 5s totem tick.
# ============================================================

# Determine the effective radius via macro (radius is dynamic per-effect/stack)
execute store result storage evercraft:inscription tier.r int 1 run scoreboard players get #inscr_radius ec.temp
function evercraft:inscription/effects/classify_macro with storage evercraft:inscription tier
