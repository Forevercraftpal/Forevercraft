# ============================================================
# Inscription Stones — Decimal Formatter (macro body)
# Called from fmt_milli.mcfunction with {i:<int>, f:<frac>, pad:<zero-pad>}.
# Writes attr.value = "<i>.<pad><f>" (e.g. i=0,f=700 -> "0.700"; i=0,f=50,pad="0" -> "0.050").
# ============================================================

$data modify storage evercraft:inscription attr.value set value "$(i).$(pad)$(f)"
