# Inscription Stone — Bulwark (Obsidian Glyph)
# Honest defense: Resistance (W5 rename — "Thornmail" was a fake reflect name; the
# true thorns-reflect now lives on Briar's consumer). Internal tag stays
# ec.inscr_thornmail; only the player-facing name + comments become "Bulwark".
# W2 zone-tier + W3 hybrid stacking + W7 party rules via the shared pipeline.
# Base: Resistance I (amp 0), radius 12. Stacking → up to Resistance III, radius up to 18.
scoreboard players set #inscr_base_amp ec.temp 0
scoreboard players set #inscr_base_radius ec.temp 12
data modify storage evercraft:inscription stack.tag set value "ec.inscr_thornmail"
function evercraft:inscription/effects/stacks
data modify storage evercraft:inscription apply.effect set value "resistance"
function evercraft:inscription/effects/apply_potion
