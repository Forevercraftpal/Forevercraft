# Inscription Stone — Force (Emberheart Glyph)
# +10% Attack Damage PER STACK (W1.2 stacking rewrite — was 1x for 7 stones).
# Magnitude = +0.10 * effective_stacks (up to +0.70 at 7), via attribute modifier.
# WEAK tier (wild / non-party) gets HALF (W2). Radius widens with stacks (W3).
scoreboard players set #inscr_base_amp ec.temp 0
scoreboard players set #inscr_base_radius ec.temp 12
data modify storage evercraft:inscription stack.tag set value "ec.inscr_force"
function evercraft:inscription/effects/stacks

# Classify recipients at the (stack-widened) radius for W2/W7 tiering.
function evercraft:inscription/effects/classify

# +0.10 attack damage per stack (multiplied_base) → 100 thousandths/stack.
scoreboard players set #inscr_attr_milli ec.temp 100
data modify storage evercraft:inscription attr.id set value "evercraft:inscr_force"
data modify storage evercraft:inscription attr.name set value "attack_damage"
data modify storage evercraft:inscription attr.op set value "add_multiplied_base"
function evercraft:inscription/effects/apply_attr
