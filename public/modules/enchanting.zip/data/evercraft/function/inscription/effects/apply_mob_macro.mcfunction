# ============================================================
# Inscription Stones — Hostile-Mob Applier (macro body)
# Called from apply_mob.mcfunction with {effect:.., r:.., amp_full:..}.
# Run as: marker (stone), at marker.
# ============================================================

$effect give @e[type=#evercraft:hostile_mobs,distance=..$(r)] $(effect) 7 $(amp_full) true
