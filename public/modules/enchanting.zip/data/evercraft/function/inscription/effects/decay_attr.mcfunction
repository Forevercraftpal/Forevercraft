# ============================================================
# Inscription Stones — Per-player attribute decay
# Run as: each player (from effects_tick, gated on stones existing).
# Strips the three inscription attribute modifiers so players who walked OUT of a
# totem's radius lose the buff. In-range players are re-added within the same cycle by
# their stones' apply_attr (idempotent remove+add), so there is no visible gap.
# (Potion-effect totems self-clean via their 7s duration; only attributes need this.)
# ============================================================

attribute @s attack_damage modifier remove evercraft:inscr_force
attribute @s armor modifier remove evercraft:inscr_guardian
attribute @s luck modifier remove evercraft:inscr_gold_greed
