# ============================================================
# Inscription Stones — Stack Count (macro body)
# Called from stacks.mcfunction with {tag:"ec.inscr_<type>"}.
# Run as: marker (stone), at marker.
# Counts every same-type stone within 48 blocks (includes self) into
# #inscr_stacks ec.temp. The LOCKED 1..7 clamp is applied by the caller.
# ============================================================

$execute as @e[type=marker,tag=ec.inscr_stone,tag=$(tag),distance=..48] run scoreboard players add #inscr_stacks ec.temp 1
