# ============================================================
# Inscription / Glyph Totem — Lifetime zone counts + milestones (F3)
# Run as: the player, immediately after a successful inscription (summon_marker).
# Reads the pool tag set during pool selection and increments the matching
# LIFETIME totem count, then fires milestone messages at 5 / 10 / 25 / 50.
#
# Three independent counts (Joseph's spec: "its own count" per zone):
#   hs.totems       — totems placed inside the player's OWN house
#   gs.totems       — totems placed inside the player's OWN guild zone
#   ec.wild_totems  — totems placed outside both house and guild
#
# NOTE: thresholds currently emit milestone TEXT only. Mechanical perks are a
# tracked followup (see BIG_BRAIN/10-pending) — "Display + threshold unlocks".
# ============================================================

# Route by pool tag (set in try_inscribe). Guild > Home > Personal/Wild, mirroring pool priority.
execute if entity @s[tag=ec.inscr_pool_guild] run function evercraft:inscription/totem_count_guild
execute if entity @s[tag=ec.inscr_pool_home] run function evercraft:inscription/totem_count_house
execute if entity @s[tag=ec.inscr_pool_personal] run function evercraft:inscription/totem_count_wild
