# Glyph Totem — Guild lifetime count + milestones (dark_aqua)
# Run as: the player (a member standing in their own guild zone).
scoreboard players add @s gs.totems 1

# Per-guild global tally (so a guild's combined total can be read later for perks).
# Keyed by guild id: fakeplayer "#gs_<id>" on gs.totems. Stage the id, then macro-increment.
execute store result storage evercraft:inscription totem_ctx.gid int 1 run scoreboard players get @s ec.guild_id
execute if score @s ec.guild_id matches 1.. run function evercraft:inscription/totem_count_guild_global with storage evercraft:inscription totem_ctx

# Milestones (REAL zone-power perks now — text announces the unlock). Exact-match so each fires once.
#   5  → +1 guild active-stone cap   10 → +1 radius on guild totems
#   25 → +1 guild active-stone cap (cumulative +2)   50 → +2 radius (cumulative +3)
execute if score @s gs.totems matches 5 run scoreboard players set @s ec.cap_bn_gs 1
data modify storage evercraft:notify stage.c set value [{text:"First Quintet — 5 guild totems set. ",color:"dark_aqua"},{text:"Unlocked: +1 guild totem slot.",color:"aqua"}]
scoreboard players set #ndur ec.temp 50
execute if score @s gs.totems matches 5 run function evercraft:util/notify/emit
execute if score @s gs.totems matches 10 run scoreboard players set @s ec.rad_bn_gs 1
data modify storage evercraft:notify stage.c set value [{text:"Ten Pillars — Your inscription takes shape. ",color:"dark_aqua"},{text:"Unlocked: +1 block radius on guild totems.",color:"aqua"}]
scoreboard players set #ndur ec.temp 50
execute if score @s gs.totems matches 10 run function evercraft:util/notify/emit
execute if score @s gs.totems matches 25 run scoreboard players set @s ec.cap_bn_gs 2
data modify storage evercraft:notify stage.c set value [{text:"Quarter Hundred — The ancient patterns deepen. ",color:"dark_aqua"},{text:"Unlocked: +1 guild totem slot (total +2).",color:"aqua"}]
scoreboard players set #ndur ec.temp 50
execute if score @s gs.totems matches 25 run function evercraft:util/notify/emit
execute if score @s gs.totems matches 50 run scoreboard players set @s ec.rad_bn_gs 3
data modify storage evercraft:notify stage.c set value [{text:"Half-Century — A potent network. ",color:"dark_aqua"},{text:"Unlocked: +2 block radius (total +3) on guild totems.",color:"aqua"}]
scoreboard players set #ndur ec.temp 50
execute if score @s gs.totems matches 50 run function evercraft:util/notify/emit
