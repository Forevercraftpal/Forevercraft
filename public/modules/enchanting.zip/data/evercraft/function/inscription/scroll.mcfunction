# ============================================================
# Inscription Stones — Scroll Self-Buff (W4, Joseph's D3 vote)
# Fired from ray/not_found: the glyph was used in-hand but NOT aimed at a
# polished_deepslate inscribe target, so it acts as a SCROLL — a short, weaker,
# SELF-ONLY burst of that glyph's theme. The glyph is CONSUMED (no restore).
# Spam guard: the rune item's own 5s use_cooldown component (cooldown_group
# "evercraft:treasure/rune") already gates re-use.
# Run as: the player, at the player. Glyph id is in ec.inscr_glyph (set in on_glyph_use).
#
# Per-glyph weak-instant (30s, amp 0 — a personal echo of the totem aura):
#   1 Emberheart  → Strength (searing strike)
#   2 Verdant     → Regeneration (a breath of green)
#   3 Quicksilver → Haste + Speed (running silver)
#   4 Obsidian    → Resistance (black-glass shell)
#   5 Zephyr      → Speed + Jump Boost (a lifting gust)
#   6 Briar       → Resistance (bristling thorns turn blows aside)
#   7 Stalwart    → Strength (plant your feet)
#   8 Gilded      → Luck (fortune glints)
#   9 Tidecall    → Regeneration (a healing wave)
#  10 Hearthstone → Absorption (a hearth-circle shelters you)
#  11 Prism       → Night Vision (light reveals)
#  12 Tempest     → Strength (a storm in your grip)
#  13 Arcanum     → one random positive boon (the wild unknown)
# ============================================================

execute if score @s ec.inscr_glyph matches 1 run effect give @s strength 30 0 true
execute if score @s ec.inscr_glyph matches 2 run effect give @s regeneration 30 0 true
execute if score @s ec.inscr_glyph matches 3 run effect give @s haste 30 0 true
execute if score @s ec.inscr_glyph matches 3 run effect give @s speed 30 0 true
execute if score @s ec.inscr_glyph matches 4 run effect give @s resistance 30 0 true
execute if score @s ec.inscr_glyph matches 5 run effect give @s speed 30 0 true
execute if score @s ec.inscr_glyph matches 5 run effect give @s jump_boost 30 0 true
execute if score @s ec.inscr_glyph matches 6 run effect give @s resistance 30 0 true
execute if score @s ec.inscr_glyph matches 7 run effect give @s strength 30 0 true
execute if score @s ec.inscr_glyph matches 8 run effect give @s luck 30 0 true
execute if score @s ec.inscr_glyph matches 9 run effect give @s regeneration 30 0 true
execute if score @s ec.inscr_glyph matches 10 run effect give @s absorption 30 0 true
execute if score @s ec.inscr_glyph matches 11 run effect give @s night_vision 30 0 true
execute if score @s ec.inscr_glyph matches 12 run effect give @s strength 30 0 true

# Arcanum: one random positive boon (matches the totem's "wild forces" theme).
execute if score @s ec.inscr_glyph matches 13 store result score #scroll_roll ec.temp run random value 1..6
execute if score @s ec.inscr_glyph matches 13 if score #scroll_roll ec.temp matches 1 run effect give @s speed 30 0 true
execute if score @s ec.inscr_glyph matches 13 if score #scroll_roll ec.temp matches 2 run effect give @s strength 30 0 true
execute if score @s ec.inscr_glyph matches 13 if score #scroll_roll ec.temp matches 3 run effect give @s regeneration 30 0 true
execute if score @s ec.inscr_glyph matches 13 if score #scroll_roll ec.temp matches 4 run effect give @s jump_boost 30 0 true
execute if score @s ec.inscr_glyph matches 13 if score #scroll_roll ec.temp matches 5 run effect give @s resistance 30 0 true
execute if score @s ec.inscr_glyph matches 13 if score #scroll_roll ec.temp matches 6 run effect give @s haste 30 0 true

# Feedback — the glyph kindles in the hand (lore §3F voice). Player text stays within
# the banned-word law (arcane/ancient/potent/power only).
data modify storage evercraft:notify stage.c set value [{text:"✦ The glyph kindles in your hand ✦",color:"gold",italic:false}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.6 1.2
particle minecraft:enchant ~ ~1 ~ 0.3 0.5 0.3 0.4 12

# Clear the glyph id so cleanup's restore branch never re-gives it (consumed as scroll).
scoreboard players reset @s ec.inscr_glyph

# Clear the pool-selection tags set by try_inscribe before the raycast (no inscribe
# happened, so no pool was consumed). Mirrors cleanup's pool-tag clear.
tag @s remove ec.inscr_pool_guild
tag @s remove ec.inscr_pool_home
tag @s remove ec.inscr_pool_personal
