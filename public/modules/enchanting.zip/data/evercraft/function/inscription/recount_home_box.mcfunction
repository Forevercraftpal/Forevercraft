# Inscription — Box count (macro {bx,by,bz}, run as @s). Part of recount_home (2026-06-19).
# Overwrites ec.inscr_home_count with the number of this player's home glyph-stones inside the
# active home's 64-block box [corner .. corner+128] (a 129-wide cube ~= the +/-64 home zone).
# `store result ... if entity @e[...]` yields the entity COUNT (same idiom as castle #ic_mobs).
$execute store result score @s ec.inscr_home_count if entity @e[type=marker,tag=ec.inscr_home_stone,x=$(bx),dx=128,y=$(by),dy=128,z=$(bz),dz=128]
