# Inscription — Check if newly placed stone completes a Rune Word
# @s = newly placed marker (tagged ec.inscr_new), at marker position

# Paradox (Force + Frostbite)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Rune Word Formed: ",color:"gray"},{text:"Paradox",color:"#FF6B6B",bold:true},{text:" — Resistance + Fire Resistance",color:"#FFD93D"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute if entity @s[tag=ec.inscr_force] if entity @e[type=marker,tag=ec.inscr_frostbite,tag=!ec.inscr_new,distance=..5,limit=1] as @a[distance=..24] run function evercraft:util/notify/emit
execute if entity @s[tag=ec.inscr_frostbite] if entity @e[type=marker,tag=ec.inscr_force,tag=!ec.inscr_new,distance=..5,limit=1] as @a[distance=..24] run function evercraft:util/notify/emit

# Updraft (Fortify + Wind) — renamed from "Tempest" to avoid the Tempest glyph name collision (W5)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Rune Word Formed: ",color:"gray"},{text:"Updraft",color:"#87CEEB",bold:true},{text:" — Jump Boost II",color:"#FFD93D"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute if entity @s[tag=ec.inscr_fortify] if entity @e[type=marker,tag=ec.inscr_wind,tag=!ec.inscr_new,distance=..5,limit=1] as @a[distance=..24] run function evercraft:util/notify/emit
execute if entity @s[tag=ec.inscr_wind] if entity @e[type=marker,tag=ec.inscr_fortify,tag=!ec.inscr_new,distance=..5,limit=1] as @a[distance=..24] run function evercraft:util/notify/emit

# Fury (Haste + Force)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Rune Word Formed: ",color:"gray"},{text:"Fury",color:"#E53935",bold:true},{text:" — Strength II",color:"#FFD93D"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute if entity @s[tag=ec.inscr_haste] if entity @e[type=marker,tag=ec.inscr_force,tag=!ec.inscr_new,distance=..5,limit=1] as @a[distance=..24] run function evercraft:util/notify/emit
execute if entity @s[tag=ec.inscr_force] if entity @e[type=marker,tag=ec.inscr_haste,tag=!ec.inscr_new,distance=..5,limit=1] as @a[distance=..24] run function evercraft:util/notify/emit

# Sanctuary (Absorption + Life Steal)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Rune Word Formed: ",color:"gray"},{text:"Sanctuary",color:"#66BB6A",bold:true},{text:" — Regeneration II",color:"#FFD93D"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute if entity @s[tag=ec.inscr_absorption] if entity @e[type=marker,tag=ec.inscr_life_steal,tag=!ec.inscr_new,distance=..5,limit=1] as @a[distance=..24] run function evercraft:util/notify/emit
execute if entity @s[tag=ec.inscr_life_steal] if entity @e[type=marker,tag=ec.inscr_absorption,tag=!ec.inscr_new,distance=..5,limit=1] as @a[distance=..24] run function evercraft:util/notify/emit

# Bastion (Guardian + Thornmail)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Rune Word Formed: ",color:"gray"},{text:"Bastion",color:"#5C6BC0",bold:true},{text:" — Resistance I Aura",color:"#FFD93D"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute if entity @s[tag=ec.inscr_guardian] if entity @e[type=marker,tag=ec.inscr_thornmail,tag=!ec.inscr_new,distance=..5,limit=1] as @a[distance=..24] run function evercraft:util/notify/emit
execute if entity @s[tag=ec.inscr_thornmail] if entity @e[type=marker,tag=ec.inscr_guardian,tag=!ec.inscr_new,distance=..5,limit=1] as @a[distance=..24] run function evercraft:util/notify/emit

# Oracle (Reveal + Wild Forces)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Rune Word Formed: ",color:"gray"},{text:"Oracle",color:"#AB47BC",bold:true},{text:" — Dreams + Night Vision",color:"#FFD93D"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
execute if entity @s[tag=ec.inscr_reveal] if entity @e[type=marker,tag=ec.inscr_wild_forces,tag=!ec.inscr_new,distance=..5,limit=1] as @a[distance=..24] run function evercraft:util/notify/emit
execute if entity @s[tag=ec.inscr_wild_forces] if entity @e[type=marker,tag=ec.inscr_reveal,tag=!ec.inscr_new,distance=..5,limit=1] as @a[distance=..24] run function evercraft:util/notify/emit

# Sound effect for any combo formed
playsound minecraft:block.beacon.activate master @a[distance=..24,scores={ec.fx_snd=1..}] ~ ~ ~ 0.6 1.5

# Remove the new tag
tag @s remove ec.inscr_new
