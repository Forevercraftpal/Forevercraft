# ============================================================
# Inscription — Recount THIS home's live glyph-stones (per-house cap fix, 2026-06-19)
# Run as @s, who is standing in their OWN active home zone (hs.in_zone=1, hs.active 1..5).
#
# WHY: ec.inscr_home_count was a single per-PLAYER running score, decremented ONLY when the owner
# personally broke/scraped a stone while ONLINE (on_break/scrape, UUID[3] match). Abandoning or
# relocating a home (housing never touches inscription), an offline-owner break, or a bulk-cleared
# deepslate all leak the count upward FOREVER — so a freshly-created home reads a maxed count and
# rejects the first glyph ("You cannot place more Inscription Stones!"). It was also shared across
# all 5 home slots, so it was never per-house.
#
# This recounts the ACTUAL home stones inside the ACTIVE home's 64-block box and overwrites
# ec.inscr_home_count, making the Home cap self-healing AND per-house (each home its own count,
# still separate from the wild/personal pool). Every ec.inscr_home_stone marker inside a player's
# OWN zone belongs to that player — the home pool requires hs.in_zone, so visitors can only land in
# the wild pool — therefore no owner filter is needed. Box mirrors housing/zone/slot_proximity_one.
# ============================================================

# Stage the active slot so the per-slot macro can read hs.h<n>_x/y/z.
execute store result storage evercraft:housing hrc.n int 1 run scoreboard players get @s hs.active
function evercraft:inscription/recount_home_slot with storage evercraft:housing hrc
