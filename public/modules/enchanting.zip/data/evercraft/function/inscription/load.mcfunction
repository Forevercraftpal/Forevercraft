# ============================================================
# Inscription Stones — Load
# Init scoreboards and start effects tick loop
# ============================================================

scoreboard objectives add ec.inscr_count dummy
scoreboard objectives add ec.inscr_guild_count dummy "Guild Zone Stones"
scoreboard objectives add ec.inscr_home_count dummy "Home Zone Stones"
scoreboard objectives add ec.inscr_owner dummy "Stone Owner ID"
scoreboard objectives add ec.inscr_glyph dummy "Glyph Type ID"
scoreboard objectives add ec.inscr_timer dummy "Glyph Totem Auto-Off Timer"

# F3: lifetime zone totem counts (house / guild / wild). Separate from the per-pool
# active-stone limits above — these are cumulative and drive milestone unlocks.
scoreboard objectives add hs.totems dummy "House Totems Placed (lifetime)"
scoreboard objectives add gs.totems dummy "Guild Totems Placed (lifetime)"
scoreboard objectives add ec.wild_totems dummy "Wild Totems Placed (lifetime)"

# Followup wave: milestone ZONE-POWER bonuses (per-player, per-zone). The 5/10/25/50
# lifetime counts above now unlock REAL perks (not just text). Two axes per zone:
#   ec.cap_bn_<z> = active-stone cap bonus  (5→+1, 25→+2)   read by try_inscribe
#   ec.rad_bn_<z> = totem radius bonus      (10→+1, 50→+3)  stamped onto each new stone
#                                                            (ec.inscr_rad_bonus) + added in stacks
# Zones: hs = home, gs = guild, wd = wild/personal. These STACK on top of the base caps
# (Guild 1 / Home 4 / Personal 3) and base radii — a DIFFERENT axis from same-type stacking.
scoreboard objectives add ec.cap_bn_hs dummy "Home Cap Bonus"
scoreboard objectives add ec.cap_bn_gs dummy "Guild Cap Bonus"
scoreboard objectives add ec.cap_bn_wd dummy "Wild Cap Bonus"
scoreboard objectives add ec.rad_bn_hs dummy "Home Radius Bonus"
scoreboard objectives add ec.rad_bn_gs dummy "Guild Radius Bonus"
scoreboard objectives add ec.rad_bn_wd dummy "Wild Radius Bonus"
# Per-stone radius bonus (stamped at placement from the placer's zone radius bonus).
scoreboard objectives add ec.inscr_rad_bonus dummy "Stone Radius Bonus"

# Clear stale tags that may survive a /reload (scheduled cleanup is lost on reload)
tag @a remove ec.inscr_placing
tag @a remove ec.inscr_restore

# NOTE (W1.3): the Arcanum stone type token was renamed (banned-word law). Any Arcanum
# stones placed BEFORE this update carry the old type tag and will no longer dispatch;
# they auto-expire on their 24000t (~20 min) timer and can simply be re-placed. No
# legacy-token migration is kept here so the source stays free of the banned word.

# Totem proc systems (House "Hearth's Blessing" + Guild "Standing Resonance" + Rally
# of Order): register scoreboards, bit-value consts, and the muteable notify key.
# House/Rally are per-player gametime-checkpointed (hooked on existing 1s/2s ticks);
# Guild proc is guild-keyed and runs on the 5s effects_tick (below).
function evercraft:inscription/procs/load

# Guild Standing-Resonance state survives /reload via fakeplayers (#resonance_*_<gid>)
# on the gs.resonance objective — register it so the guild-keyed snapshot persists.
scoreboard objectives add gs.resonance dummy "Guild Resonance Proc State"

# Start the effects/particles/break-check loop (5 seconds)
schedule function evercraft:inscription/effects_tick 100t
