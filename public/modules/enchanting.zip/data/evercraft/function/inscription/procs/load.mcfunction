# ============================================================
# Totem Procs — Load (called from inscription/load, which init.mcfunction runs)
# House passive proc (Hearth's Blessing) + Guild passive proc (Standing Resonance)
# + Rally of Order. Registers scoreboards + the bit-value consts the type picker uses.
# ============================================================

# --- Bit-value consts for the present-type bitmask picker (pick_type.mcfunction) ---
# Some of these already exist from other systems; re-setting is idempotent + cheap.
scoreboard players set #2 ec.const 2
scoreboard players set #4 ec.const 4
scoreboard players set #8 ec.const 8
scoreboard players set #16 ec.const 16
scoreboard players set #32 ec.const 32
scoreboard players set #64 ec.const 64
scoreboard players set #128 ec.const 128
scoreboard players set #256 ec.const 256
scoreboard players set #512 ec.const 512
scoreboard players set #1024 ec.const 1024

# --- House proc (per-player) ---
# ec.hb_until      = gametime checkpoint for next Hearth's Blessing proc (5min cadence)
# ec.house_types   = cached bitmask of buff-totem types present in the player's house
#                    (refreshed while the player is in their home zone; lets the proc
#                    fire ANYWHERE from the cache, like guild zone-coord lazy sync)
# ec.house_tcount  = cached count of distinct present house buff-types
scoreboard objectives add ec.hb_until dummy "Hearth's Blessing Next Proc (gametime)"
scoreboard objectives add ec.house_types dummy "House Buff-Totem Type Mask"
scoreboard objectives add ec.house_tcount dummy "House Buff-Totem Type Count"
# ec.home_gg_ct = cached count of GILDED (Gold Greed) totems in the player's home zone
#                 (0..7). Drives the persistent, zone-wide Dream Rate boost applied in
#                 housing/zone/apply_buffs (evercraft:inscr_home_gg). Refreshed by
#                 procs/house/cache_types while the owner stands in their home zone.
scoreboard objectives add ec.home_gg_ct dummy "Home Gilded Totem Count"

# --- Rally of Order (per-player recharge) ---
# ec.rally_cd_until = gametime stamp; Rally usable again only when now >= this value
scoreboard objectives add ec.rally_cd_until dummy "Rally of Order Recharge (gametime)"
# ec.rally_unlocked = 1 once the player has earned the Rally horn (500 contribution),
#                     so the grant fires exactly once on threshold crossing
scoreboard objectives add ec.rally_unlocked dummy "Rally of Order Horn Earned"

# --- Notify key: hearth (House proc chime, class:chatter, mute_at:3) ---
# Registered here AND in util/notify/load.mcfunction (the canonical notify registrar)
# so the per-key triggers are enabled at load — see util/notify/load for the contract.
scoreboard objectives add ec.nm_hearth trigger "Mute Hearth's Blessing"
scoreboard objectives add ec.un_hearth trigger "Unmute Hearth's Blessing"
scoreboard objectives add ach.mu_hearth dummy "Muted: Hearth"
scoreboard objectives add ach.nx_hearth dummy "Count: Hearth"
scoreboard players enable @a ec.nm_hearth
scoreboard players enable @a ec.un_hearth
