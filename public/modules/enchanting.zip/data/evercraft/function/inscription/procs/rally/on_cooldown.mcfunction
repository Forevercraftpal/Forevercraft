# Rally of Order — on-cooldown feedback (run as the presser).
# Shows remaining recharge in whole in-game days (216000t = 3 days, 72000t = 1 day).
scoreboard players operation #rally_left ec.var = @s ec.rally_cd_until
scoreboard players operation #rally_left ec.var -= #rally_now ec.var
scoreboard players operation #rally_left ec.var /= #72000 ec.const
data modify storage evercraft:notify stage.c set value [{text:"The Rally of Order is still recharging.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
