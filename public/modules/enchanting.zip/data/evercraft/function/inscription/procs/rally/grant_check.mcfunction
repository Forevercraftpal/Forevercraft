# ============================================================
# Rally of Order — Earn the banner-horn at 500 guild contribution (one-time grant)
# Run as: @s = a guilded player whose ec.guild_contrib just changed (called from
# guild/contribution/add after check_rank — the single chokepoint for contrib changes).
#
# Fires EXACTLY ONCE on crossing 500: gated by ec.rally_unlocked so re-reaching the
# threshold (or further contribution) never regrants. Models trophy/check_all's
# bit-gated one-time award shape.
# ============================================================

# Already earned → nothing to do.
execute if score @s ec.rally_unlocked matches 1.. run return 0
# Below threshold → not yet.
execute unless score @s ec.guild_contrib matches 500.. run return 0

# === Crossed 500 for the first time: grant the Rally of Order banner-horn. ===
scoreboard players set @s ec.rally_unlocked 1

give @s minecraft:goat_horn[custom_data={rally_of_order:true},custom_name={"text":"Rally of Order","color":"gold","italic":false},lore=[{"text":"Raise the banner-horn to rally","color":"gray","italic":false},{"text":"your guild — all guild totem","color":"gray","italic":false},{"text":"blessings flow to every member","color":"gray","italic":false},{"text":"for one minute, anywhere.","color":"gray","italic":false},{"text":"","italic":false},{"text":"Recharge: 3 days","color":"dark_gray","italic":false},{"text":"Requires guild membership","color":"dark_gray","italic":false}],item_model="minecraft:goat_horn",instrument={sound_event:"minecraft:item.goat_horn.sound.1",use_duration:7.0,range:256.0,description:"Rally of Order"}] 1

data modify storage evercraft:notify stage.c set value [{text:"You have earned the ",color:"gray"},{text:"Rally of Order",color:"gold",bold:true},{text:"! ",color:"gray"},{text:"Raise it to bless your whole guild — recharges every 3 days.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.0
