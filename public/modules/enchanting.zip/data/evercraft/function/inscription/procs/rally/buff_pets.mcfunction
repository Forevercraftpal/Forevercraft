# ============================================================
# Rally of Order — Pets get Regeneration II (kindred/owned-pet pattern)
# Run as: @s = a rallied guild member, AT @s (anywhere). Buffs the member's OWN tamed
# pets within range for 60s. Mirrors guild/zone/buff_member_pets but owner-scoped to @s.
# ============================================================

tag @s add ec.rally_pet_owner
execute as @e[type=#evercraft:zone_protected_pets,distance=..32] run function evercraft:inscription/procs/rally/buff_pet_one
tag @s remove ec.rally_pet_owner
