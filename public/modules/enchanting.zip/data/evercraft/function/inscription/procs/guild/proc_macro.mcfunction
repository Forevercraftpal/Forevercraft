# ============================================================
# Guild Proc — Standing Resonance (macro body, GUILD-KEYED)
# Args: {gid:<guild id>}
# Run as: @s = an online member of guild $(gid). #res_now ec.var = current gametime.
# Decomposed into idempotent stages so concurrent same-guild members converge.
# ============================================================

# Stage gate: guild must have at least one cached buff-totem type.
$execute unless score #resonance_cnt_$(gid) gs.resonance matches 1.. run return 0

# Stage 1 — ARM on first sight (slot unset): schedule the first proc one full interval
# out (now + 18000) so a guild gaining its first totem doesn't resonate on the next tick.
# Capture "was unset" into a flag FIRST so the subsequent writes don't invalidate the guard.
scoreboard players set #res_armed ec.temp 0
$execute unless score #resonance_until_$(gid) gs.resonance matches -2147483648.. run scoreboard players set #res_armed ec.temp 1
$execute if score #res_armed ec.temp matches 1 store result score #resonance_until_$(gid) gs.resonance run scoreboard players get #res_now ec.var
$execute if score #res_armed ec.temp matches 1 run scoreboard players add #resonance_until_$(gid) gs.resonance 18000
execute if score #res_armed ec.temp matches 1 run return 0

# Stage 2 — DUE check. If not yet due, skip (another member may arm/fire this tick).
$execute if score #res_now ec.var < #resonance_until_$(gid) gs.resonance run return 0

# === DUE: this member is the first to cross the checkpoint for guild $(gid) this tick ===

# Re-arm the GUILD slot FIRST (idempotent): now + 18000 (15 min). Any sibling member
# processing later this tick reads the new value and bails at Stage 2 → single fire.
$execute store result score #resonance_until_$(gid) gs.resonance run scoreboard players get #res_now ec.var
$scoreboard players add #resonance_until_$(gid) gs.resonance 18000

# Roll a random present buff-type from the guild-keyed cache → #proc_type.
$scoreboard players operation #proc_typemask ec.temp = #resonance_mask_$(gid) gs.resonance
$scoreboard players operation #proc_typecount ec.temp = #resonance_cnt_$(gid) gs.resonance
function evercraft:inscription/procs/grant/pick_type
# Persist the chosen type guild-keyed (race seat: guild-keyed slot, not global).
$execute store result score #resonance_type_$(gid) gs.resonance run scoreboard players get #proc_type ec.temp

# Event-push the chosen type to ALL members of guild $(gid) for 60s — works ANYWHERE
# (the timed effect travels with each member; no per-tick cross-world scan).
data modify storage evercraft:inscription proc.dur set value 60
$execute as @a[scores={ec.guild_id=$(gid)}] run function evercraft:inscription/procs/guild/apply_member with storage evercraft:inscription proc

# Announce to the guild (alert class via the action-bar queue to members) + soft chime.
data modify storage evercraft:notify stage.c set value [{text:"Standing Resonance ",color:"aqua",italic:true},{text:"rises from the guild totems — a blessing for 1 minute.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 50
$execute as @a[scores={ec.guild_id=$(gid)}] run function evercraft:util/notify/emit
$execute as @a[scores={ec.guild_id=$(gid)}] at @s if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.3 0.9
