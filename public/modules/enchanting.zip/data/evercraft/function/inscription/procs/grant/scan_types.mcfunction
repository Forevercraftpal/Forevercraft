# ============================================================
# Totem Procs — Present buff-type scan (macro)
# Args: {pool:"ec.inscr_home_stone"|"ec.inscr_guild_stone", r:<radius>}
# Run AT a scan origin (player position for house in-zone; guild zone coords for guild).
# Produces:
#   #proc_typemask ec.temp = bitmask of buff-granting totem TYPES present in range
#                            (bit (id-1) set if at least one stone of that type exists)
#   #proc_typecount ec.temp= popcount of distinct buff-granting types present (0..10)
# Only the 10 PLAYER-BUFF types are scanned (growth/reveal/frostbite excluded — they
# grant no player buff). Each type contributes at most one bit regardless of stacking,
# so the random roll picks a TYPE (the spec's "random house/guild totem TYPE").
# ============================================================

scoreboard players set #proc_typemask ec.temp 0
scoreboard players set #proc_typecount ec.temp 0

# id 1  force      (bit 1)
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_force,distance=..$(r),limit=1] run scoreboard players add #proc_typemask ec.temp 1
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_force,distance=..$(r),limit=1] run scoreboard players add #proc_typecount ec.temp 1
# id 3  haste      (bit 4)
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_haste,distance=..$(r),limit=1] run scoreboard players add #proc_typemask ec.temp 4
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_haste,distance=..$(r),limit=1] run scoreboard players add #proc_typecount ec.temp 1
# id 4  thornmail/Bulwark (bit 8)
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_thornmail,distance=..$(r),limit=1] run scoreboard players add #proc_typemask ec.temp 8
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_thornmail,distance=..$(r),limit=1] run scoreboard players add #proc_typecount ec.temp 1
# id 5  wind       (bit 16)
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_wind,distance=..$(r),limit=1] run scoreboard players add #proc_typemask ec.temp 16
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_wind,distance=..$(r),limit=1] run scoreboard players add #proc_typecount ec.temp 1
# id 6  guardian   (bit 32)
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_guardian,distance=..$(r),limit=1] run scoreboard players add #proc_typemask ec.temp 32
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_guardian,distance=..$(r),limit=1] run scoreboard players add #proc_typecount ec.temp 1
# id 7  fortify    (bit 64)
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_fortify,distance=..$(r),limit=1] run scoreboard players add #proc_typemask ec.temp 64
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_fortify,distance=..$(r),limit=1] run scoreboard players add #proc_typecount ec.temp 1
# id 8  gold_greed (bit 128)
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_gold_greed,distance=..$(r),limit=1] run scoreboard players add #proc_typemask ec.temp 128
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_gold_greed,distance=..$(r),limit=1] run scoreboard players add #proc_typecount ec.temp 1
# id 9  life_steal/Renewal (bit 256)
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_life_steal,distance=..$(r),limit=1] run scoreboard players add #proc_typemask ec.temp 256
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_life_steal,distance=..$(r),limit=1] run scoreboard players add #proc_typecount ec.temp 1
# id 10 absorption (bit 512)
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_absorption,distance=..$(r),limit=1] run scoreboard players add #proc_typemask ec.temp 512
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_absorption,distance=..$(r),limit=1] run scoreboard players add #proc_typecount ec.temp 1
# id 13 wild_forces (bit 1024)
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_wild_forces,distance=..$(r),limit=1] run scoreboard players add #proc_typemask ec.temp 1024
$execute if entity @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=$(pool),tag=ec.inscr_wild_forces,distance=..$(r),limit=1] run scoreboard players add #proc_typecount ec.temp 1
