# ============================================================
# Rally of Order — Stage 2: guild-keyed snapshot + guild-wide fan-out
# Run as: @s = the presser (already gated + recharge-stamped by on_use). #rally_now =
# current gametime. Decomposes into a GUILD-KEYED idempotent snapshot so simultaneous
# pressers from the same guild converge on one rally (trigger-count irrelevant — they
# all write the same slot to the same value).
# ============================================================

execute store result storage evercraft:inscription rally.gid int 1 run scoreboard players get @s ec.guild_id
function evercraft:inscription/procs/rally/trigger_macro with storage evercraft:inscription rally
