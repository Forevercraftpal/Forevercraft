# ============================================================
# Rally of Order — Stage 1: per-presser gated trigger + recharge stamp
# Run as: @s = the player who raised the Rally banner-horn (using_item advancement).
# Advancement is revoked immediately so the horn can be used again later.
#
# Gates (in order): debounce → guild membership → hold the horn → per-player recharge.
# On success: stamp the player's 3-day recharge, then hand off to the GUILD-KEYED
# snapshot stage (Stage 2). Decomposed so multiple members raising horns at once
# converge on the same guild slot (trigger-count irrelevant).
# ============================================================

advancement revoke @s only evercraft:inscription/use_rally

# --- Debounce: using_item fires every tick while the horn is held (whistle pattern). ---
execute if entity @s[tag=ec.rally_cd] run return 0
tag @s add ec.rally_cd
schedule function evercraft:inscription/procs/rally/cd_clear 10t

# --- Gate: must be in a guild. ---
data modify storage evercraft:notify stage.c set value [{text:"Only guild members can sound the Rally of Order.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.guild_id matches 1.. run return run function evercraft:util/notify/emit

# --- Gate: must actually be holding the Rally horn (either hand). The using_item
# advancement already fires only for a rally_of_order goat_horn (from either hand), so
# this is a defensive belt-and-suspenders check — accept mainhand OR offhand. ---
execute unless items entity @s weapon.* *[custom_data~{rally_of_order:true}] run return 0

# --- Gate: per-player 3-day recharge (gametime-delta). Compare now vs the stored stamp. ---
execute store result score #rally_now ec.var run time query gametime
execute if score @s ec.rally_cd_until matches 1.. if score #rally_now ec.var < @s ec.rally_cd_until run function evercraft:inscription/procs/rally/on_cooldown
execute if score @s ec.rally_cd_until matches 1.. if score #rally_now ec.var < @s ec.rally_cd_until run return 0

# --- Success: stamp this player's recharge (now + 3 in-game days = 216000 gametime ticks). ---
scoreboard players operation @s ec.rally_cd_until = #rally_now ec.var
scoreboard players add @s ec.rally_cd_until 216000

# Hand off to the guild-keyed snapshot + guild-wide fan-out (Stage 2).
function evercraft:inscription/procs/rally/trigger
