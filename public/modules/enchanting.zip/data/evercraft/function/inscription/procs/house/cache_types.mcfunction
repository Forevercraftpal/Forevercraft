# ============================================================
# House Proc — Cache present buff-totem types (Hearth's Blessing)
# Run as: @s = a player standing IN their own home zone (hs.in_zone = 1), at @s.
# Called from housing/zone/apply_buffs (already runs at the player while in-zone).
#
# Scans home-pool stones within the home zone radius (64) and caches the present
# buff-totem TYPE bitmask + count on the player. The 5-min proc (proc.mcfunction)
# then fires ANYWHERE off this cache — the buff travels with the player (LOCKED
# event-push pattern), so we never scan the (possibly unloaded) home chunk while away.
# ============================================================

function evercraft:inscription/procs/grant/scan_types {pool:"ec.inscr_home_stone",r:64}
scoreboard players operation @s ec.house_types = #proc_typemask ec.temp
scoreboard players operation @s ec.house_tcount = #proc_typecount ec.temp

# Gilded count: how many active Gold Greed (Gilded) totems are placed in this home zone,
# capped at 7 (matches the same-type stacking cap). housing/zone/apply_buffs reads this
# to apply a persistent, zone-wide Dream Rate boost (evercraft:inscr_home_gg) that covers
# the WHOLE home — not just the 12-block totem aura — so a gilded totem at home ALWAYS
# provides its DR while the owner is home. One @e scan, gated by this whole function only
# running while in-zone.
scoreboard players set #gg_ct ec.temp 0
execute as @e[type=marker,tag=ec.inscr_stone,tag=ec.inscr_active,tag=ec.inscr_home_stone,tag=ec.inscr_gold_greed,distance=..64] run scoreboard players add #gg_ct ec.temp 1
execute if score #gg_ct ec.temp matches 8.. run scoreboard players set #gg_ct ec.temp 7
scoreboard players operation @s ec.home_gg_ct = #gg_ct ec.temp
