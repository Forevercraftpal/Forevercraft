# Clear Rally of Order debounce tag (0.5s) — using_item fires every tick while held.
tag @a remove ec.rally_cd
