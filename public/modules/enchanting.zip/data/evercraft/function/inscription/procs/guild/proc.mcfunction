# ============================================================
# Guild Proc — Standing Resonance driver (per online guilded member, GUILD-KEYED state)
# Run as: @s = an online player with ec.guild_id >= 1, on the 5s effects_tick.
# Caller computes #res_now ec.var = current gametime ONCE per batch.
#
# Cadence: 1-min buff every 15 min (18000 ticks). State is keyed by guild id on
# gs.resonance fakeplayers (#resonance_until_<gid> / #resonance_type_<gid>), NOT
# per-player and NOT global — RACE seat lock. Multiple members of the SAME guild
# processing in one tick converge: the first to cross the checkpoint re-arms the
# guild slot and fires the event-push to ALL members; the rest see "not due" and skip.
# Simultaneous triggers write the same slot to the same value → trigger-count irrelevant.
# ============================================================

# Gate: only buff-totem types present in the guild can resonate.
# (#resonance_cnt_<gid> is cached by guild/zone cache_types while a member is in-zone.)
execute store result storage evercraft:inscription proc.gid int 1 run scoreboard players get @s ec.guild_id
function evercraft:inscription/procs/guild/proc_macro with storage evercraft:inscription proc
