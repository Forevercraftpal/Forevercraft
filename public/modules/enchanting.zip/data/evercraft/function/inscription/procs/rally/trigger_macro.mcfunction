# ============================================================
# Rally of Order — Stage 2 (macro body, GUILD-KEYED snapshot + fan-out)
# Args: {gid:<guild id>}
# Run as: @s = the presser. #rally_now ec.var = current gametime.
# ============================================================

# Idempotent convergence: if a rally is ALREADY active for this guild (#rally_until_<gid>
# in the future), a simultaneous/late presser converges — no second fan-out. The presser
# still paid their own recharge stamp (per-player), matching the locked multi-trigger rule.
data modify storage evercraft:notify stage.c set value [{text:"The Rally of Order already echoes across your guild.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
$execute if score #rally_until_$(gid) gs.resonance matches 1.. if score #rally_now ec.var < #rally_until_$(gid) gs.resonance run return run function evercraft:util/notify/emit

# Opportunistic fresh scan: if the presser is standing in the guild zone (hall chunk is
# loaded), refresh the guild's cached buff-type mask so the Rally reflects CURRENT totems.
# Otherwise we fall back to the last cached mask (refreshed by guild/zone while in-zone).
execute if score @s ec.guild_in_zone matches 1 at @s run function evercraft:inscription/procs/guild/cache_types_macro with storage evercraft:inscription rally

# Snapshot the guild buff-type mask for this rally (GUILD-KEYED slot, not global).
# EXCLUDE Gold Greed (bit 128) from the Rally buff set — Joseph's D1 soft luck fix.
$scoreboard players operation #rally_types_$(gid) gs.resonance = #resonance_mask_$(gid) gs.resonance
# Clear bit 128 (gold_greed) if present: if (mask / 128) % 2 == 1, subtract 128.
$scoreboard players operation #rally_gg ec.temp = #rally_types_$(gid) gs.resonance
scoreboard players operation #rally_gg ec.temp /= #128 ec.const
scoreboard players operation #rally_gg ec.temp %= #2 ec.const
$execute if score #rally_gg ec.temp matches 1 run scoreboard players remove #rally_types_$(gid) gs.resonance 128

# Mark the rally active for 60s (1200 ticks) on the GUILD slot.
$execute store result score #rally_until_$(gid) gs.resonance run scoreboard players get #rally_now ec.var
$scoreboard players add #rally_until_$(gid) gs.resonance 1200

# === Fan out ALL snapshotted guild totem buffs to EVERY member, anywhere (event-push) ===
# 60s duration; the timed effects travel with each member (LOCKED party-anywhere pattern).
# dispatch + wild_forces always read dur from the shared 'proc' storage — set it here.
data modify storage evercraft:inscription proc.dur set value 60
$execute as @a[scores={ec.guild_id=$(gid)}] run function evercraft:inscription/procs/rally/apply_member with storage evercraft:inscription rally

# Pets get Regeneration II (kindred/owned-pet pattern) near each rallied member, anywhere.
$execute as @a[scores={ec.guild_id=$(gid)}] at @s run function evercraft:inscription/procs/rally/buff_pets

# Guild-wide announcement + the banner-horn goat-horn sound.
data modify storage evercraft:notify stage.c set value [{text:"Rally of Order! ",color:"yellow",bold:true},{text:"Every guild totem blessing surges to all members for 1 minute.",color:"gray"}]
scoreboard players set #ndur ec.temp 50
$execute as @a[scores={ec.guild_id=$(gid)}] run function evercraft:util/notify/emit
$execute as @a[scores={ec.guild_id=$(gid)}] at @s run playsound minecraft:item.goat_horn.sound.1 master @a[scores={ec.fx_snd=1..}] ~ ~ ~ 1.0 1.0
$execute as @a[scores={ec.guild_id=$(gid)}] at @s if score @s ec.fx_vis matches 1.. run particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.6 0.4 0.1 20
