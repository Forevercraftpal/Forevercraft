# ============================================================
# Guild Proc — Apply Standing Resonance to one member (macro)
# Args: {gid:<guild id>, dur:<seconds>}
# Run as: @s = a member of guild $(gid), via the event-push @a[scores={ec.guild_id=$(gid)}].
# Loads the guild's chosen type from the guild-keyed slot (so every member gets the
# SAME type even if #proc_type were mutated mid-loop) and grants it for $(dur)s.
# ============================================================

$scoreboard players operation #proc_type ec.temp = #resonance_type_$(gid) gs.resonance
function evercraft:inscription/procs/grant/dispatch with storage evercraft:inscription proc
