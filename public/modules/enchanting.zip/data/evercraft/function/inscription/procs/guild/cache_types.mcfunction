# ============================================================
# Guild Proc — Cache present buff-totem types (Standing Resonance), guild-keyed
# Run as: @s = a guild member standing IN their guild zone (ec.guild_in_zone = 1), at @s.
# Called from guild/zone/apply_buffs (already runs at the member while in-zone).
#
# Scans guild-pool stones within the guild zone radius (128) and caches the present
# buff-totem TYPE bitmask + count GUILD-KEYED (fakeplayers #resonance_mask_<gid> /
# #resonance_cnt_<gid> on gs.resonance). The 15-min proc fires off this cache so it
# works even when the guild hall chunk is unloaded. Guild-keyed (not per-player) so
# all members of a guild share one snapshot — RACE seat lock.
# ============================================================

execute store result storage evercraft:inscription proc.gid int 1 run scoreboard players get @s ec.guild_id
function evercraft:inscription/procs/guild/cache_types_macro with storage evercraft:inscription proc
