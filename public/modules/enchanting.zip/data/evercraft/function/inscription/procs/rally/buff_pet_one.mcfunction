# ============================================================
# Rally of Order — Buff one pet if owned by the rallying member
# Run as: @s = a tameable pet near the rallying member (the member is tagged
# ec.rally_pet_owner). Grants Regeneration II (60s) only if this pet's owner is that
# member. Mirrors guild/zone/buff_member_pets' "execute on owner" ownership check.
# ============================================================

scoreboard players set #rally_pet_ok ec.temp 0
execute on owner if entity @s[tag=ec.rally_pet_owner] run scoreboard players set #rally_pet_ok ec.temp 1
execute if score #rally_pet_ok ec.temp matches 1 run effect give @s regeneration 60 1 true
