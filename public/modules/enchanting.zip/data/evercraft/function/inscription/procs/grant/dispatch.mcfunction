# ============================================================
# Totem Procs — Event-Push Buff Grant Dispatcher (macro)
# Args: {type:<1..13 glyph id>, dur:<seconds>}
# Run as: @s = the RECIPIENT player (House proc target, or a guild member via the
#   ec.guild_id event-push selector). The buff TRAVELS WITH the player for $(dur)
#   seconds — this is the LOCKED party-anywhere pattern: a single timed effect-give,
#   never a per-tick cross-world re-scan.
#
# These grants MIRROR Agent A's per-type effect definitions (effects/<type>.mcfunction)
# but route the buff to a remote recipient instead of proximity-scanning from the stone.
# Attribute-based totems (force/guardian/gold_greed) map to their auto-expiring potion
# equivalent (strength/resistance/luck) so a timed proc needs NO attribute-strip
# bookkeeping across remote players — the effect simply expires.
#
# Buff-granting types only (10 of 13). The 3 non-player-buff totems are NO-OPs here:
#   2  growth   — area crop bone-meal (no player buff)
#   11 reveal   — Glowing on hostile mobs (no player buff)
#   12 frostbite— Slowness/Weakness on hostile mobs (no player buff)
# House/Guild/Rally type-rolls already exclude these ids, so they never reach here,
# but the dispatcher is defensive (an unmatched id is simply a no-op).
# ============================================================

# 1  Force (Emberheart)      → Strength   (mirrors attack_damage attribute aura)
$execute if score #proc_type ec.temp matches 1 run effect give @s strength $(dur) 0 true
# 3  Haste (Quicksilver)     → Haste
$execute if score #proc_type ec.temp matches 3 run effect give @s haste $(dur) 0 true
# 4  Bulwark (Obsidian)      → Resistance
$execute if score #proc_type ec.temp matches 4 run effect give @s resistance $(dur) 0 true
# 5  Wind (Zephyr)           → Speed + Jump Boost
$execute if score #proc_type ec.temp matches 5 run effect give @s speed $(dur) 0 true
$execute if score #proc_type ec.temp matches 5 run effect give @s jump_boost $(dur) 0 true
# 6  Guardian (Briar)        → Resistance (mirrors armor attribute aura)
$execute if score #proc_type ec.temp matches 6 run effect give @s resistance $(dur) 0 true
# 7  Fortify (Stalwart)      → Strength
$execute if score #proc_type ec.temp matches 7 run effect give @s strength $(dur) 0 true
# 8  Gold Greed (Gilded)     → Luck  (Rally EXCLUDES this id — D1 soft luck fix)
$execute if score #proc_type ec.temp matches 8 run effect give @s luck $(dur) 0 true
# 9  Renewal (Tidecall)      → Regeneration
$execute if score #proc_type ec.temp matches 9 run effect give @s regeneration $(dur) 0 true
# 10 Absorption (Hearthstone)→ Absorption
$execute if score #proc_type ec.temp matches 10 run effect give @s absorption $(dur) 0 true
# 13 Wild Forces (Arcanum)   → random 1-of-6 (mirrors mysterious_effect roll)
execute if score #proc_type ec.temp matches 13 run function evercraft:inscription/procs/grant/wild_forces with storage evercraft:inscription proc
