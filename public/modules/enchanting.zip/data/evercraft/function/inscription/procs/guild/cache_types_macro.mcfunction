# ============================================================
# Guild Proc — Cache types (macro body)
# Args: {gid:<guild id>}
# Run AT a guild member in their guild zone. Scans guild stones (128 radius) and writes
# the present buff-type bitmask + count to the guild-keyed slots on gs.resonance.
# ============================================================

function evercraft:inscription/procs/grant/scan_types {pool:"ec.inscr_guild_stone",r:128}
$execute store result score #resonance_mask_$(gid) gs.resonance run scoreboard players get #proc_typemask ec.temp
$execute store result score #resonance_cnt_$(gid) gs.resonance run scoreboard players get #proc_typecount ec.temp
