# ============================================================
# Totem Procs — Wild Forces (Arcanum) random buff grant (macro)
# Args: {dur:<seconds>}
# Run as: @s = the RECIPIENT player. Mirrors effects/mysterious_effect.mcfunction's
# 1-of-6 positive-effect roll, but applied to a single remote recipient (event-push).
# ============================================================
execute store result score #proc_wf_roll ec.temp run random value 1..6
$execute if score #proc_wf_roll ec.temp matches 1 run effect give @s speed $(dur) 0 true
$execute if score #proc_wf_roll ec.temp matches 2 run effect give @s strength $(dur) 0 true
$execute if score #proc_wf_roll ec.temp matches 3 run effect give @s regeneration $(dur) 0 true
$execute if score #proc_wf_roll ec.temp matches 4 run effect give @s jump_boost $(dur) 0 true
$execute if score #proc_wf_roll ec.temp matches 5 run effect give @s resistance $(dur) 0 true
$execute if score #proc_wf_roll ec.temp matches 6 run effect give @s haste $(dur) 0 true
