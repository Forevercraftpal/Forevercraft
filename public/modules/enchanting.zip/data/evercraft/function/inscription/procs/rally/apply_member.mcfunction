# ============================================================
# Rally of Order — Stage 3: apply ALL snapshotted guild buffs to one member (macro)
# Args: {gid:<guild id>, dur:<seconds>}
# Run as: @s = a member of guild $(gid), via the event-push @a[scores={ec.guild_id=$(gid)}].
# Loads the guild's snapshotted buff-type mask (#rally_types_<gid>, Gold-Greed already
# excluded) and grants EVERY present type for $(dur)s. Location-free: timed effects
# travel with the member (LOCKED party-anywhere pattern).
# ============================================================

$scoreboard players operation #rally_mask ec.temp = #rally_types_$(gid) gs.resonance

# For each present buff-type bit, set #proc_type and grant via the shared dispatcher.
# (Gold Greed / id 8 / bit 128 was stripped from the mask in trigger_macro — never granted.)

# id 1 force (bit 1)
scoreboard players operation #rally_b ec.temp = #rally_mask ec.temp
scoreboard players operation #rally_b ec.temp %= #2 ec.const
execute if score #rally_b ec.temp matches 1 run scoreboard players set #proc_type ec.temp 1
execute if score #rally_b ec.temp matches 1 run function evercraft:inscription/procs/grant/dispatch with storage evercraft:inscription proc
# id 3 haste (bit 4)
scoreboard players operation #rally_b ec.temp = #rally_mask ec.temp
scoreboard players operation #rally_b ec.temp /= #4 ec.const
scoreboard players operation #rally_b ec.temp %= #2 ec.const
execute if score #rally_b ec.temp matches 1 run scoreboard players set #proc_type ec.temp 3
execute if score #rally_b ec.temp matches 1 run function evercraft:inscription/procs/grant/dispatch with storage evercraft:inscription proc
# id 4 thornmail/Bulwark (bit 8)
scoreboard players operation #rally_b ec.temp = #rally_mask ec.temp
scoreboard players operation #rally_b ec.temp /= #8 ec.const
scoreboard players operation #rally_b ec.temp %= #2 ec.const
execute if score #rally_b ec.temp matches 1 run scoreboard players set #proc_type ec.temp 4
execute if score #rally_b ec.temp matches 1 run function evercraft:inscription/procs/grant/dispatch with storage evercraft:inscription proc
# id 5 wind (bit 16)
scoreboard players operation #rally_b ec.temp = #rally_mask ec.temp
scoreboard players operation #rally_b ec.temp /= #16 ec.const
scoreboard players operation #rally_b ec.temp %= #2 ec.const
execute if score #rally_b ec.temp matches 1 run scoreboard players set #proc_type ec.temp 5
execute if score #rally_b ec.temp matches 1 run function evercraft:inscription/procs/grant/dispatch with storage evercraft:inscription proc
# id 6 guardian (bit 32)
scoreboard players operation #rally_b ec.temp = #rally_mask ec.temp
scoreboard players operation #rally_b ec.temp /= #32 ec.const
scoreboard players operation #rally_b ec.temp %= #2 ec.const
execute if score #rally_b ec.temp matches 1 run scoreboard players set #proc_type ec.temp 6
execute if score #rally_b ec.temp matches 1 run function evercraft:inscription/procs/grant/dispatch with storage evercraft:inscription proc
# id 7 fortify (bit 64)
scoreboard players operation #rally_b ec.temp = #rally_mask ec.temp
scoreboard players operation #rally_b ec.temp /= #64 ec.const
scoreboard players operation #rally_b ec.temp %= #2 ec.const
execute if score #rally_b ec.temp matches 1 run scoreboard players set #proc_type ec.temp 7
execute if score #rally_b ec.temp matches 1 run function evercraft:inscription/procs/grant/dispatch with storage evercraft:inscription proc
# id 8 gold_greed (bit 128) — EXCLUDED (mask bit already cleared); no branch.
# id 9 life_steal/Renewal (bit 256)
scoreboard players operation #rally_b ec.temp = #rally_mask ec.temp
scoreboard players operation #rally_b ec.temp /= #256 ec.const
scoreboard players operation #rally_b ec.temp %= #2 ec.const
execute if score #rally_b ec.temp matches 1 run scoreboard players set #proc_type ec.temp 9
execute if score #rally_b ec.temp matches 1 run function evercraft:inscription/procs/grant/dispatch with storage evercraft:inscription proc
# id 10 absorption (bit 512)
scoreboard players operation #rally_b ec.temp = #rally_mask ec.temp
scoreboard players operation #rally_b ec.temp /= #512 ec.const
scoreboard players operation #rally_b ec.temp %= #2 ec.const
execute if score #rally_b ec.temp matches 1 run scoreboard players set #proc_type ec.temp 10
execute if score #rally_b ec.temp matches 1 run function evercraft:inscription/procs/grant/dispatch with storage evercraft:inscription proc
# id 13 wild_forces (bit 1024)
scoreboard players operation #rally_b ec.temp = #rally_mask ec.temp
scoreboard players operation #rally_b ec.temp /= #1024 ec.const
scoreboard players operation #rally_b ec.temp %= #2 ec.const
execute if score #rally_b ec.temp matches 1 run scoreboard players set #proc_type ec.temp 13
execute if score #rally_b ec.temp matches 1 run function evercraft:inscription/procs/grant/dispatch with storage evercraft:inscription proc
