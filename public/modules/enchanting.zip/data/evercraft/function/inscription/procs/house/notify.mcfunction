# ============================================================
# House Proc — Hearth's Blessing notification + gentle amethyst chime (muteable)
# Run as: @s = the player who just received the proc buff.
# Uses the canonical muteable-notify pattern (util/notify/dispatch). class:chatter so
# it respects the global notify filter; per-key mute via the [Mute] button + ecodex.
# ============================================================

function evercraft:util/notify/dispatch {key:"hearth",class:"chatter",mute_at:3}
execute if score #notif_show_hearth ec.temp matches 0 run return 0

# Gentle, low-volume amethyst chime — non-annoying because it repeats every 5 min.
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.25 1.2

# Action-bar frame (chat→action-bar migration): the dispatch early-return above is the
# #notif_show_hearth gate. Leading indent dropped; ❖ §4-mirrored. The [Mute] button STAYS
# in chat (§3b RESOLVED — it only renders after the mute_at threshold).
data modify storage evercraft:notify stage.c set value [{text:"❖ ",color:"#C9A0FF"},{text:"Hearth's Blessing ",color:"#C9A0FF",italic:true},{text:"flows from your home totems.",color:"gray",italic:true},{text:" ❖",color:"#C9A0FF"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score #notif_show_mute_hearth ec.temp matches 1 run tellraw @s [{text:"  ",color:"dark_gray"},{text:"[Mute]",color:"dark_gray",hover_event:{action:"show_text",value:{text:"Stop showing the Hearth's Blessing chime.",color:"gray"}},click_event:{action:"run_command",command:"/trigger ec.nm_hearth set 1"}}]
