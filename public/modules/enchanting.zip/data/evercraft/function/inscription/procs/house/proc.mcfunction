# ============================================================
# House Proc — Hearth's Blessing (per-player, 10s buff every 5 min = 6000 ticks)
# Run as: @s = a player with a home (hs.tier >= 1), at @s.
# Caller (housing/tick) computes #hb_now ec.var = current gametime ONCE per batch.
#
# Cadence is a per-player gametime CHECKPOINT (ec.hb_until), NOT a scheduler — it
# rides the existing 2s housing tick. A random one of the player's HOUSE buff-totem
# types (cached in ec.house_types by cache_types) applies to the player for 10s.
# Works anywhere: the timed effect travels with the player (LOCKED event-push pattern).
# ============================================================

# Gate: must have at least one cached buff-totem type in the house.
execute unless score @s ec.house_tcount matches 1.. run return 0

# First-seen players (ec.hb_until unset) get armed: schedule their FIRST proc one full
# interval out so logging in doesn't instantly fire. Capture "was unset" into a flag
# FIRST so the subsequent writes don't invalidate the guard mid-sequence.
scoreboard players set #hb_armed ec.temp 0
execute unless score @s ec.hb_until matches -2147483648.. run scoreboard players set #hb_armed ec.temp 1
execute if score #hb_armed ec.temp matches 1 run scoreboard players operation @s ec.hb_until = #hb_now ec.var
execute if score #hb_armed ec.temp matches 1 run scoreboard players add @s ec.hb_until 6000
execute if score #hb_armed ec.temp matches 1 run return 0

# Not yet due → wait.
execute if score #hb_now ec.var < @s ec.hb_until run return 0

# === DUE: fire Hearth's Blessing ===
# Re-arm checkpoint FIRST (idempotent even if the grant below somehow re-enters).
scoreboard players operation @s ec.hb_until = #hb_now ec.var
scoreboard players add @s ec.hb_until 6000

# Pick a random present house buff-type into #proc_type.
scoreboard players operation #proc_typemask ec.temp = @s ec.house_types
scoreboard players operation #proc_typecount ec.temp = @s ec.house_tcount
function evercraft:inscription/procs/grant/pick_type

# Grant the chosen type for 10 seconds (dur=10) to @s.
data modify storage evercraft:inscription proc.dur set value 10
function evercraft:inscription/procs/grant/dispatch with storage evercraft:inscription proc

# Notify + gentle amethyst chime (muteable via the per-key notify pattern).
function evercraft:inscription/procs/house/notify
