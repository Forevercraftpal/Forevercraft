# ============================================================
# Totem Procs — Pick a random present buff-type from the scanned mask
# Inputs:  #proc_typemask ec.temp  (bitmask from scan_types)
#          #proc_typecount ec.temp (number of distinct present buff-types, >=1)
# Output:  #proc_type ec.temp      (a glyph id 1..13 of a present type, uniformly random)
#
# Walks the 10 candidate ids in fixed order; the Nth present type (N = random target)
# is selected. Uses bit masks (mask / bitval % 2 == 1 → present) to test membership
# without per-type entity scans (the scan already collapsed presence into the mask).
# ============================================================

# Random target ordinal in 1..typecount (which present type to pick).
scoreboard players set #proc_pick_n ec.temp 1
execute if score #proc_typecount ec.temp matches 2.. store result score #proc_pick_n ec.temp run random value 1..2147483647
execute if score #proc_typecount ec.temp matches 2.. run scoreboard players operation #proc_pick_n ec.temp %= #proc_typecount ec.temp
execute if score #proc_typecount ec.temp matches 2.. run scoreboard players add #proc_pick_n ec.temp 1
# (#proc_pick_n now in 1..typecount)

scoreboard players set #proc_seen ec.temp 0
scoreboard players set #proc_type ec.temp 0

# --- id 1 force (bit value 1) ---
scoreboard players operation #proc_bit ec.temp = #proc_typemask ec.temp
scoreboard players operation #proc_bit ec.temp %= #2 ec.const
execute if score #proc_bit ec.temp matches 1 run scoreboard players add #proc_seen ec.temp 1
execute if score #proc_bit ec.temp matches 1 if score #proc_seen ec.temp = #proc_pick_n ec.temp if score #proc_type ec.temp matches 0 run scoreboard players set #proc_type ec.temp 1

# --- id 3 haste (bit value 4) ---
scoreboard players operation #proc_bit ec.temp = #proc_typemask ec.temp
scoreboard players operation #proc_bit ec.temp /= #4 ec.const
scoreboard players operation #proc_bit ec.temp %= #2 ec.const
execute if score #proc_bit ec.temp matches 1 run scoreboard players add #proc_seen ec.temp 1
execute if score #proc_bit ec.temp matches 1 if score #proc_seen ec.temp = #proc_pick_n ec.temp if score #proc_type ec.temp matches 0 run scoreboard players set #proc_type ec.temp 3

# --- id 4 thornmail/Bulwark (bit value 8) ---
scoreboard players operation #proc_bit ec.temp = #proc_typemask ec.temp
scoreboard players operation #proc_bit ec.temp /= #8 ec.const
scoreboard players operation #proc_bit ec.temp %= #2 ec.const
execute if score #proc_bit ec.temp matches 1 run scoreboard players add #proc_seen ec.temp 1
execute if score #proc_bit ec.temp matches 1 if score #proc_seen ec.temp = #proc_pick_n ec.temp if score #proc_type ec.temp matches 0 run scoreboard players set #proc_type ec.temp 4

# --- id 5 wind (bit value 16) ---
scoreboard players operation #proc_bit ec.temp = #proc_typemask ec.temp
scoreboard players operation #proc_bit ec.temp /= #16 ec.const
scoreboard players operation #proc_bit ec.temp %= #2 ec.const
execute if score #proc_bit ec.temp matches 1 run scoreboard players add #proc_seen ec.temp 1
execute if score #proc_bit ec.temp matches 1 if score #proc_seen ec.temp = #proc_pick_n ec.temp if score #proc_type ec.temp matches 0 run scoreboard players set #proc_type ec.temp 5

# --- id 6 guardian (bit value 32) ---
scoreboard players operation #proc_bit ec.temp = #proc_typemask ec.temp
scoreboard players operation #proc_bit ec.temp /= #32 ec.const
scoreboard players operation #proc_bit ec.temp %= #2 ec.const
execute if score #proc_bit ec.temp matches 1 run scoreboard players add #proc_seen ec.temp 1
execute if score #proc_bit ec.temp matches 1 if score #proc_seen ec.temp = #proc_pick_n ec.temp if score #proc_type ec.temp matches 0 run scoreboard players set #proc_type ec.temp 6

# --- id 7 fortify (bit value 64) ---
scoreboard players operation #proc_bit ec.temp = #proc_typemask ec.temp
scoreboard players operation #proc_bit ec.temp /= #64 ec.const
scoreboard players operation #proc_bit ec.temp %= #2 ec.const
execute if score #proc_bit ec.temp matches 1 run scoreboard players add #proc_seen ec.temp 1
execute if score #proc_bit ec.temp matches 1 if score #proc_seen ec.temp = #proc_pick_n ec.temp if score #proc_type ec.temp matches 0 run scoreboard players set #proc_type ec.temp 7

# --- id 8 gold_greed (bit value 128) ---
scoreboard players operation #proc_bit ec.temp = #proc_typemask ec.temp
scoreboard players operation #proc_bit ec.temp /= #128 ec.const
scoreboard players operation #proc_bit ec.temp %= #2 ec.const
execute if score #proc_bit ec.temp matches 1 run scoreboard players add #proc_seen ec.temp 1
execute if score #proc_bit ec.temp matches 1 if score #proc_seen ec.temp = #proc_pick_n ec.temp if score #proc_type ec.temp matches 0 run scoreboard players set #proc_type ec.temp 8

# --- id 9 life_steal/Renewal (bit value 256) ---
scoreboard players operation #proc_bit ec.temp = #proc_typemask ec.temp
scoreboard players operation #proc_bit ec.temp /= #256 ec.const
scoreboard players operation #proc_bit ec.temp %= #2 ec.const
execute if score #proc_bit ec.temp matches 1 run scoreboard players add #proc_seen ec.temp 1
execute if score #proc_bit ec.temp matches 1 if score #proc_seen ec.temp = #proc_pick_n ec.temp if score #proc_type ec.temp matches 0 run scoreboard players set #proc_type ec.temp 9

# --- id 10 absorption (bit value 512) ---
scoreboard players operation #proc_bit ec.temp = #proc_typemask ec.temp
scoreboard players operation #proc_bit ec.temp /= #512 ec.const
scoreboard players operation #proc_bit ec.temp %= #2 ec.const
execute if score #proc_bit ec.temp matches 1 run scoreboard players add #proc_seen ec.temp 1
execute if score #proc_bit ec.temp matches 1 if score #proc_seen ec.temp = #proc_pick_n ec.temp if score #proc_type ec.temp matches 0 run scoreboard players set #proc_type ec.temp 10

# --- id 13 wild_forces (bit value 1024) ---
scoreboard players operation #proc_bit ec.temp = #proc_typemask ec.temp
scoreboard players operation #proc_bit ec.temp /= #1024 ec.const
scoreboard players operation #proc_bit ec.temp %= #2 ec.const
execute if score #proc_bit ec.temp matches 1 run scoreboard players add #proc_seen ec.temp 1
execute if score #proc_bit ec.temp matches 1 if score #proc_seen ec.temp = #proc_pick_n ec.temp if score #proc_type ec.temp matches 0 run scoreboard players set #proc_type ec.temp 13
