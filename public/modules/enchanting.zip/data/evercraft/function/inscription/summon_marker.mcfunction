# ============================================================
# Inscription Stones — Summon Marker (macro)
# Called with {rune:"<zone_type>", loot:"<Name>", desc:"<description>"}.
# Run at block center as the player.
# ============================================================

# Summon marker at block center with zone type tag
$summon marker ~ ~0.5 ~ {Tags:["ec.inscr_stone","ec.inscr_$(rune)","ec.inscr_new"]}

# Tag marker with pool type based on player's pool selection
execute if entity @s[tag=ec.inscr_pool_guild] run tag @e[type=marker,tag=ec.inscr_new,distance=..1,limit=1] add ec.inscr_guild_stone
execute if entity @s[tag=ec.inscr_pool_home] run tag @e[type=marker,tag=ec.inscr_new,distance=..1,limit=1] add ec.inscr_home_stone

# Followup wave: stamp this stone's RADIUS BONUS from the placer's per-zone milestone
# bonus (ec.rad_bn_<z>). stacks.mcfunction reads ec.inscr_rad_bonus off the marker and
# adds it AFTER the same-type radius cap, so milestone reach is a separate, additive axis.
scoreboard players set @e[type=marker,tag=ec.inscr_new,distance=..1,limit=1] ec.inscr_rad_bonus 0
execute if entity @s[tag=ec.inscr_pool_guild] if score @s ec.rad_bn_gs matches 1.. run scoreboard players operation @e[type=marker,tag=ec.inscr_new,distance=..1,limit=1] ec.inscr_rad_bonus = @s ec.rad_bn_gs
execute if entity @s[tag=ec.inscr_pool_home] if score @s ec.rad_bn_hs matches 1.. run scoreboard players operation @e[type=marker,tag=ec.inscr_new,distance=..1,limit=1] ec.inscr_rad_bonus = @s ec.rad_bn_hs
execute if entity @s[tag=ec.inscr_pool_personal] if score @s ec.rad_bn_wd matches 1.. run scoreboard players operation @e[type=marker,tag=ec.inscr_new,distance=..1,limit=1] ec.inscr_rad_bonus = @s ec.rad_bn_wd

# Visual mini-block on top of polished_deepslate
summon block_display ~ ~1 ~ {Tags:["ec.inscr_visual"],block_state:{Name:"minecraft:reinforced_deepslate"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.2f,0f,-0.2f],scale:[0.4f,0.3f,0.4f]}}

# Interaction hitbox for shear scraping
summon interaction ~ ~1.15 ~ {Tags:["ec.inscr_interact"],width:0.5f,height:0.4f,response:1b}

# Increment the correct pool counter
execute if entity @s[tag=ec.inscr_pool_guild] run scoreboard players add @s ec.inscr_guild_count 1
execute if entity @s[tag=ec.inscr_pool_home] run scoreboard players add @s ec.inscr_home_count 1
execute if entity @s[tag=ec.inscr_pool_personal] run scoreboard players add @s ec.inscr_count 1

# F3: lifetime zone totem counts + milestone messaging (house / guild / wild)
function evercraft:inscription/totem_count

# Followup wave: compute the DISPLAYED active-stone cap (base + milestone bonus) into a
# fakeplayer so the "(Guild N/cap)" feedback reflects unlocked slots, not a stale literal.
scoreboard players set #inscr_cap_disp ec.temp 1
execute if entity @s[tag=ec.inscr_pool_home] run scoreboard players set #inscr_cap_disp ec.temp 4
execute if entity @s[tag=ec.inscr_pool_personal] run scoreboard players set #inscr_cap_disp ec.temp 3
execute if entity @s[tag=ec.inscr_pool_guild] if score @s ec.cap_bn_gs matches 1.. run scoreboard players operation #inscr_cap_disp ec.temp += @s ec.cap_bn_gs
execute if entity @s[tag=ec.inscr_pool_home] if score @s ec.cap_bn_hs matches 1.. run scoreboard players operation #inscr_cap_disp ec.temp += @s ec.cap_bn_hs
execute if entity @s[tag=ec.inscr_pool_personal] if score @s ec.cap_bn_wd matches 1.. run scoreboard players operation #inscr_cap_disp ec.temp += @s ec.cap_bn_wd

# Feedback (show glyph name + pool info; cap now reflects milestone-unlocked slots)
# Guild pool
$data modify storage evercraft:notify stage.c set value [{text:"$(loot) Glyph",color:"light_purple"},{text:" inscribed! ",color:"gray"},{text:"(Guild ",color:"#55aa55"},{score:{name:"@s",objective:"ec.inscr_guild_count"},color:"white"},{text:"/",color:"#55aa55"},{score:{name:"#inscr_cap_disp",objective:"ec.temp"},color:"#55aa55"},{text:")",color:"#55aa55"}]
scoreboard players set #ndur ec.temp 50
execute if entity @s[tag=ec.inscr_pool_guild] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"$(desc)",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute if entity @s[tag=ec.inscr_pool_guild] run function evercraft:util/notify/emit
# Home pool
$data modify storage evercraft:notify stage.c set value [{text:"$(loot) Glyph",color:"light_purple"},{text:" inscribed! ",color:"gray"},{text:"(Home ",color:"#55aaff"},{score:{name:"@s",objective:"ec.inscr_home_count"},color:"white"},{text:"/",color:"#55aaff"},{score:{name:"#inscr_cap_disp",objective:"ec.temp"},color:"#55aaff"},{text:")",color:"#55aaff"}]
scoreboard players set #ndur ec.temp 50
execute if entity @s[tag=ec.inscr_pool_home] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"$(desc)",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute if entity @s[tag=ec.inscr_pool_home] run function evercraft:util/notify/emit
# Personal pool
$data modify storage evercraft:notify stage.c set value [{text:"$(loot) Glyph",color:"light_purple"},{text:" inscribed! ",color:"gray"},{text:"(",color:"dark_gray"},{score:{name:"@s",objective:"ec.inscr_count"},color:"white"},{text:"/",color:"dark_gray"},{score:{name:"#inscr_cap_disp",objective:"ec.temp"},color:"dark_gray"},{text:")",color:"dark_gray"}]
scoreboard players set #ndur ec.temp 50
execute if entity @s[tag=ec.inscr_pool_personal] run function evercraft:util/notify/emit
$data modify storage evercraft:notify stage.c set value [{text:"$(desc)",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
execute if entity @s[tag=ec.inscr_pool_personal] run function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.8 1.0
particle minecraft:enchant ~ ~1 ~ 0.3 0.5 0.3 1 10
