# ============================================================
# Inscription Stone — Toggle On/Off
# Run as: marker (ec.inscr_stone), at marker position
# Shift+right-click toggles. Auto-off after 24000 ticks (1 day)
# ============================================================

# Currently active → disable
execute if entity @s[tag=ec.inscr_active] run tag @s remove ec.inscr_active
execute unless entity @s[tag=ec.inscr_active] unless entity @s[tag=ec.inscr_toggled] run tag @s add ec.inscr_toggled
data modify storage evercraft:notify stage.c set value [{text:"Glyph totem ",color:"gray"},{text:"deactivated",color:"red",bold:true},{text:".",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.inscr_toggled] as @a[distance=..48] run function evercraft:util/notify/emit
execute if entity @s[tag=ec.inscr_toggled] run playsound minecraft:block.respawn_anchor.deplete master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.5
execute if entity @s[tag=ec.inscr_toggled] run tag @s remove ec.inscr_toggled
execute unless entity @s[tag=ec.inscr_active] run return 0

# Currently inactive → enable with auto-off timer
tag @s add ec.inscr_active
scoreboard players set @s ec.inscr_timer 24000
data modify storage evercraft:notify stage.c set value [{text:"Glyph totem ",color:"gray"},{text:"activated",color:"green",bold:true},{text:" for 1 day.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute as @a[distance=..48] run function evercraft:util/notify/emit
playsound minecraft:block.respawn_anchor.charge master @a[distance=..16,scores={ec.fx_snd=1..}] ~ ~ ~ 0.5 1.2
particle minecraft:enchant ~ ~1 ~ 0.3 0.5 0.3 0.5 20
