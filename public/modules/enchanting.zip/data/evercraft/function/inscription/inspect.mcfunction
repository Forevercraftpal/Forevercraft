# Inscription — Inspect (right-click without shears)
# Run as the marker entity. Shows the glyph name and zone effect to nearby players.

scoreboard players set #ndur ec.temp 45
data modify storage evercraft:notify stage.c set value [{text:"Emberheart Glyph",color:"light_purple"},{text:" — Increases attack damage nearby",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_force] as @a[distance=..5] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Verdant Glyph",color:"light_purple"},{text:" — Accelerates crops; its Overgrowth snares hostiles",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_growth] as @a[distance=..5] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Quicksilver Glyph",color:"light_purple"},{text:" — Grants Haste to nearby players",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_haste] as @a[distance=..5] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Obsidian Glyph",color:"light_purple"},{text:" — A Bulwark; grants Resistance to nearby players",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_thornmail] as @a[distance=..5] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Zephyr Glyph",color:"light_purple"},{text:" — Grants Speed and Jump Boost nearby",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_wind] as @a[distance=..5] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Briar Glyph",color:"light_purple"},{text:" — A bramble ward; armor and thorns for nearby players",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_guardian] as @a[distance=..5] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Stalwart Glyph",color:"light_purple"},{text:" — Grants Strength to nearby players",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_fortify] as @a[distance=..5] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Gilded Glyph",color:"light_purple"},{text:" — Increases Dream Rate for nearby players",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_gold_greed] as @a[distance=..5] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Tidecall Glyph",color:"light_purple"},{text:" — Renewal; grants Regeneration to nearby players",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_life_steal] as @a[distance=..5] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Hearthstone Glyph",color:"light_purple"},{text:" — Grants Absorption to nearby players",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_absorption] as @a[distance=..5] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Prism Glyph",color:"light_purple"},{text:" — Reveals nearby hostile mobs",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_reveal] as @a[distance=..5] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Tempest Glyph",color:"light_purple"},{text:" — Weakens and slows nearby enemies",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_frostbite] as @a[distance=..5] run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Arcanum Glyph",color:"light_purple"},{text:" — Grants random positive effects nearby",color:"gray",italic:true}]
execute if entity @s[tag=ec.inscr_wild_forces] as @a[distance=..5] run function evercraft:util/notify/emit
