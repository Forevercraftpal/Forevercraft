# Glyph Totem — Per-guild global lifetime tally (macro)
# Args: $(gid)  (guild id)
# Increments a guild-keyed fakeplayer on gs.totems so a guild's combined totem
# total is queryable (e.g. "#gs_7" gs.totems). Reserved for future guild perks.
$scoreboard players add #gs_$(gid) gs.totems 1
