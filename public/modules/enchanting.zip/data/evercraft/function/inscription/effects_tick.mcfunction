# ============================================================
# Inscription Stones — Effects Tick (every 5 seconds)
# Apply area effects, render particles, detect broken stones
# ============================================================

# Per-cycle attribute decay: strip the inscription attribute modifiers from ALL players
# first, so anyone who walked OUT of a totem's radius loses the buff (attribute modifiers
# don't auto-expire like potion effects). In-range players are immediately re-added below
# by their stones' apply_attr, within the SAME cycle — no visible gap.
# Gated on a player + a stone existing so it's a no-op on an empty/totem-less world.
execute if entity @a if entity @e[type=marker,tag=ec.inscr_stone,limit=1] as @a run function evercraft:inscription/effects/decay_attr

# OPT: All per-stone checks consolidated into 1 entity scan (was 10)
execute as @e[type=marker,tag=ec.inscr_stone] at @s run function evercraft:inscription/tick_marker

# Guild passive proc — Standing Resonance (1-min buff every 15 min, GUILD-KEYED gametime
# checkpoint). Driven per online guilded member but all state is keyed by guild id, so
# concurrent same-guild members converge on one fire. Gate the gametime read + scan on a
# guilded player existing so it's free on a guild-less world.
execute if entity @a[scores={ec.guild_id=1..},limit=1] store result score #res_now ec.var run time query gametime
execute if entity @a[scores={ec.guild_id=1..},limit=1] as @a[scores={ec.guild_id=1..}] run function evercraft:inscription/procs/guild/proc

schedule function evercraft:inscription/effects_tick 100t
