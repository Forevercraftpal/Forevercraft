# ============================================================
# Inscription Stones — Try Inscribe
# Called from on_glyph_use after glyph type is stored in storage.
# Raycasts from player eyes to find polished_deepslate.
# If found: inscribes the block (summons marker, consumes glyph).
# If not found or at limit: schedules glyph restore for 1 tick later.
# ============================================================

# === F3 Totem zone restriction: only a house owner may inscribe inside their own house ===
# A player standing in someone ELSE's protected house zone (hs.in_protected tag) but NOT in
# their own home zone (hs.in_zone != 1) is denied. The glyph is refunded.
data modify storage evercraft:notify stage.c set value [{text:"Only the owner of this house can place totems here.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=hs.in_protected] unless score @s hs.in_zone matches 1 run function evercraft:util/notify/emit
execute if entity @s[tag=hs.in_protected] unless score @s hs.in_zone matches 1 run tag @s add ec.inscr_restore
execute if entity @s[tag=hs.in_protected] unless score @s hs.in_zone matches 1 run schedule function evercraft:inscription/cleanup 1t append
execute if entity @s[tag=hs.in_protected] unless score @s hs.in_zone matches 1 run return 0

# === F3 Totem zone restriction: only a guild member may inscribe inside their guild's zone ===
# Detect a guild stone within 128 blocks. If one is present but its guild does NOT match the
# player's (ec.guild_in_zone != 1, i.e. not standing in their own guild zone), deny placement.
# Guild stones carry ec.guild_id; ec.guild_in_zone is only 1 for a member in their own zone.
data modify storage evercraft:notify stage.c set value [{text:"Only members of this guild can place totems here.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute at @s if entity @e[type=armor_stand,tag=ec.guildstone_stand,distance=..128] unless score @s ec.guild_in_zone matches 1 run function evercraft:util/notify/emit
execute at @s if entity @e[type=armor_stand,tag=ec.guildstone_stand,distance=..128] unless score @s ec.guild_in_zone matches 1 run tag @s add ec.inscr_restore
execute at @s if entity @e[type=armor_stand,tag=ec.guildstone_stand,distance=..128] unless score @s ec.guild_in_zone matches 1 run schedule function evercraft:inscription/cleanup 1t append
execute at @s if entity @e[type=armor_stand,tag=ec.guildstone_stand,distance=..128] unless score @s ec.guild_in_zone matches 1 run return 0

# Determine which pool to use (priority: guild → home → personal)
# Clear any stale pool tags
tag @s remove ec.inscr_pool_guild
tag @s remove ec.inscr_pool_home
tag @s remove ec.inscr_pool_personal

# === Active-stone caps (base + milestone bonus, followup wave) ===
# Base caps: Guild 1 / Home 4 / Personal 3. Milestone perks raise the cap per zone
# (ec.cap_bn_<z>: 5→+1, 25→+2). Pool has room iff current_count < base + bonus.
# This is a DIFFERENT axis from same-type stacking (distinct active stones, not stacks).
scoreboard players set #inscr_cap_guild ec.temp 1
scoreboard players set #inscr_cap_home ec.temp 4
scoreboard players set #inscr_cap_pers ec.temp 3
execute if score @s ec.cap_bn_gs matches 1.. run scoreboard players operation #inscr_cap_guild ec.temp += @s ec.cap_bn_gs
execute if score @s ec.cap_bn_hs matches 1.. run scoreboard players operation #inscr_cap_home ec.temp += @s ec.cap_bn_hs
execute if score @s ec.cap_bn_wd matches 1.. run scoreboard players operation #inscr_cap_pers ec.temp += @s ec.cap_bn_wd

# Guild pool: in guild zone + guild count < cap
execute if score @s ec.guild_in_zone matches 1.. if score @s ec.inscr_guild_count < #inscr_cap_guild ec.temp run tag @s add ec.inscr_pool_guild

# Per-house cap fix (2026-06-19): before reading the home count, RECOUNT this home's actual live
# glyph-stones into ec.inscr_home_count. The old running score leaked (abandon/relocate/offline-break
# never decremented it) and was shared across all 5 home slots, so a freshly-created home wrongly
# read "full". Recount = self-healing + per-house. Only when standing in a valid active home zone.
execute if score @s hs.in_zone matches 1.. if score @s hs.active matches 1..5 run function evercraft:inscription/recount_home

# Home pool: in home zone + home count < cap (only if guild pool wasn't chosen)
execute unless entity @s[tag=ec.inscr_pool_guild] if score @s hs.in_zone matches 1.. if score @s ec.inscr_home_count < #inscr_cap_home ec.temp run tag @s add ec.inscr_pool_home

# Personal pool: count < cap (only if no zone pool chosen)
execute unless entity @s[tag=ec.inscr_pool_guild] unless entity @s[tag=ec.inscr_pool_home] if score @s ec.inscr_count < #inscr_cap_pers ec.temp run tag @s add ec.inscr_pool_personal

# Reject if no pool has room
data modify storage evercraft:notify stage.c set value [{text:"You cannot place more Inscription Stones!",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute unless entity @s[tag=ec.inscr_pool_guild] unless entity @s[tag=ec.inscr_pool_home] unless entity @s[tag=ec.inscr_pool_personal] run function evercraft:util/notify/emit
execute unless entity @s[tag=ec.inscr_pool_guild] unless entity @s[tag=ec.inscr_pool_home] unless entity @s[tag=ec.inscr_pool_personal] run tag @s add ec.inscr_restore
execute unless entity @s[tag=ec.inscr_pool_guild] unless entity @s[tag=ec.inscr_pool_home] unless entity @s[tag=ec.inscr_pool_personal] run schedule function evercraft:inscription/cleanup 1t append
execute unless entity @s[tag=ec.inscr_pool_guild] unless entity @s[tag=ec.inscr_pool_home] unless entity @s[tag=ec.inscr_pool_personal] run return 0

# Raycast from player eyes to find polished_deepslate (max 5 blocks)
scoreboard players set #inscr_ray ec.temp 0
execute anchored eyes positioned ^ ^ ^0.5 run function evercraft:inscription/ray/step

# After raycast: schedule cleanup if restore needed OR if rune activation needs tag clearing
execute if entity @s[tag=ec.inscr_restore] run schedule function evercraft:inscription/cleanup 1t append
execute unless entity @s[tag=ec.inscr_restore] if entity @s[tag=ec.rune_activated] run schedule function evercraft:inscription/cleanup 1t append
