# Glyph Totem — House lifetime count + milestones (gold)
# Run as: the player.
scoreboard players add @s hs.totems 1

# Milestones (REAL zone-power perks now — text announces the unlock). Exact-match so each fires once.
#   5  → +1 home active-stone cap (place 1 more distinct totem at home)
#   10 → +1 block radius to your home totems
#   25 → +1 home active-stone cap (cumulative +2)
#   50 → +2 block radius (cumulative +3)
execute if score @s hs.totems matches 5 run scoreboard players set @s ec.cap_bn_hs 1
data modify storage evercraft:notify stage.c set value [{text:"First Quintet — 5 home totems set. ",color:"gold"},{text:"Unlocked: +1 home totem slot.",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
execute if score @s hs.totems matches 5 run function evercraft:util/notify/emit
execute if score @s hs.totems matches 10 run scoreboard players set @s ec.rad_bn_hs 1
data modify storage evercraft:notify stage.c set value [{text:"Ten Pillars — Your inscription takes shape. ",color:"gold"},{text:"Unlocked: +1 block radius on home totems.",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
execute if score @s hs.totems matches 10 run function evercraft:util/notify/emit
execute if score @s hs.totems matches 25 run scoreboard players set @s ec.cap_bn_hs 2
data modify storage evercraft:notify stage.c set value [{text:"Quarter Hundred — The ancient patterns deepen. ",color:"gold"},{text:"Unlocked: +1 home totem slot (total +2).",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
execute if score @s hs.totems matches 25 run function evercraft:util/notify/emit
execute if score @s hs.totems matches 50 run scoreboard players set @s ec.rad_bn_hs 3
data modify storage evercraft:notify stage.c set value [{text:"Half-Century — A potent network. ",color:"gold"},{text:"Unlocked: +2 block radius (total +3) on home totems.",color:"yellow"}]
scoreboard players set #ndur ec.temp 50
execute if score @s hs.totems matches 50 run function evercraft:util/notify/emit
