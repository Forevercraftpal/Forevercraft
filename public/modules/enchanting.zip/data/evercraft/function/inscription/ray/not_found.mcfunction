# Inscription — Raycast Miss: No Polished Deepslate Targeted
# W4: The glyph was used in-hand but NOT aimed at a valid inscribe block, so it acts
# as a SCROLL — a weaker, instant, self-only burst of the glyph's theme. The glyph
# stays consumed (NO restore). The rune item's 5s use_cooldown gates spam.
#
# (Pool-full / zone-denied cases set ec.inscr_restore + return BEFORE the raycast in
#  try_inscribe, so they still refund — only a genuine "no block targeted" reaches here.)

function evercraft:inscription/scroll
