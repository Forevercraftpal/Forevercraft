# Inscription Stone — Per-marker tick (runs as marker, at marker)
# OPT: Consolidates @e scans into 1 per-marker function call

# Auto-off timer: decrement and disable when expired
execute if entity @s[tag=ec.inscr_active] if score @s ec.inscr_timer matches 1.. run scoreboard players remove @s ec.inscr_timer 100
execute if entity @s[tag=ec.inscr_active] if score @s ec.inscr_timer matches ..0 run tag @s remove ec.inscr_active
data modify storage evercraft:notify stage.c set value [{text:"A glyph totem has expired and deactivated.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
execute if entity @s[tag=ec.inscr_active] if score @s ec.inscr_timer matches ..0 as @a[distance=..48] run function evercraft:util/notify/emit

# Skip effects if stone is deactivated
execute unless entity @s[tag=ec.inscr_active] run return run function evercraft:inscription/particles

# Default new stones to active (backward compat)
execute unless score @s ec.inscr_timer matches 0.. run tag @s add ec.inscr_active
execute unless score @s ec.inscr_timer matches 0.. run scoreboard players set @s ec.inscr_timer 24000

# Apply type-specific effects (tag-gated — only the matching branch runs)
execute if entity @s[tag=ec.inscr_frostbite] run function evercraft:inscription/effects/frostbite
execute if entity @s[tag=ec.inscr_life_steal] run function evercraft:inscription/effects/life_steal
execute if entity @s[tag=ec.inscr_gold_greed] run function evercraft:inscription/effects/gold_greed
execute if entity @s[tag=ec.inscr_absorption] run function evercraft:inscription/effects/absorption
execute if entity @s[tag=ec.inscr_guardian] run function evercraft:inscription/effects/guardian
execute if entity @s[tag=ec.inscr_thornmail] run function evercraft:inscription/effects/thornmail
execute if entity @s[tag=ec.inscr_force] run function evercraft:inscription/effects/force
execute if entity @s[tag=ec.inscr_growth] run function evercraft:inscription/effects/growth
execute if entity @s[tag=ec.inscr_haste] run function evercraft:inscription/effects/haste
execute if entity @s[tag=ec.inscr_wind] run function evercraft:inscription/effects/wind
execute if entity @s[tag=ec.inscr_fortify] run function evercraft:inscription/effects/fortify
execute if entity @s[tag=ec.inscr_reveal] run function evercraft:inscription/effects/reveal
execute if entity @s[tag=ec.inscr_wild_forces] run function evercraft:inscription/effects/mysterious_effect

# === Resonance — same-type stacking ===
# NOTE (W3): the stacking PAYOFF (amp + radius scaling, up to the locked caps) is now
# computed PER-EFFECT inside each effects/<type> function via effects/stacks. The old
# flat amp-1 resonance bonuses + the inscr_*_res attribute modifiers are RETIRED —
# they double-counted on top of the new scaled magnitudes. We keep only:
#   (a) a one-time strip of the LEGACY _res modifiers so they don't linger forever, and
#   (b) a lightweight same-type detection purely to drive the resonance particle cue.

# (a) Strip legacy resonance attribute modifiers from any nearby player (idempotent;
#     gated on a stone that previously resonated so this is a no-op once cleared).
execute if entity @s[tag=ec.inscr_was_res,tag=ec.inscr_guardian] as @a[distance=..48] run attribute @s armor modifier remove evercraft:inscr_guardian_res
execute if entity @s[tag=ec.inscr_was_res,tag=ec.inscr_force] as @a[distance=..48] run attribute @s attack_damage modifier remove evercraft:inscr_force_res

# (b) Detect 2+ same-type stones within 48 blocks (particle cue only).
# OPT: Gate on ANY nearby stone first (1 @e scan)
execute unless entity @e[type=marker,tag=ec.inscr_stone,distance=1..48,limit=1] run tag @s add ec.inscr_no_res
execute unless entity @s[tag=ec.inscr_no_res] if entity @s[tag=ec.inscr_frostbite] if entity @e[type=marker,tag=ec.inscr_frostbite,distance=1..48,limit=1] run tag @s add ec.inscr_res
execute unless entity @s[tag=ec.inscr_no_res] unless entity @s[tag=ec.inscr_res] if entity @s[tag=ec.inscr_absorption] if entity @e[type=marker,tag=ec.inscr_absorption,distance=1..48,limit=1] run tag @s add ec.inscr_res
execute unless entity @s[tag=ec.inscr_no_res] unless entity @s[tag=ec.inscr_res] if entity @s[tag=ec.inscr_guardian] if entity @e[type=marker,tag=ec.inscr_guardian,distance=1..48,limit=1] run tag @s add ec.inscr_res
execute unless entity @s[tag=ec.inscr_no_res] unless entity @s[tag=ec.inscr_res] if entity @s[tag=ec.inscr_force] if entity @e[type=marker,tag=ec.inscr_force,distance=1..48,limit=1] run tag @s add ec.inscr_res
execute unless entity @s[tag=ec.inscr_no_res] unless entity @s[tag=ec.inscr_res] if entity @s[tag=ec.inscr_growth] if entity @e[type=marker,tag=ec.inscr_growth,distance=1..48,limit=1] run tag @s add ec.inscr_res
execute unless entity @s[tag=ec.inscr_no_res] unless entity @s[tag=ec.inscr_res] if entity @s[tag=ec.inscr_haste] if entity @e[type=marker,tag=ec.inscr_haste,distance=1..48,limit=1] run tag @s add ec.inscr_res
execute unless entity @s[tag=ec.inscr_no_res] unless entity @s[tag=ec.inscr_res] if entity @s[tag=ec.inscr_wind] if entity @e[type=marker,tag=ec.inscr_wind,distance=1..48,limit=1] run tag @s add ec.inscr_res
execute unless entity @s[tag=ec.inscr_no_res] unless entity @s[tag=ec.inscr_res] if entity @s[tag=ec.inscr_fortify] if entity @e[type=marker,tag=ec.inscr_fortify,distance=1..48,limit=1] run tag @s add ec.inscr_res
execute unless entity @s[tag=ec.inscr_no_res] unless entity @s[tag=ec.inscr_res] if entity @s[tag=ec.inscr_reveal] if entity @e[type=marker,tag=ec.inscr_reveal,distance=1..48,limit=1] run tag @s add ec.inscr_res
execute unless entity @s[tag=ec.inscr_no_res] unless entity @s[tag=ec.inscr_res] if entity @s[tag=ec.inscr_thornmail] if entity @e[type=marker,tag=ec.inscr_thornmail,distance=1..48,limit=1] run tag @s add ec.inscr_res
execute unless entity @s[tag=ec.inscr_no_res] unless entity @s[tag=ec.inscr_res] if entity @s[tag=ec.inscr_gold_greed] if entity @e[type=marker,tag=ec.inscr_gold_greed,distance=1..48,limit=1] run tag @s add ec.inscr_res
execute unless entity @s[tag=ec.inscr_no_res] unless entity @s[tag=ec.inscr_res] if entity @s[tag=ec.inscr_life_steal] if entity @e[type=marker,tag=ec.inscr_life_steal,distance=1..48,limit=1] run tag @s add ec.inscr_res
execute unless entity @s[tag=ec.inscr_no_res] unless entity @s[tag=ec.inscr_res] if entity @s[tag=ec.inscr_wild_forces] if entity @e[type=marker,tag=ec.inscr_wild_forces,distance=1..48,limit=1] run tag @s add ec.inscr_res
tag @s remove ec.inscr_no_res

# Resonance particle cue (no gameplay payload — payoff is the scaled aura itself).
execute if entity @s[tag=ec.inscr_res] if entity @a[distance=..32] run particle soul_fire_flame ~ ~0.5 ~ 0.2 0.3 0.2 0.01 1

# Track resonance state for next tick (drives the legacy-modifier strip above).
tag @s remove ec.inscr_was_res
execute if entity @s[tag=ec.inscr_res] run tag @s add ec.inscr_was_res
tag @s remove ec.inscr_res

# Rune Word Combos — cross-type stone combinations within 5 blocks
function evercraft:inscription/rune_words

# Particles (only near players)
execute if entity @a[distance=..32] run function evercraft:inscription/particles

# Block-removed check (polished_deepslate broken?)
execute unless block ~ ~-0.5 ~ polished_deepslate run function evercraft:inscription/on_break
