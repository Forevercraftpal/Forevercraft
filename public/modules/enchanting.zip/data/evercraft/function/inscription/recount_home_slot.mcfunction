# Inscription — Per-slot recount body (macro {n}, run as @s). Part of recount_home (2026-06-19).
# Derives the active home's 64-block box corner (center - 64 per axis, matching the +/-64 zone test
# in housing/zone/slot_proximity_one), then hands the corner to recount_home_box for the count.
$scoreboard players operation #hrc_bx ec.temp = @s hs.h$(n)_x
$scoreboard players operation #hrc_by ec.temp = @s hs.h$(n)_y
$scoreboard players operation #hrc_bz ec.temp = @s hs.h$(n)_z
scoreboard players remove #hrc_bx ec.temp 64
scoreboard players remove #hrc_by ec.temp 64
scoreboard players remove #hrc_bz ec.temp 64
execute store result storage evercraft:housing hrc.bx int 1 run scoreboard players get #hrc_bx ec.temp
execute store result storage evercraft:housing hrc.by int 1 run scoreboard players get #hrc_by ec.temp
execute store result storage evercraft:housing hrc.bz int 1 run scoreboard players get #hrc_bz ec.temp
function evercraft:inscription/recount_home_box with storage evercraft:housing hrc
