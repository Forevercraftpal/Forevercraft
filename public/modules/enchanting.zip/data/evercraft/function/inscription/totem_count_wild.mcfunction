# Glyph Totem — Wild (out-of-bounds) lifetime count + milestones (dark_purple)
# Run as: the player (outside any house or guild zone).
scoreboard players add @s ec.wild_totems 1

# Milestones (REAL zone-power perks now — text announces the unlock). Exact-match so each fires once.
#   5  → +1 personal active-stone cap   10 → +1 radius on personal totems
#   25 → +1 personal active-stone cap (cumulative +2)   50 → +2 radius (cumulative +3)
execute if score @s ec.wild_totems matches 5 run scoreboard players set @s ec.cap_bn_wd 1
data modify storage evercraft:notify stage.c set value [{text:"First Quintet — 5 totems set. ",color:"dark_purple"},{text:"Unlocked: +1 personal totem slot.",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
execute if score @s ec.wild_totems matches 5 run function evercraft:util/notify/emit
execute if score @s ec.wild_totems matches 10 run scoreboard players set @s ec.rad_bn_wd 1
data modify storage evercraft:notify stage.c set value [{text:"Ten Pillars — Your inscription takes shape. ",color:"dark_purple"},{text:"Unlocked: +1 block radius on personal totems.",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
execute if score @s ec.wild_totems matches 10 run function evercraft:util/notify/emit
execute if score @s ec.wild_totems matches 25 run scoreboard players set @s ec.cap_bn_wd 2
data modify storage evercraft:notify stage.c set value [{text:"Quarter Hundred — The ancient patterns deepen. ",color:"dark_purple"},{text:"Unlocked: +1 personal totem slot (total +2).",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
execute if score @s ec.wild_totems matches 25 run function evercraft:util/notify/emit
execute if score @s ec.wild_totems matches 50 run scoreboard players set @s ec.rad_bn_wd 3
data modify storage evercraft:notify stage.c set value [{text:"Half-Century — A potent network. ",color:"dark_purple"},{text:"Unlocked: +2 block radius (total +3) on personal totems.",color:"light_purple"}]
scoreboard players set #ndur ec.temp 50
execute if score @s ec.wild_totems matches 50 run function evercraft:util/notify/emit
