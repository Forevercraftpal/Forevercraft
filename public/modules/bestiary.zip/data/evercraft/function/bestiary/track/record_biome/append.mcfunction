# Bestiary — record_biome tail: append biome_name to this mob's biome list
# Args inherited from caller: {mob:"blaze"}
# (Wired W4.1 — separated so each biome match in record_biome can early-return via this 1-line call.)
$data modify storage evercraft:bestiary biomes.$(mob) append from storage evercraft:bestiary biome_name
