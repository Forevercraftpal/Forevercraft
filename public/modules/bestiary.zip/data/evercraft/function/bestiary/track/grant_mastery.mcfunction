# Bestiary — Grant Mastery (Macro)
# Args: {pow:"#pow1", field:"lo", mob:"blaze"}
# Run as the player who just completed a bestiary entry

# Set completion bit
$scoreboard players operation @s bs.comp_$(field) += $(pow) bs.temp

# Lifetime milestone counter: +1 per entry mastered (this macro fires once when an entry reaches
# full mastery — kill threshold + all 4 drop tiers — run as @s = the completing player).
scoreboard players add @s ec.bst_mastered 1

# Announce to the player
$data modify storage evercraft:notify stage.c set value [{text:"✦ Bestiary Mastery: ",color:"gold",bold:true},{text:"$(mob)",color:"green"},{text:" — Mastered!",color:"gray"},{text:" ✦",color:"gold",bold:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Announce to OTHER players (§5b: names the actor via {selector:@s}, direct render). The actor is
# tagged out so they don't see this brag on top of their personal line above — the ec.bs_self
# exclusion tag was referenced but never actually set, so the actor saw BOTH (fixed 2026-06-02).
tag @s add ec.bs_self
# (Wave 2, 2026-06-10: bestiary-mastery brag — whoami-baked, protected, 30s TTL.)
function evercraft:util/notify/whoami
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:""},{text:" mastered ",color:"gray"},{text:"$(mob)",color:"green"},{text:" in the Bestiary! ✦",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a[tag=!ec.bs_self] run scoreboard players set #nttl ec.temp 600
execute as @a[tag=!ec.bs_self] run function evercraft:util/notify/emit_keep
tag @s remove ec.bs_self

# Coin reward
function evercraft:coins/bestiary_reward

# Sound + particles
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.1 15
