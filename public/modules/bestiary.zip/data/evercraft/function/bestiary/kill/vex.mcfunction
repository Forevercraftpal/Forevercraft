# Bestiary — Kill: vex (bestiary-only, master on first kill)
advancement revoke @s only evercraft:bestiary/kill/vex
# Auto-fill drop tiers (no crate drops for this mob) so check_complete passes
scoreboard players set @s bs.d_vex 63
function evercraft:bestiary/track/on_kill {score:"bs.k_vex",dscore:"bs.d_vex",threshold:1,pow:"#pow10",field:"hi",mob:"vex",smob:"vex",group:3}

# === ADDITIVE: D-MOBDROP Wayfarer's Lens — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/ornate/wardens_echo",name:"Wardens Echo",color:"dark_purple",chance:"0.00013"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
