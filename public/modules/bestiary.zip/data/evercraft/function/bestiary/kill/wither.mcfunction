# Bestiary — Kill: wither (bestiary-only, master on first kill)
advancement revoke @s only evercraft:bestiary/kill/wither
# Auto-fill drop tiers (no crate drops for this mob) so check_complete passes
scoreboard players set @s bs.d_wither 63
function evercraft:bestiary/track/on_kill {score:"bs.k_wither",dscore:"bs.d_wither",threshold:1,pow:"#pow14",field:"hi",mob:"wither",smob:"wither",group:5}

# === ADDITIVE: D-MOBDROP Soulguard Aegis — extremely-rare per-piece drop (Artifact-Fusion w2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/mythical/wither_rose_crown",name:"Wither Rose Crown",color:"gold",chance:"0.00007"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
