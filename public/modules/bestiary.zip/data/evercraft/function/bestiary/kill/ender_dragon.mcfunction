# Bestiary — Kill: ender_dragon (bestiary-only, master on first kill)
advancement revoke @s only evercraft:bestiary/kill/ender_dragon
# Auto-fill drop tiers (no crate drops for this mob) so check_complete passes
scoreboard players set @s bs.d_edragon 63
function evercraft:bestiary/track/on_kill {score:"bs.k_edragon",dscore:"bs.d_edragon",threshold:100,pow:"#pow13",field:"lo",mob:"ender_dragon",smob:"edragon",group:5}

# === ADDITIVE: D-MOBDROP Dragonheart (Fam11/M) — extremely-rare per-piece drop (Artifact-Fusion D2) ===
data modify storage evercraft:amd args set value {lt:"artifacts/exquisite/breathgland_sac",name:"Breath-Gland Sac",color:"light_purple",chance:"0.0001"}
function evercraft:artifacts/give/mob_drop with storage evercraft:amd args
