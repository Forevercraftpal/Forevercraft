# Bestiary GUI — Page6 (World Bosses)
# Run as the player, facing anchor

# The Hollow King (index 0)
execute rotated ~ 0 positioned ^0.47 ^1.85 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row0"],billboard:"center",text:{"text":"The Hollow King  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}

# The Verdant Warden (index 1)
execute rotated ~ 0 positioned ^0.47 ^1.73 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row1"],billboard:"center",text:{"text":"The Verdant Warden  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}

# The Stormforged (index 2)
execute rotated ~ 0 positioned ^0.47 ^1.61 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row2"],billboard:"center",text:{"text":"The Stormforged  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}

# The Tidecaller (index 3)
execute rotated ~ 0 positioned ^0.47 ^1.49 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row3"],billboard:"center",text:{"text":"The Tidecaller  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}

# The Earthshaker (index 4)
execute rotated ~ 0 positioned ^0.47 ^1.37 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row4"],billboard:"center",text:{"text":"The Earthshaker  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}

# The Nightmare (index 5)
execute rotated ~ 0 positioned ^0.47 ^1.25 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row5"],billboard:"center",text:{"text":"The Nightmare  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}

# The Infernal Titan (index 6)
execute rotated ~ 0 positioned ^-0.63 ^1.85 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row6"],billboard:"center",text:{"text":"The Infernal Titan  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}

# The Soul Warden (index 7)
execute rotated ~ 0 positioned ^-0.63 ^1.73 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row7"],billboard:"center",text:{"text":"The Soul Warden  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick7"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick7"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick7"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick7"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick7"],width:0.12f,height:0.12f,response:1b}

# The Crimson Behemoth (index 8)
execute rotated ~ 0 positioned ^-0.63 ^1.61 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row8"],billboard:"center",text:{"text":"The Crimson Behemoth  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick8"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick8"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick8"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick8"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick8"],width:0.12f,height:0.12f,response:1b}

# The Void Sovereign (index 9)
execute rotated ~ 0 positioned ^-0.63 ^1.49 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row9"],billboard:"center",text:{"text":"The Void Sovereign  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick9"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick9"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick9"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick9"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick9"],width:0.12f,height:0.12f,response:1b}

# The Elder Architect (index 10)
execute rotated ~ 0 positioned ^-0.63 ^1.37 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row10"],billboard:"center",text:{"text":"The Elder Architect  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick10"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick10"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick10"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick10"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick10"],width:0.12f,height:0.12f,response:1b}

# The Luminaire (index 11)
execute rotated ~ 0 positioned ^-0.63 ^1.25 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row11"],billboard:"center",text:{"text":"The Luminaire  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick11"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick11"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick11"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick11"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick11"],width:0.12f,height:0.12f,response:1b}
