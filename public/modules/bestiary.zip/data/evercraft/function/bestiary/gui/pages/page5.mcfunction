# Bestiary GUI — Page5 (Wolf - Zombified Piglin)
# (2026-06-10 GUI pass: this 7-mob tail page filled only the LEFT column — the single
#  column is now CENTERED at ^0; same row scale/pitch as pages 2-4/6 for flip consistency.)
# Run as the player, facing anchor

# Wolf (index 0)
execute rotated ~ 0 positioned ^ ^1.85 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row0"],billboard:"center",text:{"text":"Wolf  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.19 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.095 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^ ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.095 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.19 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}

# Zoglin (index 1)
execute rotated ~ 0 positioned ^ ^1.73 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row1"],billboard:"center",text:{"text":"Zoglin  0/1","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.19 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.095 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^ ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.095 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.19 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}

# Zombie (index 2)
execute rotated ~ 0 positioned ^ ^1.61 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row2"],billboard:"center",text:{"text":"Zombie  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.19 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.095 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^ ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.095 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.19 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}

# Zombie Horse (index 3)
execute rotated ~ 0 positioned ^ ^1.49 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row3"],billboard:"center",text:{"text":"Zombie Horse  0/1","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.19 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.095 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^ ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.095 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.19 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}

# Zombie Nautilus (index 4)
execute rotated ~ 0 positioned ^ ^1.37 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row4"],billboard:"center",text:{"text":"Zombie Nautilus  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.19 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.095 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^ ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.095 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.19 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}

# Zombie Villager (index 5)
execute rotated ~ 0 positioned ^ ^1.25 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row5"],billboard:"center",text:{"text":"Zombie Villager  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.19 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.095 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^ ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.095 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.19 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}

# Zombified Piglin (index 6)
execute rotated ~ 0 positioned ^ ^1.13 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row6"],billboard:"center",text:{"text":"Zombified Piglin  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.19 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.095 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^ ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.095 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.19 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
