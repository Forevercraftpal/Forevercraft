# Bestiary GUI — Page2 (Bee - Evoker)
# Run as the player, facing anchor

# Bee (index 0)
execute rotated ~ 0 positioned ^0.47 ^1.85 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row0"],billboard:"center",text:{"text":"Bee  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick0"],width:0.12f,height:0.12f,response:1b}

# Blaze (index 1)
execute rotated ~ 0 positioned ^0.47 ^1.73 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row1"],billboard:"center",text:{"text":"Blaze  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick1"],width:0.12f,height:0.12f,response:1b}

# Bogged (index 2)
execute rotated ~ 0 positioned ^0.47 ^1.61 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row2"],billboard:"center",text:{"text":"Bogged  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick2"],width:0.12f,height:0.12f,response:1b}

# Breeze (index 3)
execute rotated ~ 0 positioned ^0.47 ^1.49 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row3"],billboard:"center",text:{"text":"Breeze  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick3"],width:0.12f,height:0.12f,response:1b}

# Camel Husk (index 4)
execute rotated ~ 0 positioned ^0.47 ^1.37 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row4"],billboard:"center",text:{"text":"Camel Husk  0/1","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick4"],width:0.12f,height:0.12f,response:1b}

# Cave Spider (index 5)
execute rotated ~ 0 positioned ^0.47 ^1.25 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row5"],billboard:"center",text:{"text":"Cave Spider  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick5"],width:0.12f,height:0.12f,response:1b}

# Creaking (index 6)
execute rotated ~ 0 positioned ^0.47 ^1.13 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row6"],billboard:"center",text:{"text":"Creaking  0/1","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick6"],width:0.12f,height:0.12f,response:1b}

# Creeper (index 7)
execute rotated ~ 0 positioned ^0.47 ^1.01 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row7"],billboard:"center",text:{"text":"Creeper  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^0.28 ^0.95 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick7"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.375 ^0.95 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick7"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.47 ^0.95 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick7"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.565 ^0.95 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick7"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^0.66 ^0.95 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick7"],width:0.12f,height:0.12f,response:1b}

# Dolphin (index 8)
execute rotated ~ 0 positioned ^-0.63 ^1.85 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row8"],billboard:"center",text:{"text":"Dolphin  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick8"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick8"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick8"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick8"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.79 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick8"],width:0.12f,height:0.12f,response:1b}

# Drowned (index 9)
execute rotated ~ 0 positioned ^-0.63 ^1.73 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row9"],billboard:"center",text:{"text":"Drowned  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick9"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick9"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick9"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick9"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.67 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick9"],width:0.12f,height:0.12f,response:1b}

# Elder Guardian (index 10)
execute rotated ~ 0 positioned ^-0.63 ^1.61 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row10"],billboard:"center",text:{"text":"Elder Guardian  0/500","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick10"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick10"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick10"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick10"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.55 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick10"],width:0.12f,height:0.12f,response:1b}

# Enderman (index 11)
execute rotated ~ 0 positioned ^-0.63 ^1.49 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row11"],billboard:"center",text:{"text":"Enderman  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick11"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick11"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick11"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick11"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.43 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick11"],width:0.12f,height:0.12f,response:1b}

# Endermite (index 12)
execute rotated ~ 0 positioned ^-0.63 ^1.37 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row12"],billboard:"center",text:{"text":"Endermite  0/5000","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick12"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick12"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick12"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick12"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.31 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick12"],width:0.12f,height:0.12f,response:1b}

# Ender Dragon (index 13)
execute rotated ~ 0 positioned ^-0.63 ^1.25 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row13"],billboard:"center",text:{"text":"Ender Dragon  0/100","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick13"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick13"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick13"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick13"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.19 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick13"],width:0.12f,height:0.12f,response:1b}

# Evoker (index 14)
execute rotated ~ 0 positioned ^-0.63 ^1.13 ^2.28 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.Row14"],billboard:"center",text:{"text":"Evoker  0/500","color":"white"},background:1,shadow:1b,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.243f,0.243f,0.243f]}}
# [strip] Adv.MenuElement: 0.5w split into 5 x 0.12 cubes (interaction AABBs can't rotate + width is a square X/Z footprint)
execute rotated ~ 0 positioned ^-0.82 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick14"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.725 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick14"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.63 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick14"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.535 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick14"],width:0.12f,height:0.12f,response:1b}
execute rotated ~ 0 positioned ^-0.44 ^1.07 ^2.3 run summon interaction ~ ~ ~ {Tags:["Adv.MenuElement","Adv.SectionContent","Bs.PageContent","Bs.RowClick14"],width:0.12f,height:0.12f,response:1b}
