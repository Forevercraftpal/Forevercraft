# Bestiary Stages — On Stage Up
# Called when #new_bs_stage bs.temp > #bs_stage bs.temp (stage increased)
# #new_bs_stage bs.temp holds the new stage number (1-7)
# Run as player

# Stage-colored announcement (one frame, tier-gated)
scoreboard players set #ndur ec.temp 50
execute if score #new_bs_stage bs.temp matches 1 run data modify storage evercraft:notify stage.c set value [{text:"Stage up! ",color:"green"},{text:"Common",color:"white"},{text:" — Reward available! Open the Bestiary to claim.",color:"gray"}]
execute if score #new_bs_stage bs.temp matches 2 run data modify storage evercraft:notify stage.c set value [{text:"Stage up! ",color:"green"},{text:"Uncommon",color:"green"},{text:" — Reward available! Open the Bestiary to claim.",color:"gray"}]
execute if score #new_bs_stage bs.temp matches 3 run data modify storage evercraft:notify stage.c set value [{text:"Stage up! ",color:"green"},{text:"Rare",color:"aqua"},{text:" — Reward available! Open the Bestiary to claim.",color:"gray"}]
execute if score #new_bs_stage bs.temp matches 4 run data modify storage evercraft:notify stage.c set value [{text:"Stage up! ",color:"green"},{text:"Ornate",color:"light_purple"},{text:" — Reward available! Open the Bestiary to claim.",color:"gray"}]
execute if score #new_bs_stage bs.temp matches 5 run data modify storage evercraft:notify stage.c set value [{text:"Stage up! ",color:"green"},{text:"Exquisite",color:"gold"},{text:" — Reward available! Open the Bestiary to claim.",color:"gray"}]
execute if score #new_bs_stage bs.temp matches 6 run data modify storage evercraft:notify stage.c set value [{text:"Stage up! ",color:"green"},{text:"Mythical",color:"red"},{text:" — Reward available! Open the Bestiary to claim.",color:"gray"}]
execute if score #new_bs_stage bs.temp matches 7 run data modify storage evercraft:notify stage.c set value [{text:"Stage up! ",color:"green"},{text:"Spirit",color:"dark_purple",bold:true},{text:" — Reward available! Open the Bestiary to claim.",color:"gray"}]
execute if score #new_bs_stage bs.temp matches 1..7 run function evercraft:util/notify/emit

# Sound
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.4
