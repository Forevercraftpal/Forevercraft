# Dreamy Pull — Resolve
# Run as the player. Every style funnels here once play ends, having set
# ec.dp_quality to a tier 0..3 (0 = whiffed / ignored, 3 = near-perfect).
# Quality only raises the ODDS of a bonus "good find" — base loot is untouched and
# there is never a penalty for a poor result.

# Idempotency guard: a style's tick can keep executing after it has already funneled
# here this tick (no early return). cleanup zeroes ec.dp_active, so a second entry in
# the same tick bails before awarding a second good-find.
execute unless score @s ec.dp_active matches 1 run return 0

# Quality tier → good-find chance (%) — Wave D1 retune (was 10/40/70/100, the "+1/+2 slips
# away" bug: q1 landed only 40% / q2 only 70%). The headline fix: 50/65/80/100, so a flat
# whiff still pays 50/50 and landing the sweet spot reliably pays out.
scoreboard players set #dp_odds ec.temp 50
execute if score @s ec.dp_quality matches 1 run scoreboard players set #dp_odds ec.temp 65
execute if score @s ec.dp_quality matches 2 run scoreboard players set #dp_odds ec.temp 80
execute if score @s ec.dp_quality matches 3.. run scoreboard players set #dp_odds ec.temp 100

# Wave D1 under-level penalty: a too-hard zone weakens the ladder proportionally.
# ec.dp_penalty (0-100, default 100 = no reduction) was SNAPSHOTTED into this session by
# maybe_trigger from the harvest's ec.gth_dppenalty — reading the snapshot (not a live
# harvest value) keeps the in-flight odds robust against a second harvest mid-minigame.
# #dp_odds = #dp_odds * penalty / 100. Skip the multiply at penalty 100 (no-op) and guard
# against an unset/zero penalty defaulting to full odds. Integer floor is acceptable
# (65*15/100 = 9) and penalty is always >= 1 (compute_success clamps gth_succ >= floor 5),
# so the /= 100 never zeroes a valid ladder rung to 0 below 1% in-tier.
execute if score @s ec.dp_penalty matches 1..99 run scoreboard players operation #dp_odds ec.temp *= @s ec.dp_penalty
execute if score @s ec.dp_penalty matches 1..99 run scoreboard players operation #dp_odds ec.temp /= #gth_c100 ec.var

execute store result score #dp_hit ec.temp run random value 1..100
execute if score #dp_hit ec.temp <= #dp_odds ec.temp run function evercraft:dreamy_pull/give_good_find

# Tear down the mini-game (always)
function evercraft:dreamy_pull/cleanup
