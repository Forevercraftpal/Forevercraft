# Dreamy Pull — Dispatch to the rolled style's start
# Run as the player, at the player.
execute if score @s ec.dp_style matches 1 run function evercraft:dreamy_pull/style_timing/start
execute if score @s ec.dp_style matches 2 run function evercraft:dreamy_pull/style_mash/start
execute if score @s ec.dp_style matches 3 run function evercraft:dreamy_pull/style_phase/start

# Collapse the launching node's right-click hitbox so it can't swallow clicks meant for the
# floating [Pull!] button (the node persists with charges; restored in cleanup). ec.dp_source
# is set by the caller before launch/maybe_trigger -> start, so it is valid here.
function evercraft:dreamy_pull/suppress_node
