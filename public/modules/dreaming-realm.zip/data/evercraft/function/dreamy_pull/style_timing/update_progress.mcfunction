# Dreamy Pull — Style 1 — Update progress line (macro: {pulls:N})
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
$execute as @e[type=text_display,tag=DP.Prog,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"Pulls: ","color":"gray"},{"text":"$(pulls)","color":"yellow"},{"text":"/3","color":"gray"}]
