# Dreamy Pull — Style 1 (Sweet-Spot Timing) — Tick
# Run as the player each tick (from dreamy_pull/tick). ec.dp_timer is the router's
# life counter (already incremented this tick); we only read it here.

# --- Move marker ---
scoreboard players operation #dp_move ec.temp = @s ec.dp_v3
scoreboard players operation #dp_move ec.temp *= @s ec.dp_v2
scoreboard players operation @s ec.dp_v1 += #dp_move ec.temp
execute if score @s ec.dp_v1 matches 100.. run scoreboard players set @s ec.dp_v1 100
execute if score @s ec.dp_v1 matches 100 if score @s ec.dp_v2 matches 1.. run scoreboard players set @s ec.dp_v2 -1
execute if score @s ec.dp_v1 matches ..0 run scoreboard players set @s ec.dp_v1 0
execute if score @s ec.dp_v1 matches 0 if score @s ec.dp_v2 matches ..-1 run scoreboard players set @s ec.dp_v2 1

# --- Check for a click every tick ---
function evercraft:dreamy_pull/style_timing/check_click

# --- Style timeout: end after 20s even if the player never clicks ---
execute if score @s ec.dp_timer matches 400.. run return run function evercraft:dreamy_pull/resolve

# --- Render bar every 2 ticks (perf); 0-100 mapped to 20 chars, green zone chars 7-12 ---
scoreboard players set #dp_two ec.temp 2
scoreboard players operation #dp_r ec.temp = @s ec.dp_timer
scoreboard players operation #dp_r ec.temp %= #dp_two ec.temp
execute unless score #dp_r ec.temp matches 0 run return 0
scoreboard players set #dp_five ec.temp 5
scoreboard players operation #dp_char ec.temp = @s ec.dp_v1
scoreboard players operation #dp_char ec.temp /= #dp_five ec.temp
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute if score #dp_char ec.temp matches 0..1 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"█","color":"white","bold":true},{"text":"░░░░░░","color":"dark_gray"},{"text":"██████","color":"green"},{"text":"░░░░░░░","color":"dark_gray"}]
execute if score #dp_char ec.temp matches 2..3 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"░░","color":"dark_gray"},{"text":"█","color":"white","bold":true},{"text":"░░░░","color":"dark_gray"},{"text":"██████","color":"green"},{"text":"░░░░░░░","color":"dark_gray"}]
execute if score #dp_char ec.temp matches 4..6 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"░░░░","color":"dark_gray"},{"text":"█","color":"white","bold":true},{"text":"░░","color":"dark_gray"},{"text":"██████","color":"green"},{"text":"░░░░░░░","color":"dark_gray"}]
execute if score #dp_char ec.temp matches 7..8 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"░░░░░░░","color":"dark_gray"},{"text":"█","color":"yellow","bold":true},{"text":"█████","color":"green"},{"text":"░░░░░░░","color":"dark_gray"}]
execute if score #dp_char ec.temp matches 9..10 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"░░░░░░░","color":"dark_gray"},{"text":"███","color":"green"},{"text":"█","color":"yellow","bold":true},{"text":"███","color":"green"},{"text":"░░░░░░","color":"dark_gray"}]
execute if score #dp_char ec.temp matches 11..12 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"░░░░░░░","color":"dark_gray"},{"text":"█████","color":"green"},{"text":"█","color":"yellow","bold":true},{"text":"░░░░░░░","color":"dark_gray"}]
execute if score #dp_char ec.temp matches 13..15 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"░░░░░░░","color":"dark_gray"},{"text":"██████","color":"green"},{"text":"░░","color":"dark_gray"},{"text":"█","color":"white","bold":true},{"text":"░░░░","color":"dark_gray"}]
execute if score #dp_char ec.temp matches 16..17 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"░░░░░░░","color":"dark_gray"},{"text":"██████","color":"green"},{"text":"░░░░","color":"dark_gray"},{"text":"█","color":"white","bold":true},{"text":"░░","color":"dark_gray"}]
execute if score #dp_char ec.temp matches 18..19 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"░░░░░░░","color":"dark_gray"},{"text":"██████","color":"green"},{"text":"░░░░░░","color":"dark_gray"},{"text":"█","color":"white","bold":true}]
