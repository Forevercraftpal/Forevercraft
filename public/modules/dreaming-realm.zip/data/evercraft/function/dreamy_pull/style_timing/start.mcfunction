# Dreamy Pull — Style 1 (Sweet-Spot Timing) — Start
# A marker bounces across a bar; click [Pull!] when it is in the green zone.
# 3 attempts; each landed hit = +1 quality tier (final ec.dp_quality 0..3).
#   ec.dp_v1 = marker position (0-100)
#   ec.dp_v2 = direction (1 = right, -1 = left)
#   ec.dp_v3 = marker speed (ramps up each attempt)
#   ec.dp_v5 = attempts used
# Run as the player, at the player.

scoreboard players set @s ec.dp_v1 0
scoreboard players set @s ec.dp_v2 1
scoreboard players set @s ec.dp_v3 3
scoreboard players set @s ec.dp_v5 0
scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# Title label
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^0.50 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.Label"],billboard:"center",see_through:1b,text:[{"text":"✦ ","color":"gold"},{"text":"Dreamy Pull","color":"light_purple","bold":true}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
# Hint
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^0.40 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.Hint"],billboard:"center",see_through:1b,text:{"text":"Click [Pull!] in the green zone","color":"gray","italic":true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}
# Bar (updated each tick)
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^0.25 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.Bar"],billboard:"center",see_through:1b,text:{"text":"░░░░░░░██████░░░░░░░","color":"white"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.66f,0.66f,0.66f]}}
# Button
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^0.07 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.BtnText"],billboard:"center",see_through:1b,text:{"text":"[ Pull! ]","color":"light_purple","bold":true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
execute at @s rotated ~ 0 positioned ^ ^1.42 ^2.3 positioned ^0 ^-0.02 ^0 run summon interaction ~ ~ ~ {Tags:["DP.El","DP.Btn"],width:0.35f,height:0.18f,response:1b}
# Progress line
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^-0.10 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.Prog"],billboard:"center",see_through:1b,text:[{"text":"Pulls: ","color":"gray"},{"text":"0","color":"yellow"},{"text":"/3","color":"gray"}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.29f,0.29f,0.29f]}}

# Stamp newly spawned entities with this session (MP isolation)
execute at @s as @e[type=text_display,tag=DP.El,distance=..8] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_check ec.temp
execute at @s as @e[type=interaction,tag=DP.El,distance=..8] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_check ec.temp

playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.6
