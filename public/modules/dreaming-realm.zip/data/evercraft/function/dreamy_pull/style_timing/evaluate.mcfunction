# Dreamy Pull — Style 1 — Evaluate a pull attempt
# Run as the player. Green zone = marker 35..65 (matches the rendered green band).

scoreboard players set #dp_hit ec.temp 0
execute if score @s ec.dp_v1 matches 35..65 run scoreboard players set #dp_hit ec.temp 1

# Count the attempt
scoreboard players add @s ec.dp_v5 1

# Landed hit → +1 quality tier
execute if score #dp_hit ec.temp matches 1 run scoreboard players add @s ec.dp_quality 1
execute if score #dp_hit ec.temp matches 1 run playsound minecraft:entity.player.attack.crit master @s ~ ~ ~ 0.8 1.3
data modify storage evercraft:notify stage.c set value [{text:"Pull! ",color:"light_purple",bold:true},{text:"(good!)",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #dp_hit ec.temp matches 1 run function evercraft:util/notify/emit
# Miss
execute if score #dp_hit ec.temp matches 0 run playsound minecraft:entity.player.attack.nodamage master @s ~ ~ ~ 0.5 0.8
data modify storage evercraft:notify stage.c set value [{text:"Slipped...",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #dp_hit ec.temp matches 0 run function evercraft:util/notify/emit

# Marker speeds up after each attempt
scoreboard players add @s ec.dp_v3 1

# Update the progress line
data modify storage evercraft:dreamy_pull pulls set value "0"
execute store result storage evercraft:dreamy_pull pulls int 1 run scoreboard players get @s ec.dp_v5
function evercraft:dreamy_pull/style_timing/update_progress with storage evercraft:dreamy_pull

# Done after 3 attempts → resolve (ec.dp_quality already holds the 0..3 tier)
execute if score @s ec.dp_v5 matches 3.. run function evercraft:dreamy_pull/resolve
