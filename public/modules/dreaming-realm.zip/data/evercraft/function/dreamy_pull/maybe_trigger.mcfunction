# Dreamy Pull — 7% chance to launch a bonus gather mini-game.
# The CALLER (prospect/complete_mine, forage/complete_gather) sets ec.dp_source first:
#   1 = prospect (ore node)   2 = forage (bush)
# Run as the player, at the player. Base loot has ALREADY been awarded by the caller,
# so this never gates the harvest — it is purely an optional bonus.

# Never stack on an in-progress session
execute if score @s ec.dp_active matches 1 run return 0

# Wave D1 — difficulty-aware trigger threshold (was a flat 7%):
#   base 7%  ; OVER-LEVELED zone (ec.gth_overlvl == 1) -> 3% (over-leveled areas trigger less)
#   S4: a live world event nudges it +2% (7->9, 3->5).
# ec.gth_overlvl was set THIS tick by gather/compute_success in the HEAD (same harvest), so it
# is a fresh @s value here in the _success tail. #we_active ec.var is the world-event flag the
# tail already reads above. The 3rd-fail rescue path (Wave D2) is SEPARATE and does NOT route
# through this gate.
scoreboard players set #dp_thresh ec.temp 7
execute if score @s ec.gth_overlvl matches 1 run scoreboard players set #dp_thresh ec.temp 3
execute if score #we_active ec.var matches 1 run scoreboard players add #dp_thresh ec.temp 2
# Wave 35 — GS U5 Beemark pivot: gathering near ACTIVE hives nudges the trigger
# +2pp (7->9 ≈ +29% more pulls ≈ the node's "produce 25% faster"); lush_caves
# (the node's rare-biome line) doubles the nudge to +4pp (≈ "50% faster").
# ec.gs_bee_prox = the 1s bee-proximity flag (SOLE WRITER bough/growseer/
# u5_bee_tick); double-gated on the node so a stale flag can't outlive a wipe.
execute if score @s ec.gs_n_u5 matches 1.. if score @s ec.gs_bee_prox matches 1.. run scoreboard players add #dp_thresh ec.temp 2
execute if score @s ec.gs_n_u5 matches 1.. if score @s ec.gs_bee_prox matches 1.. if predicate evercraft:biome/is_lush_caves run scoreboard players add #dp_thresh ec.temp 2
execute store result score #dp_roll ec.temp run random value 1..100
execute unless score #dp_roll ec.temp <= #dp_thresh ec.temp run return 0

# Roll a random style: 1 = sweet-spot timing, 2 = button-mash, 3 = two-phase
execute store result score @s ec.dp_style run random value 1..3

# Init session state
scoreboard players set @s ec.dp_active 1
scoreboard players set @s ec.dp_quality 0
scoreboard players set @s ec.dp_timer 0
scoreboard players set @s ec.dp_phase 0

# Wave D1 — SNAPSHOT the under-level odds penalty into this Dreamy session. resolve reads
# ec.dp_penalty (this snapshot), NOT the live ec.gth_dppenalty — so a SECOND harvest during
# the minigame (which overwrites ec.gth_dppenalty) can't corrupt the in-flight ladder.
# ec.gth_dppenalty was set THIS tick by compute_success (default 100 = no penalty in-tier).
scoreboard players operation @s ec.dp_penalty = @s ec.gth_dppenalty
# Wave D2 — snapshot the harvest's win-XP into THIS Dreamy session, so give_good_find can
# double the banked XP off a session-stable value. ec.gth_lastxp was set by gather/grant_xp on
# the WIN that led here (this trigger only fires from the _success tails). Reading the live
# ec.gth_lastxp here (not in give_good_find) means a SECOND harvest mid-minigame — which
# overwrites ec.gth_lastxp — can't corrupt the in-flight 2× re-grant.
scoreboard players operation @s ec.dp_bonusxp = @s ec.gth_lastxp

# New display session id for multiplayer isolation (shared counter w/ other menus)
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var

# Announce (Wave 1, Joseph 2026-06-10: routed through the critical subtitle lane — same
# subtitle-alone display this already hand-rolled, but flash stamps times every call and is
# the one shared idiom for it).
data modify storage evercraft:notify flash.c set value [{text:"✦ Dreamy Pull!",color:"light_purple"}]
function evercraft:util/notify/flash
playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.7 1.0

# Launch the rolled style
function evercraft:dreamy_pull/start
