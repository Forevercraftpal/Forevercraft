# Dreamy Pull — launch the mini-game NOW (shared session init + dispatch to the rolled style).
# Run as @s, at the player. Opens the SAME interactive window as the 7% harvest trigger.
#
# CALLER CONTRACT: set ec.dp_source FIRST (1=prospect / 2=forage / 3=splash / 4=nest / 5=chest /
# 6=timberfall / 7=buried_cache — how give_good_find routes the bonus), and only call this when
# NO session is active
# (`execute unless score @s ec.dp_active matches 1 run function …`) — re-entry mid-session
# would clobber the in-flight minigame. Mirrors the init block in maybe_trigger so the
# 3rd-fail RESCUE (maybe_rescue) opens the same game; factored out to keep the two in sync.
#
# ec.dp_bonusxp is intentionally NOT set here — it is vestigial (give_good_find grants a random
# windfall, not a 2× of it). ec.dp_penalty snapshots the harvest's under-level penalty so the
# odds ladder in resolve matches the regular trigger (gth_dppenalty is fresh this resolve tick).

# Roll a random style: 1 = sweet-spot timing, 2 = button-mash, 3 = two-phase
execute store result score @s ec.dp_style run random value 1..3

# Init session state
scoreboard players set @s ec.dp_active 1
scoreboard players set @s ec.dp_quality 0
scoreboard players set @s ec.dp_timer 0
scoreboard players set @s ec.dp_phase 0
scoreboard players operation @s ec.dp_penalty = @s ec.gth_dppenalty

# New display session id for multiplayer isolation (shared counter w/ other menus)
scoreboard players add #gui_session ec.var 1
scoreboard players operation @s adv.gui_session = #gui_session ec.var

# Launch the rolled style (spawns the world-space window at the player)
function evercraft:dreamy_pull/start
