# Dreamy Pull — Style 3 — Phase 2 (Pry) scoring — the rising-bar click
# Run as the player. Distance from golden-zone center (70):
#   <=8 → +2,  9..16 → +1,  else +0.  Points accumulate in ec.dp_v5.

# Distance from center 70 (absolute value)
scoreboard players set #dp_center ec.temp 70
scoreboard players operation #dp_dist ec.temp = @s ec.dp_v1
scoreboard players operation #dp_dist ec.temp -= #dp_center ec.temp
scoreboard players set #dp_neg1 ec.temp -1
execute if score #dp_dist ec.temp matches ..-1 run scoreboard players operation #dp_dist ec.temp *= #dp_neg1 ec.temp

scoreboard players set #dp_pts ec.temp 0
execute if score #dp_dist ec.temp matches 9..16 run scoreboard players set #dp_pts ec.temp 1
execute if score #dp_dist ec.temp matches 0..8 run scoreboard players set #dp_pts ec.temp 2
scoreboard players operation @s ec.dp_v5 += #dp_pts ec.temp

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Pried free! ",color:"gold",bold:true},{text:"(+2)",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #dp_pts ec.temp matches 2 run function evercraft:util/notify/emit
execute if score #dp_pts ec.temp matches 2 run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.4
data modify storage evercraft:notify stage.c set value [{text:"Close pry. ",color:"yellow"},{text:"(+1)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #dp_pts ec.temp matches 1 run function evercraft:util/notify/emit
execute if score #dp_pts ec.temp matches 1 run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.0
data modify storage evercraft:notify stage.c set value [{text:"Slipped off.",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #dp_pts ec.temp matches 0 run function evercraft:util/notify/emit
execute if score #dp_pts ec.temp matches 0 run playsound minecraft:entity.player.attack.nodamage master @s ~ ~ ~ 0.5 0.8

# Finalize (sum + cap + resolve)
function evercraft:dreamy_pull/style_phase/finish
