# Dreamy Pull — Style 3 — Evaluate a click (branches on phase)
# Run as the player. ec.dp_v5 accumulates phase points across both phases.
execute if score @s ec.dp_phase matches 1 run function evercraft:dreamy_pull/style_phase/eval_phase1
execute if score @s ec.dp_phase matches 2 run function evercraft:dreamy_pull/style_phase/eval_phase2
