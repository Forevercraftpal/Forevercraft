# Dreamy Pull — Style 3 — Phase 1 (Loosen) scoring — the single timing hit
# Run as the player. Green zone 35..65 → +2; near-miss 20..34 or 66..80 → +1; else +0.
# Points accumulate in ec.dp_v5. Then advance to phase 2.

scoreboard players set #dp_pts ec.temp 0
execute if score @s ec.dp_v1 matches 20..34 run scoreboard players set #dp_pts ec.temp 1
execute if score @s ec.dp_v1 matches 66..80 run scoreboard players set #dp_pts ec.temp 1
execute if score @s ec.dp_v1 matches 35..65 run scoreboard players set #dp_pts ec.temp 2
scoreboard players operation @s ec.dp_v5 += #dp_pts ec.temp

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Loosened! ",color:"light_purple",bold:true},{text:"(+2)",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score #dp_pts ec.temp matches 2 run function evercraft:util/notify/emit
execute if score #dp_pts ec.temp matches 2 run playsound minecraft:entity.player.attack.crit master @s ~ ~ ~ 0.8 1.3
data modify storage evercraft:notify stage.c set value [{text:"Half-loose. ",color:"yellow"},{text:"(+1)",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute if score #dp_pts ec.temp matches 1 run function evercraft:util/notify/emit
execute if score #dp_pts ec.temp matches 1 run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.0
data modify storage evercraft:notify stage.c set value [{text:"Stuck fast...",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score #dp_pts ec.temp matches 0 run function evercraft:util/notify/emit
execute if score #dp_pts ec.temp matches 0 run playsound minecraft:entity.player.attack.nodamage master @s ~ ~ ~ 0.5 0.8

# Advance to phase 2 (swaps the display entities)
function evercraft:dreamy_pull/style_phase/start_phase2
