# Dreamy Pull — Style 3 (Two-Phase) — Start (Phase 1: Loosen)
# Phase 1 = a single sweet-spot timing hit (bouncing marker, ONE attempt).
# Phase 2 = a rising "pry" bar. Each phase awards up to +2; summed and capped at 3.
#   ec.dp_phase = 1 then 2
#   ec.dp_v1 = marker position (0-100)
#   ec.dp_v2 = direction (1 = right, -1 = left)
#   ec.dp_v3 = marker speed
#   ec.dp_v5 = accumulated phase points
# Run as the player, at the player.

scoreboard players set @s ec.dp_phase 1
scoreboard players set @s ec.dp_v1 0
scoreboard players set @s ec.dp_v2 1
scoreboard players set @s ec.dp_v3 4
scoreboard players set @s ec.dp_v5 0
scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# Title label
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^0.50 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.Label"],billboard:"center",see_through:1b,text:[{"text":"✦ ","color":"gold"},{"text":"Dreamy Pull","color":"light_purple","bold":true}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
# Hint
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^0.40 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.Hint"],billboard:"center",see_through:1b,text:[{"text":"Phase 1: Loosen","color":"aqua"},{"text":" — click in the green zone","color":"gray","italic":true}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}
# Bar (updated each tick)
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^0.25 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.Bar"],billboard:"center",see_through:1b,text:{"text":"░░░░░░░██████░░░░░░░","color":"white"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.66f,0.66f,0.66f]}}
# Button
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^0.07 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.BtnText"],billboard:"center",see_through:1b,text:{"text":"[ Pull! ]","color":"light_purple","bold":true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
execute at @s rotated ~ 0 positioned ^ ^1.42 ^2.3 positioned ^0 ^-0.02 ^0 run summon interaction ~ ~ ~ {Tags:["DP.El","DP.Btn"],width:0.35f,height:0.18f,response:1b}
# Progress line
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^-0.10 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.Prog"],billboard:"center",see_through:1b,text:[{"text":"Phase ","color":"gray"},{"text":"1","color":"yellow"},{"text":"/2","color":"gray"}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.29f,0.29f,0.29f]}}

# Stamp newly spawned entities with this session (MP isolation)
execute at @s as @e[type=text_display,tag=DP.El,distance=..8] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_check ec.temp
execute at @s as @e[type=interaction,tag=DP.El,distance=..8] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_check ec.temp

playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.6
