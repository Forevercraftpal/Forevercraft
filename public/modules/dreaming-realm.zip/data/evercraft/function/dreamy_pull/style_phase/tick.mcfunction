# Dreamy Pull — Style 3 (Two-Phase) — Tick (router by phase)
# Run as the player each tick (from dreamy_pull/tick). ec.dp_timer is the router's
# life counter (already incremented this tick); we only read it here.
execute if score @s ec.dp_phase matches 1 run function evercraft:dreamy_pull/style_phase/phase1
execute if score @s ec.dp_phase matches 2 run function evercraft:dreamy_pull/style_phase/phase2
