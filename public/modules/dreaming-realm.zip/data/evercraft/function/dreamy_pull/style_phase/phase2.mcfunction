# Dreamy Pull — Style 3 — Phase 2 (Pry): a bar that rises with a gentle wobble
# Run as the player. Golden zone ~62..78 (center 70). Click [Pull!] in zone via
# check_click → eval_phase2. If the bar tops out (v1 >= 100) with no click → +0.
# ec.dp_timer is the router's life counter (read-only).

# --- Base rise: +1 every 4 ticks ---
scoreboard players add @s ec.dp_v2 1
scoreboard players set #dp_four ec.temp 4
scoreboard players operation #dp_rise ec.temp = @s ec.dp_timer
scoreboard players operation #dp_rise ec.temp %= #dp_four ec.temp
execute if score #dp_rise ec.temp matches 0 run scoreboard players add @s ec.dp_v1 1

# --- Gentle wobble: sine-ish offsets on a 40-step cycle (0,+1,+2,+1,0,-1,-2,-1) ---
scoreboard players set #dp_forty ec.temp 40
scoreboard players operation #dp_sine ec.temp = @s ec.dp_v2
scoreboard players operation #dp_sine ec.temp %= #dp_forty ec.temp
execute if score #dp_sine ec.temp matches 5 run scoreboard players add @s ec.dp_v1 1
execute if score #dp_sine ec.temp matches 10 run scoreboard players add @s ec.dp_v1 1
execute if score #dp_sine ec.temp matches 15 run scoreboard players add @s ec.dp_v1 1
execute if score #dp_sine ec.temp matches 25 run scoreboard players remove @s ec.dp_v1 1
execute if score #dp_sine ec.temp matches 30 run scoreboard players remove @s ec.dp_v1 1
execute if score #dp_sine ec.temp matches 35 run scoreboard players remove @s ec.dp_v1 1

# Clamp floor at 0
execute if score @s ec.dp_v1 matches ..0 run scoreboard players set @s ec.dp_v1 0

# --- Check for a click every tick ---
function evercraft:dreamy_pull/style_phase/check_click

# --- Auto-resolve when the bar tops out (no click) → +0 for this phase ---
execute if score @s ec.dp_v1 matches 100.. run return run function evercraft:dreamy_pull/style_phase/finish

# --- Render bar every 2 ticks (perf); 0-100 mapped to 20 chars, golden zone chars 12-15 ---
scoreboard players set #dp_two ec.temp 2
scoreboard players operation #dp_r ec.temp = @s ec.dp_timer
scoreboard players operation #dp_r ec.temp %= #dp_two ec.temp
execute unless score #dp_r ec.temp matches 0 run return 0
scoreboard players set #dp_five ec.temp 5
scoreboard players operation #dp_char ec.temp = @s ec.dp_v1
scoreboard players operation #dp_char ec.temp /= #dp_five ec.temp
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute if score #dp_char ec.temp matches 0..3 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"████","color":"green"},{"text":"░░░░░░░░","color":"dark_gray"},{"text":"████","color":"gold"},{"text":"░░░░","color":"dark_gray"}]
execute if score #dp_char ec.temp matches 4..7 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"████████","color":"green"},{"text":"░░░░","color":"dark_gray"},{"text":"████","color":"gold"},{"text":"░░░░","color":"dark_gray"}]
execute if score #dp_char ec.temp matches 8..11 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"████████████","color":"green"},{"text":"████","color":"gold"},{"text":"░░░░","color":"dark_gray"}]
execute if score #dp_char ec.temp matches 12..15 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"████████████","color":"green"},{"text":"████","color":"gold","bold":true},{"text":"░░░░","color":"dark_gray"}]
execute if score #dp_char ec.temp matches 16..20 as @e[type=text_display,tag=DP.Bar,distance=..8,limit=1] if score @s adv.gui_session = #gui_check ec.temp run data modify entity @s text set value [{"text":"████████████","color":"green"},{"text":"████","color":"gold"},{"text":"████","color":"red"}]
