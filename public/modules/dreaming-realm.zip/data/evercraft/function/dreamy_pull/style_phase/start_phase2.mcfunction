# Dreamy Pull — Style 3 — Start Phase 2 (Pry): rising bar with a gentle wobble
# Run as the player. Kills phase-1 display entities (session-scoped, like cleanup),
# then spawns the phase-2 set. Click [Pull!] when in the golden zone (~62..78).
#   ec.dp_v1 = bar position (0-100, rises over time)
#   ec.dp_v2 = wobble step counter (sine-ish offsets)
#   ec.dp_v5 = accumulated phase points (carried from phase 1)

# Kill phase-1 entities for THIS session only
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=DP.El,distance=..12] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=DP.El,distance=..12] if score @s adv.gui_session = #gui_check ec.temp run kill @s

# Init phase-2 state
scoreboard players set @s ec.dp_phase 2
scoreboard players set @s ec.dp_v1 0
scoreboard players set @s ec.dp_v2 0

# Title label
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^0.50 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.Label"],billboard:"center",see_through:1b,text:[{"text":"✦ ","color":"gold"},{"text":"Dreamy Pull","color":"light_purple","bold":true}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
# Hint
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^0.40 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.Hint"],billboard:"center",see_through:1b,text:[{"text":"Phase 2: Pry","color":"gold"},{"text":" — click in the golden zone","color":"gray","italic":true}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.24f,0.24f,0.24f]}}
# Bar (updated each tick)
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^0.25 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.Bar"],billboard:"center",see_through:1b,text:{"text":"░░░░░░░░░░░░░░░░░░░░","color":"dark_gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.66f,0.66f,0.66f]}}
# Button
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^0.07 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.BtnText"],billboard:"center",see_through:1b,text:{"text":"[ Pull! ]","color":"light_purple","bold":true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
execute at @s rotated ~ 0 positioned ^ ^1.42 ^2.3 positioned ^0 ^-0.02 ^0 run summon interaction ~ ~ ~ {Tags:["DP.El","DP.Btn"],width:0.35f,height:0.18f,response:1b}
# Progress line
execute at @s rotated ~ 0 positioned ^ ^1.4 ^2.3 positioned ^0 ^-0.10 ^0 run summon text_display ~ ~ ~ {brightness:{block:15,sky:15},shadow_radius:0f,Tags:["DP.El","DP.Prog"],billboard:"center",see_through:1b,text:[{"text":"Phase ","color":"gray"},{"text":"2","color":"yellow"},{"text":"/2","color":"gray"}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.29f,0.29f,0.29f]}}

# Stamp newly spawned entities with this session (MP isolation)
execute as @e[type=text_display,tag=DP.El,distance=..8] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_check ec.temp
execute as @e[type=interaction,tag=DP.El,distance=..8] unless score @s adv.gui_session matches 1.. run scoreboard players operation @s adv.gui_session = #gui_check ec.temp

playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.5 1.2
