# Dreamy Pull — Style 3 — Finish: sum both phases, cap at 3, resolve
# Run as the player. ec.dp_v5 holds (phase-1 points + phase-2 points), each 0..2.
# Reached from eval_phase2 (after a phase-2 click) or from phase2's auto-resolve
# when the bar tops out with no click (+0 for phase 2).

scoreboard players operation @s ec.dp_quality = @s ec.dp_v5
execute if score @s ec.dp_quality matches 4.. run scoreboard players set @s ec.dp_quality 3

function evercraft:dreamy_pull/resolve
