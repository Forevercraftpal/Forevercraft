# Dreamy Pull — Award the bonus "good find"
# Run as the player. Routed by ec.dp_source (1 = prospect, 2 = forage, 3 = splash, 4 = nest, 5 = chest, 6 = timberfall, 7 = buried_cache).
# Reuses the pack's existing rare tables; the rarest sub-rolls are gated to quality 3.

execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

# ---------------- Prospect (mining) ----------------
execute if score @s ec.dp_source matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:prospect/fortune_drops
execute if score @s ec.dp_source matches 1 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:prospect/fortune_drops
# Top-tier flourish (quality 3): a shot at a crate, else a chance at a random glyph
execute if score @s ec.dp_source matches 1 if score @s ec.dp_quality matches 3.. store result score #dp_rare ec.temp run random value 1..100
execute if score @s ec.dp_source matches 1 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 1..35 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/bonus_crate
execute if score @s ec.dp_source matches 1 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 1..35 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/bonus_crate
execute if score @s ec.dp_source matches 1 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 36..50 run function evercraft:gacha/pull/grant_random_glyph

# ---------------- Forage (harvesting) ----------------
execute if score @s ec.dp_source matches 2 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:forage/fortune_drops
execute if score @s ec.dp_source matches 2 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:forage/fortune_drops
# Top-tier flourish (quality 3): a rare reagent, else a shot at a crate
execute if score @s ec.dp_source matches 2 if score @s ec.dp_quality matches 3.. store result score #dp_rare ec.temp run random value 1..100
execute if score @s ec.dp_source matches 2 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 1..45 run function evercraft:forage/bonus_potion_ingredient
execute if score @s ec.dp_source matches 2 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 46..58 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/bonus_crate
execute if score @s ec.dp_source matches 2 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 46..58 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/bonus_crate

# ---------------- Fishing / splash (water-surface node) ----------------
execute if score @s ec.dp_source matches 3 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:fishing/splash_nodes/crate
execute if score @s ec.dp_source matches 3 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:fishing/splash_nodes/crate
# Top-tier flourish (quality 3): a shot at a bonus crate, else a chance at a random glyph
execute if score @s ec.dp_source matches 3 if score @s ec.dp_quality matches 3.. store result score #dp_rare ec.temp run random value 1..100
execute if score @s ec.dp_source matches 3 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 1..35 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/bonus_crate
execute if score @s ec.dp_source matches 3 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 1..35 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/bonus_crate
execute if score @s ec.dp_source matches 3 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 36..50 run function evercraft:gacha/pull/grant_random_glyph

# ---------------- Nest (source 4 = Lamentor shear-harvest) ----------------
# Nests are a foraging act (shears), so the bonus mirrors forage (source 2): the forage fortune
# table + a quality-3 flourish (rare reagent, else a shot at a crate). inv-full guarded each.
execute if score @s ec.dp_source matches 4 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:forage/fortune_drops
execute if score @s ec.dp_source matches 4 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:forage/fortune_drops
execute if score @s ec.dp_source matches 4 if score @s ec.dp_quality matches 3.. store result score #dp_rare ec.temp run random value 1..100
execute if score @s ec.dp_source matches 4 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 1..45 run function evercraft:forage/bonus_potion_ingredient
execute if score @s ec.dp_source matches 4 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 46..58 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/bonus_crate
execute if score @s ec.dp_source matches 4 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 46..58 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/bonus_crate

# ---------------- Chest node (source 5 = Gearwright chest open) ----------------
# A landed chest Dreamy Pull IS the "boosts the crate threshold" payoff (PLAN §2): it hands the player
# a crate directly. Routes through the chest loot resolver's crate channel so the crate type respects
# the held key/chronicle (resolve reads gth_temp.ctype, still pinned from this open). Quality 3 adds a
# bonus crate on top. The base crate give is unconditional (the won minigame is the reward).
execute if score @s ec.dp_source matches 5 run function evercraft:tinkering/chest_drop/dreamy_crate
execute if score @s ec.dp_source matches 5 if score @s ec.dp_quality matches 3.. store result score #dp_rare ec.temp run random value 1..100
execute if score @s ec.dp_source matches 5 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 1..35 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/bonus_crate
execute if score @s ec.dp_source matches 5 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 1..35 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/bonus_crate

# ---------------- Timberfall (source 6 = Lumberfell channeled chop) ----------------
# A landed Timberfall Dreamy Pull is a wood/forage windfall — reuse the forage fortune table (a
# tree chop IS a foraging act), inv-full guarded like the other branches. Quality 3 adds a bonus
# crate. The base give is unconditional (the won minigame is the reward).
execute if score @s ec.dp_source matches 6 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:forage/fortune_drops
execute if score @s ec.dp_source matches 6 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:forage/fortune_drops
execute if score @s ec.dp_source matches 6 if score @s ec.dp_quality matches 3.. store result score #dp_rare ec.temp run random value 1..100
execute if score @s ec.dp_source matches 6 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 1..45 run function evercraft:forage/bonus_potion_ingredient
execute if score @s ec.dp_source matches 6 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 46..58 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/bonus_crate
execute if score @s ec.dp_source matches 6 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 46..58 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/bonus_crate

# ---------------- Buried Cache (source 7 = Terrawarp dig node) ----------------
# A landed Buried Cache Dreamy Pull is an earth windfall — reuse the prospect fortune table (a dig
# unearths the same kind of mineral/buried-treasure bonus a mining strike does), inv-full guarded.
# Quality 3 adds a bonus crate, else a shot at the Terrawarp material (Geode Dust). Base give is
# unconditional (the won minigame is the reward). Mirrors the source-1/3 shape (crate-then-extra).
execute if score @s ec.dp_source matches 7 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:prospect/fortune_drops
execute if score @s ec.dp_source matches 7 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:prospect/fortune_drops
execute if score @s ec.dp_source matches 7 if score @s ec.dp_quality matches 3.. store result score #dp_rare ec.temp run random value 1..100
execute if score @s ec.dp_source matches 7 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 1..35 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/bonus_crate
execute if score @s ec.dp_source matches 7 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 1..35 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/bonus_crate
execute if score @s ec.dp_source matches 7 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 36..55 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:buried_cache/geode_dust
execute if score @s ec.dp_source matches 7 if score @s ec.dp_quality matches 3.. if score #dp_rare ec.temp matches 36..55 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:buried_cache/geode_dust

# ---------------- Wave D2: random class XP on a landed (won) Dreamy Pull ----------------
# This file is ONLY the won-minigame path, so reaching here means a landed Dreamy Pull grants
# a random windfall of craft-class XP in [80, 330] to the pull's mapped class. The difficulty
# multiplier (×10 Newcomer / ×5 Adventurer / ×1 Pioneer) is applied INSIDE internal_grant, so a
# Newcomer landed Dreamy = 800–3300; a Pioneer = 80–330. Do NOT scale the roll here.
# (Lowered from 250–1000 — Joseph 2026-06-08, dreamy pulls were over-rewarding.)
# Map ec.dp_source -> class_id (1->1 ss, 2->3 gs, 3->5 sc), same mapping as gather/grant_xp.
execute if score @s ec.dp_source matches 1 run scoreboard players set @s ec.caff_class 1
execute if score @s ec.dp_source matches 2 run scoreboard players set @s ec.caff_class 3
execute if score @s ec.dp_source matches 3 run scoreboard players set @s ec.caff_class 5
# Nest family (source 4 -> Lamentor, class 6) — the shears Craft-Affinity, same mapping as
# gather/grant_xp's gth_src=4. Lamentor HAS a daily cap, so the #caff_node flag below (set for
# every dreamy grant) keeps the 50k/day cap applying here as for the other node families.
execute if score @s ec.dp_source matches 4 run scoreboard players set @s ec.caff_class 6
# Chest-Node family (PLAN-chest-nodes §2, ADDITIVE): source 5 -> Gearwright (class 7). The XP
# grant below honors the same 50k-cap path; class 7 has no daily cap (§14.5) so internal_grant's
# cap pass is a no-op for it (harmless). Never touches sources 1-3.
execute if score @s ec.dp_source matches 5 run scoreboard players set @s ec.caff_class 7
# Timberfall family (Lumberfell channeled chop, ADDITIVE): source 6 -> Lumberfell (class 2). The
# XP grant below honors the same 50k/day-cap node path (#caff_node 1) — Lumberfell HAS a daily cap,
# so the flag keeps it applying here as for the other node families. Never touches sources 1-5.
execute if score @s ec.dp_source matches 6 run scoreboard players set @s ec.caff_class 2
# Buried Cache family (Terrawarp dig node, ADDITIVE): source 7 -> Terrawarp (class 4). The XP grant
# below honors the same 50k/day-cap node path (#caff_node 1) — Terrawarp HAS a daily cap, so the
# flag keeps it applying here as for the other node families. Never touches sources 1-6.
execute if score @s ec.dp_source matches 7 run scoreboard players set @s ec.caff_class 4
# delta = a random windfall of 80–330 class XP (difficulty-scaled in internal_grant); #caff_node 1
# marks this as NODE XP so internal_grant applies the 50k/day cap EVEN for spirit-tool holders
# (node:1b, balance #11). Both #delta and #caff_node are set IMMEDIATELY before internal_grant —
# no intervening function call — so the shared ec.temp can't be clobbered between set + read
# (grant_verb pattern). internal_grant resets #caff_node to 0 afterward, so other (non-node) grant
# callers keep their spirit-bypass.
execute store result score #delta ec.temp run random value 80..330
scoreboard players set #caff_node ec.temp 1
function evercraft:craft_affinity/internal_grant
# Make the windfall feel rewarding (one terse line; never "magic").
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"light_purple"},{text:"Dreamy XP",color:"light_purple",bold:true},{text:" — a windfall of insight!",color:"gray"},{text:" ✦",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Cross-epic S2: a landed splash Dreamy Pull advances the Fisher's Questline (type "dreamy_win").
# Joseph wires the questline-side quest type. Source-3 (fishing/splash) ONLY — self-gating no-op
# for players without an active dreamy_win quest, so it's free until those quests exist.
execute if score @s ec.dp_source matches 3 run function evercraft:fishing/questline/on_dreamy_win

# Shared feedback
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your find was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Dreamy Pull",color:"light_purple",bold:true},{text:" — a fortunate find!",color:"light_purple"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.4
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.5 0.4 0.15 12
