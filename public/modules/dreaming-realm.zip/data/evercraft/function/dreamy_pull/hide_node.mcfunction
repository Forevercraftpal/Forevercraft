# Dreamy Pull — @s is the launching node's interaction entity (selected by suppress_node).
# #gui_check ec.temp = the launching player's adv.gui_session.
# Snapshot the node's true hitbox dims onto its OWN scores (x100, int — so cleanup/restore_node
# puts them back exactly with no per-source dims table), stamp the player's session for MP-safe
# restore, then collapse the box to ~0 so it can't catch the look ray meant for the [Pull!] button.

scoreboard players operation @s adv.gui_session = #gui_check ec.temp
execute store result score @s ec.dp_nodew run data get entity @s width 100
execute store result score @s ec.dp_nodeh run data get entity @s height 100
tag @s add DP.HidNode
data merge entity @s {width:0.05f,height:0.05f}
