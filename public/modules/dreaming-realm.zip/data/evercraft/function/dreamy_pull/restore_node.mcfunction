# Dreamy Pull — @s is the node interaction whose hitbox suppress_node/hide_node collapsed.
# Run as @s (the interaction entity), from cleanup, session-matched. The node was never killed
# (it has charges), so we just put the real dims back from the snapshot scores and clear our
# markers, leaving a clean, fully-clickable harvest node behind. width float scale 0.01 undoes
# the x100 snapshot (score 80 -> 0.80f). Guard at 1 keeps a never-snapshotted node off 0-width.
execute if score @s ec.dp_nodew matches 1.. store result entity @s width float 0.01 run scoreboard players get @s ec.dp_nodew
execute if score @s ec.dp_nodeh matches 1.. store result entity @s height float 0.01 run scoreboard players get @s ec.dp_nodeh
tag @s remove DP.HidNode
scoreboard players reset @s ec.dp_nodew
scoreboard players reset @s ec.dp_nodeh
scoreboard players reset @s adv.gui_session
