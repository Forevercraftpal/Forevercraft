# Dreamy Pull — collapse the LAUNCHING node's right-click hitbox for the session.
# Run as @s (the player), at @s. ec.dp_source picks the node family.
#
# WHY: most harvest nodes have charges and PERSIST after a winning gather (complete_mine only
# despawns on ec.gth_despawn) — and the 7% pull fires on that same win. So the node's interaction
# box is still sitting right where the player just clicked. Minecraft routes a right-click to the
# CLOSEST interaction box on the look ray, and the node (point-blank, up to 3.2x3.0 for a felling
# tree) is nearer than the [Pull!] button floating ^2.3 ahead — so the node swallows the click.
# We shrink the nearest matching node's hitbox to ~0 (snapshotting its true dims onto its own
# scores so cleanup can restore them exactly), MP-stamped with this player's session.
# Paired with restore_node (called from cleanup). The node is NEVER killed — it has charges.

scoreboard players operation #gui_check ec.temp = @s adv.gui_session

# Source -> click-tag family. tag=!DP.HidNode guards against re-collapsing an already-suppressed
# node (a prior pull that never cleaned up would otherwise bake 0.05 in as the "true" size).
execute if score @s ec.dp_source matches 1 as @e[type=interaction,tag=ec.prospect_click,tag=!DP.HidNode,sort=nearest,limit=1,distance=..4] run function evercraft:dreamy_pull/hide_node
execute if score @s ec.dp_source matches 2 as @e[type=interaction,tag=ec.forage_click,tag=!DP.HidNode,sort=nearest,limit=1,distance=..4] run function evercraft:dreamy_pull/hide_node
execute if score @s ec.dp_source matches 3 as @e[type=interaction,tag=ec.splash_click,tag=!DP.HidNode,sort=nearest,limit=1,distance=..4] run function evercraft:dreamy_pull/hide_node
execute if score @s ec.dp_source matches 4 as @e[type=interaction,tag=ec.nest_click,tag=!DP.HidNode,sort=nearest,limit=1,distance=..4] run function evercraft:dreamy_pull/hide_node
execute if score @s ec.dp_source matches 5 as @e[type=interaction,tag=ec.chest_click,tag=!DP.HidNode,sort=nearest,limit=1,distance=..4] run function evercraft:dreamy_pull/hide_node
execute if score @s ec.dp_source matches 6 as @e[type=interaction,tag=ec_tf_treeclick,tag=!DP.HidNode,sort=nearest,limit=1,distance=..6] run function evercraft:dreamy_pull/hide_node
execute if score @s ec.dp_source matches 7 as @e[type=interaction,tag=ec.cache_click,tag=!DP.HidNode,sort=nearest,limit=1,distance=..4] run function evercraft:dreamy_pull/hide_node
