# Dreamy Pull — Style 2 — Check for button click
# Run as the player. Session-matched so only THIS player's button counts.
# `on target` routes evaluate to the EXACT player who clicked (the house GUI convention,
# matching advantage/cooking/etc.) — robust regardless of @a distance/session-stamp timing.
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=interaction,tag=DP.Btn,distance=..8] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction on target run function evercraft:dreamy_pull/style_mash/evaluate
execute as @e[type=interaction,tag=DP.Btn,distance=..8] if score @s adv.gui_session = #gui_check ec.temp if data entity @s interaction run data remove entity @s interaction
