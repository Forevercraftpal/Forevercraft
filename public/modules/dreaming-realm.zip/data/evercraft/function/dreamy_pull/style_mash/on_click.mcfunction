# Dreamy Pull — Style 2 — Click handler  (deprecated 2026-06-01)
# No longer called: check_click now uses `if data entity @s interaction on target run ... evaluate`
# (the house GUI convention) and routes directly to the clicking player. Kept as a no-op-safe
# stub for revert; the `@a` re-derivation below was the old, more fragile routing path.
data remove entity @s interaction
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @a[scores={ec.dp_active=1},distance=..8] if score @s adv.gui_session = #gui_check ec.temp run function evercraft:dreamy_pull/style_mash/evaluate
