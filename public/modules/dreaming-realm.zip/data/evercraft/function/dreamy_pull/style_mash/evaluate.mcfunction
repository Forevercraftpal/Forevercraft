# Dreamy Pull — Style 2 — Per-click fill bump
# Run as the player. Each [Pull!] adds 8 fill (clamp at 100). No resolve here —
# the mash only ends when the countdown (ec.dp_v4) runs out in tick.

scoreboard players add @s ec.dp_v1 8
execute if score @s ec.dp_v1 matches 100.. run scoreboard players set @s ec.dp_v1 100

# Click feedback — brighter chime once the charge is high (>=85)
scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute if score @s ec.dp_v1 matches ..84 run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 1.4
execute if score @s ec.dp_v1 matches 85.. run playsound minecraft:entity.player.attack.crit master @s ~ ~ ~ 0.7 1.6
