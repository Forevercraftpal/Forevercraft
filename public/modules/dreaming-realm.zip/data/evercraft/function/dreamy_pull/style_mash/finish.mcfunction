# Dreamy Pull — Style 2 (Button-Mash) — Finish
# Run as the player when the countdown (ec.dp_v4) hits 0.
# Final fill (ec.dp_v1) → quality tier:  <25 → 0,  25..54 → 1,  55..84 → 2,  85.. → 3.

scoreboard players set @s ec.dp_quality 0
execute if score @s ec.dp_v1 matches 25..54 run scoreboard players set @s ec.dp_quality 1
execute if score @s ec.dp_v1 matches 55..84 run scoreboard players set @s ec.dp_quality 2
execute if score @s ec.dp_v1 matches 85.. run scoreboard players set @s ec.dp_quality 3

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"Fully charged! ",color:"light_purple",bold:true},{text:"(perfect!)",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.dp_quality matches 3 run function evercraft:util/notify/emit
execute if score @s ec.dp_quality matches 3 run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.5
data modify storage evercraft:notify stage.c set value [{text:"Charged up. ",color:"green"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.dp_quality matches 1..2 run function evercraft:util/notify/emit
execute if score @s ec.dp_quality matches 1..2 run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.2
data modify storage evercraft:notify stage.c set value [{text:"Drained away...",color:"red"}]
scoreboard players set #ndur ec.temp 45
execute if score @s ec.dp_quality matches 0 run function evercraft:util/notify/emit
execute if score @s ec.dp_quality matches 0 run playsound minecraft:entity.player.attack.nodamage master @s ~ ~ ~ 0.5 0.8

function evercraft:dreamy_pull/resolve
