# === DREAMY PULL — bonus gather mini-game ===
# A short optional skill mini-game that fires 7% of the time AFTER a node is
# gathered/mined (base loot is always already given — this is pure upside).
# Playing well raises the odds of an extra "good find". Shared by prospect + forage.
# Called once from init on load.

scoreboard objectives add ec.dp_active dummy "Dreamy Pull Active"
scoreboard objectives add ec.dp_style dummy "Dreamy Pull Style"
scoreboard objectives add ec.dp_source dummy "Dreamy Pull Source"
scoreboard objectives add ec.dp_quality dummy "Dreamy Pull Quality"
scoreboard objectives add ec.dp_timer dummy "Dreamy Pull Life Timer"
scoreboard objectives add ec.dp_phase dummy "Dreamy Pull Phase"
scoreboard objectives add ec.dp_v1 dummy "Dreamy Pull Scratch 1"
scoreboard objectives add ec.dp_v2 dummy "Dreamy Pull Scratch 2"
scoreboard objectives add ec.dp_v3 dummy "Dreamy Pull Scratch 3"
scoreboard objectives add ec.dp_v4 dummy "Dreamy Pull Scratch 4"
scoreboard objectives add ec.dp_v5 dummy "Dreamy Pull Scratch 5"
# Wave D1: the under-level odds penalty (0-100, default 100 = no reduction), SNAPSHOTTED
# from ec.gth_dppenalty by maybe_trigger at session init. resolve reads THIS (the session
# snapshot), never the live harvest value — so a second harvest mid-minigame can't corrupt
# the in-flight ladder. SINGLE WRITER = maybe_trigger.
scoreboard objectives add ec.dp_penalty dummy "Dreamy Pull odds penalty x100 (default 100)"
# Wave D2: the 2×-on-Dreamy-win bonus XP, SNAPSHOTTED from ec.gth_lastxp by maybe_trigger at
# session init = the harvest's full win-XP (baseXP × areaMult × familiar). give_good_find
# re-grants it on a won minigame to double the harvest XP. Session-stable snapshot so a second
# harvest mid-minigame can't corrupt it. SINGLE WRITER = maybe_trigger.
scoreboard objectives add ec.dp_bonusxp dummy "Dreamy Pull 2x bonus XP (snapshot of last win XP)"
# Hitbox snapshot of the launching node's interaction entity (width/height x100, int), held ON
# the node entity by hide_node so cleanup/restore_node puts the exact dims back. SINGLE WRITER =
# hide_node (set) / restore_node (reset). Lets us collapse the node's box during the pull so it
# can't swallow clicks meant for the [Pull!] button, then restore it without a per-source table.
scoreboard objectives add ec.dp_nodew dummy "Dreamy Pull suppressed-node width x100"
scoreboard objectives add ec.dp_nodeh dummy "Dreamy Pull suppressed-node height x100"
