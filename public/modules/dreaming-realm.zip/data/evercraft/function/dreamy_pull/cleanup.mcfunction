# Dreamy Pull — Cleanup
# Run as the player. Removes this session's display entities and resets all state.
# Kills are SESSION-scoped (matched on adv.gui_session) with NO distance cap: the
# router fires cleanup the moment the player walks >12 blocks from the panel, and the
# entities must still be removed even though they're now out of a small radius (they
# would otherwise orphan in the world). The session match keeps it multiplayer-safe —
# only THIS player's panel is touched, never a nearby player's Dreamy Pull.

scoreboard players operation #gui_check ec.temp = @s adv.gui_session
execute as @e[type=text_display,tag=DP.El] if score @s adv.gui_session = #gui_check ec.temp run kill @s
execute as @e[type=interaction,tag=DP.El] if score @s adv.gui_session = #gui_check ec.temp run kill @s

# Restore the launching node's hitbox we collapsed for the duration (suppress_node). Session-
# matched so only THIS player's suppressed node is touched, never a nearby player's. The node
# persists (charges) — it was never killed — so this puts its real dims back from the snapshot.
execute as @e[type=interaction,tag=DP.HidNode] if score @s adv.gui_session = #gui_check ec.temp run function evercraft:dreamy_pull/restore_node

scoreboard players set @s ec.dp_active 0
scoreboard players set @s ec.dp_style 0
scoreboard players set @s ec.dp_quality 0
scoreboard players set @s ec.dp_timer 0
scoreboard players set @s ec.dp_phase 0
