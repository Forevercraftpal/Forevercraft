# Dreamy Pull — Per-tick router
# Run as each player with ec.dp_active=1 (driven from root tick), at the player.
# Owns the life timer (ec.dp_timer); styles must NOT write ec.dp_timer, only read it.

# Watchdog: force-resolve a stuck session after 60s (1200t)
scoreboard players add @s ec.dp_timer 1
execute if score @s ec.dp_timer matches 1200.. run return run function evercraft:dreamy_pull/resolve

# Safety: display entities vanished (reload / chunk unload) → silent cleanup
execute unless entity @e[type=interaction,tag=DP.El,distance=..12] run return run function evercraft:dreamy_pull/cleanup

# Dispatch to the active style's tick
execute if score @s ec.dp_style matches 1 run function evercraft:dreamy_pull/style_timing/tick
execute if score @s ec.dp_style matches 2 run function evercraft:dreamy_pull/style_mash/tick
execute if score @s ec.dp_style matches 3 run function evercraft:dreamy_pull/style_phase/tick
