# === DREAMY PULL — 3rd-FAIL RESCUE (10%, opens the dreamy mini-game) ==================
# Run as @s, at the node, from gather/resolve_crumble at its "maybe_rescue" hook — which
# fires ON the crumble, BEFORE the caller despawns the spent node. ec.gth_src holds the
# source (1=prospect, 2=forage, 3=splash, 4=nest, 5=chest, 6=timberfall, 7=buried_cache).
# Wiring Audit #37 D2: widened from 1..3 to 1..7 — give_good_find pays a reward + class XP for
# ALL seven sources (branches at give_good_find:8-76,84-102), and nest(4)/chest(5)/cache(7) DO
# reach resolve_crumble, so they now get the same 10% consolation. src 6 (timberfall) never
# crumbles (it computes win/fail directly, miss → resolve_miss), so 1..7 simply never fires for 6.
#
# On a 10% save the spent node offers ONE Dreamy Pull — the SAME mini-game as the 7% harvest
# trigger (Joseph 2026-06-04: "a game just like the regular one", then "replace" the old
# instant give). You PLAY for the reward: land the pull -> give_good_find's dreamy reward
# (source-routed by ec.dp_source); whiff -> nothing (the node still crumbled). There is NO
# guaranteed primary loot anymore — earning it through the game IS the rescue.
#
# The window summons `at @s` (the player) and give_good_find is source-routed, so neither
# needs the node — correct, and (per the 2026-06-22 per-player retrofit) the crumble no longer
# despawns the node at all: it stays alive (the crumbling player is merely marked spent for
# themselves). The rescue is unchanged — it's a per-player consolation either way.
#
# RACE: resolve_crumble only runs for the tick's claim-winner; all scratch is @s-scoped or
# #...ec.temp consumed immediately.

# 10% roll. Otherwise the node crumbles to nothing as before (the crumble line already played
# in resolve_crumble — return, add nothing).
execute store result score #dp_rescue ec.temp run random value 1..100
execute unless score #dp_rescue ec.temp matches 1..10 run return 0

# All seven sources give_good_find pays a dreamy reward for (prospect/forage/splash/nest/chest/
# timberfall/buried_cache), and never stack on an already-running mini-game (that session owns
# ec.dp_source + the window).
execute unless score @s ec.gth_src matches 1..7 run return 0
execute if score @s ec.dp_active matches 1 run return 0

# Announce (Wave 1, Joseph 2026-06-10: subtitle-alone FLASH — the critical lane. Lower-center,
# small text, NO full title blocking the crosshair; util/notify/flash stamps its own times every
# call) + a PREEMPTIVE bar copy (emit_crit cuts whatever the queue is showing — ≤1 tick to render
# — and #nttl lets it die silently if somehow still queued after the moment passes) + the Dreamy
# peak signature (chime + totem particle). This prompts the game; the reward is earned by
# playing, so there is no "you found loot" promise here.
data modify storage evercraft:notify flash.c set value [{text:"✦ ",color:"gold"},{text:"Dreamy Pull",color:"light_purple"},{text:" — one last pull, take it!",color:"light_purple"},{text:" ✦",color:"gold"}]
function evercraft:util/notify/flash
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"light_purple"},{text:"A Dreamy Pull",color:"light_purple"},{text:" rises from the spent node — pull it free!",color:"gray",italic:true},{text:" ✦",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
scoreboard players set #nttl ec.temp 100
function evercraft:util/notify/emit_crit
playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.7 1.0
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.5 0.4 0.15 12

# Open the mini-game. give_good_find routes its reward by ec.dp_source, so map it from gth_src
# (1=prospect / 2=forage / 3=splash / 4=nest / 5=chest / 7=buried_cache; 6 never reaches here).
# launch contract: dp_source set + no active session (both guaranteed by the early returns above).
scoreboard players operation @s ec.dp_source = @s ec.gth_src
function evercraft:dreamy_pull/launch
