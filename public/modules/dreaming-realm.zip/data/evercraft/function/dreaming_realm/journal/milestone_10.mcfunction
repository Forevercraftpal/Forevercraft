# Dream Journal — 10 entries milestone: "Dreamkeeper"
tellraw @s {text:""}
# §5b actor-named broadcast — render directly in actor's context so {selector:"@s"} resolves once
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Dreamkeeper",color:"#CE93D8"},{text:" ✦",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
tellraw @s [{text:"  ",color:"gray"},{text:"10 dreams recorded in your journal.",color:"#B39DDB"}]
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2

# Unlock Dreamkeeper title (bit 0)
scoreboard players add @s ec.special_titles 1

# Lifetime special-titles-unlocked counter (fires once globally — caller gates on ec.dj_count matches 10)
scoreboard players add @s ec.titles_count 1
