# Dream Journal — 30 entries milestone: "Dream Chronicler"
tellraw @s {text:""}
# §5b actor-named broadcast — render directly in actor's context so {selector:"@s"} resolves once
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"",color:"white"},{text:" has earned the title: ",color:"gray"},{text:"Dream Chronicler",color:"#AB47BC"},{text:" ✦",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
tellraw @s [{text:"  ",color:"gray"},{text:"30 dreams recorded. The realm remembers you.",color:"#B39DDB"}]
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
particle minecraft:witch ~ ~1 ~ 0.5 0.5 0.5 0.1 15

# Unlock Dream Chronicler title (bit 1)
scoreboard players add @s ec.special_titles 2

# Lifetime special-titles-unlocked counter (fires once globally — caller gates on ec.dj_count matches 30)
scoreboard players add @s ec.titles_count 1
