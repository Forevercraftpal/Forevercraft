# Dreaming Realm — Grant Dreamer's Cloak (Master Dreamer reward)
# All 3 challenges complete + all 5 lore pieces collected
# Context: as @s = dreaming/waking player

# Grant the Dreamer's Cloak — an exquisite leather chestplate.
# Inv-full guard (#49 W1-A): drop at feet rather than void on a full inventory, and stamp the
# one-time dr.master_dreamer guard ONLY AFTER a confirmed delivery — so an inv-full failure can
# never permanently lose the Cloak while latching the dup-guard.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run give @s leather_chestplate[custom_name={text:"Dreamer's Cloak",color:"#E8A0F0",italic:false},lore=[{text:"Woven from the threads of dreams",color:"#D4A574",italic:true},{text:"by one who mastered the sleeping realm.",color:"#D4A574",italic:true},{text:""},{text:"Exquisite",color:"#FFD700",italic:false}],custom_data={dreamers_cloak:true},dyed_color=6832367,enchantment_glint_override=true,enchantments={protection:4,unbreaking:3}] 1
execute if score #inv_full ec.var matches 1 at @s run summon item ~ ~0.5 ~ {Item:{id:"minecraft:leather_chestplate",count:1,components:{custom_name:{text:"Dreamer's Cloak",color:"#E8A0F0",italic:false},lore:[{text:"Woven from the threads of dreams",color:"#D4A574",italic:true},{text:"by one who mastered the sleeping realm.",color:"#D4A574",italic:true},{text:""},{text:"Exquisite",color:"#FFD700",italic:false}],custom_data:{dreamers_cloak:true},dyed_color:6832367,enchantment_glint_override:true,enchantments:{protection:4,unbreaking:3}}},PickupDelay:10s}

# Mark as earned (prevent duplicates) — stamped AFTER the give-or-drop above (both deliver the Cloak)
tag @s add dr.master_dreamer

# Achievement
advancement grant @s only evercraft:dreaming_realm/master_dreamer

# Inv-full notice — the Cloak was dropped at the player's feet
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your Dreamer's Cloak was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit

# Announcement
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"MASTER DREAMER",color:"#FFD700",bold:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"The Dreamer's Cloak materializes around your shoulders...",color:"#E8A0F0",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
playsound ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.5
particle totem_of_undying ~ ~1 ~ 1.0 1.0 1.0 0.5 80 normal @s

# Realm-wide announcement
# §5b actor-named broadcast — render directly in actor's context so {selector:"@s"} resolves once
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"",color:"white"},{text:" has become a ",color:"#D4A574"},{text:"Master Dreamer",color:"#FFD700"},{text:"!",color:"#D4A574"},{text:" ✦",color:"gold"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
