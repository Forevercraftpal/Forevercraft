# Dreaming Realm — Intro Part 2 (3s after entry)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"This place exists between waking and sleeping...",color:"#D4A574",italic:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 70
execute as @a[tag=dr.in_realm] run function evercraft:util/notify/emit
execute as @a[tag=dr.in_realm] run playsound block.amethyst_block.chime master @s ~ ~ ~ 0.4 0.6
