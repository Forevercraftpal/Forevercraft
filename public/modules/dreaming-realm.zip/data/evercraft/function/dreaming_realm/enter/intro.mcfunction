# Dreaming Realm — Intro Narration
# Timed tellraw sequence delivered to the dreaming player
# Context: as @s = dreaming player

# Immediate (plays during blindness — player reads it as vision clears)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"You feel the world dissolve around you...",color:"#D4A574",italic:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 70
function evercraft:util/notify/emit

# Delayed narration
schedule function evercraft:dreaming_realm/enter/intro_2 3s
schedule function evercraft:dreaming_realm/enter/intro_3 7s

# Route to first challenge after intro settles
schedule function evercraft:dreaming_realm/challenges/start_first 10s
