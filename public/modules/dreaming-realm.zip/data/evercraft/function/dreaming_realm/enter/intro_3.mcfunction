# Dreaming Realm — Intro Part 3 (7s after entry)
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Prove yourself, Dreamer. You have ",color:"#D4A574",italic:true},{text:"five minutes",color:"white",bold:true,italic:true},{text:" before you wake.",color:"#D4A574",italic:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 70
execute as @a[tag=dr.in_realm] run function evercraft:util/notify/emit
execute as @a[tag=dr.in_realm] run playsound ambient.soul_sand_valley.mood master @s ~ ~ ~ 0.5 1.0
