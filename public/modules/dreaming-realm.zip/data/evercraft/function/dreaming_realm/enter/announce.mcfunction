# Dreaming Realm — Realm-Wide Announcement
# Context: as @s = dreaming player

# Check if this was a lucky dream (sub-30 DR)
# §5b actor-named broadcast — render directly in actor's context so {selector:"@s"} resolves once
execute if data storage evercraft:dreaming {lucky_dream: true} run function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Against all odds, ",color:"#D4A574",italic:true},{text:"",color:"white",bold:true},{text:" has slipped into a Lucid Dream...",color:"#D4A574",italic:true},{text:" ✦",color:"gold"}]
data modify storage evercraft:notify stage.c[2].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute if data storage evercraft:dreaming {lucky_dream: true} run execute as @a run scoreboard players set #nttl ec.temp 600
execute if data storage evercraft:dreaming {lucky_dream: true} run execute as @a run function evercraft:util/notify/emit_keep
execute if data storage evercraft:dreaming {lucky_dream: true} run playsound ui.toast.challenge_complete master @a ~ ~ ~ 1.0 1.0
execute if data storage evercraft:dreaming {lucky_dream: true} run return 0

# Normal dream announcement
# §5b actor-named broadcast — render directly in actor's context so {selector:"@s"} resolves once
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"#9B59B6"},{text:"",color:"white"},{text:" has entered the Dreaming Realm...",color:"#D4A574",italic:true},{text:" ✦",color:"#9B59B6"}]
data modify storage evercraft:notify stage.c[1].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
playsound block.amethyst_block.chime master @a ~ ~ ~ 1.0 0.6
