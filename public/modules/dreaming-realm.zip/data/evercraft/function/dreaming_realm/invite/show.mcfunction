# Dreaming Realm — Show spectate invite to a party member
# Run as: the invited player

# Enable trigger
scoreboard players set @s ec.tp_join 0
scoreboard players enable @s ec.tp_join

# Mark as invited
tag @s add dr.invited

# Clickable invite message
tellraw @s [{text:"[Dream] ",color:"dark_purple",bold:true},{text:"Your party member has entered the Dreaming Realm! ",color:"light_purple"},{text:"[Spectate]",color:"green",bold:true,click_event:{action:"run_command",command:"/trigger ec.tp_join set 2"},hover_event:{action:"show_text",value:{text:"Spectate the dream",color:"yellow"}}}]

# Sound
playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.0
