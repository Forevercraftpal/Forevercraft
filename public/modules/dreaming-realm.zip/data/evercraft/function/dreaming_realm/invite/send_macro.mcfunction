# Dreaming Realm — Send spectate invite (macro)
# Arg: pid
$execute as @a[scores={ec.party_id=$(pid)},tag=!dr.in_realm,tag=!dr.spectator] run function evercraft:dreaming_realm/invite/show
