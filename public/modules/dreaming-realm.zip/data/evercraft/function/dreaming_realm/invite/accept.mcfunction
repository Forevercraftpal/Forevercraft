# Dreaming Realm — Accept spectate invite
# Run as: the accepting player

# Remove invited tag
tag @s remove dr.invited

# Validate that the dream is still active
data modify storage evercraft:notify stage.c set value [{text:"The dream has ended.",color:"gray"}]
scoreboard players set #ndur ec.temp 45
execute unless score #dr_active ec.var matches 1 run function evercraft:util/notify/emit
execute unless score #dr_active ec.var matches 1 run return 0

# Save return position
scoreboard players set @s ec.tp_ret_sys 2
execute at @s run function evercraft:tp_safety/save

# Switch to spectator mode
tag @s add dr.spectator
gamemode spectator @s

# Teleport to the dream arena center marker
execute at @e[type=marker,tag=dr.center,limit=1] run tp @s ~ ~1 ~

# Feedback
data modify storage evercraft:notify stage.c set value [{text:"\u2726 ",color:"dark_purple"},{text:"You peer into the dream...",color:"light_purple",italic:true},{text:" \u2726",color:"dark_purple"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You are spectating. The dream will end on its own.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.2
