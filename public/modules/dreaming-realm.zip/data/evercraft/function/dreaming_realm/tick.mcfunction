# Dreaming Realm — Per-Tick Logic
# Only called when #dr_active = 1 (from main tick.mcfunction)

# === ORPHAN SWEEP (#49 W3) ===
# The realm is a single GLOBAL-locked resource. The dreamer's timer only decrements while they are
# online (player_tick runs as @a[tag=dr.in_realm]); a dreamer who disconnects and never returns would
# otherwise leave #dr_active=1 forever, bricking the realm server-wide. Recovery is normally keyed to
# that one player reconnecting (reconnect/dispatch:7 → crash_recovery, fires within ~1 tick of rejoin).
# This sweep is the safety net for "never returns": when the lock is held but NO dreamer is online,
# advance a grace counter; after ~30s (600t — comfortably longer than any relogin, so crash_recovery
# always wins the race for a returning player) force exit/cleanup to release the lock. A live solo run
# resets the counter every tick, so it can never trip mid-run.
execute if entity @a[tag=dr.in_realm,limit=1] run scoreboard players set #dr_orphan ec.var 0
execute unless entity @a[tag=dr.in_realm,limit=1] run scoreboard players add #dr_orphan ec.var 1
execute unless entity @a[tag=dr.in_realm,limit=1] if score #dr_orphan ec.var matches 600.. run function evercraft:dreaming_realm/exit/orphan_sweep

# OPT: Single @a scan for all per-player logic (was 7 separate scans)
execute as @a[tag=dr.in_realm] at @s run function evercraft:dreaming_realm/player_tick

# Challenge per-tick checks (maze step detection, wave check, trial fragments)
function evercraft:dreaming_realm/challenges/tick

# Atmosphere effects (every 20 ticks = 1 second)
scoreboard players add #dr_atmo ec.var 1
execute if score #dr_atmo ec.var matches 20.. as @a[tag=dr.in_realm] at @s run function evercraft:dreaming_realm/atmosphere_tick
execute if score #dr_atmo ec.var matches 20.. run scoreboard players set #dr_atmo ec.var 0
