# Dreamer's Trial — Complete!
# Context: as @s = dreaming player

# Mark challenge 3 done
scoreboard players set @s ec.dream_ch3 1

# Remove trial tag
tag @s remove dr.trial_active

# Celebration
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Dreamer's Trial ",color:"#3498DB",bold:true},{text:"— Complete! ",color:"#2ECC71",bold:true},{text:"A Dream Shard materializes...",color:"#D4A574",italic:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
playsound ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
particle totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.3 30 normal @s

# Give Dream Shard — inv-full guard: drop at feet rather than void on a full inventory (#49 W1)
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run give @s amethyst_shard[custom_name={text:"Dream Shard",color:"light_purple",italic:false},custom_data={dream_shard:true},enchantment_glint_override=true] 1
execute if score #inv_full ec.var matches 1 at @s run summon item ~ ~0.5 ~ {Item:{id:"minecraft:amethyst_shard",count:1,components:{custom_name:{text:"Dream Shard",color:"light_purple",italic:false},custom_data:{dream_shard:true},enchantment_glint_override:true}},PickupDelay:10s}
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your Dream Shard was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit

# Kill remaining fragments
kill @e[type=item_display,tag=dr.frag]

# All 3 challenges complete → bonus reward
execute if score @s ec.dream_ch1 matches 1 if score @s ec.dream_ch2 matches 1 run function evercraft:dreaming_realm/exit/complete

# If not all done, hint at remaining
data modify storage evercraft:notify stage.c set value [{text:"Other challenges in the realm still await...",color:"#D4A574",italic:true}]
scoreboard players set #ndur ec.temp 40
execute unless score @s ec.dream_ch1 matches 1 run function evercraft:util/notify/emit
execute if score @s ec.dream_ch1 matches 1 unless score @s ec.dream_ch2 matches 1 run function evercraft:util/notify/emit
