# Memory Maze — Enable Input
# Called after sequence display completes. Player can now step on colors.

execute as @a[tag=dr.in_realm] run tag @s add dr.maze_input
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Now repeat the sequence! Step on the colors in order.",color:"#D4A574",italic:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=dr.in_realm] run function evercraft:util/notify/emit
execute as @a[tag=dr.in_realm] run playsound block.note_block.bell master @s ~ ~ ~ 1.0 1.0
