# Dream Guardians — Complete!
# Context: as @s = dreaming player

# Mark challenge 2 done
scoreboard players set @s ec.dream_ch2 1

# Celebration
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Dream Guardians ",color:"#E74C3C",bold:true},{text:"— Complete! ",color:"#2ECC71",bold:true},{text:"A Dream Shard materializes...",color:"#D4A574",italic:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
playsound ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
particle totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.3 30 normal @s

# Give Dream Shard — inv-full guard: drop at feet rather than void on a full inventory (#49 W1)
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run give @s amethyst_shard[custom_name={text:"Dream Shard",color:"light_purple",italic:false},custom_data={dream_shard:true},enchantment_glint_override=true] 1
execute if score #inv_full ec.var matches 1 at @s run summon item ~ ~0.5 ~ {Item:{id:"minecraft:amethyst_shard",count:1,components:{custom_name:{text:"Dream Shard",color:"light_purple",italic:false},custom_data:{dream_shard:true},enchantment_glint_override:true}},PickupDelay:10s}
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your Dream Shard was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit

# Direct to next challenge
data modify storage evercraft:notify stage.c set value [{text:"The floating platforms to the southeast beckon...",color:"#D4A574",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit

# Schedule next challenge start
schedule function evercraft:dreaming_realm/challenges/start_first 5s
