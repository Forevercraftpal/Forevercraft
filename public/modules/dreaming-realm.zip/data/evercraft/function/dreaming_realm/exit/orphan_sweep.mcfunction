# Dreaming Realm — Orphan Sweep (#49 W3)
# Called from dreaming_realm/tick when #dr_active=1 but NO dreamer has been online for ~30s (600t).
# Context: server (no @s — the dreamer is offline; that is the whole point).
#
# Releases the global lock + tears down the arena so a never-returning dreamer can't brick the realm
# server-wide. Idempotent vs crash_recovery: if the dreamer DOES return later, reconnect/dispatch:7
# fires crash_recovery (guarded build/destroy + dr.return tp + cleanup) which is harmless against an
# already-swept realm (#dr_active already 0, markers/mobs already gone). The offline dreamer's
# per-player ec.dream_* scores are reset by that crash_recovery on return (cleanup here runs with no
# @s executor, so its @s-targeted lines no-op — only the global teardown takes effect).

# Reset the grace counter so the next dream starts clean.
scoreboard players set #dr_orphan ec.var 0

# Log the reclaim (ops only — quiet for normal players).
execute as @a[tag=ec.admin] run tellraw @s [{text:"[Dreaming Realm] ",color:"dark_purple"},{text:"Orphaned dream lock reclaimed — the dreamer disconnected and did not return within 30s. The realm is open again.",color:"gray",italic:true}]

# Full teardown: releases #dr_active, restores any stranded spectators to survival, kills the
# return/center markers + dream mobs/entities. (cleanup's @s lines no-op without an executor.)
function evercraft:dreaming_realm/exit/cleanup
