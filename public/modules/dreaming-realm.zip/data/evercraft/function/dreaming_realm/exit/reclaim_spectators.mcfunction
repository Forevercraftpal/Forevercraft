# Dreaming Realm — Reclaim Stranded Spectators (#49 W3)
# Called from main tick when a dr.spectator player exists but the realm is NOT active (#dr_active=0).
# Context: server (no @s).
#
# Closes the invite/accept:10 TOCTOU strand: if a party member clicked [Spectate] the same tick the
# dreamer's run ended, accept could run AFTER cleanup already swept spectators — leaving the joiner in
# gamemode spectator at the destroyed arena with no dreamer to end the run and no future cleanup
# targeting them (the lock is now 0). This idempotent sweep restores them to survival regardless of
# the race. Mirrors cleanup:30-32 exactly.
execute as @a[tag=dr.spectator] run gamemode survival @s
execute as @a[tag=dr.spectator] run function evercraft:tp_safety/restore
execute as @a[tag=dr.spectator] run data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"The dream ended — you return to the waking world.",color:"#D4A574",italic:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute as @a[tag=dr.spectator] run function evercraft:util/notify/emit
tag @a remove dr.spectator
tag @a remove dr.invited
