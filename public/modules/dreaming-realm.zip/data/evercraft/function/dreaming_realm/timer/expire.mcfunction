# Dreaming Realm — Timer Expired (Force Exit)
# Context: as @s = dreaming player

data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"The dream fades to nothing...",color:"#D4A574",italic:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Run normal wake up sequence
function evercraft:dreaming_realm/exit/wake_up
