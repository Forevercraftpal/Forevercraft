# Dreaming Realm — 1 Minute Warning
# Context: as @s = dreaming player

data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"The dream grows thin... you feel yourself waking.",color:"#D4A574",italic:true},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
playsound block.amethyst_block.chime master @s ~ ~ ~ 0.6 0.4
