# Give Fisherman's Anecdote and mark as received
# Inv-full guard: drop the book at the player's feet rather than void it on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:books/fishermans_anecdote
execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:books/fishermans_anecdote
scoreboard players set @s ec.anec_fisher 1
data modify storage evercraft:notify stage.c set value [{text:"You found a salt-stained journal... ",color:"gray",italic:true},{text:"Fisherman's Anecdote",color:"aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 1 0.8
