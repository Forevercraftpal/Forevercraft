# Dream Echo — Display artifact memory (macro)
# Run as the clicking player
$data modify storage evercraft:notify stage.c set value [{text:"✧ ",color:"light_purple"},{text:"The dream echo whispers... ",color:"dark_purple",italic:true},{text:"\"$(artifact) was found here...\"",color:"light_purple",italic:true},{text:" ✧",color:"light_purple"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
