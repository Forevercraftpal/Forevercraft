# Secret 2: Sky Wanderer — Reach above Y 300
tag @s add jn.s2
scoreboard players add @s jn.secret_count 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 0.8 1.0
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Secret Discovered: ",color:"yellow",bold:true},{text:"Sky Wanderer",color:"dark_purple"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You reached the sky above Y 300!",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
function evercraft:journal/regions/check_all
