# Secret 3: Dimensional Traveler — Visit all 3 dimensions
tag @s add jn.s3
scoreboard players add @s jn.secret_count 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 0.8 1.0
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Secret Discovered: ",color:"yellow",bold:true},{text:"Dimensional Traveler",color:"dark_purple"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 50
function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"You have set foot in all three dimensions!",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 40
function evercraft:util/notify/emit
function evercraft:journal/regions/check_all
