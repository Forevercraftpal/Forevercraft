# ============================================================
# Record Structure Discovery
# Fires when jn.struct_count increases (new structure type found)
# Run as player, #jn_sc jn.temp has the new count
# ============================================================

execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.7 1.2
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"dark_aqua"},{text:"New Structure Discovered! ",color:"yellow"},{text:"(",color:"gray"},{score:{name:"#jn_sc",objective:"jn.temp"},color:"aqua"},{text:"/18)",color:"gray"},{text:" ✦",color:"dark_aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Check region completion
function evercraft:journal/regions/check_all
