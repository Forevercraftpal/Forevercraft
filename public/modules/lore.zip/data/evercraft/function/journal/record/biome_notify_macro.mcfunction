# Biome discovery notification — macro
$data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"dark_aqua"},{text:"Biome Discovered: ",color:"yellow"},{text:"$(bname)",color:"green"},{text:" (",color:"gray"},{score:{name:"@s",objective:"jn.biome_count"},color:"aqua"},{text:"/25)",color:"gray"},{text:" ✦",color:"dark_aqua"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
