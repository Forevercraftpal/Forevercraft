# Lore Discovery: Reset spawn timer based on movement state
# Moving (counter > 0): 533 ticks (~26.7 seconds) — 3/4 rate (Joseph 2026-06-03)
# Standing still (counter = 0): 11200 ticks (~9.3 minutes) — 3/4 rate

execute if score @s ec.lore_moving matches 1.. run scoreboard players set @s ec.lore_timer 533
execute if score @s ec.lore_moving matches ..0 run scoreboard players set @s ec.lore_timer 11200

# The Dreaming: triple lore sparkle spawn rate
execute if score #we_dreaming_lock ec.var matches 1 if score @s ec.lore_moving matches 1.. run scoreboard players set @s ec.lore_timer 177
execute if score #we_dreaming_lock ec.var matches 1 if score @s ec.lore_moving matches ..0 run scoreboard players set @s ec.lore_timer 3733
