# Lore Reward: Grant all rewards for completing a set (macro)
# ec.lore_rarity has rarity (1-6). temp.set_meta has full set data.

# 1. Apply permanent Dream Rate modifier
function evercraft:lore/reward/apply_dr with storage evercraft:lore temp

# 2. Give XP levels based on rarity
execute if score @s ec.lore_rarity matches 1 run function evercraft:util/xp_levels {n:3}
execute if score @s ec.lore_rarity matches 2 run function evercraft:util/xp_levels {n:5}
execute if score @s ec.lore_rarity matches 3 run function evercraft:util/xp_levels {n:10}
execute if score @s ec.lore_rarity matches 4 run function evercraft:util/xp_levels {n:15}
execute if score @s ec.lore_rarity matches 5 run function evercraft:util/xp_levels {n:25}
execute if score @s ec.lore_rarity matches 6 run function evercraft:util/xp_levels {n:50}

# 3. Give crate based on rarity
function evercraft:lore/reward/give_crate

# 4. Announce set completion with set name from storage
# §5b actor-naming broadcast — render direct in the actor's context so {selector:@s} resolves once.
function evercraft:util/notify/whoami
data modify storage evercraft:notify stage.c set value [{text:"",color:"yellow"},{text:" completed the ",color:"yellow"},{nbt:"temp.set_meta.name",storage:"evercraft:lore",color:"green"},{text:" lore set!",color:"yellow"}]
data modify storage evercraft:notify stage.c[0].text set from storage evercraft:notify named.who
scoreboard players set #ndur ec.temp 50
execute as @a run scoreboard players set #nttl ec.temp 600
execute as @a run function evercraft:util/notify/emit_keep
