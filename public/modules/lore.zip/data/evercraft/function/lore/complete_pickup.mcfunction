# Lore Discovery: Pickup complete — award collectible piece
# Run as player, at player position

# Hide boss bar and reset state
bossbar set evercraft:lore_pickup visible false
scoreboard players set @s ec.lore_picking 0
scoreboard players set @s ec.lore_progress 0

# Despawn the sparkle THIS player claimed (race #48 W1). Restrict to ec.lore_claimed and take
# the nearest such marker: the claim is 1:1 with a marker, the player channeled within 5 blocks
# of THEIR claimed sparkle, and any other player's claimed sparkle is a different, farther marker
# — so the nearest claimed marker is this player's own. This also fixes the old wrong-sparkle
# despawn (the bare distance=..8,sort=nearest could despawn an un-channeled neighbor).
# despawn_sparkle kills the marker, which clears its claim along with it.
execute as @e[type=marker,tag=ec.lore_data,tag=ec.lore_claimed,distance=..8,limit=1,sort=nearest] at @s run function evercraft:lore/despawn_sparkle

# Roll for collectible piece and give to player
# Convergence sparkles use a dedicated roll (forced to convergence lore set)
scoreboard players set #conv_lore ec.temp 0
execute if entity @s[tag=ec.conv_pickup] run scoreboard players set #conv_lore ec.temp 1
execute if entity @s[tag=ec.conv_pickup] run tag @s remove ec.conv_pickup
execute if score #conv_lore ec.temp matches 1 run function evercraft:convergence/roll_piece
execute if score #conv_lore ec.temp matches 0 run function evercraft:lore/roll/pick_piece

# The Gatherer's Path — Wave F (§7): celebratory by-rarity boost to every advantage tree +
# every craft & combat affinity. Rarity (ec.lore_rarity 1..6) is now set by pick_piece_from_set.
# Guard on a valid rarity in case a path left it unset. Adds the "Ancient Insight" summary line.
execute if score @s ec.lore_rarity matches 1.. run function evercraft:lore/gather_path_boost

# Completion effects — the world-pickup path's fragment reveal (channel-gated FX preset).
# Replaces the old ungated resonate + experience_orb.pickup + end_rod cue. Off/Reduced/Full/Cracked.
execute at @s run function evercraft:fx/collect/lore_piece

# Award XP for collecting
experience add @s 3 points

# 1/3000 chance for Collector's Dream Relic (permanent +1 dream rate)
execute unless score @s ec.dream_relic_count matches 1.. store result score #dream_roll ec.temp run random value 1..3000
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute unless score @s ec.dream_relic_count matches 1.. if score #dream_roll ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:items/collectors_dream_relic
execute unless score @s ec.dream_relic_count matches 1.. if score #dream_roll ec.temp matches 1 at @s if score #inv_full ec.var matches 1 run loot spawn ~ ~ ~ loot evercraft:items/collectors_dream_relic
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"A ",color:"yellow"},{text:"Collector's Dream Relic",color:"light_purple",bold:true},{text:" resonates within the fragments!",color:"yellow"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
execute unless score @s ec.dream_relic_count matches 1.. if score #dream_roll ec.temp matches 1 run function evercraft:util/notify/emit

# 1/50 chance for a bonus crate
execute store result score #lore_crate ec.temp run random value 1..50
execute if score #lore_crate ec.temp matches 1 store result score #inv_full ec.var run function evercraft:util/check_inv_full
execute if score #lore_crate ec.temp matches 1 if score #inv_full ec.var matches 0 run loot give @s loot evercraft:cooking/bonus_crate
execute if score #lore_crate ec.temp matches 1 if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:cooking/bonus_crate
data modify storage evercraft:notify stage.c set value [{text:"A crate was hidden among the fragments!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #lore_crate ec.temp matches 1 run function evercraft:util/notify/emit
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your crate was dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #lore_crate ec.temp matches 1 if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit
execute if score #lore_crate ec.temp matches 1 if score #inv_full ec.var matches 1 if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass player @s ~ ~ ~ 1 0.5

# Track for achievements
scoreboard players add @s ach.lore_found 1

# Notify player
data modify storage evercraft:notify stage.c set value [{text:"You found a lore fragment!",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# The G-MAJOR lore "discovery lift" (lore-FX identity pass, 2026-06-09 — completing a lore pickup
# previously had NO success sound at all; the channel just ended). Breathy flute + harp with a bell
# glint, in one of THREE randomized voicings: wonder, not fanfare. G major: G4 1.059 / B4 1.335 /
# D5 1.587. #fx_voice scratch, local to this file.
execute if score @s ec.fx_snd matches 1.. store result score #fx_voice ec.temp run random value 1..3
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 1 run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 1.059
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 1 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.45 1.335
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 1 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.3 1.587
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 2 run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 1.335
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 2 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.45 1.587
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 2 run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.3 1.587
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 3 run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.6 1.059
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 3 run playsound minecraft:block.note_block.harp master @s ~ ~ ~ 0.45 1.587
execute if score @s ec.fx_snd matches 1.. if score #fx_voice ec.temp matches 3 run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.3 1.335
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.0

# Guild Diplomacy Event: Lore Discovery scoring (activity 8)
execute if score #gd_event_active ec.var matches 1 if score #gd_event_activity ec.var matches 8 if score @s ec.gd_event_active matches 1 run scoreboard players add @s ec.gd_event_score 1
