# Lore Discovery: Release the claim on THIS player's pinned sparkle (race #48 W1, macro)
# Called with storage evercraft:lore {cx:X, cy:Y, cz:Z} — the channel coords stored at
# start_pickup (ec.lore_sx/sy/sz). Coord-pin mirrors gather/release_claims: we clear
# ec.lore_claimed ONLY on the marker the cancelling player owned, never another player's
# concurrently-claimed sparkle. distance=..2 covers the <1-block gap between the integer-
# truncated stored coords and the marker's fractional Pos. Idempotent: a no-op if the
# marker is already gone (lifetime despawn) or never claimed.
$execute positioned $(cx) $(cy) $(cz) run tag @e[type=marker,tag=ec.lore_data,tag=ec.lore_claimed,distance=..2,limit=1,sort=nearest] remove ec.lore_claimed
