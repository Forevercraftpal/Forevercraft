# Lore "Ancient Insight" toast — the all-crafts/disciplines XP-boost summary line.
# Run as @s (the player). Called by lore/gather_path_boost ONLY when the rate-limit gate passes
# (once per login/reload via ec.lore_ins_seen + 15 lifetime cap via ec.lore_ins_cnt).
# Emits the toast, marks it shown this session, then ticks the lifetime counter.
data modify storage evercraft:notify stage.c set value [{text:"✦ ",color:"gold"},{text:"Ancient Insight",color:"light_purple",bold:true},{text:" — this fragment sharpens ",color:"gray"},{text:"every",color:"white",italic:true},{text:" craft and discipline you pursue.",color:"gray"},{text:" ✦",color:"gold"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
scoreboard players set @s ec.lore_ins_seen 1
scoreboard players add @s ec.lore_ins_cnt 1
