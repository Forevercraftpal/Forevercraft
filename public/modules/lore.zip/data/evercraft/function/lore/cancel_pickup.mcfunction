# Lore Discovery: Cancel active pickup (moved too far)
# Run as player

data modify storage evercraft:chanbar bar set value "lore_pickup"
execute store result storage evercraft:chanbar id int 1 run scoreboard players get @s ec.chanbar_id
function evercraft:bossbar/chanbar/op_hide with storage evercraft:chanbar
scoreboard players set @s ec.lore_picking 0
scoreboard players set @s ec.lore_progress 0

# Free the claim on the pinned sparkle so an abandoned pickup is re-claimable (race #48 W1).
# Coord-pin to the stored channel coords so we release only THIS player's claimed marker.
execute store result storage evercraft:lore cx int 1 run scoreboard players get @s ec.lore_sx
execute store result storage evercraft:lore cy int 1 run scoreboard players get @s ec.lore_sy
execute store result storage evercraft:lore cz int 1 run scoreboard players get @s ec.lore_sz
function evercraft:lore/release_claim with storage evercraft:lore
data modify storage evercraft:notify stage.c set value [{text:"You moved too far away...",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.break master @s ~ ~ ~ 0.4 0.6
