# Lore Roll: Set #lr_owned ec.var = 1 if the player already collected this set/piece (macro)
# Called: function evercraft:lore/roll/check_owned with storage evercraft:lore temp   {rr_set, rr_piece}
scoreboard players set #lr_owned ec.var 0
$execute if entity @s[advancements={evercraft:lore/collected/s$(rr_set)/p$(rr_piece)=true}] run scoreboard players set #lr_owned ec.var 1
