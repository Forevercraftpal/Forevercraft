# Lore Roll: Loreroll — if the rolled piece is already collected, reroll the chain once
# Run as: player, at player. Uses ec.lore_set_id / ec.lore_piece_id (set by pick_set + pick_piece_from_set).
# Single reroll only — the re-picked result is kept whether or not it's also a duplicate.

# Check ownership of the current roll via its collected-advancement
execute store result storage evercraft:lore temp.rr_set int 1 run scoreboard players get @s ec.lore_set_id
execute store result storage evercraft:lore temp.rr_piece int 1 run scoreboard players get @s ec.lore_piece_id
function evercraft:lore/roll/check_owned with storage evercraft:lore temp

# Not a duplicate -> keep the original roll
execute if score #lr_owned ec.var matches 0 run return 0

# Duplicate -> reroll once: re-pick category, set, and piece (dimension/biome/structure context is unchanged)
function evercraft:lore/roll/pick_category
function evercraft:lore/roll/pick_set
function evercraft:lore/roll/pick_piece_from_set
