# The Gatherer's Path — Wave F (§7): lore-pickup celebratory boost
# Run as: @s (the player who picked up the lore fragment), at player position.
# Called from evercraft:lore/complete_pickup AFTER the piece roll (ec.lore_rarity is 1..6),
# gated by `if score @s ec.lore_rarity matches 1..`.
#
# A small, by-rarity, celebratory boost to EVERY advantage tree + every ALREADY-AWAKENED craft &
# combat affinity. Rarity -> boost (EPIC §7): common·uncommon (1,2) -> 1; rare·ornate (3,4) -> 2;
# exquisite·mythical (5,6) -> 3.
#
# AWAKENED-ONLY (Joseph 2026-06-04): picking up lore does NOT awaken an un-awakened class, and it is
# NOT banked. The by-rarity boost is granted to each craft/combat class ONLY IF that class is already
# awakened (its seen-bit is set); an un-awakened class's share is simply skipped (no running total,
# no awaken-dump). Advantage trees never awaken, so they keep getting the full boost unconditionally.
#
# CLOBBER NOTE: the craft/combat internal_grant calls below each run update_stage, which churns
# nearly every #...ec.temp fakeplayer (#aff_total, #old_stage, #new_stage, #new_boost, #delta,
# #tcred, #20, #caff_old). So the boost is parked in #lore_boost ec.var — a holder NO other
# function writes — and the per-grant #delta ec.temp is (re)set IMMEDIATELY before each
# internal_grant from #lore_boost. Never read #...ec.temp across a grant call. The awakened-check
# below uses #lore_aw ec.temp (set fresh per class, never read across a grant).

# 1. Map rarity (1..6) -> boost (1/2/3), parked in the survives-everything holder #lore_boost ec.var.
scoreboard players set #lore_boost ec.var 1
execute if score @s ec.lore_rarity matches 3..4 run scoreboard players set #lore_boost ec.var 2
execute if score @s ec.lore_rarity matches 5..6 run scoreboard players set #lore_boost ec.var 3

# 2. 15 advantage trees — via the canonical grant_tree_credit (per-tree credit = mult * factor / 20).
# Set the factor from the boost, then fan out. Beastmaster (#mult_beastmaster=1) yields 1*factor/20=0
# by integer floor — INTENTIONAL (its adv.stat_pets100 is a discrete maxed-pet count; flooring to 1
# would gift a free maxed pet). Left untouched; the celebratory summary line never enumerates trees.
# Trees do NOT awaken — they ALWAYS receive the boost (unchanged by the lore-limbo feature).
scoreboard players operation #adv_credit_num ec.var = #lore_boost ec.var
function evercraft:advantage/grant_tree_credit

# 3. 6 craft affinities (ec.caff_class 1..6) -> internal_grant, ONLY IF that class is already
# AWAKENED (its bit is set in ec.caff_seen: ss=1 lf=2 gs=4 tw=8 sc=16 lm=32). An un-awakened class
# is SKIPPED — its share is simply dropped (no banking; the class earns lore boosts only once it has
# awakened through tool use).
# #delta ec.temp is set fresh from #lore_boost ec.var before each call, so update_stage's ec.temp
# churn cannot stale it. Celebratory XP -> do NOT set #caff_node (keeps the normal spirit-bypass /
# daily-cap behaviour). Awakened-check = (caff_seen / bit) % 2 == 1 (mirrors first_xp_check).
# Per-class bit divisor held in #lore_cbit_<N> ec.var (load constants).
scoreboard players set @s ec.caff_class 1
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.caff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_cbit_1 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:craft_affinity/internal_grant
scoreboard players set @s ec.caff_class 2
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.caff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_cbit_2 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:craft_affinity/internal_grant
scoreboard players set @s ec.caff_class 3
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.caff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_cbit_3 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:craft_affinity/internal_grant
scoreboard players set @s ec.caff_class 4
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.caff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_cbit_4 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:craft_affinity/internal_grant
scoreboard players set @s ec.caff_class 5
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.caff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_cbit_5 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:craft_affinity/internal_grant
scoreboard players set @s ec.caff_class 6
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.caff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_cbit_6 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:craft_affinity/internal_grant

# 4. 14 combat affinities (ec.aff_class 1..14) -> internal_grant, ONLY IF that class is already
# AWAKENED (its bit is set in ec.aff_seen, bit per class 1<<0..1<<13). Same skip-if-un-awakened
# rule; an un-awakened combat class's share is simply dropped (no banking, no awaken-dump).
# Fresh #delta per call. The bit divisor for class N is 2^(N-1), held in #lore_abit_<N> ec.var.
scoreboard players set @s ec.aff_class 1
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_1 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 2
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_2 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 3
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_3 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 4
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_4 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 5
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_5 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 6
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_6 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 7
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_7 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 8
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_8 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 9
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_9 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 10
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_10 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 11
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_11 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 12
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_12 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 13
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_13 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant
scoreboard players set @s ec.aff_class 14
scoreboard players set #lore_aw ec.temp 0
scoreboard players operation #lore_aw ec.temp = @s ec.aff_seen
scoreboard players operation #lore_aw ec.temp /= #lore_abit_14 ec.var
scoreboard players operation #lore_aw ec.temp %= #lore_2 ec.var
execute if score #lore_aw ec.temp matches 1 run scoreboard players operation #delta ec.temp = #lore_boost ec.var
execute if score #lore_aw ec.temp matches 1 run function evercraft:affinity/internal_grant

# 5. ONE celebratory summary line (lore seat L8, verbatim). Law-approved "Ancient" (never "magic").
# Additive — does NOT replace complete_pickup's existing "[Lore] You found a lore fragment!" line.
# Rate-limited (2026-06-03 Joseph): the XP boost above ALWAYS applies, but this toast is anti-spam
# gated — at most ONCE per login/reload (ec.lore_ins_seen, reset in dreams/on_join + lore/load) and
# at most 15 times in a player's lifetime (ec.lore_ins_cnt), then it stops permanently.
execute if score @s ec.lore_ins_seen matches 0 if score @s ec.lore_ins_cnt matches ..14 run function evercraft:lore/insight_notify
