# Lore Resync: Periodic re-sync of set counters (self-scheduling, every 5 min)
# Recounts all ec.ls_N scoreboards from advancements to fix any drift

execute as @a run function evercraft:lore/resync/resync_all

# Silently sentinel any ALREADY-complete lore set so the loud passive scanner
# (milestones/lore/check_all_passive, 60s) never re-announces a pre-existing completion as a fresh
# "Lore set complete!" pop. Root cause (Joseph 2026-06-05): lore-set advancements are pickup-only,
# so resync rebuilds completion state faithfully — but if a complete set lacks its notif/lore/<id>_1
# sentinel (e.g. it was granted before the notif system, or the sentinel was wiped on a Pioneer
# death while the score/advancements were rebuilt), the loud scanner surfaces it every cycle, and
# the symptom tracks THIS 10-min resync cadence with different sets each time. PRIME mode (#ms_prime=1)
# makes milestones/lore/check_one GRANT the sentinel directly with NO notify; #ms_scan_only=1 skips
# the claim accumulator. Genuinely-fresh completions are unaffected — the 60s passive scanner fires
# (loud) long before this 10-min resync, so it still announces real new completions first.
scoreboard players set #ms_prime ec.temp 1
scoreboard players set #ms_scan_only ec.temp 1
execute as @a[tag=ec.joined] run function evercraft:milestones/lore/check_all
scoreboard players set #ms_prime ec.temp 0
scoreboard players set #ms_scan_only ec.temp 0

schedule function evercraft:lore/resync/tick 12000t replace
