# Lore Resync: Recount pieces for one set from advancements (macro)
# Args: {id:N} where N is the set number
# Run as: player
# Rebuilds ec.ls_N by counting actual advancements (source of truth)

$scoreboard players set @s ec.ls_$(id) 0
$execute if entity @s[advancements={evercraft:lore/collected/s$(id)/p1=true}] run scoreboard players add @s ec.ls_$(id) 1
$execute if entity @s[advancements={evercraft:lore/collected/s$(id)/p2=true}] run scoreboard players add @s ec.ls_$(id) 1
$execute if entity @s[advancements={evercraft:lore/collected/s$(id)/p3=true}] run scoreboard players add @s ec.ls_$(id) 1
$execute if entity @s[advancements={evercraft:lore/collected/s$(id)/p4=true}] run scoreboard players add @s ec.ls_$(id) 1
$execute if entity @s[advancements={evercraft:lore/collected/s$(id)/p5=true}] run scoreboard players add @s ec.ls_$(id) 1
$execute if entity @s[advancements={evercraft:lore/collected/s$(id)/p6=true}] run scoreboard players add @s ec.ls_$(id) 1
$execute if entity @s[advancements={evercraft:lore/collected/s$(id)/p7=true}] run scoreboard players add @s ec.ls_$(id) 1
$execute if entity @s[advancements={evercraft:lore/collected/s$(id)/p8=true}] run scoreboard players add @s ec.ls_$(id) 1
