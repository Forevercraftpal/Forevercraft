# === LORE DISCOVERY SYSTEM ===
# Initialize scoreboards, boss bar, and start scheduled loops

# --- Core spawning scoreboards ---
scoreboard objectives add ec.lore_timer dummy "Lore Spawn Timer"
scoreboard objectives add ec.lore_lastx dummy "Lore Last X"
scoreboard objectives add ec.lore_lastz dummy "Lore Last Z"
scoreboard objectives add ec.lore_moving dummy "Lore Moving Flag"

# --- Pickup mechanic scoreboards ---
scoreboard objectives add ec.lore_picking dummy "Lore Pickup Active"
scoreboard objectives add ec.lore_progress dummy "Lore Pickup Progress"
scoreboard objectives add ec.lore_sx dummy "Lore Sparkle X"
scoreboard objectives add ec.lore_sy dummy "Lore Sparkle Y"
scoreboard objectives add ec.lore_sz dummy "Lore Sparkle Z"

# --- Collection system scoreboards ---
scoreboard objectives add ec.lore_add trigger "Add Lore"
scoreboard objectives add ec.lore_dim dummy "Lore Dimension"
scoreboard objectives add ec.lore_cat dummy "Lore Category"
scoreboard objectives add ec.lore_set_id dummy "Lore Set ID"
scoreboard objectives add ec.lore_piece_id dummy "Lore Piece ID"
scoreboard objectives add ec.lore_struct_id dummy "Lore Structure ID"
scoreboard objectives add ec.lore_rarity dummy "Lore Rarity"
scoreboard objectives add ec.lore_set dummy "Lore Decoded Set"
scoreboard objectives add ec.lore_piece dummy "Lore Decoded Piece"
scoreboard objectives add ec.lore_sets_done dummy "Lore Sets Complete"
scoreboard objectives add ec.lore_dim0_done dummy "Lore Overworld Done"
scoreboard objectives add ec.lore_dim1_done dummy "Lore Nether Done"
scoreboard objectives add ec.lore_dim2_done dummy "Lore End Done"
scoreboard objectives add ec.lore_dim3_done dummy "Lore Pages Done"
scoreboard objectives add ec.lore_cached dummy "Lore Cached UID"
scoreboard objectives add ec.lore_map trigger "Lore Map"

# --- GUI scoreboards ---
scoreboard objectives add adv.gui_lore_dim dummy "Lore GUI Dim"
scoreboard objectives add adv.gui_lore_subcat dummy "Lore GUI Subcat"
scoreboard objectives add adv.gui_lore_set dummy "Lore GUI Set"
scoreboard objectives add adv.gui_lore_pg dummy "Lore GUI List Page"

# --- Lore Exchange scoreboards ---
scoreboard objectives add lx.count dummy "Lore Exchange Count"
scoreboard objectives add lx.tier dummy "Lore Exchange Tier"
scoreboard objectives add lx.required dummy "Lore Exchange Required"
scoreboard objectives add lx.reward dummy "Lore Exchange Reward"
scoreboard objectives add lx.temp dummy "Lore Exchange Temp"

# --- Auto-Convert + Loreroll (lore glowie rework) ---
# ec.lore_ex_total: running count of duplicate pieces exchanged into the codex (>=10 unlocks auto-convert)
scoreboard objectives add ec.lore_ex_total dummy "Lore Exchanged Total"
# ec.lore_ac_open: 1 once auto-convert is unlocked (gates the toggle + black-market lore sale)
scoreboard objectives add ec.lore_ac_open dummy "Auto-Convert Unlocked"
# ec.lore_autoconv: the player's auto-convert toggle (0/1)
scoreboard objectives add ec.lore_autoconv dummy "Auto-Convert Toggle"
# ec.lore_ac_count: number of duplicates auto-converted (>=50 unlocks loreroll)
scoreboard objectives add ec.lore_ac_count dummy "Auto-Convert Count"
# ec.loreroll: 1 once loreroll is unlocked (reroll is then always-on)
scoreboard objectives add ec.loreroll dummy "Loreroll Unlocked"

# --- Ancient Insight toast rate-limit (anti-spam, 2026-06-03 Joseph) ---
# The lore-pickup XP boost to every craft/discipline ALWAYS applies; only the celebratory toast
# (lore/insight_notify, called from gather_path_boost) is rate-limited.
# ec.lore_ins_seen: 1 once the toast has shown THIS session — reset per login (dreams/on_join) and
#   per /reload (below), so the toast appears at most once per login/reload.
# ec.lore_ins_cnt: lifetime count of toast showings; at 15 it stops permanently.
scoreboard objectives add ec.lore_ins_seen dummy "Lore Insight Seen"
scoreboard objectives add ec.lore_ins_cnt dummy "Lore Insight Count"
# On /reload: clear the session flag + seed the counter for everyone already online (one fresh
# showing per reload, like a login). `add 0` only seeds an unset score; it never resets the count.
scoreboard players set @a ec.lore_ins_seen 0
scoreboard players add @a ec.lore_ins_cnt 0

# --- Constants (ensure they exist) ---
scoreboard players set #5 ec.const 5
scoreboard players set #16 ec.const 16

# --- Awakened-check bit divisors (lore per-pickup boost, Joseph 2026-06-03; dump removed 2026-06-04) ---
# gather_path_boost grants lore-XP to a class ONLY IF that class is already awakened. "Awakened" is
# read from the per-system seen bitmask via (seen / bit) % 2 == 1. These hold the per-class bit
# divisor (2^(class-1)) so the check needs no recompute. #lore_2 is the modulo divisor.
# Read-only by lore/gather_path_boost. (There is no longer a banked total — an un-awakened class's
# share is simply skipped.)
scoreboard players set #lore_2 ec.var 2
# Craft (6 classes): ss=1 lf=2 gs=4 tw=8 sc=16 lm=32.
scoreboard players set #lore_cbit_1 ec.var 1
scoreboard players set #lore_cbit_2 ec.var 2
scoreboard players set #lore_cbit_3 ec.var 4
scoreboard players set #lore_cbit_4 ec.var 8
scoreboard players set #lore_cbit_5 ec.var 16
scoreboard players set #lore_cbit_6 ec.var 32
# Combat (14 classes): 2^(class-1), 1 .. 8192.
scoreboard players set #lore_abit_1 ec.var 1
scoreboard players set #lore_abit_2 ec.var 2
scoreboard players set #lore_abit_3 ec.var 4
scoreboard players set #lore_abit_4 ec.var 8
scoreboard players set #lore_abit_5 ec.var 16
scoreboard players set #lore_abit_6 ec.var 32
scoreboard players set #lore_abit_7 ec.var 64
scoreboard players set #lore_abit_8 ec.var 128
scoreboard players set #lore_abit_9 ec.var 256
scoreboard players set #lore_abit_10 ec.var 512
scoreboard players set #lore_abit_11 ec.var 1024
scoreboard players set #lore_abit_12 ec.var 2048
scoreboard players set #lore_abit_13 ec.var 4096
scoreboard players set #lore_abit_14 ec.var 8192

# Enable trigger for all players
scoreboard players enable @a ec.lore_add

# --- Boss bar for pickup progress ---
# evercraft:lore_pickup is now a PER-PLAYER bar pool (WA62-CHANNEL-BAR, 2026-06-22):
# each channeler drives their own evercraft:lore_pickup.<id> (see bossbar/chanbar/), so
# there is no shared global bar to create here. The id is allocated lazily on first open.

# --- Load set data, pools, and per-set scoreboards ---
function evercraft:lore/data/load_sets
function evercraft:lore/data/load_pools
function evercraft:lore/data/load_scoreboards

# --- Start scheduled loops ---
schedule function evercraft:lore/tick_spawn 1s
schedule function evercraft:lore/tick_particles 10t
schedule function evercraft:lore/tick_despawn 100t
# First resync runs ~10s after load (was 12000t/10min) so the silent sentinel-sync inside it clears
# any stale complete-without-sentinel lore sets right after a /reload instead of up to 10 min later
# (Joseph 2026-06-05). resync/tick self-schedules the recurring pass at 12000t afterward.
schedule function evercraft:lore/resync/tick 200t replace
