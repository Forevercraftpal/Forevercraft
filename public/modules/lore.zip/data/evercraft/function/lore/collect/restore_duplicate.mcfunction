# Lore Collect: Restore consumed physical item (it was a duplicate)
# Item was destroyed by consumption — give it back via loot table
# Inv-full guard: drop at the player's feet rather than void on a full inventory.
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full
$execute if score #inv_full ec.var matches 0 run loot give @s loot evercraft:lore/sets/s$(set_idx)/p$(piece_idx)
$execute if score #inv_full ec.var matches 1 at @s run loot spawn ~ ~ ~ loot evercraft:lore/sets/s$(set_idx)/p$(piece_idx)
data modify storage evercraft:notify stage.c set value [{text:"Already collected!",color:"yellow"},{text:" Trade it to another player instead.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.5
