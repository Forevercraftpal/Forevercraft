# Lore Collect: Check loreroll unlock (>=50 auto-converts)
# Run as: player

execute if score @s ec.loreroll matches 1.. run return 0
execute unless score @s ec.lore_ac_count matches 50.. run return 0

# === UNLOCK LOREROLL ===
scoreboard players set @s ec.loreroll 1
advancement grant @s only evercraft:lore/loreroll

# Fanfare — a grand one-time unlock milestone (50 lore collected), routed through the set-complete
# reveal preset (channel-gated). Replaces the old ungated ui.toast + levelup + totem cue.
execute at @s run function evercraft:fx/collect/lore_set_complete
# (AB-1 sticky-times sweep 2026-06-10: explicit stamp — `title times` is sticky per player and this sequence set none, so it inherited whatever ran last.)
title @s times 10 60 20
title @s subtitle {text:"Duplicate lore now rerolls once automatically",color:"yellow"}
title @s title {text:"Loreroll",color:"gold"}
data modify storage evercraft:notify stage.c set value [{text:"LOREROLL UNLOCKED! ",color:"gold",bold:true},{text:"Any duplicate lore you collect now automatically rerolls once for a chance at something new.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
