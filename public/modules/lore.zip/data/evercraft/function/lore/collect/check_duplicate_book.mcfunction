# Lore Collect: Check if book piece is already collected (macro)
# Duplicate + Auto-Convert ON: consume the book -> Lore Shards.
# Duplicate + Auto-Convert OFF: notify (book stays in inventory for trading).
# New: add to collection.
$execute if entity @s[advancements={evercraft:lore/collected/s$(set_idx)/p$(piece_idx)=true}] if score @s ec.lore_autoconv matches 1.. run return run function evercraft:lore/collect/auto_convert_book with storage evercraft:lore temp
$execute if entity @s[advancements={evercraft:lore/collected/s$(set_idx)/p$(piece_idx)=true}] run return run function evercraft:lore/collect/notify_duplicate
function evercraft:lore/collect/add_piece_book with storage evercraft:lore temp
