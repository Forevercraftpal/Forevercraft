# Lore Collect: Add book piece to collection (macro)
# Remove the book from inventory, grant advancement, update counter
$clear @s written_book[custom_data~{lore_uid:$(uid)}] 1
$advancement grant @s only evercraft:lore/collected/s$(set_idx)/p$(piece_idx)

# Increment set counter
function evercraft:lore/collect/increment_set with storage evercraft:lore temp

data modify storage evercraft:notify stage.c set value [{text:"Fragment added to your collection!",color:"green"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Fragment-added reveal — channel-gated (Off/Reduced/Full/Cracked). One-shot.
execute at @s run function evercraft:fx/collect/lore_piece

# Check set completion
function evercraft:lore/collect/check_complete with storage evercraft:lore temp
