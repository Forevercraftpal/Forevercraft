# Lore Collect: Auto-convert a duplicate BOOK piece into Lore Shards (macro)
# Called: function evercraft:lore/collect/auto_convert_book with storage evercraft:lore temp   {uid, set_idx, piece_idx}
# Consume the exact duplicate book by UID, then grant shards.
$clear @s written_book[custom_data~{lore_uid:$(uid)}] 1
function evercraft:lore/collect/auto_convert with storage evercraft:lore temp
