# Lore Collect: Notify player this piece is already collected
data modify storage evercraft:notify stage.c set value [{text:"Already collected!",color:"yellow"},{text:" Trade it to another player instead.",color:"gray",italic:true}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.5
