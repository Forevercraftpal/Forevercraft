# Lore Collect: Give N Lore Shards (macro)
# Called: function evercraft:lore/collect/grant_shards with storage evercraft:lore temp   {shards}
# Run as: the player.

# Inv-full check BEFORE the give so we know whether the shards will feet-drop. `give` is
# safe-by-vanilla (overflow drops at the player's feet, never voided) — we add the matching
# "dropped at your feet" notify the sibling reward paths emit (complete_pickup:51-53).
execute store result score #inv_full ec.var run function evercraft:util/check_inv_full

$give @s minecraft:echo_shard[minecraft:custom_name={text:"Lore Shard",color:"yellow",italic:false},minecraft:enchantment_glint_override=true,minecraft:custom_data={lore_shard:true}] $(shards)

# Full inventory → notify the player the shards landed at their feet.
data modify storage evercraft:notify stage.c set value [{text:"Inventory full! Your Lore Shard(s) were dropped at your feet.",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
execute if score #inv_full ec.var matches 1 run function evercraft:util/notify/emit
