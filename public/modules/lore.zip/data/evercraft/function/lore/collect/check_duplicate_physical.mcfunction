# Lore Collect: Check if physical piece is already collected (macro)
# Duplicate + Auto-Convert ON: grant Lore Shards instead of restoring the item.
# Duplicate + Auto-Convert OFF: restore the consumed item + notify.
# New: add to collection.
$execute if entity @s[advancements={evercraft:lore/collected/s$(set_idx)/p$(piece_idx)=true}] if score @s ec.lore_autoconv matches 1.. run return run function evercraft:lore/collect/auto_convert with storage evercraft:lore temp
$execute if entity @s[advancements={evercraft:lore/collected/s$(set_idx)/p$(piece_idx)=true}] run return run function evercraft:lore/collect/restore_duplicate with storage evercraft:lore temp
function evercraft:lore/collect/add_piece_physical with storage evercraft:lore temp
