# Lore Collect: Auto-convert a duplicate piece into Lore Shards (macro)
# Called: function evercraft:lore/collect/auto_convert with storage evercraft:lore temp   {set_idx, piece_idx}
# Caller must have already verified ec.lore_autoconv>=1 and consumed/removed the item.

# Look up rarity (1-6) from set metadata
$execute store result score #ac_rarity ec.temp run data get storage evercraft:lore sets.s$(set_idx).rarity

# rarity -> shard count (mirrors lx.reward: common/uncommon/rare ->1, ornate ->2, exquisite ->3, mythical ->4)
scoreboard players set #ac_shards ec.temp 1
execute if score #ac_rarity ec.temp matches 4 run scoreboard players set #ac_shards ec.temp 2
execute if score #ac_rarity ec.temp matches 5 run scoreboard players set #ac_shards ec.temp 3
execute if score #ac_rarity ec.temp matches 6 run scoreboard players set #ac_shards ec.temp 4

# Grant the shards
execute store result storage evercraft:lore temp.shards int 1 run scoreboard players get #ac_shards ec.temp
function evercraft:lore/collect/grant_shards with storage evercraft:lore temp

# Count this auto-convert (feeds the loreroll milestone) + feedback
scoreboard players add @s ec.lore_ac_count 1
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.5 1.5
particle minecraft:enchant ~ ~1 ~ 0.2 0.3 0.2 0.4 6
data modify storage evercraft:notify stage.c set value [{text:"Duplicate auto-converted: ",color:"gray"},{text:"+",color:"yellow"},{score:{name:"#ac_shards",objective:"ec.temp"},color:"yellow",bold:true},{text:" Lore Shard(s)",color:"yellow"}]
scoreboard players set #ndur ec.temp 45
function evercraft:util/notify/emit

# Loreroll milestone check (>=50 auto-converts)
function evercraft:lore/collect/check_loreroll
