# Lore Discovery: Begin 3-second pickup progress
# Run as the player who clicked, at player position

# If already picking up another sparkle, ignore
execute if score @s ec.lore_picking matches 1 run return 0

# --- Claim-lock (race #48 W1): port of gather/claim_node_pinned test-then-set ---
# Only START a pickup if there is an UNCLAIMED sparkle within range. Two players who
# converge on the same sparkle each select the nearest UNCLAIMED marker; the first to run
# (MC serial-within-tick) stamps it ec.lore_claimed, so the second finds it claimed and,
# with no other unclaimed sparkle in range, starts no channel at all (no double-grant).
# The claim persists across ticks until complete_pickup / cancel_pickup / despawn frees it,
# so a STAGGERED second starter is also locked out (the staggered-dupe the existence guard
# at progress_step:22 could not close).
execute unless entity @e[type=marker,tag=ec.lore_data,tag=!ec.lore_claimed,distance=..5,limit=1,sort=nearest] run return 0

# Mark player as picking up
scoreboard players set @s ec.lore_picking 1
scoreboard players set @s ec.lore_progress 0

# Store sparkle position (the nearest UNCLAIMED marker — the one we are about to claim)
# for range checking during pickup.
execute store result score @s ec.lore_sx run data get entity @e[type=marker,tag=ec.lore_data,tag=!ec.lore_claimed,distance=..5,limit=1,sort=nearest] Pos[0] 1
execute store result score @s ec.lore_sy run data get entity @e[type=marker,tag=ec.lore_data,tag=!ec.lore_claimed,distance=..5,limit=1,sort=nearest] Pos[1] 1
execute store result score @s ec.lore_sz run data get entity @e[type=marker,tag=ec.lore_data,tag=!ec.lore_claimed,distance=..5,limit=1,sort=nearest] Pos[2] 1

# Stamp the claim on THAT exact marker (same nearest-unclaimed selector). After this line the
# marker is owned; another player's start_pickup will not select it.
tag @e[type=marker,tag=ec.lore_data,tag=!ec.lore_claimed,distance=..5,limit=1,sort=nearest] add ec.lore_claimed

# Show boss bar
function evercraft:bossbar/chanbar/ensure
data modify storage evercraft:chanbar bar set value "lore_pickup"
data modify storage evercraft:chanbar val set value 0
execute store result storage evercraft:chanbar id int 1 run scoreboard players get @s ec.chanbar_id
data modify storage evercraft:chanbar max set value 60
function evercraft:bossbar/chanbar/op_show with storage evercraft:chanbar
# Safety auto-dismiss: clear the bar if it lingers 30s (e.g. interrupted mid-collect by death).
schedule function evercraft:bossbar/autodismiss/clear/lore_pickup 15s replace

# Start sound — the kept amethyst shimmer (now channel-gated; was ungated) + the lore "instrument
# picks up" note (flute G4 — lore's family voice is G MAJOR, breathy flute + bell over the amethyst
# palette: ancient discovery — lore-FX identity pass, 2026-06-09).
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.6 0.8
execute if score @s ec.fx_snd matches 1.. run playsound minecraft:block.note_block.flute master @s ~ ~ ~ 0.4 1.059
