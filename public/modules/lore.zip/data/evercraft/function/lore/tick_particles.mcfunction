# Lore Discovery: Render sparkle particles (10-tick schedule)
schedule function evercraft:lore/tick_particles 10t

# Gate: skip if no players online
execute unless entity @a run return 0

# Gate: skip if no sparkles exist (cheap pre-gate, mirrors tick_despawn:5) — idle is the
# common state, so this avoids the limit=50 marker scan every 10t when no lore is spawned.
execute unless entity @e[type=marker,tag=ec.lore_data,limit=1] run return 0

# Only render for sparkles near players (performance optimization)
# OPT: Capped at 50 to prevent worst-case in heavily-explored worlds
execute as @e[type=marker,tag=ec.lore_data,limit=50] at @s if entity @a[distance=..48] run function evercraft:lore/render_sparkle
